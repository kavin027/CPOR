# CPOR Cov/ML results with matched outcome-domain comparison

Current Cov/ML-only manuscript attachment: CPOR_CovML_Results_Minor_20261024.zip.
Run `python check_results.py` in this directory. Python 3 with its standard library is sufficient. It checks file hashes and recomputes paired reductions, window aggregation, means/SDs, protection-cost ratios and levelwise effects. It then runs matched_envelope/check_aggregates.py for the new comparison. These commands check aggregate records; they do not retrain models or replay prediction caches.

Current manuscript mapping:
- Table 6 and Supplementary Tables S4–S5: GROUP_RUN_RMSE.csv and ALL_CELL_METRICS.csv.
- Table 7: RISK_SUMMARY.csv (numerical prefix-compliance counts).
- Figure 2, Table 8 and the new paired analyses: matched_envelope/README.md.
- Table 9: GROUP_RUN_RMSE.csv, classical and matched-target controls.
- Table 10: LEVEL_RUNS.csv; supplementary paired level effects use matched_envelope/analysis/.
- Table 11: timing_full/TIMING_SUMMARY.csv, generated from timing_full/ISSUE_TIMES.csv; timing_full/TIMING_BY_RUN.csv retains separate runs. TIMING_REPLAY.csv is historical and no longer feeds Table 11.
- Supplementary Table S7: GROUP_RUN_RMSE.csv, pairing CovFullFix/CovUnprotected and ProtectedMLPol/MLPol.
- Protocol: CONFIG_INDEX and ALL_FITTING_STAGES.csv. Updated DLinear fits supersede the historical training cap.

CovFullFix denotes CPOR-Cov; ProtectedMLPol denotes CPOR-ML. Original source names remain provenance identifiers. source_map.json identifies the relevant functions in archived_source; the imported project closure for the new experiment is in matched_envelope/source_closure. requirements_archived.txt records the numerical dependencies. Other historical entry points are not additional methods in the paper.

Public project: https://github.com/kavin027/CPOR. This ZIP is the current attachment; older repository bundles do not replace it. This revision reuses all old forecasts and controls, while adding the explicitly registered matched-envelope experiment. Inputs, outputs and the separate local rational audit are hash-identified. Observation/prediction NPZ caches and neural checkpoints are excluded. Replaying trajectories requires those inputs under their source access terms; the aggregate checker does not reproduce the exact protection audit. Contact: Lei Zhang, lei.zhang@cnu.edu.cn.

The current Table 11 timing evidence and replay source are under timing_full/. Its checker is invoked by the top-level command. Component timing requires no neural retraining; full numerical replay requires the hash-identified archived inputs.

See REPRODUCTION.md for three distinct verification levels and NUMERICAL_ENVIRONMENT.json for the timing environment. This minor revision changes terminology, navigation and one Figure 1 connector; it adds no experiments. MINOR_EVIDENCE_CHECK.json records the full-precision gain concentration and fitting-count checks.
