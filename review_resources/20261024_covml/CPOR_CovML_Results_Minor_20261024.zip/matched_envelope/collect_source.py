"""Archive the imported project source closure without running an experiment."""
from pathlib import Path
import sys,json,hashlib,shutil
import run_comparison as experiment

H=Path(__file__).resolve().parent;R=H.parents[1]
E=R/'output/cpor_cov_ml_20261024/evidence/matched_envelope'
D=E/'source_closure';D.mkdir(parents=True,exist_ok=True)
experiment.kernels('real')
paths={Path(__file__).resolve(),Path(experiment.__file__).resolve(),experiment.INDEX.resolve()}
for module in tuple(sys.modules.values()):
 p=getattr(module,'__file__',None)
 if p:
  p=Path(p).resolve()
  if p.is_file() and p.suffix=='.py' and p.is_relative_to(R) and '.runtime' not in p.parts:paths.add(p)
records=[]
for p in sorted(paths):
 rel=p.relative_to(R);dest=D/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 records.append(dict(path=rel.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(E/'SOURCE_CLOSURE.json').write_text(json.dumps(records,indent=2))
print(json.dumps({'files':len(records),'path':str(D)}))
