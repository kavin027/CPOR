from pathlib import Path
import sys,copy,json,hashlib
from types import SimpleNamespace
import numpy as np
import pandas as pd
import torch
from torch import nn

HERE=Path(__file__).resolve().parent;O=HERE.parent
AUTHOR=HERE/'author_source/PIR-fc372bb02090da887d4a20b614a6cfecbfd813d0'
sys.path.insert(0,str(O.parent/'.runtime/pir_dependencies'))
sys.path.insert(0,str(AUTHOR))
from models.PIR import Model as AuthorPIR
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

class CachedForecast(nn.Module):
    def forward(self,x_enc,*args):
        assert self.value.shape[0]==x_enc.shape[0]
        return self.value

class CachedPIR(AuthorPIR):
    def _build_model(self):self.model=CachedForecast()
    def bind(self,x,raw):
        # Author Model normalizes x before calling the frozen base.
        if self.use_norm:
            mean=x.mean(1,keepdim=True).detach();sd=torch.sqrt(x.var(1,keepdim=True,unbiased=False)+1e-5)
            self.model.value=(raw-mean)/sd
        else:self.model.value=raw

def config(n):
    return SimpleNamespace(seq_len=24,pred_len=1,enc_in=n,including_time_features=1,
        retrieval_stride=1,use_norm=1,refine_d_model=128,refine_d_ff=128,refine_layers=1,
        retrieval_num=10,factor=1,dropout=.1,output_attention=False,n_heads=4,activation='gelu',d_model=16)

def calendar(dates):
    d=pd.DatetimeIndex(dates)
    # utils.timefeatures.time_features(freq='t'): Minute, Hour, Weekday, Day, DayOfYear.
    return np.stack([d.minute/59-.5,d.hour/23-.5,d.dayofweek/6-.5,(d.day-1)/30-.5,(d.dayofyear-1)/365-.5],axis=-1).astype('float32')

def load(cell):
    ds,bb,w=cell;rel='/'.join(cell)+'/42';root=O/'rr_recap_evidence_extension_20261002'
    if ds=='Labour':root=root/'major_revision_20261002'
    cp=(root/('external/forecasts' if ds=='Labour' else 'forecasts')/rel/'raw.npz')
    hp=O/'rr_recap_trajectory_learning_20261003/inputs'/('/'.join(cell))/'train.npz'
    mp=hp.with_name('metadata.json');meta=json.loads(mp.read_text());h=dict(np.load(hp));x=dict(np.load(cp))
    assert sha(hp)==meta['output_sha256'];assert meta['last_training_date']<meta['first_scored_date']
    for p,v in meta['source_sha256'].items():assert sha(p)==v,p
    dp=next(Path(p) for p in meta['source_sha256'] if p.endswith('.csv'))
    wide=pd.read_csv(dp,parse_dates=['ds']).set_index('ds');values=wide.to_numpy(dtype='float64')
    start,end=int(meta['start']),int(meta['end']);assert end-start==len(h['raw'])
    np.testing.assert_array_equal(h['truth'],values[start:end]);np.testing.assert_array_equal(h['raw'][-36:],x['raw'][:36])
    np.testing.assert_array_equal(x['truth'][36:],values[end:end+72]);np.testing.assert_array_equal(h['S'],x['S'])
    train_end=end-36
    dropped=max(0,24-start);usable_start=start+dropped
    assert train_end>usable_start and train_end-24>=60
    mu=values[:train_end].mean(0);sd=values[:train_end].std(0);sd=np.where(sd>0,sd,1.)
    raw=np.concatenate([h['raw'],x['raw'][36:]])[dropped:];positions=np.arange(usable_start,end+72)
    contexts=np.stack([values[t-24:t] for t in positions]);encmark=np.stack([calendar(wide.index[t-24:t]) for t in positions])
    marks=calendar(wide.index[positions])[:,None,:]
    lib_positions=np.arange(24,train_end)
    lib_x=np.stack([values[t-24:t] for t in lib_positions])
    result=dict(x=((contexts-mu)/sd).astype('float32'),raw=((raw-mu)/sd)[:,None,:].astype('float32'),
        y=((values[positions]-mu)/sd)[:,None,:].astype('float32'),encmark=encmark,mark=marks,
        mu=mu,sd=sd,score_raw=x['raw'][36:],truth=x['truth'][36:],S=x['S'],
        lib_x=((lib_x-mu)/sd).astype('float32'),lib_y=((values[lib_positions]-mu)/sd)[:,None,:].astype('float32'),
        library_index=(positions-24).astype('int64'),library_last_label=str(wide.index[train_end-1]),
        train_count=len(h['raw'])-36-dropped,score_start=len(h['raw'])-dropped,dropped_initial_contexts=dropped,dates=wide.index[positions].astype(str).tolist(),
        inputs={str(p.resolve()):sha(p) for p in [cp,hp,mp,dp]})
    assert result['dates'][result['train_count']-1]<result['dates'][result['train_count']]
    return result

def tensors(data,device):
    return {k:torch.as_tensor(data[k],device=device) for k in ['x','raw','y','encmark','mark','lib_x','lib_y','library_index']}

def forward(model,t,ids,training=False):
    x=t['x'][ids];model.bind(x,t['raw'][ids]);dec=torch.zeros_like(t['raw'][ids])
    return model(x,t['encmark'][ids],dec,t['mark'][ids],t['library_index'][ids] if training else None,mode='refine')

def prepare(model,t,n=None):
    n=len(t['lib_x'])
    model.construct_index(n)
    with torch.no_grad():
        for first in range(0,n,32):
            ids=torch.arange(first,min(first+32,n),device=t['x'].device)
            model.add_key_value(t['lib_x'][ids],t['lib_y'][ids],ids)
    model.value_permute=model.values.permute(2,0,1)

def fit(model,t,train_count,score_start):
    prepare(model,t,train_count);opt=torch.optim.Adam(model.parameters(),lr=1e-4)
    rng=np.random.default_rng(42);best=float('inf');state=None;waiting=0;log=[]
    for epoch in range(10):
        model.train();losses=[];qualities=[]
        order=rng.permutation(train_count)
        for first in range(0,train_count,32):
            ids=torch.as_tensor(order[first:first+32],device=t['x'].device)
            opt.zero_grad();p,q=forward(model,t,ids,True)
            # Exact author loss; quality target is detached intermediate forecast MSE.
            target=(q[0]-t['y'][ids]).square().detach().permute(0,2,1).mean(-1,keepdim=True)
            loss=(p-t['y'][ids]).square().mean();quality=(q[1]-target).abs().mean()
            assert torch.isfinite(loss+quality);(loss+quality).backward();opt.step()
            losses.append(float(loss.detach()));qualities.append(float(quality.detach()))
        model.eval()
        with torch.no_grad():
            vl=[]
            for first in range(train_count,score_start,32):
                ids=torch.arange(first,min(first+32,score_start),device=t['x'].device)
                p,_=forward(model,t,ids);vl.append(float((p-t['y'][ids]).square().mean()))
        # Author validation averages loader-batch losses, including final partial batch.
        validation=float(np.mean(vl));log.append(dict(epoch=epoch+1,train_mse=float(np.mean(losses)),quality_l1=float(np.mean(qualities)),validation_mse=validation))
        if validation<best:
            best=validation;state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()};waiting=0
        else:waiting+=1
        if waiting>=3:break
        for group in opt.param_groups:group['lr']=1e-4*(.5**epoch)
    assert state is not None;model.load_state_dict(state);model.eval()
    return log,state
