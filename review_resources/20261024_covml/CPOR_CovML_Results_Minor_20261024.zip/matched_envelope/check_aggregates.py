"""Standard-library check of current matched and paired summaries; no cache replay."""
from pathlib import Path
import csv,json,statistics,math,collections
H=Path(__file__).resolve().parent;A=H/'analysis'
def rows(n):
 with (A/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def close(a,b):assert math.isclose(float(a),float(b),rel_tol=1e-10,abs_tol=1e-9),(a,b)
def groupkey(r):return tuple(r[k] for k in ['dataset','backbone','seed','scope','method'])
groups=collections.defaultdict(list)
for r in rows('LEVEL_CELL_METRICS.csv'):groups[groupkey(r)].append(float(r['rmse']))
g={groupkey(r):float(r['rmse']) for r in rows('LEVEL_GROUP_RUN.csv')}
assert len(g)==len(groups)
for k,vals in groups.items():
 assert len(vals)==(1 if k[0]=='Labour' else 2)
 close(g[k],statistics.mean(vals))
e=rows('ENVELOPE_GROUP_RUN.csv');assert len(e)==72
gs=collections.defaultdict(list);ex=collections.defaultdict(list);rl=collections.defaultdict(list)
for r in e:
 k=tuple(r[f] for f in ['dataset','backbone','seed']);m=r['implementation']
 close(r['exact_rmse'],g[k+('all',m)]);close(r['real_rmse'],g[k+('all',m+'Real')])
 close(r['gain_pct'],100*(1-float(r['exact_rmse'])/float(r['real_rmse'])))
 key=(k[0],k[1],m);gs[key].append(float(r['gain_pct']));ex[key].append(float(r['exact_rmse']));rl[key].append(float(r['real_rmse']))
for r in rows('ENVELOPE_GROUP.csv'):
 k=tuple(r[f] for f in ['dataset','backbone','implementation'])
 for field,value in [('gain',statistics.mean(gs[k])),('exact_mean',statistics.mean(ex[k])),('real_mean',statistics.mean(rl[k])),('exact_sd',statistics.stdev(ex[k])),('real_sd',statistics.stdev(rl[k]))]:close(r[field],value)
p=rows('PAIRED_GROUP_RUN.csv');assert len(p)==72
for r in p:
 k=tuple(r[f] for f in ['dataset','backbone','seed']);m=r['implementation']
 for field,name in [('rmse',m),('unprotected_rmse',m+'U'),('reference_rmse','NNLS')]:close(r[field],g[k+('all',name)])
 close(r['protection_cost_pct'],100*(float(r['rmse'])/float(r['unprotected_rmse'])-1))
 close(r['reference_gain_pct'],100*(1-float(r['rmse'])/float(r['reference_rmse'])))
for r in rows('PAIRED_DATASET.csv'):
 selected=[a for a in p if a['dataset']==r['dataset'] and a['implementation']==r['implementation']]
 assert len(selected)==6
 for field in ['protection_cost_pct','reference_gain_pct','unprotected_ever_pct','protected_ever_pct']:close(r[field],statistics.mean(float(a[field]) for a in selected))
for r in rows('PAIRED_LEVEL_RUN.csv'):
 k=tuple(r[f] for f in ['dataset','backbone','seed','scope']);m=r['implementation']
 close(r['reference_gain_pct'],100*(1-g[k+(m,)]/g[k+('NNLS',)]))
 close(r['protection_cost_pct'],100*(g[k+(m,)]/g[k+(m+'U',)]-1))
 close(r['envelope_gain_pct'],100*(1-g[k+(m,)]/g[k+(m+'Real',)]))
summary=json.loads((A/'SUMMARY.json').read_text());mech=rows('MECHANISM_CELLS.csv');assert len(mech)==132
for m in ['Cov','ML']:
 q=[r for r in e if r['implementation']==m];a=summary['envelope'][m];close(a['mean_gain'],statistics.mean(float(r['gain_pct']) for r in q))
 assert all(float(r['gain'])>0 for r in rows('ENVELOPE_GROUP.csv') if r['implementation']==m)
 mm=[r for r in mech if r['implementation']==m]
 assert all(r['replay_bitwise']=='True' for r in mm)
 assert sum(int(r['exact_audit.exact_node_checks']) for r in mm)==431568
 assert sum(int(r['real_audit.exact_node_checks']) for r in mm)==431568
 for field in ['same_state_objective_better','same_state_objective_worse_beyond_tolerance']:assert sum(int(r[field]) for r in mm)==a['same_state_objective_better' if field.endswith('better') else 'same_state_worse']
 for prefix in ['exact_audit','real_audit']:assert sum(int(r[prefix+'.exact_node_checks']) for r in mm)==431568
 risk=[r for r in rows('RISK_CELLS.csv') if r['method']==m+'Real'];assert len(risk)==66 and sum(int(r['ever']) for r in risk)==0
 nd=[r for r in rows('NODE_DISTRIBUTION.csv') if r['method']==m];assert len(nd)==36
audit=json.loads((H/'INDEPENDENT_AUDIT.json').read_text());assert audit['passed'] and audit['exact_envelope_and_prefix_node_checks']==1726272
print(json.dumps(dict(passed=True,online_trajectories=132,replayed_existing_trajectories=132,fixed_state_actions=9504,groups=12,runs=3,all_means_and_sd_checked=True,scope='Recomputed aggregate arithmetic and cross-file correspondence. Exact rational replay is separately documented by INDEPENDENT_AUDIT.json; not rerun by this checker.'),indent=2))
