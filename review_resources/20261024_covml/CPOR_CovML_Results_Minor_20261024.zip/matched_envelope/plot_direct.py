"""Direct paired protection effects from existing records; no new experiment."""
from pathlib import Path
import json,hashlib
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
H=Path(__file__).resolve().parent;P=H.parent/'cpor_cov_ml_20261024'
q=pd.read_csv(H/'analysis/PAIRED_GROUP_RUN.csv')
assert len(q)==72
q['recomputed_cost']=100*(q.rmse/q.unprotected_rmse-1)
np.testing.assert_allclose(q.recomputed_cost,q.protection_cost_pct,rtol=1e-12,atol=1e-12)
g=q.groupby(['dataset','implementation']).mean(numeric_only=True)
expected=pd.read_csv(H/'analysis/PAIRED_DATASET.csv').set_index(['dataset','implementation'])
for col in ['protection_cost_pct','unprotected_ever_pct','protected_ever_pct']:
 np.testing.assert_allclose(g[col],expected.loc[g.index,col],rtol=1e-12,atol=1e-12)
assert (g.protected_ever_pct==0).all()
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11.5,'axes.titlesize':12.5,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,(left,right)=plt.subplots(1,2,figsize=(10,5.5),sharey=True,gridspec_kw={'width_ratios':[1,1.15]})
fig.subplots_adjust(left=.12,right=.98,bottom=.18,top=.81,wspace=.17)
datasets=['RH','ECommerce','Traffic','Wiki2','Labour','M5']
styles=[('Cov','#b75912',-.16),('ML','#1b6ca8',.16)]
for i,ds in enumerate(datasets):
 for impl,color,dy in styles:
  r=g.loc[ds,impl];y=i+dy;before=r.unprotected_ever_pct;after=r.protected_ever_pct;cost=r.protection_cost_pct
  left.plot([after,before],[y,y],color=color,lw=1.8,zorder=2)
  left.scatter(before,y,s=47,facecolors='white',edgecolors=color,lw=1.5,zorder=4)
  left.scatter(after,y,s=40,facecolors=color,edgecolors='white',lw=.4,zorder=5)
  left.text(before+2,y,f'{before:.1f}%',va='center',fontsize=10,color=color)
  right.barh(y,cost,height=.25,color=color,alpha=.9,zorder=3)
  right.text(cost+(2.3 if cost>=0 else -2.3),y,f'{cost:+.2f}%',ha='left' if cost>=0 else 'right',va='center',fontsize=10,color=color)
left.set_yticks(range(6),datasets);left.set_ylim(5.55,-.55)
left.set_xlim(-4,112);left.set_xticks([0,25,50,75,100]);left.tick_params(axis='y',length=0,pad=8)
left.set_title('(a) Nodewise cumulative protection',loc='left',pad=14,fontweight='bold')
left.set_xlabel('Sequences with any prefix violation (%)',labelpad=10)
right.set_xlim(-88,170);right.set_xticks([-50,0,50,100,150]);right.tick_params(axis='y',length=0)
right.set_title('(b) Accuracy change from protection',loc='left',pad=14,fontweight='bold')
right.set_xlabel('RMSE change from unprotected forecasts (%)',labelpad=10,fontsize=10.5)
right.axvline(0,color='#555',lw=.9,zorder=2)
for ax in [left,right]:
 ax.grid(axis='x',alpha=.15,zorder=0)
 ax.spines['left'].set_visible(False)
 for y in np.arange(.5,5.5):ax.axhline(y,color='#ececec',lw=.7,zorder=0)
left.text(.0,-.20,'All protected violation rates: 0%',transform=left.transAxes,fontsize=10.5)
right.text(.0,-.20,'Negative: lower error     Positive: higher error',transform=right.transAxes,fontsize=10.5)
fig.legend(handles=[Patch(facecolor=styles[0][1],label='Cov'),Patch(facecolor=styles[1][1],label='ML'),Line2D([],[],marker='o',color='#555',markerfacecolor='white',label='Before protection (a)',ls=''),Line2D([],[],marker='o',color='#555',label='After protection (a)',ls='')],loc='upper center',bbox_to_anchor=(.54,.99),ncol=4,frameon=False,fontsize=10.5,handlelength=1.3,columnspacing=1.7)
for ext in ['pdf','svg','png']:
 dest=P/'artwork'/('Fig2_Protection_Tradeoffs.'+ext);fig.savefig(dest,dpi=220)
 if ext=='pdf':(P/'source/images'/dest.name).write_bytes(dest.read_bytes())
plt.close(fig)
audit={'input':str(H/'analysis/PAIRED_GROUP_RUN.csv'),'input_sha256':hashlib.sha256((H/'analysis/PAIRED_GROUP_RUN.csv').read_bytes()).hexdigest(),'new_experiments':0,'groups_per_dataset':6,'cost_definition':'100*(protected RMSE / unprotected RMSE - 1), paired after window averaging, then averaged across two backbones and three runs','data_match_existing_dataset_summary':True,'all_protected_violation_rates_zero':True,'axes':'Two aligned linear panels; same scales across all datasets','figure1_modified':False}
(P/'FIGURE2_DIRECT_AUDIT.json').write_text(json.dumps(audit,indent=2))
print(json.dumps(audit,indent=2))
