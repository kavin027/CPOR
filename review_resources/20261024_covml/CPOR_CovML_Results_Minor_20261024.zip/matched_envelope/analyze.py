from pathlib import Path
import json,hashlib,sys
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent;O=H.parent
E=O/'cpor_cov_ml_20261024/evidence'
idx=pd.read_csv(O/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv')
maps=pd.read_csv(O/'kais_review_v2_revision_20261017/Online_Resource_3/review_evidence/node_map.csv')
RR=(1.005)**2
KEY=['dataset','backbone','window','seed'];GR=['dataset','backbone','seed'];inputs={}
def load(p):
 inputs[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files if k not in ['dates','stats']}
cells=[];risk=[];nodes=[];mechanism=[]
for r in idx.to_dict('records'):
 d=Path(r['source']);x=load(d/'endpoints.npz');ctx=load(d/'contexts.npz');ctl=load(d/'controls.npz');cov=load(d/'CovFullFix.npz');y=x['truth'][36:];b=x['b'][36:]
 meta={k:r[k] for k in KEY};B=np.cumsum((b-y)**2,0)
 predictions={'Raw':x['raw'][36:],'NNLS':b,'CovU':ctx['D'][36:],'Cov':cov['pred'],'MLU':ctl['MLPol'],'ML':ctl['ProtectedMLPol']}
 dest=H/'runs'/r['dataset']/r['backbone']/r['window']/str(r['seed'])
 if (dest/'DONE.json').exists():
  done=json.loads((dest/'DONE.json').read_text())
  for a in done['records']:
   q=load(dest/(a['implementation']+'.npz'));predictions[a['implementation']+'Real']=q['real_pred'];mechanism.append(a)
 mm=maps[maps.dataset==r['dataset']];scopes=sorted(set(s for ss in mm.scopes for s in ss.split(';')))
 for method,p in predictions.items():
  assert p.shape==y.shape and np.isfinite(p).all()
  sse=np.cumsum((p-y)**2,0);bad=sse>RR*B+1e-8*np.maximum(1,B);rm=np.sqrt(np.mean((p-y)**2,0));rb=np.sqrt(np.mean((b-y)**2,0))
  ratio=np.divide(rm,rb,out=np.full_like(rm,np.nan),where=rb>0)
  risk.append(dict(**meta,method=method,sequences=len(rm),checks=p.size,ever=int(bad.any(0).sum()),dates=int(bad.sum()),final=int(bad[-1].sum()),ever_pct=100*bad.any(0).mean(),
   zero_reference_nodes=int((rb==0).sum()),max_excess_sse=float(np.max(sse-RR*B)),max_normalized_excess=float(np.max(np.maximum(sse-RR*B,0)/(1+RR*B))),
   node_gain_fraction_pct=100*np.mean(rm<rb-1e-10*np.maximum(1,rb)),median_node_gain_pct=float(np.nanmedian(100*(1-ratio))),p95_node_final_ratio=float(np.nanquantile(ratio,.95))))
  for i in range(len(rm)):nodes.append(dict(**meta,method=method,node=i,rmse=rm[i],reference_rmse=rb[i],ever=bool(bad[:,i].any()),worst_excess_sse=float(np.max(sse[:,i]-RR*B[:,i]))))
  for scope in scopes:
   ii=mm[mm.scopes.str.split(';').map(lambda z:scope in z)].node.to_numpy(int)
   cells.append(dict(**meta,method=method,scope=scope,nodes=len(ii),rmse=float(rm[ii].mean())))
out=H/'analysis';out.mkdir(exist_ok=True)
c=pd.DataFrame(cells);rk=pd.DataFrame(risk);nd=pd.DataFrame(nodes)
c.to_csv(out/'LEVEL_CELL_METRICS.csv',index=False);rk.to_csv(out/'RISK_CELLS.csv',index=False);nd.to_csv(out/'NODE_METRICS.csv',index=False)
g=c.groupby(GR+['scope','method'],as_index=False).rmse.mean();g.to_csv(out/'LEVEL_GROUP_RUN.csv',index=False)
wide=g[g.scope=='all'].pivot(index=GR,columns='method',values='rmse')
old=pd.read_csv(E/'GROUP_RUN_RMSE.csv');om={'Raw':'Raw','NNLS':'NNLS','Cov':'CovFullFix','ML':'ProtectedMLPol','CovU':'CovUnprotected','MLU':'MLPol'}
for m,n in om.items():
 a=old[old.method==n].set_index(GR).rmse.reindex(wide.index);np.testing.assert_allclose(wide[m],a,rtol=1e-10,atol=1e-10)
rw=rk.groupby(GR+['method']).ever_pct.mean().unstack('method')
paired=[]
for impl in ['Cov','ML']:
 for key,row in wide.iterrows():
  paired.append(dict(zip(GR,key))|dict(implementation=impl,rmse=row[impl],unprotected_rmse=row[impl+'U'],reference_rmse=row.NNLS,
   protection_cost_pct=100*(row[impl]/row[impl+'U']-1),reference_gain_pct=100*(1-row[impl]/row.NNLS),unprotected_ever_pct=rw.loc[key,impl+'U'],protected_ever_pct=rw.loc[key,impl]))
p=pd.DataFrame(paired);p.to_csv(out/'PAIRED_GROUP_RUN.csv',index=False)
pdg=p.drop(columns='seed').groupby(['dataset','implementation']).mean(numeric_only=True).reset_index();pdg.to_csv(out/'PAIRED_DATASET.csv',index=False)
p.drop(columns='seed').groupby(['dataset','backbone','implementation']).mean(numeric_only=True).reset_index().to_csv(out/'PAIRED_GROUP.csv',index=False)
lw=g.pivot(index=GR+['scope'],columns='method',values='rmse');lp=[]
for impl in ['Cov','ML']:
 for key,row in lw.iterrows():
  lp.append(dict(zip(GR+['scope'],key))|dict(implementation=impl,reference_gain_pct=100*(1-row[impl]/row.NNLS),protection_cost_pct=100*(row[impl]/row[impl+'U']-1),envelope_gain_pct=100*(1-row[impl]/row.get(impl+'Real',np.nan))))
pd.DataFrame(lp).to_csv(out/'PAIRED_LEVEL_RUN.csv',index=False)
ng=nd.groupby(GR+['node','method'],as_index=False)[['rmse','reference_rmse']].mean()
ng['gain_pct']=100*(1-ng.rmse/ng.reference_rmse.replace(0,np.nan));ng.to_csv(out/'NODE_GROUP_RUN.csv',index=False)
ns=[]
for key,q in ng[ng.method.isin(['Cov','ML'])].groupby(GR+['method']):
 ns.append(dict(zip(GR+['method'],key))|dict(nodes=len(q),improved_pct=100*(q.gain_pct>1e-8).mean(),median_gain=q.gain_pct.median(),p10_gain=q.gain_pct.quantile(.1),min_gain=q.gain_pct.min()))
pd.DataFrame(ns).to_csv(out/'NODE_DISTRIBUTION.csv',index=False)
summary=dict(reused_trajectories=66,verified_previous_group_run_metrics=36*len(om),complete_new_configurations=len(mechanism)//2,
 protection_cost=p.groupby('implementation').protection_cost_pct.agg(['mean','median']).to_dict('index'),
 paired_dataset=pdg[['dataset','implementation','protection_cost_pct','reference_gain_pct','unprotected_ever_pct']].to_dict('records'))
if len(mechanism)==132:
 m=pd.json_normalize(mechanism);m.to_csv(out/'MECHANISM_CELLS.csv',index=False)
 ew=[]
 for impl in ['Cov','ML']:
  for key,row in wide.iterrows():ew.append(dict(zip(GR,key))|dict(implementation=impl,exact_rmse=row[impl],real_rmse=row[impl+'Real'],gain_pct=100*(1-row[impl]/row[impl+'Real'])))
 ew=pd.DataFrame(ew);ew.to_csv(out/'ENVELOPE_GROUP_RUN.csv',index=False)
 eg=ew.groupby(['dataset','backbone','implementation']).agg(exact_mean=('exact_rmse','mean'),exact_sd=('exact_rmse','std'),real_mean=('real_rmse','mean'),real_sd=('real_rmse','std'),gain=('gain_pct','mean')).reset_index();eg.to_csv(out/'ENVELOPE_GROUP.csv',index=False)
 summary['envelope']={}
 for impl in ['Cov','ML']:
  q=ew[ew.implementation==impl];mg=m[m.implementation==impl];groups=eg[eg.implementation==impl]
  summary['envelope'][impl]=dict(mean_gain=q.gain_pct.mean(),median_group_gain=groups.gain.median(),wins=int((groups.gain>1e-6).sum()),losses=int((groups.gain < -1e-6).sum()),ties=int((abs(groups.gain)<=1e-6).sum()),
   replay_bitwise=int(mg.replay_bitwise.sum()),max_replay_difference=mg.replay_max_abs_difference.max(),
   exact_node_checks=int(mg['exact_audit.exact_node_checks'].sum()),real_node_checks=int(mg['real_audit.exact_node_checks'].sum()),
   active_interval_pct=100*mg['exact_audit.active_interval_node_dates'].sum()/mg['exact_audit.exact_node_checks'].sum(),
   outside_real_pct=100*mg['exact_audit.outside_real_node_dates'].sum()/mg['exact_audit.exact_node_checks'].sum(),
   same_state_objective_better=int(mg.same_state_objective_better.sum()),same_state_worse=int(mg.same_state_objective_worse_beyond_tolerance.sum()),
   same_state_distance_reduction_pct=100*(1-mg.same_state_objective_exact.sum()/mg.same_state_objective_real.sum()),
   same_state_max_normalized_worse=mg.same_state_max_normalized_objective_worse.max())
 # Repeated-run variation, not independent data uncertainty.
 ew.groupby(['seed','implementation']).gain_pct.mean().reset_index().to_csv(out/'ENVELOPE_RUN_GAINS.csv',index=False)
 print(eg.to_string(index=False))
summary['risk_totals']=rk.groupby('method')[['sequences','checks','ever','dates','final']].sum().to_dict('index')
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');(out/'INPUT_HASHES.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
