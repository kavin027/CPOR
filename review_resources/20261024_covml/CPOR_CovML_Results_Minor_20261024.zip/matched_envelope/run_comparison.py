"""Matched outcome-domain experiment. Archived predictors and selectors are frozen.

No historical file is modified. Function clones retain each archived numerical
path and replace only the outcome domain in bounds, certification and reservation.
"""
from pathlib import Path
import sys, json, hashlib, types, time, os, warnings
from fractions import Fraction
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
import pandas as pd

H=Path(__file__).resolve().parent; O=H.parent; ROOT=O.parent
INDEX=O/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv'
RR=(1+Fraction('.005'))**2; K=RR-1
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files if k not in ['dates','stats']}
def js(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2),encoding='utf-8')
def clone(f,**updates):
 g=dict(f.__globals__);g.update(updates)
 return types.FunctionType(f.__code__,g,f.__name__,f.__defaults__,f.__closure__)
def kernels(domain):
 sys.path.insert(0,str(O/'c0_seed_validation_20261016'))
 import common
 import engine, rollout, guard_v8, precision_release
 old=common.old; nonnegative=domain=='nonnegative'
 def bounds(b,A,epsilon=.005,nonnegative_ignored=True):
  return engine.safe_bounds(b,A,epsilon,nonnegative=nonnegative)
 def certified(b,p,A,rr,k,*args):return engine.certified(b,p,A,rr,k,nonnegative)
 def excess(b,p,rr,k):
  ans=[]
  for bb,pp in zip(b,p):
   bb,pp=Fraction.from_float(float(bb)),Fraction.from_float(float(pp))
   ans.append(pp*pp-rr*bb*bb if nonnegative and pp>rr*bb else rr*(pp-bb)**2/k)
  return ans
 guard=clone(guard_v8.guard,certified=certified)
 def numerical(b,p,ub,u,S,lo,hi,A,rr,k,*args):
  return engine.numerical_guard(b,p,ub,u,S,lo,hi,A,rr,k,nonnegative)
 action=clone(rollout.action,safe_bounds=bounds,numerical_guard=numerical)
 cov=clone(precision_release.release_repaired,safe_bounds=bounds,certified=certified,guard=guard,excess_bound=excess)
 m5=clone(old.cov.release,safe_bounds=bounds,action=action,excess_bound=excess)
 ml=clone(old.one_action,safe_bounds=bounds,certified=certified,guard=guard)
 return dict(old=old,cov=cov,m5=m5,ml=ml,certified=certified,bounds=bounds)
def run(x,target,implementation,dataset,domain,fixed_states=None):
 k=kernels(domain);old=k['old'];start=time.perf_counter()
 if implementation=='Cov':
  f=k['m5'] if dataset=='M5' else k['cov']
  if fixed_states is not None:
   count=[0]
   def fixed_advance(*args):count[0]+=1;return list(fixed_states[count[0]])
   f=clone(f,advance=fixed_advance)
  out=f(x,target,'CovFull' if dataset=='M5' else 'Full')
 else:
  qp=old.SafeProjection(x['S'],x['v']);A=[Fraction(0) for _ in x['v']];rows=[];us=[];infos=[]
  for j,t in enumerate(range(36,108)):
   if fixed_states is not None:A=list(fixed_states[j])
   elif j:A=old.advance(A,x['b'][t-1],rows[-1],x['truth'][t-1])
   p,u,info=k['ml'](qp,x['S'],x['b'][t],x['ub'][t],target[j],A)
   assert k['certified'](x['b'][t],p,A,RR,K)
   rows.append(p);us.append(u);infos.append(info)
  out=dict(pred=np.array(rows),witness=np.array(us),stats=infos)
 out['elapsed_seconds']=time.perf_counter()-start
 return out
def states_and_audit(x,p,u,domain):
 k=kernels(domain);A=[Fraction(0) for _ in x['v']];states=[];active=[];outside=[];bad=0
 for j,t in enumerate(range(36,108)):
  states.append(list(A));b=x['b'][t]
  assert k['certified'](b,p[j],A,RR,K),('envelope',j,domain)
  for i in range(len(A)):
   bb=Fraction.from_float(float(b[i]));pp=Fraction.from_float(float(p[j,i]));yy=Fraction.from_float(float(x['truth'][t,i]))
   active.append(A[i]>K*RR*bb*bb)
   outside.append(RR*(pp-bb)**2/K>A[i])
   A[i]+=RR*(bb-yy)**2-(pp-yy)**2
   assert A[i]>=0,('prefix',j,i)
 if u is not None:
  assert u.min()>=0
  np.testing.assert_allclose(p,u@x['S'].T,rtol=1e-8,atol=2e-6)
 return states,dict(exact_node_checks=p.size,active_interval_node_dates=int(sum(active)),outside_real_node_dates=int(sum(outside)),max_coherence_abs=float(np.abs(p-u@x['S'].T).max()) if u is not None else None)
def work(row):
 from threadpoolctl import threadpool_limits
 warnings.filterwarnings('ignore',message='Solution may be inaccurate')
 ds,bb,w,seed=[row[k] for k in ['dataset','backbone','window','seed']]
 dest=H/'runs'/ds/bb/w/str(seed);dest.mkdir(parents=True,exist_ok=True)
 done=dest/'DONE.json'
 if done.exists():return json.loads(done.read_text())
 source=Path(row['source']);x=load(source/'endpoints.npz');ctx=load(source/'contexts.npz');controls=load(source/'controls.npz');cov=load(source/'CovFullFix.npz')
 inputs={str(source/n):sha(source/n) for n in ['endpoints.npz','contexts.npz','controls.npz','CovFullFix.npz']}
 records=[]
 with threadpool_limits(1):
  for impl,target,expected in [('Cov',ctx['D'][36:],cov['pred']),('ML',controls['MLPol'],controls['ProtectedMLPol'])]:
   f=dest/(impl+'_RESULT.json')
   if f.exists():records.append(json.loads(f.read_text()));continue
   exact=run(x,target,impl,ds,'nonnegative')
   maxdiff=float(np.abs(exact['pred']-expected).max())
   np.testing.assert_allclose(exact['pred'],expected,rtol=1e-8,atol=2e-6,err_msg=str((ds,bb,w,seed,impl)))
   # Strictly stop if replay changes scientific metrics, even within point tolerance.
   rmse=lambda pp:float(np.sqrt(np.mean((pp-x['truth'][36:])**2,axis=0)).mean())
   assert abs(rmse(exact['pred'])-rmse(expected))<=1e-8*max(1,rmse(expected))
   states,audit=states_and_audit(x,exact['pred'],exact['witness'],'nonnegative')
   real=run(x,target,impl,ds,'real')
   _,ar=states_and_audit(x,real['pred'],real['witness'],'real')
   same=run(x,target,impl,ds,'real',fixed_states=states)
   kk=kernels('real')
   for j in range(72):assert kk['certified'](x['b'][36+j],same['pred'][j],states[j],RR,K)
   np.testing.assert_allclose(same['pred'],same['witness']@x['S'].T,rtol=1e-8,atol=2e-6)
   obj=lambda pp:.5*np.sum((pp-target)**2/x['v'],axis=1)
   a,b=obj(exact['pred']),obj(same['pred'])
   gap=b-a
   record=dict(dataset=ds,backbone=bb,window=w,seed=seed,implementation=impl,
    exact_rmse=rmse(exact['pred']),real_rmse=rmse(real['pred']),unprotected_rmse=rmse(target),
    replay_max_abs_difference=maxdiff,replay_bitwise=bool(np.array_equal(exact['pred'],expected)),
    exact_audit=audit,real_audit=ar,exact_seconds=exact['elapsed_seconds'],real_seconds=real['elapsed_seconds'],
    same_state_objective_exact=float(a.sum()),same_state_objective_real=float(b.sum()),
    same_state_objective_better=int((gap>2e-6*(1+np.maximum(a,b))).sum()),
    same_state_objective_worse_beyond_tolerance=int((gap < -4e-6*(1+np.maximum(a,b))).sum()),
    same_state_max_normalized_objective_worse=float(np.max(-gap/(1+np.maximum(a,b)))))
   arrays=dict(exact_pred=exact['pred'],exact_witness=exact['witness'],real_pred=real['pred'],real_witness=real['witness'],same_state_real_pred=same['pred'],same_state_real_witness=same['witness'],target=target,allowance_before=np.array([[float(a) for a in s] for s in states]),objective_exact=a,objective_same_state_real=b)
   np.savez_compressed(dest/(impl+'.npz'),**arrays);record['output_sha256']=sha(dest/(impl+'.npz'));js(f,record);records.append(record)
 rec=dict(cell={k:row[k] for k in ['dataset','backbone','window','seed']},inputs=inputs,records=records)
 js(done,rec);return rec
def register():
 idx=pd.read_csv(INDEX);assert len(idx)==66
 registration=dict(date='2026-10-24',purpose='Outcome-domain ablation of existing CPOR protection; not a new forecasting method or untouched confirmation',
  grid=idx[['dataset','backbone','window','seed']].to_dict('records'),implementations=['Cov','ML'],
  arms=['nonnegative exact (archived-path replay)','all-real conservative'],
  fixed=['base predictions','causal combined targets','NNLS reference','variance weights','36 calibration /72 score dates','zero starting allowance','epsilon=.005','per-implementation projection solver, inward margin, repair, guard and failure paths'],
  changed='Bounds, exact envelope certification and reservation use sup over all real outcomes in conservative arm; both settle own actual released errors. No hypothetical future labels enter actions.',
  same_state='All-real projection at each nonnegative trajectory pre-release state. This is a conditional operator comparison, not an online strategy trajectory.',
  primary='Mean-node RMSE: windows averaged within dataset/backbone/run, paired percentage exact vs conservative, then equally average 12 groups and 3 runs. Cov and ML reported separately.',
  secondary=['selected system/region/bottom RMSE','paired nodewise risk and protection cost','same-state weighted target distance','active-set and extra-region usage','publication timings'],
  safeguards=['Require replay agreement before adding conservative result','Exact rational envelope and prefix audit','Coherence tolerance 1e-8 relative, 2e-6 absolute','Keep all positive, zero and negative comparisons; no outcome-based selection'],
  source_sha256={str(INDEX):sha(INDEX),str(Path(__file__)):sha(__file__)})
 p=H/'REGISTRATION.json'
 if p.exists():assert json.loads(p.read_text())==registration,'Registration changed'
 else:js(p,registration)
 return idx
def boundaries():
 k=kernels('real');e=kernels('nonnegative')
 for b in [0.,1.,100.]:
  for credit in [0.,1e-12,float(K*RR)*b*b,1.,1e6]:
   B=[Fraction.from_float(credit)];bb=np.array([b]);lo,hi=k['bounds'](bb,np.array([credit]));le,he=e['bounds'](bb,np.array([credit]))
   assert lo[0]>=0 and np.allclose(lo,le) and he[0]>=hi[0]-1e-12
   for v in [lo[0],b,hi[0]]:assert k['certified'](bb,np.array([v]),B,RR,K)
   if credit==0:assert lo[0]==hi[0]==b
 # Nonnegative domain admits a strictly larger upper action with zero anchor.
 assert e['certified'](np.array([0.]),np.array([.5]),[Fraction(1)],RR,K)
 assert not k['certified'](np.array([0.]),np.array([.5]),[Fraction(1)],RR,K)
 js(H/'BOUNDARY_CHECK.json',dict(passed=True,checks='Zero allowance, zero anchor, switching threshold, interval containment and strict-domain example'))
if __name__=='__main__':
 idx=register();boundaries()
 if '--check-only' in sys.argv:print('registration and boundary checks passed');sys.exit(0)
 selected=idx.to_dict('records')
 if '--first' in sys.argv:selected=selected[:1]
 workers=3
 with ProcessPoolExecutor(max_workers=workers) as pool:
  futures={pool.submit(work,r):r for r in selected}
  for n,f in enumerate(as_completed(futures),1):
   rec=f.result();print(json.dumps(dict(completed=n,total=len(selected),cell=rec['cell'],results=[{k:r[k] for k in ['implementation','exact_rmse','real_rmse','replay_bitwise','same_state_objective_worse_beyond_tolerance']} for r in rec['records']])),flush=True)
 print('COMPLETE',len(selected),flush=True)
