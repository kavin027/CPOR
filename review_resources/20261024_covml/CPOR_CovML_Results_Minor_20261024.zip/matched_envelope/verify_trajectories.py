"""Independent audit: no imports of the release, guard or fitting implementation."""
from pathlib import Path
import json,hashlib
from fractions import Fraction as F
import numpy as np
H=Path(__file__).resolve().parent;R=F(40401,40000);K=R-1
totals={'Cov':0,'ML':0};files={};coherence=0.;objective_worse=0;replay=0
def exact(v):return F.from_float(float(v))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for d in sorted((H/'runs').glob('*/*/*/*/DONE.json')):
 info=json.loads(d.read_text());source=Path(next(iter(info['inputs']))).parent
 for p,h in info['inputs'].items():assert sha(p)==h
 x=np.load(source/'endpoints.npz');b=x['b'][36:];y=x['truth'][36:];S=x['S'];v=x['v']
 for impl in ['Cov','ML']:
  path=d.parent/(impl+'.npz')
  with np.load(path) as archive:q={key:archive[key] for key in archive.files}
  rec=json.loads((d.parent/(impl+'_RESULT.json')).read_text());assert sha(path)==rec['output_sha256']
  files[str(path.relative_to(H))]=sha(path)
  orig=np.load(source/('CovFullFix.npz' if impl=='Cov' else 'controls.npz'))['pred' if impl=='Cov' else 'ProtectedMLPol']
  assert np.array_equal(orig,q['exact_pred']);replay+=1
  for arm in ['exact','real']:
   p=q[arm+'_pred'];u=q[arm+'_witness'];assert u.min()>=0
   np.testing.assert_allclose(p,u@S.T,rtol=1e-8,atol=2e-6);coherence=max(coherence,float(abs(p-u@S.T).max()))
   A=[F(0)]*len(v)
   for t in range(72):
    for i in range(len(v)):
     bb,pp,yy=map(exact,[b[t,i],p[t,i],y[t,i]])
     gamma=R*(pp-bb)**2/K
     if arm=='exact' and pp>R*bb:gamma=pp*pp-R*bb*bb
     assert gamma<=A[i]
     if arm=='exact':
      sp=exact(q['same_state_real_pred'][t,i]);assert R*(sp-bb)**2/K<=A[i]
      assert float(A[i])==q['allowance_before'][t,i]
     A[i]+=R*(bb-yy)**2-(pp-yy)**2;assert A[i]>=0
     totals[impl]+=1
  np.testing.assert_allclose(q['same_state_real_pred'],q['same_state_real_witness']@S.T,rtol=1e-8,atol=2e-6)
  a=.5*np.sum((q['exact_pred']-q['target'])**2/v,axis=1);c=.5*np.sum((q['same_state_real_pred']-q['target'])**2/v,axis=1)
  np.testing.assert_array_equal(a,q['objective_exact']);np.testing.assert_array_equal(c,q['objective_same_state_real'])
  objective_worse+=int(np.sum(a-c>4e-6*(1+np.maximum(a,c))))
 assert len(info['records'])==2
assert replay==132 and totals=={'Cov':863136,'ML':863136} and objective_worse==0
result=dict(passed=True,bitwise_archived_replays=replay,exact_envelope_and_prefix_node_checks=sum(totals.values()),checks_by_implementation=totals,same_state_checks=863136,max_absolute_coherence_residual=coherence,coherence_rtol=1e-8,coherence_atol=2e-6,same_state_objective_worse_beyond_tolerance=objective_worse,scope='Stored output, frozen-input hashes, rational one-step envelopes, own-path cumulative settlement, fixed-state real-domain feasibility, tolerance coherence and projection distances; no backbone retraining')
(H/'INDEPENDENT_AUDIT.json').write_text(json.dumps(result,indent=2));(H/'OUTPUT_HASHES.json').write_text(json.dumps(files,indent=2));print(json.dumps(result,indent=2))
