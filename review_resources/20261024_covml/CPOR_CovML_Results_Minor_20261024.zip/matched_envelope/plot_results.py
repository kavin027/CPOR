from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
H=Path(__file__).resolve().parent;P=H.parent/'cpor_cov_ml_20261024'
q=pd.read_csv(H/'analysis/PAIRED_GROUP_RUN.csv')
q['protected_ratio']=q.rmse/q.reference_rmse;q['unprotected_ratio']=q.unprotected_rmse/q.reference_rmse
g=q.groupby(['dataset','implementation']).mean(numeric_only=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.titlesize':13,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,axes=plt.subplots(2,3,figsize=(9,6.2),layout='constrained')
for ax,ds in zip(axes.flat,['RH','ECommerce','Traffic','Wiki2','Labour','M5']):
 ax.set_title(ds,fontweight='bold');ax.axhline(1,color='#777',lw=.8,ls='--',zorder=1)
 for impl,color,marker in [('Cov','#b75912','o'),('ML','#1b6ca8','^')]:
  r=g.loc[ds,impl];a=(r.unprotected_ever_pct,r.unprotected_ratio);b=(0,r.protected_ratio)
  ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',color=color,lw=1.4,alpha=.8,shrinkA=5,shrinkB=5),zorder=2)
  ax.scatter(*a,s=66,marker=marker,facecolors='white',edgecolors=color,linewidths=1.5,zorder=4)
  ax.scatter(*b,s=66,marker=marker,facecolors=color,edgecolors='white',linewidths=.4,zorder=5)
 ax.set_xlim(-6,104);ax.set_xticks([0,25,50,75,100]);ax.grid(axis='y',alpha=.18);ax.margins(y=.18)
 ax.set_xlabel('Sequences ever violating\n(%)')
for ax in axes[:,0]:ax.set_ylabel('Mean RMSE / reference RMSE')
fig.legend(handles=[Line2D([],[],marker='o',color='#b75912',label='Cov',ls=''),Line2D([],[],marker='^',color='#1b6ca8',label='ML',ls=''),Line2D([],[],marker='o',markerfacecolor='white',color='#555',label='Unprotected',ls=''),Line2D([],[],marker='o',color='#555',label='CPOR-protected',ls='')],loc='outside upper center',ncol=4,frameon=False)
for ext in ['pdf','svg','png']:
 dest=P/'artwork'/('Fig2_Protection_Tradeoffs.'+ext);fig.savefig(dest,dpi=220)
 if ext=='pdf':(P/'source/images'/dest.name).write_bytes(dest.read_bytes())
plt.close(fig)
print('Wrote six-dataset paired risk/accuracy figure. Ratios and rates first average windows then six backbone/run pairs per dataset.')
