# Matched outcome-domain comparison — 24 October 2026

The frozen comparison adds 132 all-real online trajectories (22 configurations × three training runs × Cov/ML), replays the 132 nonnegative trajectories, and computes 9,504 conditional all-real projections at the exact arm's pre-release states. The current timing revision reuses the completed outcome-domain study unchanged. No backbone is retrained and no external method is rerun. This is a retrospective controlled comparison, not a new untouched-data confirmation.

`REGISTRATION.json` fixes the grid and rules before scoring. `BOUNDARY_CHECK.json` records boundary tests. `INDEPENDENT_AUDIT.json` records a separate local audit using direct rational formulas, without importing publication or guard routines. It checked 1,726,272 online node-date records (each with an exact envelope assertion and an exact prefix-balance assertion) and 863,136 fixed-state instances. Coherence is checked separately at the stated tolerance. `OUTPUT_HASHES.json`, `analysis/INPUT_HASHES.json` and the JSON receipts under `runs/` identify the audited inputs and outputs. Output NPZ files and observation caches are not included in this aggregate attachment.

Run `python check_aggregates.py` here to verify the supplied arithmetic and cross-file correspondence. The top-level checker also calls it. This command does not independently repeat the rational trajectory audit. Repeating `verify_trajectories.py` requires the original input caches and NPZ outputs identified by those hashes.

Table mapping:
- Main Figure 2: analysis/PAIRED_GROUP_RUN.csv and PAIRED_DATASET.csv. The current plotting entry is plot_direct.py; plot_results.py retains the previous figure for provenance. Both use unchanged records.
- Main Table 8, Supplementary Table S6: ENVELOPE_GROUP_RUN.csv and ENVELOPE_GROUP.csv.
- Main Section 6.3 mechanism counts: MECHANISM_CELLS.csv; exact replay and audit are also recorded per trajectory.
- Supplementary Table S8: PAIRED_LEVEL_RUN.csv (averaged over backbones and runs).
- Supplementary Table S9: NODE_DISTRIBUTION.csv.
- All these summaries derive from LEVEL_CELL_METRICS.csv and LEVEL_GROUP_RUN.csv; RISK_CELLS.csv retains matched risk counts.

For each training run, window RMSEs are averaged first (two windows except Labour). The relative change is then computed within the matched dataset–backbone–run pair. Overall means weight the twelve dataset–backbone groups equally and average the three runs; group SDs describe training-run variation. Pooling node-sequence violation counts and averaging dataset-level rates are different summaries and are labeled separately.

`source_closure/` preserves 38 files, covering imported project sources and the fixed trajectory index in their original project-relative layout; SOURCE_CLOSURE.json identifies their hashes. It excludes installed third-party dependencies. Use the run driver under source_closure/output/cpor_envelope_comparison_20261024 in that layout with the numerical dependencies and required archived inputs. The top-level driver is the same frozen source for convenient inspection, not a relocated turnkey reproduction entry. The code changes only the outcome domain through cloned function globals; historical source files are not edited. Cov and ML retain their respective archived numerical paths.

The fixed-state projections are conditional operator comparisons, not valid substitute online trajectories. Own-state online arms separately settle actual released errors. Neither lower target distance nor use of the enlarged set is treated as proof of universal accuracy improvement. All early/late windows, runs and levelwise losses remain in the numerical records.
