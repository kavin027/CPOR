"""Verify the Cov/ML paper's existing aggregate records. No forecast experiment."""
from pathlib import Path
import csv,json,hashlib,statistics,math
H=Path(__file__).resolve().parent
def rows(name):
 with (H/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def avg(xs):return statistics.mean(xs)
def close(a,b):assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-9),(a,b)
manifest=json.loads((H/'SHA256.json').read_text())
for path,sha in manifest.items():assert hashlib.sha256((H/path).read_bytes()).hexdigest()==sha,path
data=rows('GROUP_RUN_RMSE.csv');lookup={(r['dataset'],r['backbone'],r['seed'],r['method']):float(r['rmse']) for r in data}
assert len(lookup)==len(data)
keys=sorted({k[:3] for k in lookup});assert len(keys)==36
methods=['Raw','NNLS','ProCAST','Ada-Y','PIR','CovFullFix','ProtectedMLPol','ProtectedCalBest','CovUnprotected','MLPol','WLSstruct','WLSvar','MinTshrink','WLSvar_Cov','MinT_Cov']
for k in keys:
 for m in methods:assert (*k,m) in lookup,(*k,m)
out={'checked_files':len(manifest),'groups':12,'training_runs':3,'new_experiments_in_reused_records':0,'comparisons':{},'protection_costs':{},'level_reductions':{},'means_and_sd':[]}
for m in ['CovFullFix','ProtectedMLPol']:
 out['comparisons'][m]={}
 for c in ['Raw','NNLS','ProCAST','Ada-Y','PIR','MinTshrink','MinT_Cov','WLSvar_Cov','ProtectedCalBest']:
  vals=[100*(1-lookup[(*k,m)]/lookup[(*k,c)]) for k in keys]
  g=[avg([x for k,x in zip(keys,vals) if k[:2]==pair]) for pair in sorted({k[:2] for k in keys})]
  out['comparisons'][m][c]={'mean':avg(vals),'median':statistics.median(vals),'groups_improved':sum(x>1e-8 for x in g),'groups_tied_within_1e_8_percentage_points':sum(abs(x)<=1e-8 for x in g)}
  expected=json.loads((H/'EXPECTED_SUMMARY.json').read_text())[m][c]['mean'];close(avg(vals),expected)
 c='CovUnprotected' if m=='CovFullFix' else 'MLPol'
 vals=[100*(lookup[(*k,m)]/lookup[(*k,c)]-1) for k in keys]
 out['protection_costs'][m]={'mean':avg(vals),'median':statistics.median(vals)}
for d,b in sorted({k[:2] for k in keys}):
 for m in methods:
  vals=[lookup[(*k,m)] for k in keys if k[:2]==(d,b)]
  out['means_and_sd'].append({'dataset':d,'backbone':b,'method':m,'mean':avg(vals),'sd':statistics.stdev(vals)})
cell=rows('ALL_CELL_METRICS.csv');grouped={}
for r in cell:
 if r['method'] not in methods:continue
 k=(r['dataset'],r['backbone'],r['seed'],r['method']);grouped.setdefault(k,[]).append(float(r['rmse']))
verified=0
for k,values in grouped.items():
 if k not in lookup:continue
 expected=1 if k[0]=='Labour' else 2
 assert len(values)==expected,(k,len(values))
 close(avg(values),lookup[k]);verified+=1
out['cell_to_group_comparisons']=verified
levels=rows('LEVEL_RUNS.csv');lv={(r['dataset'],r['backbone'],r['seed'],r['scope'],r['method']):float(r['rmse']) for r in levels}
for m in ['CovFullFix','ProtectedMLPol']:
 out['level_reductions'][m]={}
 for scope in ['system','region','bottom']:
  ks=[k[:-1] for k in lv if k[-1]==m and k[3]==scope]
  vals=[100*(1-lv[(*k,m)]/lv[(*k,'NNLS')]) for k in ks]
  out['level_reductions'][m][scope]=avg(vals)
for r in rows('RISK_SUMMARY.csv'):
 assert int(r['node_sequences'])==5994 and int(r['prefixes'])==431568
 for count,pct,den in [('ever','ever_pct',5994),('all_dates','dates_pct',431568),('final','final_pct',5994)]:close(100*int(r[count])/den,float(r[pct]))
 if r['method'] in ['CovFullFix','ProtectedMLPol']:assert all(int(r[k])==0 for k in ['ever','all_dates','final'])
timing=rows('TIMING_REPLAY.csv');assert len(timing)==6
for r in timing:assert r['equivalent']=='True' and float(r['max_abs_difference'])==0
fits=rows('ALL_FITTING_STAGES.csv');assert len(fits)==144
assert all(r['at_cap']=='False' and int(r['last_step'])<10000 for r in fits)
out['passed']=True
(H/'CHECK_RESULT.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ['means_and_sd']},indent=2))

# Check the new matched study in addition to reused records.
import subprocess,sys
subprocess.run([sys.executable,str(H/"matched_envelope/check_aggregates.py")],check=True)

subprocess.run([sys.executable,str(H/"timing_full/check_results.py")],check=True)
