"""Check stored replay arrays against original archives without timing kernels."""
from pathlib import Path
import json,hashlib
import numpy as np
H=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
n=0;targets=0;predictions=0;max_target=0.;max_pred=0.
for receipt in sorted((H/'runs').glob('*/*/*/*/DONE.json')):
 r=json.loads(receipt.read_text());root=Path(next(k for k in r['inputs'] if k.endswith('endpoints.npz'))).parent
 path=receipt.with_name('REPLAY.npz');assert sha(path)==r['output_sha256']
 with np.load(path) as z:out={k:z[k] for k in z.files}
 with np.load(root/'contexts.npz') as z:cov_target=z['D'][36:]
 with np.load(root/'controls.npz') as z:ml_target=z['MLPol'];ml_pred=z['ProtectedMLPol']
 with np.load(root/'CovFullFix.npz') as z:cov_pred=z['pred']
 for name,expected_t,expected_p in [('Cov',cov_target,cov_pred),('ML',ml_target,ml_pred)]:
  target=out[name+'_target'];pred=out[name+'_pred']
  np.testing.assert_allclose(target,expected_t,rtol=1e-8,atol=2e-6);np.testing.assert_allclose(pred,expected_p,rtol=1e-8,atol=2e-6)
  n+=1;targets+=int(np.array_equal(target,expected_t));predictions+=int(np.array_equal(pred,expected_p))
  max_target=max(max_target,float(abs(target-expected_t).max()));max_pred=max(max_pred,float(abs(pred-expected_p).max()))
assert n==132
result=dict(passed=True,trajectories=n,bitwise_targets=targets,bitwise_predictions=predictions,max_target_difference=max_target,max_prediction_difference=max_pred,scope='Independent comparison of stored replay arrays to original cached targets and publications; no numerical method imported or rerun.')
(H/'INDEPENDENT_REPLAY_CHECK.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
