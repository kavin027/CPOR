from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
H=Path(__file__).resolve().parent
frames=[];checks=[];inputs={};outputs={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p in sorted((H/'runs').glob('*/*/*/*/DONE.json')):
 a=json.loads(p.read_text());t=p.with_name('TIMES.csv');out=p.with_name('REPLAY.npz')
 assert sha(t)==a['timing_sha256'] and sha(out)==a['output_sha256']
 f=pd.read_csv(t);assert len(f)==144
 np.testing.assert_allclose(f.total_s,f.target_s+f.publication_s,rtol=1e-12,atol=1e-12)
 np.testing.assert_allclose(f.target_s,f.expert_s+f.reference_s+f.combination_s+f.reconciliation_s,rtol=1e-12,atol=1e-12)
 frames.append(f);inputs.update(a['inputs']);outputs[str(out)]=a['output_sha256']
 for r in a['records']:
  checks.append({k:v for k,v in r.items() if k not in ['target_check','prediction_check','reference_check','amortized_nonloop_seconds']}|{s+'_'+k:v for s in ['target_check','prediction_check','reference_check'] for k,v in r[s].items()})
assert len(frames)==66
for p,h in inputs.items():assert sha(p)==h
q=pd.concat(frames,ignore_index=True);assert len(q)==9504
q.to_csv(H/'ISSUE_TIMES.csv',index=False);c=pd.DataFrame(checks);c.to_csv(H/'REPLAY_CHECKS.csv',index=False)
assert len(c)==132
rows=[];runrows=[]
for keys,df in q.groupby(['dataset','backbone','implementation']):
 assert len(df)==(216 if keys[0]=='Labour' else 432)
 r=dict(zip(['dataset','backbone','implementation'],keys));r['publications']=len(df)
 for col in ['target','publication','total','expert','reference','combination','reconciliation']:
  r[col+'_mean_ms']=float(1000*df[col+'_s'].mean());r[col+'_p95_ms']=float(1000*np.quantile(df[col+'_s'],.95,method='linear'))
 rows.append(r)
for keys,df in q.groupby(['dataset','backbone','seed','implementation']):
 r=dict(zip(['dataset','backbone','seed','implementation'],keys));r['publications']=len(df)
 for col in ['target','publication','total']:r[col+'_mean_ms']=float(1000*df[col+'_s'].mean());r[col+'_p95_ms']=float(1000*np.quantile(df[col+'_s'],.95,method='linear'))
 runrows.append(r)
s=pd.DataFrame(rows);s.to_csv(H/'TIMING_SUMMARY.csv',index=False);pd.DataFrame(runrows).to_csv(H/'TIMING_BY_RUN.csv',index=False)
summary=dict(configurations=22,streams=66,implementations=2,publication_cycles=9504,bitwise_publication_matches=int(c.prediction_check_bitwise.sum()),bitwise_target_matches=int(c.target_check_bitwise.sum()),max_publication_difference=float(c.prediction_check_max_abs_difference.max()),max_target_difference=float(c.target_check_max_abs_difference.max()),rtol=1e-8,atol=2e-6,new_model_training=0,means_and_p95_source='Issue times, pooled windows and three runs within each dataset/backbone/implementation',hardware='AMD Ryzen 9 8945HX; one numerical thread; sequential component replay',summary=s.to_dict('records'))
(H/'SUMMARY.json').write_text(json.dumps(summary,indent=2));(H/'INPUT_HASHES.json').write_text(json.dumps(inputs,indent=2));(H/'OUTPUT_HASHES.json').write_text(json.dumps(outputs,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='summary'},indent=2));print(s[['dataset','backbone','implementation','target_mean_ms','publication_mean_ms','total_mean_ms','total_p95_ms']].to_string(index=False))
