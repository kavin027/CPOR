"""Standard-library arithmetic verification of the complete timing grid."""
from pathlib import Path
import csv,json,math,statistics,collections
H=Path(__file__).resolve().parent
def rows(n):
 with (H/n).open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def close(a,b):assert math.isclose(float(a),float(b),rel_tol=1e-10,abs_tol=1e-9),(a,b)
def p95(values):
 a=sorted(values);x=.95*(len(a)-1);i=int(x);return a[i]+(x-i)*(a[min(i+1,len(a)-1)]-a[i])
q=rows('ISSUE_TIMES.csv');assert len(q)==9504
groups=collections.defaultdict(list);runs=collections.defaultdict(list)
for r in q:
 close(r['total_s'],float(r['target_s'])+float(r['publication_s']))
 close(r['target_s'],sum(float(r[k+'_s']) for k in ['expert','reference','combination','reconciliation']))
 assert all(float(r[k+'_s'])>0 for k in ['target','publication','total'])
 groups[tuple(r[k] for k in ['dataset','backbone','implementation'])].append(r)
 runs[tuple(r[k] for k in ['dataset','backbone','seed','implementation'])].append(r)
assert len(groups)==24 and len(runs)==72
for name,by,key,cols in [('TIMING_SUMMARY.csv',groups,['dataset','backbone','implementation'],['target','publication','total','expert','reference','combination','reconciliation']),('TIMING_BY_RUN.csv',runs,['dataset','backbone','seed','implementation'],['target','publication','total'])]:
 for r in rows(name):
  a=by[tuple(r[k] for k in key)];assert len(a)==int(r['publications'])
  for col in cols:
   values=[float(z[col+'_s'])*1000 for z in a]
   close(r[col+'_mean_ms'],statistics.mean(values));close(r[col+'_p95_ms'],p95(values))
checks=rows('REPLAY_CHECKS.csv');assert len(checks)==132
summary=json.loads((H/'SUMMARY.json').read_text())
for kind in ['target','publication']:
 prefix='prediction' if kind=='publication' else 'target'
 assert sum(r[prefix+'_check_bitwise']=='True' for r in checks)==summary['bitwise_'+kind+'_matches']
 close(max(float(r[prefix+'_check_max_abs_difference']) for r in checks),summary['max_'+kind+'_difference'])
print(json.dumps(dict(passed=True,streams=66,implementation_trajectories=132,issue_times=9504,summary_rows=24,run_rows=72,bitwise_predictions=summary['bitwise_publication_matches'],scope='Aggregate timings, means, linear p95 and replay receipts; does not reexecute numerical replay.'),indent=2))
