"""Sequential component timing on the fixed 66 cached prediction streams."""
from pathlib import Path
import ast,inspect,textwrap,sys,time,json,hashlib,platform,os,argparse
import numpy as np,pandas as pd
from threadpoolctl import threadpool_limits,threadpool_info
H=Path(__file__).resolve().parent;O=H.parent;R=O.parent
sys.path.insert(0,str(O/'c0_seed_validation_20261016'))
import common
from frozen_core import expert_bank
from precision_release import release_repaired
old=common.old;cov=old.cov
INDEX=O/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv'
idx=pd.read_csv(INDEX)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files if k!='dates'}
def js(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2),encoding='utf-8')

def timed_loop(func,*args):
 """Insert clocks around the existing outer loop, preserving arithmetic/order."""
 tree=ast.parse(textwrap.dedent(inspect.getsource(func)));fn=tree.body[0]
 loop=next(a for a in fn.body if isinstance(a,ast.For))
 loop.body=ast.parse('_tic=__clock()').body+loop.body+ast.parse('__times.append(__clock()-_tic)').body
 ret=next(i for i,a in enumerate(fn.body) if isinstance(a,ast.Return))
 fn.body[ret:ret]=ast.parse('__state.update(A=locals().get("accounts",locals().get("A")),reservation=locals().get("reservation"))').body
 ast.fix_missing_locations(tree);ns=dict(func.__globals__);ns.update(__clock=time.perf_counter,__times=[],__state={})
 exec(compile(tree,inspect.getsourcefile(func),'exec'),ns)
 start=time.perf_counter();out=ns[func.__name__](*args);elapsed=time.perf_counter()-start
 a=np.array(ns['__times']);assert len(a)>0
 overhead=max(0.,elapsed-float(a.sum()))
 if isinstance(out,dict):out['_end_state']=ns['__state']
 return out,a+overhead/len(a),overhead

def ml_mix(bank,y,v):
 n,J=bank.shape[1:];w=np.full((n,J),1/J);regrets=np.zeros_like(w);squares=np.zeros_like(w);mixtures=[]
 scaled=bank/np.sqrt(v)[None,:,None];labels=y/np.sqrt(v)[None,:]
 for t in range(108):
  p=(scaled[t]*w).sum(1);mixtures.append(p*np.sqrt(v))
  r=2*(p-labels[t])[:,None]*(p[:,None]-scaled[t]);regrets+=r;squares+=r*r
  q=np.maximum(regrets,0)/(1+squares);total=q.sum(1,keepdims=True);w=np.divide(q,total,out=np.full_like(q,1/J),where=total>0)
 return np.asarray(mixtures)

def cov_mix(bank,y,v):
 rows=[]
 for t in range(108):
  w=np.full_like(bank[t],1/9) if t==0 else common.fresh.weights(cov.moment(bank[:t],y[:t],v,t),cov)
  rows.append((bank[t]*w).sum(1))
 return np.asarray(rows)

def ml_release(x,target):
 A=[old.Fraction(0) for _ in x['v']];qp=old.SafeProjection(x['S'],x['v']);rows=[];us=[]
 for j,t in enumerate(range(36,108)):
  if j:A=old.advance(A,x['b'][t-1],rows[-1],x['truth'][t-1])
  p,u,_=old.one_action(qp,x['S'],x['b'][t],x['ub'][t],target[j],A)
  assert old.certified(x['b'][t],p,A,old.RR,old.K,True)
  rows.append(p);us.append(u)
 return dict(pred=np.asarray(rows),witness=np.asarray(us))

def check(a,b):
 np.testing.assert_allclose(a,b,rtol=1e-8,atol=2e-6)
 return dict(bitwise=bool(np.array_equal(a,b)),max_abs_difference=float(np.max(abs(a-b))))

def inputs(row):
 d=Path(row.source);x=load(d/'endpoints.npz');c=load(d/'contexts.npz');co=load(d/'controls.npz')
 data=common.datafile(dict(dataset=row.dataset));wide=pd.read_csv(data,parse_dates=['ds']).set_index('ds')
 y=wide.to_numpy();poss=np.flatnonzero(np.isclose(y[:,0],x['truth'][0,0],rtol=1e-12,atol=1e-12))
 starts=[int(i) for i in poss if i>=7 and i+108<=len(y) and np.array_equal(y[i:i+108],x['truth'])]
 assert len(starts)==1,(row.dataset,starts)
 return d,x,c,co,wide,starts[0],data

def run(row,save=True):
 d,x,c,co,wide,start,data=inputs(row)
 bank,bt,bsetup=timed_loop(expert_bank,wide,x['raw'],x['v'],start)
 if 'bank' in c:check(bank,c['bank'])
 reference,rt,rsetup=timed_loop(old.project,x['S'],x['raw'])
 refcheck=check(reference[0],x['b']);check(reference[1],x['ub'])
 allrows=[];records=[];outputs={}
 for impl in ['Cov','ML']:
  mixed,mt,msetup=timed_loop(cov_mix if impl=='Cov' else ml_mix,bank,x['truth'],x['v'])
  # Original non-M5 PatchTST Cov targets were reconstructed as a 72-row
  # block; other targets used 108 rows. Preserve BLAS batching exactly.
  score_only=impl=='Cov' and row.backbone=='PatchTST' and row.dataset!='M5'
  target,pt,psetup=timed_loop(old.project,x['S'],mixed[36:] if score_only else mixed,x['v'])
  target_score=target[0] if score_only else target[0][36:]
  projection_times=pt if score_only else pt[36:]
  expected_target=c['D'][36:] if impl=='Cov' else co['MLPol']
  tc=check(target_score,expected_target)
  # Replay regenerated targets; never replace them with cached targets to force a match.
  fn=(cov.release if row.dataset=='M5' else release_repaired) if impl=='Cov' else ml_release
  args=(x,target_score,'CovFull' if row.dataset=='M5' else 'Full') if impl=='Cov' else (x,target_score)
  out,pub,pubsetup=timed_loop(fn,*args)
  # Include final feedback settlement for both implementations.
  tic=time.perf_counter()
  state=out.pop('_end_state');A=state['A']
  if state['reservation'] is not None:A=[a+r for a,r in zip(A,state['reservation'])]
  final=old.advance(A,x['b'][-1],out['pred'][-1],x['truth'][-1]);assert min(final)>=0
  final_seconds=time.perf_counter()-tic;pub[-1]+=final_seconds
  expected=load(d/'CovFullFix.npz')['pred'] if impl=='Cov' else co['ProtectedMLPol']
  pc=check(out['pred'],expected)
  np.testing.assert_allclose(out['pred'],out['witness']@x['S'].T,rtol=1e-8,atol=2e-6)
  target_time=bt[36:]+rt[36:]+mt[36:]+projection_times
  key=dict(dataset=row.dataset,backbone=row.backbone,window=row.window,seed=int(row.seed),implementation=impl)
  for j in range(72):
   allrows.append(dict(**key,issue=j+1,expert_s=float(bt[36+j]),reference_s=float(rt[36+j]),combination_s=float(mt[36+j]),reconciliation_s=float(projection_times[j]),target_s=float(target_time[j]),publication_s=float(pub[j]),total_s=float(target_time[j]+pub[j])))
  records.append(dict(**key,target_check=tc,prediction_check=pc,reference_check=refcheck,nodes=len(x['v']),underlying=x['S'].shape[1],seconds=float((target_time+pub).sum()),amortized_nonloop_seconds=dict(bank=bsetup,reference=rsetup,combination=msetup,reconciliation=psetup,publication=pubsetup),final_feedback_seconds=final_seconds))
  outputs[impl+'_target']=target_score;outputs[impl+'_pred']=out['pred']
 if save:
  dest=H/'runs'/row.dataset/row.backbone/row.window/str(row.seed);dest.mkdir(parents=True,exist_ok=True)
  pd.DataFrame(allrows).to_csv(dest/'TIMES.csv',index=False)
  np.savez_compressed(dest/'REPLAY.npz',**outputs)
  js(dest/'DONE.json',dict(driver_sha256=sha(__file__),records=records,inputs={str(p):sha(p) for p in [d/'endpoints.npz',d/'contexts.npz',d/'controls.npz',d/'CovFullFix.npz',data]},output_sha256=sha(dest/'REPLAY.npz'),timing_sha256=sha(dest/'TIMES.csv')))
 return records

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int);a=ap.parse_args()
 js(H/'DESIGN.json',dict(grid=idx.to_dict('records'),threads=1,clock='perf_counter',warmup='One unreported full RH/PatchTST/early run; per-stream 36 calibration issues excluded from reported timing',scope='Existing raw forecasts -> nine raw experts, reference, target combination and reconciliation -> protection and feedback. Component loops replay sequentially; total is the per-issue sum, not independently measured request latency. Non-loop setup and batch reconstruction are evenly allocated over that component loop. Common expert/reference costs counted in each implementation.',excluded='backbone training/inference, disk I/O, import/AST compilation, post-hoc consistency audit',percentiles='numpy linear 95th quantile of issue-level stage times; total quantile computed from issue-level sums',registration_code_sha256=sha(__file__),index_sha256=sha(INDEX)))
 with threadpool_limits(1):
  env=dict(platform=platform.platform(),processor=platform.processor(),python=sys.version,threads=threadpool_info(),repetitions='One timed replay per archived training-run configuration',pid=os.getpid())
  js(H/'ENVIRONMENT.json',env)
  print('WARMUP',flush=True);run(idx.iloc[0],False)
  for i,row in idx.iterrows():
   if a.limit is not None and i>=a.limit:break
   dest=H/'runs'/row.dataset/row.backbone/row.window/str(row.seed)
   if (dest/'DONE.json').exists():continue
   start=time.perf_counter();records=run(row)
   print(json.dumps(dict(done=i+1,total=len(idx),dataset=row.dataset,backbone=row.backbone,window=row.window,seed=int(row.seed),wall_seconds=time.perf_counter()-start,checks=[r['prediction_check'] for r in records])),flush=True)
if __name__=='__main__':main()
