from run_timing import *
import shutil,types
D=H/'source_closure';D.mkdir(exist_ok=True)
paths={Path(__file__).resolve(),H/'run_timing.py',INDEX,O/'kais_review_response_20261016/Online_Resource_1/cells.json'}
pending=list(sys.modules.values());seen=set()
while pending:
 m=pending.pop()
 if id(m) in seen:continue
 seen.add(id(m))
 p=getattr(m,'__file__',None)
 if p:
  p=Path(p).resolve()
  if p.is_file() and p.suffix=='.py' and p.is_relative_to(R) and '.runtime' not in p.parts:
   paths.add(p)
   pending.extend(v for v in vars(m).values() if isinstance(v,types.ModuleType))
records=[]
for p in sorted(paths):
 rel=p.relative_to(R);dest=D/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);records.append(dict(path=rel.as_posix(),sha256=sha(p)))
js(H/'SOURCE_MAP.json',records);print('source files',len(records))
