from pathlib import Path
import sys,importlib.util,json,hashlib,time,copy,argparse,logging,random
import numpy as np
import pandas as pd
import torch
HERE=Path(__file__).resolve().parent;O=HERE.parent
def mod(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
sys.path.insert(0,str(O/'c0_matched_ablation_20261014'))
import experiment as factorial
base=factorial.base;old=base.original
sys.path.insert(0,str(O/'c0_external_sota_20261014'))
import pir_adapter as pir
author_pro=mod('fresh_author_procast',O/'rr_recap_strong_baseline_20261006/run.py')
sys.path.insert(0,str(O/'rr_recap_evidence_extension_20261002'))
import endpoints
from frozen_core import expert_bank
from calibration_contexts import weights
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
REGIONS=['NSW1','QLD1','SA1','TAS1','VIC1'];CELLS=[(b,w) for b in ['PatchTST','DLinear'] for w in ['early','late']]

def registration():
    p=HERE/'REGISTRATION.json'
    oldreg=json.loads((base.HERE/'PREREGISTRATION_PAIRED_ROOT.json').read_text())
    sources=dict(oldreg['source_sha256'])
    for file in [Path(__file__),HERE/'acquire.py',HERE/'PROTOCOL.md',O/'c0_matched_ablation_20261014/square_learning.py',O/'c0_matched_ablation_20261014/experiment.py',O/'rr_recap_strong_baseline_20261006/run.py',O/'rr_recap_evidence_extension_20261002/endpoints.py',O/'rr_recap_evidence_extension_20261002/frozen_core.py']:
        sources[str(file.resolve())]=sha(file)
    sources.update(json.loads((O/'c0_external_sota_20261014/PIR_REGISTRATION.json').read_text())['sources'])
    for file,h in sources.items():assert sha(file)==h,file
    reg=dict(sources=sources,regions=REGIONS,cells=CELLS,months=[202606,202607,202608,202609],seed=42,
        score_targets='first/last72 September half-hour interval ends',primary_groups=2,
        method='unchanged frozen C0; no selection on confirmation',prior_known_AEMO_cutoff='2026-07',
        old_development_scored=True,new_confirmation_labels_acquired=False,
        c0_ablation_report_sha256=sha(O/'c0_matched_ablation_20261014/FULL18_RESULT.json'),
        pir_result_sha256=sha(O/'c0_external_sota_20261014/PIR_FULL18_RESULT.json'))
    reg=json.loads(json.dumps(reg))
    if p.exists():
        previous=json.loads(p.read_text());reg['registered_utc']=previous['registered_utc'];assert previous==reg
    else:
        import datetime
        assert not (HERE/'source').exists(),'cannot register as pre-acquisition after source acquisition'
        reg['registered_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(reg,indent=2))
    return p

def data():
    reg=registration();receipt=json.loads((HERE/'SOURCE_RECEIPT.json').read_text());allregions=[]
    for region in REGIONS:
        parts=[]
        for month in [202606,202607,202608,202609]:
            p=HERE/'source'/f'PRICE_AND_DEMAND_{month}_{region}.csv';assert sha(p)==receipt['files'][str(p.resolve())]['sha256']
            f=pd.read_csv(p);assert set(['SETTLEMENTDATE','TOTALDEMAND','REGION']).issubset(f.columns)
            assert set(f.REGION)=={region};s=pd.Series(f.TOTALDEMAND.to_numpy(dtype='float64'),index=pd.to_datetime(f.SETTLEMENTDATE))
            parts.append(s)
        s=pd.concat(parts).sort_index();assert not s.index.duplicated().any() and np.isfinite(s).all() and s.min()>=0
        minutes=(s.index[1:]-s.index[:-1]).total_seconds()/60;assert (minutes==minutes[0]).all()
        assert minutes[0] in [5,30]
        if minutes[0]==5:
            counts=s.resample('30min',closed='right',label='right').count();mean=s.resample('30min',closed='right',label='right').mean()
            # Only source-boundary bins may be incomplete; never drop an internal bin.
            inside=counts.iloc[1:-1];assert (inside==6).all()
            bad=np.flatnonzero(counts.to_numpy()!=6);assert set(bad).issubset({0,len(counts)-1})
            s=mean[counts==6]
        s.name=region;allregions.append(s)
    for s in allregions[1:]:assert s.index.equals(allregions[0].index)
    wide=pd.concat(allregions,axis=1);wide.insert(0,'SYSTEM',wide.sum(axis=1));wide.index.name='ds'
    S=np.vstack([np.ones((1,5)),np.eye(5)]);wide.to_csv(HERE/'observed.csv');np.save(HERE/'S.npy',S)
    assert np.all((wide.index[1:]-wide.index[:-1]).total_seconds()==1800)
    return wide,S

def forecast(wide,S,bb,w):
    dest=HERE/'results'/bb/w/'42';dest.mkdir(parents=True,exist_ok=True);p=dest/'raw.npz'
    sept=np.flatnonzero((wide.index>=pd.Timestamp('2026-09-01'))&(wide.index<pd.Timestamp('2026-10-01')))
    start=int(sept[0] if w=='early' else sept[-72]);begin=start-144;end=start+72
    assert begin>=100 and len(sept)>=144
    if p.exists():
        j=json.loads(p.with_suffix('.json').read_text());assert j['sha256']==sha(p);x=dict(np.load(p));return dest,x,start
    from neuralforecast import NeuralForecast
    from neuralforecast.models import PatchTST,DLinear
    from pytorch_lightning.callbacks import ModelCheckpoint
    torch.set_num_threads(1);logging.getLogger('pytorch_lightning').setLevel(logging.ERROR)
    cls=PatchTST if bb=='PatchTST' else DLinear
    cb=ModelCheckpoint(dirpath=str(dest/'checkpoint'),monitor='ptl/val_loss',save_top_k=1)
    opts=dict(h=12,input_size=24,val_check_steps=1,early_stop_patience_steps=50,random_seed=42,max_steps=500,
        enable_checkpointing=True,callbacks=[cb],enable_progress_bar=False,enable_model_summary=False,logger=False,
        accelerator='gpu',devices=1,default_root_dir=str(dest))
    if bb=='PatchTST':opts['n_series']=6
    model=cls(**opts);nf=NeuralForecast(models=[model],freq='30min')
    df=wide.reset_index().melt(id_vars='ds',var_name='unique_id',value_name='y').sort_values(['ds','unique_id'])
    nf.fit(df=df[df.ds<wide.index[begin]],val_size=36)
    cb=next(c for c in nf.models[0].trainer_kwargs['callbacks'] if isinstance(c,ModelCheckpoint));best=cb.best_model_path;assert best
    nf.models=[cls.load_from_checkpoint(best,weights_only=False,early_stop_patience_steps=0,enable_checkpointing=False,
        callbacks=[],enable_progress_bar=False,enable_model_summary=False,logger=False)]
    predictions=[]
    for i in range(begin,end,12):
        z=nf.predict(df=df[df.ds<wide.index[i]])
        if 'unique_id' not in z:z=z.reset_index()
        z['origin']=wide.index[i-1];assert (z.ds>z.origin).all();predictions.append(z)
    f=pd.concat(predictions);assert not f.duplicated(['unique_id','ds']).any();f.to_csv(dest/'base_forecasts.csv',index=False)
    raw=f.pivot(index='ds',columns='unique_id',values=bb).reindex(index=wide.index[begin:end],columns=wide.columns).to_numpy()
    assert raw.shape==(216,6) and np.isfinite(raw).all()
    np.savez_compressed(p,raw=raw,truth=wide.to_numpy()[begin:end],S=S,begin=begin,cal_start=start-36,start=start,dates=wide.index[begin:end].astype(str).to_numpy())
    p.with_suffix('.json').write_text(json.dumps(dict(sha256=sha(p),registration_sha256=sha(HERE/'REGISTRATION.json'),
        checkpoint=best,checkpoint_sha256=sha(best),last_base_fit_label=str(wide.index[begin-1]),
        first_forecast=str(wide.index[begin]),first_scored=str(wide.index[start]),best_val=float(cb.best_model_score)),indent=2))
    del nf,model;torch.cuda.empty_cache();print('FRESH_BASE_READY',bb,w,flush=True)
    return dest,dict(np.load(p)),start

def prepare_context(wide,S,raw,start):
    x=endpoints.build(wide,raw[-108:],S,start-36);bank=expert_bank(wide,raw[-108:],x['v'],start-36);mix=[]
    for t in range(108):
        w=np.full_like(bank[t],1/9) if t==0 else weights(old.cov.moment(bank[:t],x['truth'][:t],x['v'],t),old.cov)
        mix.append((bank[t]*w).sum(1))
    D,_=old.project(S,np.asarray(mix),x['v']);_,expert=base.make_contexts(x,bank,dict(target=D[36:]),old)
    np.testing.assert_allclose(D[:36],base.make_contexts(x,bank,dict(target=D[36:]),old)[0][:36],rtol=1e-9,atol=1e-6)
    return x,D,expert

def protected(dest,x,D,expert):
    cal=base.Actor(x['S'],x['v'],'C0')
    for t in range(36):cal.issue(t,x['b'][t],x['ub'][t],D[t],expert[t],None if t==0 else x['truth'][t-1],calibration=True)
    cal.close(x['truth'][35]);records=copy.deepcopy(cal.records)
    E=np.sum((np.array([r['published'] for r in records])-x['truth'][:36])**2,axis=0)
    kappa=float(np.sqrt(E).mean()/E.mean()) if E.mean()>0 else 1/float(np.sqrt(x['v'].mean()))
    for arm in ['C0','SquareFull']:
        p=dest/(arm+'.npz')
        if p.with_suffix('.json').exists():assert json.loads(p.with_suffix('.json').read_text())['sha256']==sha(p);continue
        a=base.Actor(x['S'],x['v'],'C0') if arm=='C0' else factorial.Actor(x['S'],x['v'],arm,records,kappa)
        a.records=copy.deepcopy(records);rows=[];logs=[];started=time.perf_counter()
        for t in range(36,108):
            z=a.issue(t,x['b'][t],x['ub'][t],D[t],expert[t],None if t==36 else x['truth'][t-1])
            logs.append(dict(t=t,fit=z.pop('fit')));rows.append(z)
        out={k:np.array([r[k] for r in rows]) for k in rows[0]};checks=old.audit(x,out,1);a.close(x['truth'][-1])
        np.savez_compressed(p,**out);np.savez_compressed(dest/(arm+'_snapshots.npz'),**{k:np.array([r[k] for r in a.records]) for k in a.records[0]})
        p.with_suffix('.json').write_text(json.dumps(dict(sha256=sha(p),registration_sha256=sha(HERE/'REGISTRATION.json'),
            checks=checks,failed_publications=int(out['solver_failed'].sum()),kappa=kappa,seconds=time.perf_counter()-started,logs=logs),indent=2))
        print('FRESH_PROTECTED_READY',dest,arm,flush=True)
    p=dest/'CovFullFix.npz'
    if not p.exists():
        out=old.cov.release(x,D[36:],'CovFull');out.pop('stats');checks=old.audit(x,out,1)
        np.savez_compressed(p,**out);p.with_suffix('.json').write_text(json.dumps(dict(sha256=sha(p),checks=checks)))

def external(dest,wide,S,stream,start):
    raw=stream['raw'];y=stream['truth'];begin=int(stream['begin'])
    p=dest/'ProCAST72Warm.npz'
    if not p.exists():
        counts=[];yh=torch.tensor(raw,device='cuda',dtype=torch.float64);yt=torch.tensor(y,device='cuda',dtype=torch.float64)
        model=author_pro._TorchPinv(torch.tensor(S,dtype=torch.float32),masked=False,max_iter=100000,
            callback=lambda item:counts.append(int(item[1])) if item[0]=='count' else None).to(device='cuda',dtype=torch.float64)
        preds=[];latent=[];started=time.perf_counter()
        for i in range(144,216):
            n=72;ww=torch.tensor([.5/n]*n+[.5],device='cuda',dtype=torch.float64)
            model.fit(yh[i-n:i+1],torch.cat([yt[i-n:i],yh[i:i+1]]),weights=ww)
            with torch.no_grad():
                u=(yh[i:i+1]@model.pinv).clamp(min=0);preds.append((u@model.mat).cpu().numpy()[0]);latent.append(u.cpu().numpy()[0])
        np.savez_compressed(p,pred=preds,witness=latent,raw=raw[-72:],truth=y[-72:],iterations=counts)
        p.with_suffix('.json').write_text(json.dumps(dict(sha256=sha(p),seconds=time.perf_counter()-started,limit_hits=sum(a>=100000 for a in counts),seed=42)))
        del model,yh,yt;torch.cuda.empty_cache();print('FRESH_PROCAST_READY',dest,flush=True)
    p=dest/'PIR.npz'
    if not p.exists():
        train_end=start-36;values=wide.to_numpy();mu=values[:train_end].mean(0);sd=values[:train_end].std(0);sd=np.where(sd>0,sd,1.)
        pos=np.arange(begin,start+72);contexts=np.stack([values[t-24:t] for t in pos]);lib_pos=np.arange(24,train_end)
        d=dict(x=((contexts-mu)/sd).astype('float32'),raw=((raw-mu)/sd)[:,None,:].astype('float32'),y=((y-mu)/sd)[:,None,:].astype('float32'),
            encmark=np.stack([pir.calendar(wide.index[t-24:t]) for t in pos]),mark=pir.calendar(wide.index[pos])[:,None,:],
            lib_x=((np.stack([values[t-24:t] for t in lib_pos])-mu)/sd).astype('float32'),
            lib_y=((values[lib_pos]-mu)/sd)[:,None,:].astype('float32'),library_index=pos-24)
        assert wide.index[train_end-1]<wide.index[start];torch.manual_seed(42);np.random.seed(42);random.seed(42)
        tt=pir.tensors(d,'cuda');model=pir.CachedPIR(pir.config(6)).float().cuda();logs,state=pir.fit(model,tt,108,144);pred=[]
        with torch.no_grad():
            for i in range(144,216):z,_=pir.forward(model,tt,torch.tensor([i],device='cuda'));pred.append(z.cpu().numpy()[0,0]*sd+mu)
        np.savez_compressed(p,pred=pred,raw=raw[-72:],truth=y[-72:]);torch.save(state,dest/'PIR_checkpoint.pt')
        p.with_suffix('.json').write_text(json.dumps(dict(sha256=sha(p),epochs=logs,seed=42,library_last_label=str(wide.index[train_end-1]),first_score=str(wide.index[start]))))
        del model,tt;torch.cuda.empty_cache();print('FRESH_PIR_READY',dest,flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--register',action='store_true');ap.add_argument('--cell',type=int);args=ap.parse_args()
    reg=registration()
    if args.register:print('FRESH_FROZEN',sha(reg),flush=True);return
    torch.set_num_threads(1);wide,S=data()
    for ci in ([args.cell] if args.cell is not None else range(4)):
        bb,w=CELLS[ci];dest,stream,start=forecast(wide,S,bb,w);x,D,expert=prepare_context(wide,S,stream['raw'],start)
        np.savez_compressed(dest/'endpoints.npz',**x);np.savez_compressed(dest/'contexts.npz',D=D,expert=expert)
        protected(dest,x,D,expert);external(dest,wide,S,stream,start)
    (HERE/'RUN_STATUS.json').write_text(json.dumps(dict(required=4,completed=sum(all((HERE/'results'/b/w/'42'/(a+'.npz')).exists() for a in ['C0','SquareFull','CovFullFix','ProCAST72Warm','PIR']) for b,w in CELLS))))

if __name__=='__main__':main()
