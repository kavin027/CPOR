"""Recompute new display columns and contrasts from existing stored results only."""
from pathlib import Path
import pandas as pd
import numpy as np
H=Path(__file__).resolve().parent
tr=pd.read_csv(H/'current/data/three_run_rmse.csv')
got=tr[(tr.level=='all') & tr.protocol.isin(['window','continuous_carry']) & (tr.method=='PIRCoherent')].reset_index(drop=True)
want=pd.read_csv(H/'presentation/COHERENT_PIR_TABLES.csv')
pd.testing.assert_frame_equal(got,want,check_exact=False,rtol=1e-12,atol=1e-10)
assert len(got)==42 and (got['count']==3).all()
rg=pd.read_csv(H/'current/data/run_group_rmse.csv')
b=rg[rg.level=='all'].pivot(index=['dataset','backbone','seed','protocol'],columns='method',values='rmse').reset_index()
want=pd.read_csv(H/'presentation/COHERENT_PIR_EFFECTS.csv')
for row in want.itertuples():
    q=b[b.protocol==row.protocol]
    gains=100*(1-q[row.method]/q[row.comparator])
    groups=q.assign(gain=gains).groupby(['dataset','backbone']).gain.mean()
    np.testing.assert_allclose(gains.mean(),row.gain_percent,rtol=1e-12,atol=1e-10)
    assert (groups>0).sum()==row.groups_improving and len(groups)==row.groups
print('COHERENT_PIR_PASS: 42 three-run means/SDs and 12 existing-record paired contrasts; no training or release-policy execution.')
