# Online Resource 2 — compact integrated v11

This is the single OR2 file for the frozen AI-declaration manuscript. It
combines the current numerical records and the latest verification addendum.
Original complete archives remain preserved locally; this package removes
repeated archives, prediction/context caches, checkpoints and detailed logs.

## Check

Use Python3.11 with NumPy and pandas (versions in requirements.txt):

    python check_all.py

This verifies file hashes, window/continuous arithmetic, training-run mean/SD,
Table8 costs and paired gains, seven-dataset uncertainty, all retained node-to-
level results, and recorded protection-check summaries. It also checks all
23 Supplement result tables (2,188 numeric components) and the twelve Li
level comparisons. No neural training or forecast-release optimization is run.

## Contents

- current/data and current/derived: current unrounded results, paired changes,
  protection costs, complete/monthly level results and statistical summaries.
- process: node RMSEs, node definitions and per-stream/method check records.
- supplement: retained empirical-table checks and Li-level/node scope data.
- historical: only result/process records supporting the retained domain,
  order, recent-method, timing and numerical-event analyses.

Protected PIR means CPOR projection of the same reconciled PIR candidate.
Comparisons with common/two-group shrinkage use identical candidates and
separate actual-error allowance paths. Different-target comparisons measure
complete procedures. All negative cases are retained.

Li intermediate levels include every nonsystem, nonbottom observed node;
Labour includes8 regions and16 sex-region series. The legacy Labour-early
middle label used only the latter16; the explicit corrected scope and node
records are integrated here. No measured prediction was changed.

The retained check records are results of the original exact audits. This
compact package does not contain per-date prediction/observation arrays and
cannot independently rerun those exact arithmetic audits or retrain models.
The original full local OR2 remains unchanged. Fixed code/configuration:
https://github.com/kavin027/CPOR/tree/scientific-review-20261109 .


Current Coherent PIR display update (9 November 2026): presentation/COHERENT_PIR_TABLES.csv supplies the 42 three-run means and SDs added to main Tables 6-7 and Supplement S1-S6. presentation/COHERENT_PIR_EFFECTS.csv supplies reconciliation, protection and paired-procedure contrasts. check_all.py also invokes check_coherent_pir.py. All pre-existing numerical records remain byte-identical. No new model or release experiment.
