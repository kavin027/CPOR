# OR2 v8 — table-note revision

Current manuscript: 29 main pages, 20 supplementary pages, one-page cover letter. This revision changes three explanatory table notes only; no experimental result, saved trajectory, numerical record or checker is changed.

- Main Table 14: one AEMO month and one initialization per backbone. Overall percentages average the two within-backbone paired percentages equally.
- Supplement Table S23: six datasets are the analysis units. The empirical intervals are unadjusted; Holm correction covers the two retrospective contrasts.
- Supplement Table S26: positive reductions mean lower RMSE; positive costs mean higher RMSE than direct release.

The local-freeze and evidence-scope changes already present in v7 remain in aemo_minor/EVIDENCE_SCOPE.md. Original protocols and hashes stay unchanged. Existing result checks:

    python aemo_october/check_current.py
    python aemo_october/check_package.py
    python pir_matched/check_pir.py
    python pir_grouped/check_grouped.py
    python projection_order/check_addendum.py

For file identification, the current upload PDFs are named CPOR_Manuscript_v8_Clean.pdf, CPOR_Supplement_v8_Clean.pdf and CPOR_Cover_Letter_v8.pdf. Their hashes are in the repository release receipt. This avoids confusing the current manuscript with the previously reviewed v6 PDFs.
