# CPOR numerical resources — OR2 v9

Current AEMO results use three backbone training runs per PatchTST/DLinear stream, one continuous October trajectory and unchanged Cov/ML configurations. See CURRENT_VERSION.json for exact table-to-file mapping. Original six-benchmark results and the original single-run AEMO study remain unchanged.

From this extracted directory:

    python aemo_three_runs/check_current.py
    python aemo_three_runs/check_results.py --self-test

The aggregate checker rebuilds RMSE and paired percentages from saved forecasts using NumPy and the standard library. The second checker independently verifies every protected trajectory's exact nodewise envelope/prefix limits, and floating-point coherence. These commands do not retrain backbones or rerun optimizers.

Historical six-benchmark checks:

    python pir_matched/check_pir.py
    python pir_grouped/check_grouped.py
    python projection_order/check_addendum.py

The original one-run AEMO files are under aemo_october. The current extension is under aemo_three_runs. It was registered after reviewing the original validation and is not a new untouched confirmation. The earlier pre-acquisition outcome registration and source receipts are retained. All methods use finalized observations under sequential feedback, not reconstructed historical data vintages.

The archive includes current streams, candidates, reference forecasts, observations, release arrays, selection records, source closure and numerical-operation logs. Original neural checkpoints and all source ZIPs are not required for these saved-trajectory checks. Training, data acquisition and optimizer execution remain separate operations documented by their source/record hashes.
