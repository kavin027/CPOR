"""Length-generalized canonical Cov/ML and baseline publication drivers."""
from aemo_extension_common import *
import time,inspect,types,importlib.util
from fractions import Fraction as F
from threadpoolctl import threadpool_limits
sys.path.insert(0,str(O/'cpor_duet_stream_20261106'))
import evaluate as duet
sys.path.insert(0,str(O/'pir_grouped_release_20261106'))
from grouped import grouped
c=duet.c;old=duet.cpu.old;fresh=duet.cpu.fresh
ns=duet.ns;R=F(40401,40000);K=R-1
def pin():
    verify();files={str(Path(m.__file__).resolve()) for m in list(sys.modules.values()) if getattr(m,'__file__',None) and Path(m.__file__).suffix=='.py' and Path(m.__file__).resolve().is_relative_to(ROOT)}
    files={p for p in files if Path(p).is_file() and '.runtime' not in Path(p).parts}
    files.update(str(p) for p in H.glob('*.py'))
    path=H/'AMENDMENT_implementation_closure.json'
    if path.exists():
        for p,h in json.loads(path.read_text())['sources'].items():assert sha(p)==h,p
    else:js(path,dict(registration_sha256=sha(H/'REGISTRATION.json'),reason='Pin imported canonical implementation closure before scoring the new Cov/ML grid; only extend array lengths.',sources={p:sha(p) for p in sorted(files)}))
def context(bb,seed):
    d=folder(bb,seed);p=d/'context.npz'
    if p.exists():return load(p)
    base=load(d/'models'/bb/'raw.npz');wide=pd.read_csv(OLD/'observed.csv',parse_dates=['ds']).set_index('ds')
    raw=base['raw'][108:];start=int(base['start'])-36;S=base['S'];y=wide.iloc[start:].to_numpy()
    assert raw.shape==y.shape==(1524,6)
    v=wide.iloc[:start].var(ddof=0).to_numpy();v=np.maximum(v,max(1e-12,1e-6*np.median(v[v>1e-12])))
    b,ub=old.project(S,raw)
    begun=time.perf_counter();bank=fresh.expert_bank(wide,raw,v,start);bank_seconds=time.perf_counter()-begun
    assert bank.shape==(1524,6,9)
    cov=[];cov_times=[];ml=[];ml_times=[];w=np.full((6,9),1/9);regrets=np.zeros_like(w);squares=np.zeros_like(w)
    scaled=bank/np.sqrt(v)[None,:,None];labels=y/np.sqrt(v)[None,:]
    for t in range(len(y)):
        tick=time.perf_counter()
        wc=np.full_like(bank[t],1/9) if not t else fresh.weights(old.cov.moment(bank[:t],y[:t],v,t),old.cov)
        cov.append((bank[t]*wc).sum(1));cov_times.append(time.perf_counter()-tick)
        tick=time.perf_counter();pm=(scaled[t]*w).sum(1);ml.append(pm*np.sqrt(v))
        r=2*(pm-labels[t])[:,None]*(pm[:,None]-scaled[t]);regrets+=r;squares+=r*r
        q=np.maximum(regrets,0)/(1+squares);total=q.sum(1,keepdims=True);w=np.divide(q,total,out=np.full_like(q,1/9),where=total>0)
        ml_times.append(time.perf_counter()-tick)
    covraw=np.array(cov);mlraw=np.array(ml);cov,uc=old.project(S,covraw,v);ml,um=old.project(S,mlraw,v)
    expert=np.stack([old.project(S,bank[:,:,j],v)[0] for j in range(9)],axis=2)
    cal=np.sqrt(((expert[:36]-y[:36,:,None])**2).mean(0)).mean(0);chosen=int(cal.argmin())
    cb,ucb=old.project(S,bank[:,:,chosen],v)
    x=dict(raw=raw,truth=y,S=S,v=v,b=b,ub=ub,bank=bank,CovRaw=covraw,CovTarget=cov,CovU=uc,MLRaw=mlraw,MLTarget=ml,MLU=um,CalBest=cb,CalBestU=ucb,chosen=np.array(chosen))
    if seed==42:
        prev=load(OLD/'results'/bb/'trajectories.npz')
        for name,key in [('reference','b'),('reference_u','ub')]:np.testing.assert_array_equal(prev[name],x[key][36:])
        np.testing.assert_array_equal(prev['v'],v)
    # Prefix replay gate: generalized selectors equal the original 108-date implementation.
    gate=d/'selector_gate';gate.mkdir(exist_ok=True)
    short={k:a[:108] if isinstance(a,np.ndarray) and a.ndim and len(a)==1524 else a for k,a in x.items()}
    old_common=duet.cpu.saved;old_h=old_common.H
    try:
        old_common.H=H
        if not (gate/'controls.npz').exists():old_common.controls(gate,short,expert[:108],bank[:108])
        check=load(gate/'controls.npz');np.testing.assert_array_equal(check['MLPol'],ml[36:108]);np.testing.assert_array_equal(check['CalBest'],cb[36:108])
    finally:old_common.H=old_h
    np.savez_compressed(p,**x)
    js(d/'CONTEXT_READY.json',dict(sha256=sha(p),chosen_expert=chosen,calibration_rmse=cal.tolist(),bank_seconds=bank_seconds,cov_seconds=sum(cov_times[36:]),ml_seconds=sum(ml_times[36:]),cov_ms_p95=float(np.quantile(cov_times[36:],.95)*1000),ml_ms_p95=float(np.quantile(ml_times[36:],.95)*1000),original_prefix_selector_gate=True))
    return x
def exactcheck(x,p,u,domain='nonnegative',protected=False):
    b=x['b'][36:];y=x['truth'][36:];A=[F(0)]*6;ever=set();events=envelope=0;active=outside=0
    for t,(bb,pp,yy) in enumerate(zip(b,p,y)):
        bq,pq,yq=ns['exact'](bb),ns['exact'](pp),ns['exact'](yy)
        for i,(beta,z,label) in enumerate(zip(bq,pq,yq)):
            g=z*z-R*beta*beta if domain=='nonnegative' and z>R*beta else R*(z-beta)**2/K
            envelope+=int(g>A[i]);outside+=int(R*(z-beta)**2/K>A[i]);active+=int(A[i]>R*K*beta*beta)
            A[i]+=R*(beta-label)**2-(z-label)**2
            if A[i]<0:events+=1;ever.add(i)
    coh=float(np.max(np.abs(p-u@x['S'].T))) if u is not None else None
    if u is not None:assert u.min()>=0 and np.allclose(p,u@x['S'].T,rtol=1e-8,atol=2e-6)
    if protected:assert not events and not envelope,(events,envelope)
    return dict(node_date_checks=p.size,ever_violating_nodes=len(ever),violating_node_dates=events,envelope_failures=envelope,max_coherence_abs=coh,extra_region_node_dates=outside,large_allowance_node_dates=active,final_allowances=[float(a) for a in A])
def numeric(v):
    if isinstance(v,dict):return {str(k):numeric(z) for k,z in v.items()}
    if isinstance(v,(tuple,list)):return [numeric(z) for z in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,F):return str(v)
    return v
def publish(x,z,rule='Full',domain='nonnegative'):
    k=c.kernels(domain);S=x['S'];qp=k['old'].SafeProjection(S,x['v']);A=[F(0)]*6;ps=[];us=[];logs=[]
    if rule=='Cov':
        f=k['cov'];tree=ast.parse(inspect.getsource(f));fn=tree.body[0]
        loop=next(a for a in fn.body if isinstance(a,ast.For))
        loop.body.insert(0,ast.parse('_tick_aemo=__aemo_time.perf_counter_ns()').body[0])
        loop.body.append(ast.parse("stats[-1]['publication_ms']=(__aemo_time.perf_counter_ns()-_tick_aemo)/1e6").body[0])
        ast.fix_missing_locations(tree);g=dict(f.__globals__,__aemo_time=time);exec(compile(tree,'canonical_cov_timing_only','exec'),g)
        start=time.perf_counter();out=g[fn.name](x,z,'Full');elapsed=time.perf_counter()-start
        return out['pred'],out['witness'],out['stats'],elapsed
    start=time.perf_counter()
    for j in range(len(z)):
        t=j+36;b=x['b'][t];bq=ns['exact'](b);tick=time.perf_counter_ns()
        if rule=='Common':
            p,w=ns['ray'](b,z[j],bq,A);u=(1-w)*x['ub'][t]+w*np.array([*z[j,1:]])
            info=dict(contraction=w)
        elif rule=='TwoGroup':
            mask=np.array([0,1,2]);p,u,w,repair=grouped(S[:,mask],mask,b,x['ub'][t],z[j],z[j,1:],A,bq,1/x['v'],ns,float(R));info=dict(weights=w,repair=repair)
        else:p,u,info=k['ml'](qp,S,b,x['ub'][t],z[j],A)
        assert k['certified'](b,p,A,R,K)
        info['publication_ms']=(time.perf_counter_ns()-tick)/1e6
        ps.append(p);us.append(u);logs.append(info)
        A=ns['settle'](bq,ns['exact'](p),ns['exact'](x['truth'][t]),A)
        if (j+1)%360==0:print('RELEASE',rule,domain,j+1,flush=True)
    return np.array(ps),np.array(us),logs,time.perf_counter()-start
def savearm(d,x,name,z,u=None,protected=False,logs=None,elapsed=None,domain='nonnegative'):
    path=d/(name+'.npz');assert z.shape==(1488,6) and np.isfinite(z).all()
    audit=exactcheck(x,z,u,domain,protected)
    args=dict(pred=z)
    if u is not None:args['witness']=u
    np.savez_compressed(path,**args)
    js(path.with_suffix('.json'),dict(sha256=sha(path),audit=audit,elapsed_seconds=elapsed,logs=numeric(logs),protected=protected,domain=domain))
    print('ARM_READY',name,flush=True)
def ready(d,name):
    p=d/(name+'.json')
    if p.exists():assert sha(d/(name+'.npz'))==json.loads(p.read_text())['sha256'];return True
    return False
def run(bb,seed):
    pin();d=folder(bb,seed)/'results';d.mkdir(parents=True,exist_ok=True);x=context(bb,seed)
    for name,key,uk in [('Raw','raw',None),('NNLS','b','ub'),('CovTarget','CovTarget','CovU'),('MLTarget','MLTarget','MLU'),('CalBest','CalBest','CalBestU')]:
        if not ready(d,name):savearm(d,x,name,x[key][36:],x[uk][36:] if uk else None,name=='NNLS')
    arms=[('CPOR-Cov','CovTarget','Cov','nonnegative'),('CPOR-ML','MLTarget','Full','nonnegative'),('ProtectedCalBest','CalBest','Full','nonnegative'),('CovCommon','CovTarget','Common','nonnegative'),('MLCommon','MLTarget','Common','nonnegative'),('CovAllReal','CovTarget','Cov','real'),('MLAllReal','MLTarget','Full','real')]
    for name,key,rule,domain in arms:
        if ready(d,name):continue
        p,u,logs,elapsed=publish(x,x[key][36:],rule,domain);savearm(d,x,name,p,u,True,logs,elapsed,domain)
    W,C,lam,floor=duet.cpu.classic.covariance(x['raw'][:36]-x['truth'][:36])
    for arm in ['WLSstruct','WLSvar','MinTshrink','RollingMinT_Raw','WLSvar_Cov','MinT_Cov','MinT_CalBest']:
        if ready(d,arm):z=load(d/(arm+'.npz'))['pred']
        else:
            tick=time.perf_counter()
            if arm=='RollingMinT_Raw':
                zz=[];uu=[]
                for t in range(36,len(x['truth'])):
                    WW,*_=duet.cpu.classic.covariance(x['raw'][t-36:t]-x['truth'][t-36:t]);p,u,_=duet.cpu.classic.target(x['S'],x['raw'][t:t+1],WW);zz.append(p[0]);uu.append(u[0])
                z,u=np.array(zz),np.array(uu)
            else:
                if arm in ['WLSstruct','WLSvar','MinTshrink']:
                    Z=x['raw'];WW={'WLSstruct':np.diag(x['S'].sum(1)),'WLSvar':np.diag(np.maximum(np.diag(C),floor)),'MinTshrink':W}[arm]
                else:
                    Z=x['CovRaw'] if arm.endswith('_Cov') else x['bank'][:,:,int(x['chosen'])]
                    WW,CC,ll,ff=duet.cpu.classic.covariance(Z[:36]-x['truth'][:36])
                    if arm.startswith('WLS'):WW=np.diag(np.maximum(np.diag(CC),ff))
                z,u,_=duet.cpu.classic.target(x['S'],Z[36:],WW)
            savearm(d,x,arm,z,u,elapsed=time.perf_counter()-tick)
        if not ready(d,'Protected'+arm):
            p,u,logs,elapsed=publish(x,z);savearm(d,x,'Protected'+arm,p,u,True,logs,elapsed)
    pir=load(folder(bb,seed)/'models'/bb/'pir.npz')['pred'];z,u=old.project(x['S'],pir,x['v'])
    for name,p,rep in [('PIR',pir,None),('PIRCoherent',z,u)]:
        if not ready(d,name):savearm(d,x,name,p,rep)
    for name,rule in [('PIRCommon','Common'),('PIRTwoGroup','TwoGroup'),('PIRFull','Full')]:
        if ready(d,name):continue
        if seed==42:
            prev=load(OLD/'results'/bb/'trajectories.npz');np.testing.assert_array_equal(z,prev['candidate']);np.testing.assert_array_equal(x['b'][36:],prev['reference'])
            key={'PIRCommon':'Common','PIRTwoGroup':'TwoGroup','PIRFull':'Full'}[name]
            steps=pd.read_csv(OLD/'results'/bb/'steps.csv');logs=steps.loc[steps.arm==key].to_dict('records')
            savearm(d,x,name,prev[key],prev[key+'_u'],True,logs,None)
        else:
            p,rep,logs,elapsed=publish(x,z,rule);savearm(d,x,name,p,rep,True,logs,elapsed)
    js(d/'CPU_DONE.json',dict(backbone=bb,initialization=seed,registration_sha256=sha(H/'REGISTRATION.json'),covariance_shrinkage=lam))
if __name__=='__main__':
    with threadpool_limits(1):
        if sys.argv[1]=='pin':pin()
        else:run(sys.argv[1],int(sys.argv[2]))
