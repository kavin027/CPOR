"""Matched classical reconciliation; no neural fitting or test-set tuning."""
from pathlib import Path
import argparse,sys,importlib.util,json,hashlib,time,datetime,ast
import numpy as np
from scipy.linalg import solve_triangular
from scipy.optimize import nnls,lsq_linear
from fractions import Fraction as F
O=Path(__file__).resolve().parent;R=O.parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=Path,default=R/'output/kais_review4_20261016/Online_Resource_3/replay_inputs');ap.add_argument('--checkout',type=Path,default=R/'output/kais_minor3_20261016/Online_Resource_1/replay_checkout');ap.add_argument('--out',type=Path,default=O);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
root=a.checkout/'output/paired_root_actual_credit_20261013/numerical_v2';sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('classical_frozen_driver',root/'run.py');frozen=importlib.util.module_from_spec(spec);spec.loader.exec_module(frozen);old=frozen.original
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2),encoding='utf-8')
arms=['WLSstruct','WLSvar','MinTshrink'];RR=F(40401,40000)

def covariance(e):
 T,n=e.shape;X=e-e.mean(0);C=X.T@X/(T-1);eps=2e-8
 Z=X/(e.std(0)+eps);Z-=Z.mean(0)
 idx=np.tril_indices(n,-1);products=Z[:,idx[0]]*Z[:,idx[1]]
 means=products.mean(0);num=np.square(products-means).sum()/(T*(T-1));den=np.square(means).sum()
 lam=float(np.clip(num/(den+eps),0,1));floor=max(1e-8,1e-10*float(np.median(np.diag(C))))
 W=(1-lam)*C+lam*np.diag(np.diag(C));W[np.diag_indices(n)]=np.maximum(np.diag(W),floor)
 return W,C,lam,floor

def weights(x):
 W,C,lam,floor=covariance(x['raw'][:36]-x['truth'][:36])
 return {'WLSstruct':np.diag(x['S'].sum(1)), 'WLSvar':np.diag(np.maximum(np.diag(C),floor)), 'MinTshrink':W},dict(shrinkage_to_diagonal=lam,variance_floor=floor,calibration_rows=36)

def target(S,raw,W):
 L=np.linalg.cholesky(W);design=solve_triangular(L,S,lower=True);Y=solve_triangular(L,raw.T,lower=True).T
 scale=np.linalg.norm(design,axis=0);active=scale>0;M=design[:,active]/scale[active];us=[];errors=[];fallbacks=0
 for y in Y:
  try:w,_=nnls(M,y,maxiter=100*len(scale))
  except RuntimeError:
   sol=lsq_linear(M,y,bounds=(0,np.inf),tol=1e-12,max_iter=2000);assert sol.success;w=sol.x;fallbacks+=1
  grad=M.T@(M@w-y);den=max(1.,np.max(abs(M.T@y)))
  err=max(float(np.maximum(-grad,0).max()/den),float(abs(w*grad).max()/max(1.,np.linalg.norm(y)**2)))
  assert err<=1e-7,(err,'NNLS optimality')
  u=np.zeros(S.shape[1]);u[active]=w/scale[active];us.append(u);errors.append(err)
 U=np.array(us);return U@S.T,U,dict(max_scaled_kkt=max(errors),nnls_fallbacks=fallbacks)

def protect(x,z):
 A=[F(0) for _ in x['v']];qp=old.SafeProjection(x['S'],x['v']);rows=[];us=[];logs=[]
 for j,t in enumerate(range(36,108)):
  if j:A=old.advance(A,x['b'][t-1],rows[-1],x['truth'][t-1])
  p,u,info=old.one_action(qp,x['S'],x['b'][t],x['ub'][t],z[j],A)
  assert old.certified(x['b'][t],p,A,old.RR,old.K,True)
  rows.append(p);us.append(u);logs.append({k:v for k,v in info.items() if np.isscalar(v)})
 old.advance(A,x['b'][-1],rows[-1],x['truth'][-1]);return np.array(rows),np.array(us),logs

def audit(x,p,u):
 A=[F(0) for _ in x['v']];pre=post=0
 for b,pred,y in zip(x['b'][36:],p,x['truth'][36:]):
  for i,(bf,pf,yf) in enumerate(zip(b,pred,y)):
   bf,pf,yf=F(float(bf)),F(float(pf)),F(float(yf));gamma=pf*pf-RR*bf*bf if pf>RR*bf else RR*(pf-bf)**2/(RR-1)
   assert gamma<=A[i];pre+=1;A[i]+=RR*(bf-yf)**2-(pf-yf)**2;assert A[i]>=0;post+=1
 assert (u>=0).all() and np.allclose(p,u@x['S'].T,rtol=1e-8,atol=2e-6)
 return dict(pre_checks=pre,prefix_checks=post,violations=0,max_scaled_coherence=float((abs(p-u@x['S'].T)/np.maximum(1,abs(p))).max()))

# Numerical gates before baseline scores: estimator agrees with the published
# implementation, zero residuals are handled, and test rows cannot change W.
tree=ast.parse((O/'hierarchicalforecast_utils_1.3.0.txt').read_text());fn=next(z for z in tree.body if isinstance(z,ast.FunctionDef) and z.name=='_shrunk_covariance_schaferstrimmer_no_nans');fn.decorator_list=[]
ns={'np':np,'prange':range};exec(compile(ast.Module(body=[fn],type_ignores=[]),'upstream_reference','exec'),ns)
rng=np.random.default_rng(42);e=rng.normal(size=(36,9));W,C,lam,floor=covariance(e)
assert np.allclose(W,ns[fn.name](e.T,floor),rtol=1e-12,atol=1e-12)
assert np.linalg.eigvalsh(covariance(np.zeros((36,9)))[0]).min()>0
cells=[];inputs={}
for d in sorted(a.inputs.iterdir()):
 c=json.loads((d/'cell.json').read_text())
 if c['seed']!=42:continue
 cells.append((d,c));inputs[d.name]={f:sha(d/f) for f in ['cell.json','endpoints.npz','expected.npz']}
assert len(cells)==22
sources={str(Path(m.__file__).relative_to(a.checkout)):sha(Path(m.__file__)) for m in list(sys.modules.values()) if getattr(m,'__file__',None) and Path(m.__file__).suffix=='.py' and Path(m.__file__).is_relative_to(a.checkout)}
reg=dict(seed=42,configs=22,calibration=36,score=72,arms=arms,source_sha256=sha(Path(__file__)),frozen_source_hashes=sources,inputs=inputs,
 protocol='Freeze covariance from the 36 pre-score raw forecast residuals; no mean-bias correction. NNLS in whitened coordinates; OLS is reused anchor. Each wrapper uses original SafeProjection with diag(1/v), exact rational guard, its own zero initial actual account and R=40401/40000. No model tuning or selection on scored labels.',
 covariance='Centered sample covariance, ddof=1. WLSstruct diag(S 1), WLSvar sample variances. MinT diagonal-target Schafer-Strimmer shrinkage, numerically matched to HierarchicalForecast v1.3.0; floor=max(1e-8,1e-10 median variance).',
 metrics='Average window mean-node RMSE within dataset/backbone, then percentage C0 gains and win counts across 10 development and 2 M5 groups; MAE/nMSE secondary. Protected/unprotected costs, node/layer results, all failures retained.',
 status='Retrospective additional baseline evaluation on previously used datasets; not untouched confirmation.',gates='Synthetic covariance/reference equality and zero variance passed; per-solve KKT and per-node exact account audits required.')
rp=a.out/'REGISTRATION.json'
if rp.exists():
 prior=json.loads(rp.read_text());reg['registered_utc']=prior['registered_utc']
 if reg['source_sha256']!=prior['source_sha256']:
  assert sha(O/'run_registered_v1.py')==prior['source_sha256']
  save(a.out/'AMENDMENT_1.json',dict(old_source_sha256=prior['source_sha256'],new_source_sha256=reg['source_sha256'],reason='Integer Wiki2 labels require float copy only for the synthetic no-leakage perturbation. No estimator, target, protection or scoring change; reuse completed outputs.',registration_sha256=sha(rp)))
  reg['source_sha256']=prior['source_sha256']
 assert reg==prior
else:
 reg['registered_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(rp,reg)
for d,c in cells:
 dest=a.out/'results'/d.name;dest.mkdir(parents=True,exist_ok=True)
 x=dict(np.load(d/'endpoints.npz'));C0=np.load(d/'expected.npz')['pred'];assert C0.shape==x['truth'][36:].shape
 Ws,meta=weights(x);changed={**x,'truth':x['truth'].astype(float).copy()};changed['truth'][36:]+=1e9
 assert all(np.array_equal(W,weights(changed)[0][k]) for k,W in Ws.items())
 for arm in arms:
  file=dest/f'{arm}.npz'
  if file.exists():assert sha(file)==json.loads(file.with_suffix('.json').read_text())['sha256'];continue
  started=time.perf_counter();z,u,check=target(x['S'],x['raw'][36:],Ws[arm]);fit_seconds=time.perf_counter()-started
  p,up,logs=protect(x,z);aud=audit(x,p,up)
  np.savez_compressed(file,unprotected=z,unprotected_witness=u,protected=p,protected_witness=up)
  receipt=dict(cell=c,method=arm,sha256=sha(file),registration_sha256=sha(rp),covariance=meta,numerical=check,audit=aud,target_seconds=fit_seconds,total_seconds=time.perf_counter()-started,protection_logs=logs)
  save(file.with_suffix('.json'),receipt);print('DONE',d.name,arm,round(receipt['total_seconds'],2),flush=True)
 # Anchor predictions are reused, rather than solved again with different roundoff.
 audit(x,x['b'][36:],x['ub'][36:])
save(a.out/'COMPLETE.json',dict(configs=22,new_target_trajectories=66,new_protected_trajectories=66,reused_C0=22,reused_OLS_and_protected_OLS=22,registration_sha256=sha(rp)))
