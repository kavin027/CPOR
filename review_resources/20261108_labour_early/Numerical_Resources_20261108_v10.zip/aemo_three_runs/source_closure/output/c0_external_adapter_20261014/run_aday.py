from pathlib import Path
import ast,sys,json,hashlib,copy,time,random,argparse,importlib.util
import numpy as np
import torch
import torch.nn.functional as F
HERE=Path(__file__).resolve().parent;O=HERE.parent
sys.path.insert(0,str(O/'c0_external_sota_20261014'));import pir_adapter as shared
from pir_run import CELLS as OLD_CELLS
AUTHOR=HERE/'author_core/Adapter-0add06ea7b4d2e0a84c364a8be72eef2676a92f2'
SOURCE=AUTHOR/'Adapter-X+Y/experiments/exp_online_y_mul.py'
tree=ast.parse(SOURCE.read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PostProcessingNet')
exec(compile(ast.Module(body=[node],type_ignores=[]),str(SOURCE),'exec'),globals())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
CELLS=[('original',*c) for c in OLD_CELLS]+[('M5','M5',bb,w) for bb in ['PatchTST','DLinear'] for w in ['early','late']]

def load(cell):
    family,ds,bb,w=cell
    if family=='original':d=shared.load((ds,bb,w));return dict(raw=d['raw'][:,0],y=d['y'][:,0],mu=d['mu'],sd=d['sd'],score_start=d['score_start'],train_count=d['train_count'],score_raw=d['score_raw'],truth=d['truth'],S=d['S'],inputs=d['inputs'])
    root=O/'c0_frozen_m5_20261014';folder=root/'results'/bb/w/'42';p=folder/'raw.npz';s=np.load(p);a={k:s[k] for k in s.files if k!='dates'}
    wide=shared.pd.read_csv(root/'observed.csv',parse_dates=['ds']).set_index('ds');train_end=int(a['start'])-36;v=wide.to_numpy();mu=v[:train_end].mean(0);sd=v[:train_end].std(0);sd=np.where(sd>0,sd,1.)
    return dict(raw=((a['raw']-mu)/sd).astype('float32'),y=((a['truth']-mu)/sd).astype('float32'),mu=mu,sd=sd,score_start=144,train_count=108,score_raw=a['raw'][-72:],truth=a['truth'][-72:],S=a['S'],inputs={str(p.resolve()):sha(p),str((root/'observed.csv').resolve()):sha(root/'observed.csv')})

def sources():
    result={str(p.resolve()):sha(p) for p in [Path(__file__),HERE/'admission.py',HERE/'PROTOCOL.md',HERE/'CORE_SOURCE_RECEIPT.json',HERE/'DISCOVERY_REGISTRATION.json',SOURCE,AUTHOR/'Adapter-X+Y/run_xy_mul.py',AUTHOR/'Adapter-X+Y/run_xy.sh']}
    result.update(json.loads((O/'c0_external_sota_20261014/PIR_REGISTRATION.json').read_text())['sources'])
    return result

def registration():
    p=HERE/'REGISTRATION.json';ad=json.loads((HERE/'ADMISSION.json').read_text());assert ad['passed'] and ad['sources']==sources()
    data={}
    for c in CELLS:data.update(load(c)['inputs'])
    reg=dict(sources=sources(),inputs=data,cells=CELLS,seed=42,config=dict(hidden=512,delta=.2,epochs=10,lr=.0001,batch=32,patience=3,
        branch='published standalone Ada-Y batch, multiplicative',normalization='historical before36cal',horizon=1),
        admission_sha256=sha(HERE/'ADMISSION.json'),M5_comparative_scoring_not_yet_done=True,no_proposed_method_change=True,original_paper_protocol_reproduction=False)
    reg=json.loads(json.dumps(reg))
    if p.exists():assert json.loads(p.read_text())==reg
    else:
        assert not (O/'c0_frozen_m5_20261014/CONFIRMATION_RESULT.json').exists()
        p.write_text(json.dumps(reg,indent=2),encoding='utf-8')
    return p

def run(ci,reg):
    cell=CELLS[ci];d=load(cell);folder=HERE/'results'/('/'.join(cell)+'/42');folder.mkdir(parents=True,exist_ok=True);p=folder/'AdaYBatch.npz';j=p.with_suffix('.json')
    if j.exists():old=json.loads(j.read_text());assert old['sha256']==sha(p) and old['registration_sha256']==sha(reg);return
    torch.manual_seed(42);np.random.seed(42);random.seed(42);device='cuda' if torch.cuda.is_available() else 'cpu'
    raw=torch.as_tensor(d['raw'],device=device);y=torch.as_tensor(d['y'],device=device);n=raw.shape[1];model=PostProcessingNet(n,512,n,.2).float().to(device)
    opt=torch.optim.Adam(model.parameters(),lr=.0001);best=float('inf');state=None;wait=0;logs=[];started=time.perf_counter()
    for epoch in range(10):
        model.train();order=torch.randperm(d['train_count'],device=device);train=[]
        for first in range(0,len(order),32):
            ids=order[first:first+32];opt.zero_grad();p0=raw[ids]*model(raw[ids]);loss=(p0-y[ids]).square().mean();assert torch.isfinite(loss);loss.backward();opt.step();train.append(float(loss.detach()))
        model.eval()
        with torch.no_grad():
            val=[]
            for first in range(d['train_count'],d['score_start'],32):
                z=raw[first:min(first+32,d['score_start'])];pred=z*model(z);val.append(float((pred-y[first:first+len(z)]).square().mean()))
        score=float(np.mean(val));logs.append(dict(epoch=epoch+1,train_mse=float(np.mean(train)),validation_mse=score))
        if score<best:best=score;state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()};wait=0
        else:wait+=1
        if wait>=3:break
        for group in opt.param_groups:group['lr']=.0001*(.5**epoch)
    assert state is not None;model.load_state_dict(state);model.eval()
    with torch.no_grad():
        factor=model(raw[d['score_start']:]);assert factor.min()>=.8-1e-6 and factor.max()<=1.2+1e-6
        pred=(raw[d['score_start']:]*factor).cpu().numpy()*d['sd']+d['mu']
    assert pred.shape==d['truth'].shape and len(pred)==72 and np.isfinite(pred).all()
    np.savez_compressed(p,pred=pred,raw=d['score_raw'],truth=d['truth'],factor=factor.cpu().numpy(),S=d['S']);torch.save(state,folder/'adapter.pt')
    j.write_text(json.dumps(dict(sha256=sha(p),registration_sha256=sha(reg),cell=cell,seed=42,inputs=d['inputs'],epochs=logs,
        train_count=d['train_count'],validation_count=36,scored_count=72,checkpoint_sha256=sha(folder/'adapter.pt'),seconds=time.perf_counter()-started),indent=2))
    print('ADAY_COMPLETED',ci,cell,flush=True);del model,raw,y;torch.cuda.empty_cache()

if __name__=='__main__':
    torch.set_num_threads(1);ap=argparse.ArgumentParser();ap.add_argument('--cell',type=int);args=ap.parse_args();reg=registration()
    for ci in ([args.cell] if args.cell is not None else range(len(CELLS))):run(ci,reg)
    (HERE/'RUN_STATUS.json').write_text(json.dumps(dict(required=22,completed=sum((HERE/'results'/('/'.join(c)+'/42')/'AdaYBatch.json').exists() for c in CELLS))))
