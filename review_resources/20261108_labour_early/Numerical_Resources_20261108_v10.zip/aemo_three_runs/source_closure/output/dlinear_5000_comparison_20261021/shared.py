from pathlib import Path
import json,hashlib,sys,importlib.util
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent
R=H.parents[1]
O=R/'output'
VALID=O/'dlinear_budget_validation_20261021'
CELLS=[c for c in json.loads((O/'kais_review_response_20261016/Online_Resource_1/cells.json').read_text()) if c['backbone']=='DLinear']
assert len(CELLS)==11
DS=['RH','ECommerce','Traffic','Wiki2','Labour','M5']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8');q.replace(p)
def load(p):
    with np.load(p,allow_pickle=False) as x:return {k:x[k] for k in x.files if k!='dates'}
def mod(name,p):
    sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
def datafile(ds):
    if ds=='M5':return O/'c0_frozen_m5_20261014/observed.csv'
    if ds=='Labour':return O/'rr_recap_evidence_extension_20261002/major_revision_20261002/external/data/Labour.csv'
    return O/f'procast_joint_safe_20261001_v4/data/{ds}.csv'
def oldraw(c):
    ds,w=c['dataset'],c['window']
    if ds=='M5':return O/f'c0_frozen_m5_20261014/results/DLinear/{w}/42/raw.npz'
    pre=O/'rr_recap_evidence_extension_20261002'
    if ds=='Labour':pre=pre/'major_revision_20261002/external'
    return pre/f'forecasts/{ds}/DLinear/{w}/42/raw.npz'
def dest(c):return H/'results'/c['dataset']/c['window']
def historymeta(ds):return O/f'rr_recap_trajectory_learning_20261003/history/{ds}/DLinear/complete.json'
def freq(ds):return 'MS' if ds=='Labour' else 'B' if ds=='ECommerce' else 'D'
def plan():
    out=[]
    for ds in DS:
        if ds!='M5':
            m=json.loads(historymeta(ds).read_text())
            for off in range(0,m['count'],72):out.append(dict(dataset=ds,kind='historical_support',window='shared',ix=m['start']+off,count=min(72,m['count']-off)))
        for c in [z for z in CELLS if z['dataset']==ds]:
            a=load(oldraw(c));start=int(a['start'])
            if ds=='M5':out.append(dict(dataset=ds,kind='support_calibration_scoring',window=c['window'],ix=int(a['begin']),count=216))
            else:
                for f in range(4):out.append(dict(dataset=ds,kind=f'fold{f}',window=c['window'],ix=start-36+12*f,count=72 if f==3 else 12))
    assert len({(j['dataset'],j['ix']) for j in out})==len(out)
    return out
def fitdir(job):return H/'fits'/job['dataset']/f"{job['ix']:04d}"
def frozen():
    p=H/'REGISTRATION.json'
    if not p.exists():raise RuntimeError('register before execution')
    j=json.loads(p.read_text(encoding='utf-8'))
    for q,v in j['immutable_inputs'].items():assert sha(q)==v,q
    return j
