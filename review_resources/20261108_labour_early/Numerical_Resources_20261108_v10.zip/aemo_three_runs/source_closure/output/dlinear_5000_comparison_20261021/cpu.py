from shared import *
import time,copy,argparse
from threadpoolctl import threadpool_limits
saved=mod('budget_seed_common',O/'c0_seed_validation_20261016/common.py')
saved.H=H
fresh=saved.fresh;fresh.HERE=H
base=saved.base;old=saved.old;factorial=fresh.factorial
classic=mod('budget_classical',O/'cpor_classical_repetitions_20261020/run.py')
from precision_release import release_repaired

def receipt(p,**kw):js(p.with_suffix('.json'),dict(sha256=sha(p),**kw))

def contexts(c,d,raw_override=None):
    if (d/'CONTEXT_READY.json').exists():
        x=load(d/'endpoints.npz');a=load(d/'contexts.npz');return x,a['D'],a['expert'],a['bank'],a['mixed']
    rp=load(dest(c)/'raw.npz') if raw_override is None else raw_override
    wide=pd.read_csv(datafile(c['dataset']),parse_dates=['ds']).set_index('ds');start=int(rp['start'])
    x,D,expert=fresh.prepare_context(wide,rp['S'],rp['raw'],start)
    bank=fresh.expert_bank(wide,x['raw'],x['v'],start-36)
    mixed=[]
    for t in range(108):
        w=np.full_like(bank[t],1/9) if t==0 else fresh.weights(old.cov.moment(bank[:t],x['truth'][:t],x['v'],t),old.cov)
        mixed.append((bank[t]*w).sum(1))
    mixed=np.array(mixed);proj,_=old.project(x['S'],mixed,x['v'])
    np.testing.assert_allclose(proj,D,rtol=1e-8,atol=2e-6)
    d.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(d/'endpoints.npz',**x);np.savez_compressed(d/'contexts.npz',D=D,expert=expert,bank=bank,mixed=mixed)
    js(d/'CONTEXT_READY.json',dict(endpoint_sha256=sha(d/'endpoints.npz'),context_sha256=sha(d/'contexts.npz')))
    return x,D,expert,bank,mixed

def protected(c,d,x,D,expert,bank):
    if c['dataset']=='M5':fresh.protected(d,x,D,expert)
    else:saved.protected_dev(d,x,D,expert)
    p=d/'CovFullFix.npz'
    if not p.exists():
        start=time.perf_counter();out=release_repaired(x,D[36:],'Full');stats=out.pop('stats');checks=old.audit(x,out,1)
        np.savez_compressed(p,**out,target=D[36:]);receipt(p,checks=checks,seconds=time.perf_counter()-start,stats=stats)
    saved.controls(d,x,expert,bank)
    snaps=load(d/'C0_snapshots.npz');records=[{k:np.array(v[t],copy=True) for k,v in snaps.items()} for t in range(36)]
    E=np.sum((snaps['published'][:36]-x['truth'][:36])**2,axis=0)
    kappa=float(np.sqrt(E).mean()/E.mean()) if E.mean()>0 else 1/float(np.sqrt(x['v'].mean()))
    for arm in ['RootDirectional','SquareDirectional']:
        p=d/(arm+'.npz')
        if p.exists():assert sha(p)==json.loads(p.with_suffix('.json').read_text())['sha256'];continue
        a=factorial.Actor(x['S'],x['v'],arm,records,kappa);rows=[];logs=[];start=time.perf_counter()
        for t in range(36,108):
            row=a.issue(t,x['b'][t],x['ub'][t],D[t],expert[t],None if t==36 else x['truth'][t-1]);logs.append(dict(t=t,fit=row.pop('fit')));rows.append(row)
        out={k:np.array([r[k] for r in rows]) for k in rows[0]};checks=old.audit(x,out,1);a.close(x['truth'][-1]);a.pending=None
        np.savez_compressed(p,**out);np.savez_compressed(d/(arm+'_snapshots.npz'),**{k:np.array([r[k] for r in a.records]) for k in a.records[0]})
        receipt(p,checks=checks,kappa=kappa,seconds=time.perf_counter()-start,logs=logs,failed_publications=int(out['solver_failed'].sum()))
        print('CPU_ARM_DONE',c['dataset'],c['window'],arm,flush=True)

def classical(d,x,expert,bank,mixed):
    folder=d/'classical';folder.mkdir(exist_ok=True)
    chosen=int(np.argmin(np.sqrt(((expert[:36]-x['truth'][:36,:,None])**2).mean(0)).mean(0)))
    inp=dict(Cov=mixed,CalBest=bank[:,:,chosen]);rawW,C,lam,floor=classic.covariance(x['raw'][:36]-x['truth'][:36])
    for arm in classic.arms:
        p=folder/(arm+'.npz')
        if p.exists():assert sha(p)==json.loads(p.with_suffix('.json').read_text())['sha256'];continue
        start=time.perf_counter();meta={}
        if arm=='RollingMinT_Raw':
            ps=[];us=[];details=[]
            for t in range(36,108):
                W,*_=classic.covariance(x['raw'][t-36:t]-x['truth'][t-36:t])
                z,u,info=classic.target(x['S'],x['raw'][t:t+1],W);ps.append(z[0]);us.append(u[0]);details.append(info)
            z,u=np.array(ps),np.array(us);check=dict(max_scaled_kkt=max(a['max_scaled_kkt'] for a in details))
        else:
            if arm in classic.arms[:3]:
                Z=x['raw'];W={'WLSstruct':np.diag(x['S'].sum(1)),'WLSvar':np.diag(np.maximum(np.diag(C),floor)),'MinTshrink':rawW}[arm]
                meta=dict(shrinkage=lam,variance_floor=floor)
            else:
                Z=inp[arm.split('_')[1]];W,CC,ll,ff=classic.covariance(Z[:36]-x['truth'][:36])
                if arm.startswith('WLS'):W=np.diag(np.maximum(np.diag(CC),ff))
                meta=dict(shrinkage=ll,variance_floor=ff)
            z,u,check=classic.target(x['S'],Z[36:],W)
        pp,up,logs=classic.protect(x,z);audit=classic.audit(x,pp,up)
        np.savez_compressed(p,unprotected=z,unprotected_witness=u,protected=pp,protected_witness=up)
        receipt(p,audit=audit,numerical=check,covariance=meta,seconds=time.perf_counter()-start,protection_logs=logs)
        print('CLASSIC_DONE',d.name,d.parent.name,arm,flush=True)

def run(c):
    d=dest(c)
    if (d/'CPU_DONE.json').exists():return
    ready=json.loads((d/'RAW_READY.json').read_text());assert ready['raw_sha256']==sha(d/'raw.npz')
    start=time.perf_counter();x,D,expert,bank,mixed=contexts(c,d)
    np.testing.assert_array_equal(x['raw'][-72:],load(d/'raw.npz')['raw'][-72:])
    print('CPU_START',c['dataset'],c['window'],flush=True)
    protected(c,d,x,D,expert,bank);classical(d,x,expert,bank,mixed)
    js(d/'CPU_DONE.json',dict(seconds=time.perf_counter()-start,endpoint_sha256=sha(d/'endpoints.npz'),registration_sha256=sha(H/'REGISTRATION.json'),
        files={str(p.relative_to(d)):sha(p) for p in d.rglob('*.npz') if 'ProCAST' not in p.name and p.name not in ['raw.npz','full_stream.npz']}))
    print('CPU_DONE',c['dataset'],c['window'],time.perf_counter()-start,flush=True)

def gate():
    c=next(c for c in CELLS if c['dataset']=='RH' and c['window']=='late');d=H/'gate';d.mkdir(exist_ok=True)
    x,D,expert,bank,mixed=contexts(c,d,load(oldraw(c)))
    source=O/'c0_seed_validation_20261016/results/RH/DLinear/late/42'
    expected=load(source/'endpoints.npz');oldctx=load(source/'contexts.npz')
    for k in ['raw','truth','v','b','ub','S']:np.testing.assert_array_equal(x[k],expected[k])
    for k,z in [('D',D),('expert',expert)]:np.testing.assert_allclose(z,oldctx[k],rtol=1e-12,atol=1e-8)
    saved.protected_dev(d,x,D,expert);saved.controls(d,x,expert,bank)
    diffs={}
    for arm in ['C0','SquareFull']:
        a=load(d/(arm+'.npz'))['pred'];b=load(source/(arm+'.npz'))['pred']
        np.testing.assert_allclose(a,b,rtol=1e-8,atol=2e-6);diffs[arm]=float(np.max(abs(a-b)))
    cov=release_repaired(x,D[36:],'Full')['pred'];orig=load(source/'CovFullFix.npz')['pred'];np.testing.assert_allclose(cov,orig,rtol=1e-8,atol=2e-6)
    a,b=load(d/'controls.npz'),load(source/'controls.npz')
    for k in ['MLPol','ProtectedMLPol','CalBest','ProtectedCalBest']:np.testing.assert_allclose(a[k],b[k],rtol=1e-8,atol=2e-6)
    js(H/'CPU_GATE.json',dict(passed=True,prediction_max_absolute_difference=diffs,cov_max_absolute_difference=float(np.max(abs(cov-orig)))))
    print('CPU_GATE_PASSED',diffs,flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--gate',action='store_true');ap.add_argument('--wait',action='store_true');ap.add_argument('--datasets',nargs='+',default=DS);args=ap.parse_args()
    with threadpool_limits(1):
        frozen()
        if args.gate:gate()
        else:
            assert json.loads((H/'CPU_GATE.json').read_text())['passed']
            todo=[c for c in CELLS if c['dataset'] in args.datasets]
            while todo:
                done=[]
                for c in todo:
                    if (dest(c)/'CPU_DONE.json').exists():done.append(c);continue
                    if (dest(c)/'RAW_READY.json').exists():
                        claim=dest(c)/'cpu_claim'
                        try:claim.mkdir()
                        except FileExistsError:continue
                        try:run(c);done.append(c)
                        finally:claim.rmdir()
                todo=[c for c in todo if c not in done]
                if todo:
                    if not args.wait:break
                    time.sleep(5)
