"""Complete registered classical controls on the three existing forecast streams."""
from pathlib import Path
import ast, sys, importlib.util, json, hashlib, time, datetime, argparse
import numpy as np
import pandas as pd
from scipy.linalg import solve_triangular
from scipy.optimize import nnls, lsq_linear
from fractions import Fraction as F
from threadpoolctl import threadpool_limits

H=Path(__file__).resolve().parent; R=H.parents[1]; O=R/'output'
oldrun=O/'c0_classical_matched_20261017/run.py'
checkout=O/'kais_minor3_20261016/Online_Resource_1/replay_checkout'
root=checkout/'output/paired_root_actual_credit_20261013/numerical_v2'
sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('classical_repeat_frozen',root/'run.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);old=base.original
from calibration_contexts import weights
from frozen_core import expert_bank
RR=F(40401,40000)
ns=dict(np=np,nnls=nnls,lsq_linear=lsq_linear,solve_triangular=solve_triangular,F=F,RR=RR,old=old)
names=['covariance','target','audit','protect']
tree=ast.parse(oldrun.read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],
                        type_ignores=[]),'unchanged_classical_functions','exec'),ns)
covariance,target,audit,protect=[ns[k] for k in names]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2),encoding='utf-8')
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files if k!='dates'}
cells=json.loads((O/'kais_review_response_20261016/Online_Resource_1/cells.json').read_text())
arms=['WLSstruct','WLSvar','MinTshrink','RollingMinT_Raw','WLSvar_Cov','MinT_Cov','MinT_CalBest']
def source(c,seed):return O/'c0_seed_validation_20261016/results'/c['dataset']/c['backbone']/c['window']/str(seed)
def key(c,seed):return f"{c['dataset']}_{c['backbone']}_{c['window']}_seed{seed}"
def targets(c,seed,x,ctx):
    d=source(c,seed)
    if c['dataset']=='M5':
        wide=pd.read_csv(O/'c0_frozen_m5_20261014/observed.csv',index_col=0,parse_dates=True)
        rawpath=d/'raw.npz'
        if not rawpath.exists():rawpath=R/Path(c['endpoint_source']).parent/'raw.npz'
        stream=load(rawpath)
        bank=expert_bank(wide,x['raw'],x['v'],int(stream['start'])-36)
    else:
        bank=load(O/'rr_recap_error_dependence_20261003/results'/c['dataset']/c['backbone']/c['window']/str(seed)/'bank.npz')['bank']
    mixed=[]
    for t in range(108):
        w=np.full_like(bank[t],1/9) if t==0 else weights(old.cov.moment(bank[:t],x['truth'][:t],x['v'],t),old.cov)
        mixed.append((bank[t]*w).sum(1))
    mixed=np.array(mixed);projected,_=old.project(x['S'],mixed,x['v'])
    err=float(np.max(abs(projected-ctx['D'])/np.maximum(1,abs(ctx['D']))))
    assert err<1e-5,(key(c,seed),err)
    chosen=int(np.argmin(np.sqrt(((ctx['expert'][:36]-x['truth'][:36,:,None])**2).mean(0)).mean(0)))
    np.testing.assert_allclose(ctx['expert'][36:,:,chosen],load(d/'controls.npz')['CalBest'],rtol=1e-8,atol=2e-6)
    inp=dict(Cov=mixed,CalBest=bank[:,:,chosen])
    if seed==42:
        original=load(O/'kais_review_v2_revision_20261017/evidence/inputs'/key(c,seed)/'targets.npz')
        for k,v in inp.items():np.testing.assert_allclose(v,original[k],rtol=1e-12,atol=1e-10)
    return inp,dict(cov_reconstruction_max_scaled_error=err,chosen_expert=chosen)

def main():
    H.mkdir(exist_ok=True)
    sources={str(p):sha(p) for p in [Path(__file__),oldrun,O/'kais_review_v2_revision_20261017/evidence/run.py',root/'run.py']}
    reg=dict(registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        request='Complete Table 6 with three-experiment mean RMSE and explicit CPOR',
        cells=22,experiments=[42,1,2],arms=arms,new_arm_runs=308,reused_arm_runs=154,
        protocol='Unchanged calibration36/scoring72, raw/Cov targets, estimators, floor and solver. Own actual allowance per protected trajectory; R=40401/40000. All backbone and CPOR forecasts reused. No model fitting or parameter search.',
        status='Retrospective extension on previously examined dates.',
        sources=sources)
    if (H/'REGISTRATION.json').exists():
        saved=json.loads((H/'REGISTRATION.json').read_text())
        assert saved['sources']==sources
    else:js(H/'REGISTRATION.json',reg)
    # Frozen estimator gate, independent of outcomes in scored windows.
    tree=ast.parse((oldrun.parent/'hierarchicalforecast_utils_1.3.0.txt').read_text())
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_shrunk_covariance_schaferstrimmer_no_nans')
    fn.decorator_list=[];ref={'np':np,'prange':range}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'published_estimator','exec'),ref)
    e=np.random.default_rng(42).normal(size=(36,9));W,_,_,floor=covariance(e)
    np.testing.assert_allclose(W,ref[fn.name](e.T,floor),rtol=1e-12,atol=1e-12)
    index=[];inputs={}
    for c in cells:
        for seed in [42,1,2]:
            d=source(c,seed);k=key(c,seed);x=load(d/'endpoints.npz');ctx=load(d/'contexts.npz')
            for n in ['endpoints.npz','contexts.npz','C0.npz']:
                inputs[str(d/n)]=sha(d/n)
            # Confirm identical scoring inputs to earlier classical evaluations.
            if seed==42:
                orig=load(O/'kais_review4_20261016/Online_Resource_3/replay_inputs'/k/'endpoints.npz')
                for name in ['S','v','raw','truth','b','ub']:np.testing.assert_array_equal(x[name],orig[name])
            inp,check=targets(c,seed,x,ctx)
            dest=H/'results'/k;dest.mkdir(parents=True,exist_ok=True)
            tfile=dest/'targets.npz'
            if not tfile.exists():np.savez_compressed(tfile,**inp)
            for name,arr in inp.items():np.testing.assert_array_equal(load(tfile)[name],arr)
            rawW,C,lam,floor=covariance(x['raw'][:36]-x['truth'][:36])
            for arm in arms:
                if seed==42:
                    folder=oldrun.parent if arm in arms[:3] else O/'kais_review_v2_revision_20261017/evidence'
                    path=folder/'results'/k/(arm+'.npz');receipt=json.loads(path.with_suffix('.json').read_text())
                    assert sha(path)==receipt['sha256']
                    z=load(path);ad=audit(x,z['protected'],z['protected_witness'])
                    index.append(dict(cell=k,seed=seed,arm=arm,path=str(path),reused=True,sha256=sha(path),audit=ad))
                    continue
                path=dest/(arm+'.npz')
                if path.exists():
                    receipt=json.loads(path.with_suffix('.json').read_text());assert sha(path)==receipt['sha256']
                else:
                    start=time.perf_counter();meta={}
                    if arm=='RollingMinT_Raw':
                        ps=[];us=[];checks=[]
                        for t in range(36,108):
                            W,*_=covariance(x['raw'][t-36:t]-x['truth'][t-36:t])
                            p,u,ch=target(x['S'],x['raw'][t:t+1],W);ps.append(p[0]);us.append(u[0]);checks.append(ch)
                        z,u=np.array(ps),np.array(us);ch=dict(max_scaled_kkt=max(q['max_scaled_kkt'] for q in checks))
                    else:
                        if arm in arms[:3]:
                            Z=x['raw']
                            W={'WLSstruct':np.diag(x['S'].sum(1)),'WLSvar':np.diag(np.maximum(np.diag(C),floor)),'MinTshrink':rawW}[arm]
                            meta=dict(shrinkage=lam,variance_floor=floor)
                        else:
                            Z=inp[arm.split('_')[1]]
                            W,CC,ll,ff=covariance(Z[:36]-x['truth'][:36])
                            if arm.startswith('WLS'):W=np.diag(np.maximum(np.diag(CC),ff))
                            meta=dict(shrinkage=ll,variance_floor=ff)
                        z,u,ch=target(x['S'],Z[36:],W)
                    p,pu,logs=protect(x,z);ad=audit(x,p,pu)
                    assert np.isfinite(z).all()
                    np.savez_compressed(path,unprotected=z,unprotected_witness=u,protected=p,protected_witness=pu)
                    receipt=dict(cell=c,seed=seed,arm=arm,seconds=time.perf_counter()-start,
                        audit=ad,numerical=ch,covariance=meta,target_check=check,
                        sha256=sha(path),target_input_sha256=sha(tfile),protection_logs=logs)
                    js(path.with_suffix('.json'),receipt)
                    print('DONE',k,arm,round(receipt['seconds'],2),flush=True)
                index.append(dict(cell=k,seed=seed,arm=arm,path=str(path),reused=False,sha256=sha(path),audit=receipt['audit']))
            js(H/'RUN_STATUS.json',dict(complete=False,completed=len(index),new=sum(not r['reused'] for r in index)))
    assert len(index)==462 and sum(not r['reused'] for r in index)==308
    js(H/'RESULT_INDEX.json',index);js(H/'INPUT_SHA256.json',inputs)
    js(H/'RUN_STATUS.json',dict(complete=True,completed=462,new=308,reused=154,neural_fits=0,cpor_runs=0))
    print('COMPLETE',flush=True)
if __name__=='__main__':
    with threadpool_limits(1):main()
