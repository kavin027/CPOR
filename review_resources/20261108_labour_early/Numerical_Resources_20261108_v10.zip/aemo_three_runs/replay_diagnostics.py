"""Replay completed Cov/ML releases to retain numerical diagnostics and timings."""
from aemo_extension_common import *
import compare as cc
import inspect,time,ast
from threadpoolctl import threadpool_limits
def main():
    verify();summary=[]
    for bb in ['PatchTST','DLinear']:
      for seed in [42,1,2]:
        d=folder(bb,seed);x=load(d/'context.npz');dest=d/'diagnostics';dest.mkdir(exist_ok=True)
        for name in ['Cov','ML']:
            path=dest/(name+'.json')
            if path.exists():summary.append(json.loads(path.read_text()));continue
            target=x[name+'Target'][36:];k=cc.c.kernels('nonnegative')
            if name=='Cov':
                f=k['cov'];tree=ast.parse(inspect.getsource(f));fn=tree.body[0];loop=next(a for a in fn.body if isinstance(a,ast.For))
                loop.body.insert(0,ast.parse('_tick_aemo=__aemo_time.perf_counter_ns()').body[0]);loop.body.append(ast.parse("stats[-1]['publication_ms']=(__aemo_time.perf_counter_ns()-_tick_aemo)/1e6").body[0])
                ast.fix_missing_locations(tree);g=dict(f.__globals__,__aemo_time=time);exec(compile(tree,'timed_cov_diagnostic_replay','exec'),g)
                out=g[fn.name](x,target,'Full');p,u,logs=out['pred'],out['witness'],out['stats']
                for j,info in enumerate(logs):
                    for key in ['contraction','rounding_move','objective','gap','first_order_bound']:info[key]=out[key][j]
            else:p,u,logs,_=cc.publish(x,target)
            original=load(d/'results'/('CPOR-'+name+'.npz'));np.testing.assert_array_equal(p,original['pred']);np.testing.assert_array_equal(u,original['witness'])
            table=pd.DataFrame([{k:cc.numeric(v) for k,v in a.items() if np.isscalar(v) or v is None} for a in logs]);table.to_csv(dest/(name+'_steps.csv'),index=False)
            times=table.publication_ms.to_numpy();attempts=table.get('attempts',pd.Series(np.ones(len(table)))).fillna(1).to_numpy()
            con=table.get('contraction',pd.Series(np.ones(len(table)))).fillna(1).to_numpy();move=table.get('rounding_move',pd.Series(np.zeros(len(table)))).fillna(0).to_numpy()
            record=dict(backbone=bb,run=seed,method='CPOR-'+name,calls=len(logs),bitwise_replay=True,mean_ms=float(times.mean()),p95_ms=float(np.quantile(times,.95)),repeated_solver_calls=int((attempts>1).sum()),additional_solver_attempts=int(np.maximum(0,attempts-1).sum()),contractions_below_one=int((con<1).sum()),rounding_moves=int((move>0).sum()),max_rounding_move=float(move.max()),stored_anchor_releases=int(np.all(p==x['b'][36:],axis=1).sum()),first_release_is_mandatory_anchor=True)
            js(path,record);summary.append(record);print('DIAGNOSTICS',bb,seed,name,flush=True)
    pd.DataFrame(summary).to_csv(H/'CPOR_REPLAY_DIAGNOSTICS.csv',index=False)
if __name__=='__main__':
    with threadpool_limits(1):main()
