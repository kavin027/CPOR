"""Package the completed extension, leaving the submitted manuscript unchanged."""
from aemo_extension_common import *
import zipfile,platform,importlib.metadata
def table(df,cols):
    def cell(x):return (f'{x:.2e}' if 0<abs(x)<.001 else f'{x:.3f}') if isinstance(x,(float,np.floating)) else str(x)
    return '| '+' | '.join(cols)+' |\n| '+' | '.join(['---']*len(cols))+' |\n'+'\n'.join('| '+' | '.join(cell(row[c]) for c in cols)+' |' for _,row in df.iterrows())
def main():
    verify();status=json.loads((H/'STATUS.json').read_text());audit=json.loads((H/'INDEPENDENT_CHECK.json').read_text());gates=json.loads((H/'IMPLEMENTATION_GATES.json').read_text())
    assert status['complete'] and audit['passed'] and gates['passed']
    frozen=O/'cpor_kais_submission_final_20261107/KAIS_CPOR_Submission_Final_20261107.zip';assert sha(frozen)==gates['frozen_submission_sha256']
    stats=pd.read_csv(H/'THREE_RUN_RMSE.csv');pairs=pd.read_csv(H/'PAIRED_SUMMARY.csv');byrun=pd.read_csv(H/'PAIRED_GAINS.csv');checks=pd.read_csv(H/'PROTECTION_CHECKS.csv');diag=pd.read_csv(H/'CPOR_REPLAY_DIAGNOSTICS.csv')
    headline=['Raw','NNLS','ProCAST','ProtectedProCAST','Ada-Y','ProtectedAda-Y','PIR','LiDiag','LiFactor','Biswas','CovTarget','CPOR-Cov','MLTarget','CPOR-ML','ProtectedCalBest','ProtectedMinTshrink','ProtectedMinT_Cov','ProtectedLiDiag','ProtectedLiFactor','ProtectedBiswas','PIRCommon','PIRTwoGroup','PIRFull']
    allrows=stats[(stats.scope=='Overall')&stats.method.isin(headline)].copy();allrows['RMSE (mean ± SD)']=[f'{a:.3f} ± {b:.3f}' for a,b in zip(allrows['mean'],allrows['std'])]
    layers=stats[(stats.method.isin(['CPOR-Cov','CPOR-ML']))&stats.scope.isin(['SYSTEM','Regions']+['NSW1','QLD1','SA1','TAS1','VIC1'])]
    effects=pairs[(pairs.scope=='Overall')&pairs.method.isin(['CPOR-Cov','CPOR-ML','PIRFull'])]
    eventrows=[]
    for bb in ['PatchTST','DLinear']:
      for seed in [42,1,2]:
        d=folder(bb,seed);m=json.loads((d/'CONTEXT_READY.json').read_text())
        for method in ['Cov','ML']:
            z=diag[(diag.backbone==bb)&(diag.run==seed)&(diag.method=='CPOR-'+method)].iloc[0]
            eventrows.append(dict(backbone=bb,run=seed,method='CPOR-'+method,target_combination_mean_ms=m[method.lower()+'_seconds']/1488*1000,publication_mean_ms=z.mean_ms,publication_p95_ms=z.p95_ms,shared_expert_bank_mean_ms=m['bank_seconds']/1524*1000,solver_retries=z.repeated_solver_calls,guard_contractions=z.contractions_below_one,rounding_repairs=z.rounding_moves,max_rounding_move=z.max_rounding_move))
    events=pd.DataFrame(eventrows);events.to_csv(H/'CPOR_COST_AND_EVENTS.csv',index=False)
    summary=events.groupby(['backbone','method']).mean(numeric_only=True).reset_index()
    negatives=byrun[(byrun.comparator.isin(['CovCommon','MLCommon','ProtectedCalBest','PIRTwoGroup']))&byrun.scope.isin(['NSW1','QLD1','SA1','TAS1','VIC1','SYSTEM'])&(byrun.gain_pct<0)]
    report='''# AEMO 整月 Cov / ML 三次训练重复：完成报告

本轮只增加独立结果目录，不修改冻结论文、Figure 1、投稿包或公开仓库。

## 协议和证据身份

- 观测为未截断的 AEMO operational demand 加 rooftop PV measurement 所定义的 estimated underlying demand；保留 NSW1、QLD1、SA1、TAS1、VIC1 及其系统总和。原始分量的负值仍在既有来源记录中，派生观测不通过截断或删区变成非负。
- 评分覆盖 2026-10-01 00:30 至 2026-11-01 00:00（固定 AEST），1488 个半小时观测。所有路径沿整月连续运行，仅月初一次零余额；没有每日、每周或预测块重置。
- PatchTST 和 DLinear 各三次训练初始化（42、1、2）。原来的两条预测及 PIR 结果逐值复用，只新增四次骨干拟合；每条预测流供所有对应方法共同使用。三个运行复用同一个月份，不能当成三个独立新时段。
- 基础训练规则不变：输入24、预测块12、学习率0.0001、验证36点、每步验证、早停耐心50；PatchTST上限500，DLinear上限10000，以验证MAE选模。具体停止步数见 BACKBONE_FITS.csv；达到上限不被解释为收敛。在线发布在收到前一期真值后进行。
- Cov、ML、CalBest、WLS/MinT 的候选和选择规则复用论文实现。ProCAST、Ada-Y、PIR、Biswas 的适配器每条流固定初始化42，不以十月精度搜索参数；Li沿用其只使用已返回残差的历史选参规则。三次结果反映骨干训练重复及在相应流上重拟合的适配器，不估计独立的适配器初始化方差。
- 所有受保护方法共享该预测流的 NNLS 参考、方差权重、0.5%容差和反馈顺序；R精确取40401/40000。每条路径独立结算实际发布误差。未保护基线单独列出，不能称为相同保护条件下的比较。
- 本轮是在此前单次冻结时段验证结果已被查看后的回顾性覆盖扩展。新 Cov/ML 结果不改称第二次未触及确认实验；原登记和原结果均保留。没有使用十月结果调参。

## 整体精度

单位MW；RMSE先在1488期内逐节点计算，再在六节点等权平均。下面为三次运行的均值和样本SD。两种骨干分别列出，避免将不同基础预测流混为同一比较。

'''
    report+=table(allrows,['backbone','method','RMSE (mean ± SD)'])
    report+='\n\n## 配对收益、保护代价与归因\n\n改善率为每条相同预测流上先算 `100*(1-M_method/M_comparator)`，再等权平均六条流；它不一定等于上表平均RMSE的比值。正值表示方法误差更低。\n\n'
    report+=table(effects,['method','comparator','mean','min','max','positive_runs'])
    report+='''

相对 ProCAST、PIR、Li、Biswas 或原始预测的大幅改善，属于完整流程效果，包含候选生成及历史更新的差异。对保护机制本身更直接的证据是：同一 Cov/ML 目标下完整保护与统一收缩、非负域与全实数域的匹配比较，以及同一 PIR 目标下三种发布规则的比较。不同规则的余额各自随发布误差演化，这些百分比是整条策略路径的经验结果，不是同状态投影距离界或普遍 RMSE 支配定理。

对 CovTarget / MLTarget 的负改善率，表示为了守约增加了误差，是保护成本。对使用 Cov 输入的 ProtectedMinT_Cov 的小幅差距须与对原始输入经典方法的大幅差距区分。DLinear 的 CalBest 选出持久性专家；ML与该固定专家的整体RMSE近乎相同，不能用其结果宣称在线组合总有独立增益。

## 区域与系统

下表给出三次RMSE的均值和SD，系统为总量单节点，Regions为五区域等权平均。各区域仍逐项列出。

'''
    report+=table(layers,['backbone','method','scope','mean','std'])
    report+='\n\n## 保留的负面结果\n\n下表筛出相对同保护收缩、固定专家或PIR两组收缩的区域/系统退化。完整负面比较见 NEGATIVE_NODE_COMPARISONS.csv。逐节点守约与逐节点更准确是不同结论。\n\n'
    report+=table(negatives,['backbone','run','method','comparator','scope','gain_pct'])
    report+='\n\n## 保护检查与数值事件\n\n'
    protected=checks[checks.protected]
    report+=f"已完成 {status['completed_results']} 条方法级月轨迹；其中 {audit['protected_trajectories']} 条受保护轨迹通过独立重算。每条1488期、6节点，合计 {audit['exact_prefix_node_dates']:,} 次精确前缀检查，以及同数目的精确包络检查，均零违规；聚合一致性按相对1e-8、绝对2e-6检查。这些相关检查不是独立实验样本。\n\n"
    report+='未保护路径的越限节点数、越限日期及最坏包络检查见 PROTECTION_CHECKS.csv。不能用其中未保护方法的误差优势否定或证明保护算子的精度收益。\n\n'
    report+=table(summary,['backbone','method','target_combination_mean_ms','publication_mean_ms','publication_p95_ms','shared_expert_bank_mean_ms','solver_retries','guard_contractions','rounding_repairs','max_rounding_move'])
    report+='''

计时为本机已有运行/串行回放的观测值：target列只计组合规则，shared expert bank列单独列出共享候选构造，不把它重复计入两种实现的相对开销。publication列为保护发布，不含神经训练、文件写入。各次P95的均值不称为合并P95。回放的Cov/ML预测及非负表示与保存值逐元素相同；数值修补统计与求解失败分别报告，不把必需的首期参考发布叫作回退。期间存在其他GPU任务，这些是本机记录而非受控性能上界。

## 可复核材料与结论边界

- RUN_SCOPE_RMSE.csv：每条流、每个方法、每个节点/层级的全精度RMSE。
- THREE_RUN_RMSE.csv：按骨干汇总的三次均值、SD及范围。
- PAIRED_GAINS.csv / PAIRED_SUMMARY.csv：运行内百分比与等权汇总。
- PROTECTION_CHECKS.csv：未保护违规及受保护路径检查。
- runs/**/results：实际预测、非负表示、检查记录和数值日志；context.npz包含共同参考、观测、权重和候选。
- runs/**/models：复用或新生成的基础/PIR预测、最佳检查点及训练选模记录。
- REGISTRATION.json、AMENDMENT*.json、IMPLEMENTATION_GATES.json：扩展登记、源码版本及实现一致性检查。
- `python check_results.py --self-test`：从保存预测重新进行精确包络与逐前缀检查，另包含人为破坏轨迹的拒绝测试。它不重训骨干，也不声称重下全部AEMO源档案。

结果支持在这个新增月份、既定合同及因果反馈协议下考察保护方法和两种实现。能否推广到更多年份、突发变化或延迟反馈，不能由三次初始化替代验证。本轮未更改研究问题，也未据新结果修改论文。
'''
    (H/'AEMO_Cov_ML_Three_Run_Report.md').write_text(report,encoding='utf8')
    allsources=dict(json.loads((OLD/'REGISTRATION.json').read_text()).get('sources',{}))
    for amendment in OLD.glob('AMENDMENT*.json'):
        for p,change in json.loads(amendment.read_text()).get('changes',{}).items():allsources[p]=change['new']
    for f in [H/'REGISTRATION.json',*H.glob('AMENDMENT*.json')]:allsources.update(json.loads(f.read_text()).get('sources',{}))
    closure=H/'source_closure'
    for p,digest in allsources.items():
        src=Path(p)
        if src.suffix not in ['.py','.R'] or not src.is_relative_to(ROOT):continue
        assert sha(src)==digest
        dest=closure/src.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():shutil.copy2(src,dest)
    if not (H/'observed.csv').exists():shutil.copy2(OLD/'observed.csv',H/'observed.csv')
    provenance=H/'original_study_provenance';provenance.mkdir(exist_ok=True)
    for f in [OLD/'REGISTRATION.json',OLD/'DATA_READY.json',*OLD.glob('AMENDMENT*.json')]:shutil.copy2(f,provenance/f.name)
    versions={}
    for package in ['torch','numpy','pandas','scipy','scikit-learn','neuralforecast','pytorch-lightning','cvxpy','clarabel']:
        try:versions[package]=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:versions[package]=None
    js(H/'DELIVERY.json',dict(complete=True,status=status,audit=audit,frozen_submission_sha256=sha(frozen),python_executable=sys.executable,python_version=platform.python_version(),dependencies=versions,original_study_unchanged=True,new_backbone_fits=4,reused_backbone_streams=2))
    pack=O/'AEMO_CPOR_Cov_ML_Three_Runs_20261107.zip'
    with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in H.rglob('*'):
            if not p.is_file() or any(a in ['__pycache__','blocks','checkpoint'] for a in p.relative_to(H).parts):continue
            if p.name in ['splits.csv','factor.bin','residuals.csv']:continue
            z.write(p,p.relative_to(H))
    js(H/'PACKAGE_RECEIPT.json',dict(path=str(pack),bytes=pack.stat().st_size,sha256=sha(pack),frozen_submission_sha256=sha(frozen)))
    print('DELIVERED',pack,sha(pack),flush=True)
if __name__=='__main__':main()
