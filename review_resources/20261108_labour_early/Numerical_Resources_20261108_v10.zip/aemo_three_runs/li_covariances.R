args<-commandArgs(trailingOnly=TRUE)
source(args[1]);res<-as.matrix(read.csv(args[2],header=FALSE));n<-nrow(res)
splits<-matrix(NA_integer_,n-35,n+1)
out<-file(args[4],'wb')
for(t in 36:n){
 set.seed(123);idx<-sample(seq_len(t));splits[t-35,1:(t+1)]<-c(t,idx)
 for(rows in list(idx[seq_len(floor(.8*t))],seq_len(t))){
  sigma<-covEstimation(res[rows,,drop=FALSE],control=list(type='large'))
  stopifnot(all(is.finite(sigma)),isSymmetric(unname(sigma),tol=1e-9))
  writeBin(as.double(t(sigma)),out,size=8,endian='little')
 }
}
close(out)
write.table(splits,args[3],row.names=FALSE,col.names=FALSE,sep=',',na='')
