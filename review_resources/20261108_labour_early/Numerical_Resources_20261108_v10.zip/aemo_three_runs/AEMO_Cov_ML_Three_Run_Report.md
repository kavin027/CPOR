# AEMO 整月 Cov / ML 三次训练重复：完成报告

本轮只增加独立结果目录，不修改冻结论文、Figure 1、投稿包或公开仓库。

## 协议和证据身份

- 观测为未截断的 AEMO operational demand 加 rooftop PV measurement 所定义的 estimated underlying demand；保留 NSW1、QLD1、SA1、TAS1、VIC1 及其系统总和。原始分量的负值仍在既有来源记录中，派生观测不通过截断或删区变成非负。
- 评分覆盖 2026-10-01 00:30 至 2026-11-01 00:00（固定 AEST），1488 个半小时观测。所有路径沿整月连续运行，仅月初一次零余额；没有每日、每周或预测块重置。
- PatchTST 和 DLinear 各三次训练初始化（42、1、2）。原来的两条预测及 PIR 结果逐值复用，只新增四次骨干拟合；每条预测流供所有对应方法共同使用。三个运行复用同一个月份，不能当成三个独立新时段。
- 基础训练规则不变：输入24、预测块12、学习率0.0001、验证36点、每步验证、早停耐心50；PatchTST上限500，DLinear上限10000，以验证MAE选模。具体停止步数见 BACKBONE_FITS.csv；达到上限不被解释为收敛。在线发布在收到前一期真值后进行。
- Cov、ML、CalBest、WLS/MinT 的候选和选择规则复用论文实现。ProCAST、Ada-Y、PIR、Biswas 的适配器每条流固定初始化42，不以十月精度搜索参数；Li沿用其只使用已返回残差的历史选参规则。三次结果反映骨干训练重复及在相应流上重拟合的适配器，不估计独立的适配器初始化方差。
- 所有受保护方法共享该预测流的 NNLS 参考、方差权重、0.5%容差和反馈顺序；R精确取40401/40000。每条路径独立结算实际发布误差。未保护基线单独列出，不能称为相同保护条件下的比较。
- 本轮是在此前单次冻结时段验证结果已被查看后的回顾性覆盖扩展。新 Cov/ML 结果不改称第二次未触及确认实验；原登记和原结果均保留。没有使用十月结果调参。

## 整体精度

单位MW；RMSE先在1488期内逐节点计算，再在六节点等权平均。下面为三次运行的均值和样本SD。两种骨干分别列出，避免将不同基础预测流混为同一比较。

| backbone | method | RMSE (mean ± SD) |
| --- | --- | --- |
| DLinear | Ada-Y | 1198.838 ± 14.538 |
| DLinear | Biswas | 1248.060 ± 15.480 |
| DLinear | CPOR-Cov | 288.592 ± 2.531 |
| DLinear | CPOR-ML | 287.815 ± 2.229 |
| DLinear | CovTarget | 198.396 ± 0.467 |
| DLinear | LiDiag | 1234.134 ± 17.394 |
| DLinear | LiFactor | 1241.669 ± 20.545 |
| DLinear | MLTarget | 197.220 ± 0.002 |
| DLinear | NNLS | 1234.138 ± 17.390 |
| DLinear | PIR | 709.373 ± 4.783 |
| DLinear | PIRCommon | 728.341 ± 4.140 |
| DLinear | PIRFull | 719.981 ± 4.079 |
| DLinear | PIRTwoGroup | 725.218 ± 4.292 |
| DLinear | ProCAST | 1174.716 ± 14.216 |
| DLinear | ProtectedAda-Y | 1198.147 ± 15.078 |
| DLinear | ProtectedBiswas | 1240.101 ± 17.462 |
| DLinear | ProtectedCalBest | 287.815 ± 2.229 |
| DLinear | ProtectedLiDiag | 1234.134 ± 17.394 |
| DLinear | ProtectedLiFactor | 1234.382 ± 17.379 |
| DLinear | ProtectedMinT_Cov | 288.616 ± 2.541 |
| DLinear | ProtectedMinTshrink | 1234.133 ± 17.394 |
| DLinear | ProtectedProCAST | 1172.261 ± 13.701 |
| DLinear | Raw | 1234.135 ± 17.392 |
| PatchTST | Ada-Y | 672.736 ± 34.585 |
| PatchTST | Biswas | 674.004 ± 30.992 |
| PatchTST | CPOR-Cov | 291.095 ± 13.186 |
| PatchTST | CPOR-ML | 286.473 ± 13.272 |
| PatchTST | CovTarget | 190.234 ± 0.480 |
| PatchTST | LiDiag | 660.753 ± 27.756 |
| PatchTST | LiFactor | 661.670 ± 27.807 |
| PatchTST | MLTarget | 183.219 ± 0.634 |
| PatchTST | NNLS | 667.189 ± 29.715 |
| PatchTST | PIR | 609.648 ± 26.680 |
| PatchTST | PIRCommon | 604.943 ± 31.890 |
| PatchTST | PIRFull | 569.584 ± 30.112 |
| PatchTST | PIRTwoGroup | 585.694 ± 29.252 |
| PatchTST | ProCAST | 614.345 ± 29.158 |
| PatchTST | ProtectedAda-Y | 661.110 ± 31.690 |
| PatchTST | ProtectedBiswas | 662.721 ± 30.375 |
| PatchTST | ProtectedCalBest | 425.739 ± 21.322 |
| PatchTST | ProtectedLiDiag | 660.682 ± 28.057 |
| PatchTST | ProtectedLiFactor | 660.584 ± 28.138 |
| PatchTST | ProtectedMinT_Cov | 293.538 ± 12.106 |
| PatchTST | ProtectedMinTshrink | 658.382 ± 27.451 |
| PatchTST | ProtectedProCAST | 614.634 ± 29.156 |
| PatchTST | Raw | 669.443 ± 30.401 |

## 配对收益、保护代价与归因

改善率为每条相同预测流上先算 `100*(1-M_method/M_comparator)`，再等权平均六条流；它不一定等于上表平均RMSE的比值。正值表示方法误差更低。

| method | comparator | mean | min | max | positive_runs |
| --- | --- | --- | --- | --- | --- |
| CPOR-Cov | Ada-Y | 66.322 | 56.410 | 76.465 | 6 |
| CPOR-Cov | Biswas | 66.842 | 56.790 | 77.404 | 6 |
| CPOR-Cov | CPOR-ML | -0.943 | -1.740 | -0.154 | 0 |
| CPOR-Cov | CovAllReal | 14.046 | 4.922 | 23.017 | 6 |
| CPOR-Cov | CovCommon | 9.019 | 8.428 | 10.289 | 6 |
| CPOR-Cov | CovTarget | -49.238 | -60.686 | -44.397 | 0 |
| CPOR-Cov | LiDiag | 66.279 | 55.705 | 77.187 | 6 |
| CPOR-Cov | LiFactor | 66.381 | 55.753 | 77.187 | 6 |
| CPOR-Cov | NNLS | 66.491 | 56.325 | 77.187 | 6 |
| CPOR-Cov | PIR | 55.785 | 51.988 | 59.551 | 6 |
| CPOR-Cov | ProCAST | 64.022 | 52.419 | 75.936 | 6 |
| CPOR-Cov | ProtectedBiswas | 66.399 | 55.963 | 77.296 | 6 |
| CPOR-Cov | ProtectedCalBest | 15.673 | -0.359 | 32.004 | 3 |
| CPOR-Cov | ProtectedLiDiag | 66.277 | 55.737 | 77.187 | 6 |
| CPOR-Cov | ProtectedLiFactor | 66.276 | 55.734 | 77.187 | 6 |
| CPOR-Cov | ProtectedMinT_Cov | 0.426 | 0.004 | 1.075 | 6 |
| CPOR-Cov | ProtectedMinTshrink | 66.201 | 55.603 | 77.187 | 6 |
| CPOR-ML | Ada-Y | 66.699 | 57.156 | 76.501 | 6 |
| CPOR-ML | Biswas | 67.216 | 57.478 | 77.438 | 6 |
| CPOR-ML | LiDiag | 66.661 | 56.355 | 77.222 | 6 |
| CPOR-ML | LiFactor | 66.762 | 56.404 | 77.222 | 6 |
| CPOR-ML | MLAllReal | 14.320 | 5.170 | 23.061 | 6 |
| CPOR-ML | MLCommon | 9.098 | 8.467 | 10.502 | 6 |
| CPOR-ML | MLTarget | -51.142 | -64.312 | -44.645 | 0 |
| CPOR-ML | NNLS | 66.870 | 56.967 | 77.222 | 6 |
| CPOR-ML | PIR | 56.220 | 52.810 | 59.613 | 6 |
| CPOR-ML | ProCAST | 64.432 | 53.176 | 75.973 | 6 |
| CPOR-ML | ProtectedBiswas | 66.780 | 56.717 | 77.331 | 6 |
| CPOR-ML | ProtectedCalBest | 16.351 | -2.35e-04 | 33.003 | 3 |
| CPOR-ML | ProtectedLiDiag | 66.659 | 56.388 | 77.222 | 6 |
| CPOR-ML | ProtectedLiFactor | 66.658 | 56.386 | 77.222 | 6 |
| CPOR-ML | ProtectedMinT_Cov | 1.348 | 0.158 | 2.767 | 6 |
| CPOR-ML | ProtectedMinTshrink | 66.584 | 56.255 | 77.222 | 6 |
| PIRFull | PIRCoherent | 1.764 | -1.798 | 6.004 | 3 |
| PIRFull | PIRCommon | 3.496 | 1.068 | 6.420 | 6 |
| PIRFull | PIRTwoGroup | 1.740 | 0.654 | 3.753 | 6 |

相对 ProCAST、PIR、Li、Biswas 或原始预测的大幅改善，属于完整流程效果，包含候选生成及历史更新的差异。对保护机制本身更直接的证据是：同一 Cov/ML 目标下完整保护与统一收缩、非负域与全实数域的匹配比较，以及同一 PIR 目标下三种发布规则的比较。不同规则的余额各自随发布误差演化，这些百分比是整条策略路径的经验结果，不是同状态投影距离界或普遍 RMSE 支配定理。

对 CovTarget / MLTarget 的负改善率，表示为了守约增加了误差，是保护成本。对使用 Cov 输入的 ProtectedMinT_Cov 的小幅差距须与对原始输入经典方法的大幅差距区分。DLinear 的 CalBest 选出持久性专家；ML与该固定专家的整体RMSE近乎相同，不能用其结果宣称在线组合总有独立增益。

## 区域与系统

下表给出三次RMSE的均值和SD，系统为总量单节点，Regions为五区域等权平均。各区域仍逐项列出。

| backbone | method | scope | mean | std |
| --- | --- | --- | --- | --- |
| DLinear | CPOR-Cov | NSW1 | 313.788 | 2.629 |
| DLinear | CPOR-Cov | QLD1 | 258.688 | 1.086 |
| DLinear | CPOR-Cov | Regions | 179.784 | 1.507 |
| DLinear | CPOR-Cov | SA1 | 73.780 | 0.499 |
| DLinear | CPOR-Cov | SYSTEM | 832.628 | 7.653 |
| DLinear | CPOR-Cov | TAS1 | 27.155 | 0.210 |
| DLinear | CPOR-Cov | VIC1 | 225.512 | 4.513 |
| DLinear | CPOR-ML | NSW1 | 313.108 | 2.279 |
| DLinear | CPOR-ML | QLD1 | 258.224 | 1.446 |
| DLinear | CPOR-ML | Regions | 179.261 | 1.302 |
| DLinear | CPOR-ML | SA1 | 73.555 | 0.589 |
| DLinear | CPOR-ML | SYSTEM | 830.587 | 6.861 |
| DLinear | CPOR-ML | TAS1 | 26.581 | 0.207 |
| DLinear | CPOR-ML | VIC1 | 224.837 | 4.170 |
| PatchTST | CPOR-Cov | NSW1 | 289.197 | 16.325 |
| PatchTST | CPOR-Cov | QLD1 | 210.149 | 13.166 |
| PatchTST | CPOR-Cov | Regions | 202.703 | 6.392 |
| PatchTST | CPOR-Cov | SA1 | 81.149 | 1.977 |
| PatchTST | CPOR-Cov | SYSTEM | 733.057 | 47.338 |
| PatchTST | CPOR-Cov | TAS1 | 33.706 | 1.422 |
| PatchTST | CPOR-Cov | VIC1 | 399.311 | 10.517 |
| PatchTST | CPOR-ML | NSW1 | 282.955 | 15.834 |
| PatchTST | CPOR-ML | QLD1 | 203.226 | 14.193 |
| PatchTST | CPOR-ML | Regions | 199.074 | 6.468 |
| PatchTST | CPOR-ML | SA1 | 79.936 | 2.004 |
| PatchTST | CPOR-ML | SYSTEM | 723.469 | 47.590 |
| PatchTST | CPOR-ML | TAS1 | 32.812 | 1.353 |
| PatchTST | CPOR-ML | VIC1 | 396.440 | 10.700 |

## 保留的负面结果

下表筛出相对同保护收缩、固定专家或PIR两组收缩的区域/系统退化。完整负面比较见 NEGATIVE_NODE_COMPARISONS.csv。逐节点守约与逐节点更准确是不同结论。

| backbone | run | method | comparator | scope | gain_pct |
| --- | --- | --- | --- | --- | --- |
| DLinear | 42 | CPOR-Cov | ProtectedCalBest | SYSTEM | -0.263 |
| DLinear | 42 | CPOR-Cov | ProtectedCalBest | NSW1 | -0.188 |
| DLinear | 42 | CPOR-Cov | ProtectedCalBest | QLD1 | -0.357 |
| DLinear | 42 | CPOR-Cov | ProtectedCalBest | SA1 | -0.233 |
| DLinear | 42 | CPOR-Cov | ProtectedCalBest | TAS1 | -2.176 |
| DLinear | 42 | CPOR-Cov | ProtectedCalBest | VIC1 | -0.290 |
| DLinear | 1 | CPOR-Cov | ProtectedCalBest | SYSTEM | -0.142 |
| DLinear | 1 | CPOR-Cov | ProtectedCalBest | NSW1 | -0.105 |
| DLinear | 1 | CPOR-Cov | ProtectedCalBest | QLD1 | -0.002 |
| DLinear | 1 | CPOR-Cov | ProtectedCalBest | SA1 | -0.451 |
| DLinear | 1 | CPOR-Cov | ProtectedCalBest | TAS1 | -2.161 |
| DLinear | 1 | CPOR-Cov | ProtectedCalBest | VIC1 | -0.110 |
| DLinear | 2 | CPOR-Cov | ProtectedCalBest | SYSTEM | -0.331 |
| DLinear | 2 | CPOR-Cov | ProtectedCalBest | NSW1 | -0.357 |
| DLinear | 2 | CPOR-Cov | ProtectedCalBest | QLD1 | -0.183 |
| DLinear | 2 | CPOR-Cov | ProtectedCalBest | SA1 | -0.235 |
| DLinear | 2 | CPOR-Cov | ProtectedCalBest | TAS1 | -2.153 |
| DLinear | 2 | CPOR-Cov | ProtectedCalBest | VIC1 | -0.495 |
| DLinear | 42 | CPOR-ML | ProtectedCalBest | NSW1 | -7.66e-05 |
| DLinear | 42 | CPOR-ML | ProtectedCalBest | QLD1 | -9.04e-05 |
| DLinear | 42 | CPOR-ML | ProtectedCalBest | SA1 | -2.58e-06 |
| DLinear | 42 | CPOR-ML | ProtectedCalBest | TAS1 | -0.018 |
| DLinear | 1 | CPOR-ML | ProtectedCalBest | NSW1 | -1.33e-13 |
| DLinear | 1 | CPOR-ML | ProtectedCalBest | VIC1 | -2.22e-14 |
| DLinear | 2 | CPOR-ML | ProtectedCalBest | SYSTEM | -2.22e-14 |
| DLinear | 2 | CPOR-ML | ProtectedCalBest | QLD1 | -6.44e-13 |
| DLinear | 2 | CPOR-ML | ProtectedCalBest | SA1 | -4.44e-14 |
| DLinear | 2 | CPOR-ML | ProtectedCalBest | VIC1 | -6.66e-14 |
| PatchTST | 42 | CPOR-Cov | CovCommon | QLD1 | -1.415 |
| PatchTST | 2 | CPOR-Cov | CovCommon | QLD1 | -10.277 |
| PatchTST | 42 | CPOR-ML | MLCommon | QLD1 | -1.011 |
| PatchTST | 2 | CPOR-ML | MLCommon | QLD1 | -10.022 |
| PatchTST | 42 | PIRFull | PIRTwoGroup | NSW1 | -1.310 |
| PatchTST | 1 | PIRFull | PIRTwoGroup | NSW1 | -2.728 |
| PatchTST | 2 | PIRFull | PIRTwoGroup | NSW1 | -0.354 |
| PatchTST | 2 | PIRFull | PIRTwoGroup | QLD1 | -8.15e-05 |

## 保护检查与数值事件

已完成 246 条方法级月轨迹；其中 138 条受保护轨迹通过独立重算。每条1488期、6节点，合计 1,232,064 次精确前缀检查，以及同数目的精确包络检查，均零违规；聚合一致性按相对1e-8、绝对2e-6检查。这些相关检查不是独立实验样本。

未保护路径的越限节点数、越限日期及最坏包络检查见 PROTECTION_CHECKS.csv。不能用其中未保护方法的误差优势否定或证明保护算子的精度收益。

| backbone | method | target_combination_mean_ms | publication_mean_ms | publication_p95_ms | shared_expert_bank_mean_ms | solver_retries | guard_contractions | rounding_repairs | max_rounding_move |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DLinear | CPOR-Cov | 13.355 | 3.351 | 3.570 | 4.462 | 0.000 | 0.000 | 5.000 | 1.32e-07 |
| DLinear | CPOR-ML | 0.035 | 1.804 | 2.006 | 4.462 | 0.000 | 0.000 | 6.000 | 1.32e-07 |
| PatchTST | CPOR-Cov | 23.336 | 3.555 | 3.894 | 4.072 | 0.000 | 0.000 | 3.333 | 8.12e-11 |
| PatchTST | CPOR-ML | 0.032 | 1.834 | 2.095 | 4.072 | 0.000 | 0.000 | 3.333 | 8.97e-11 |

计时为本机已有运行/串行回放的观测值：target列只计组合规则，shared expert bank列单独列出共享候选构造，不把它重复计入两种实现的相对开销。publication列为保护发布，不含神经训练、文件写入。各次P95的均值不称为合并P95。回放的Cov/ML预测及非负表示与保存值逐元素相同；数值修补统计与求解失败分别报告，不把必需的首期参考发布叫作回退。期间存在其他GPU任务，这些是本机记录而非受控性能上界。

## 可复核材料与结论边界

- RUN_SCOPE_RMSE.csv：每条流、每个方法、每个节点/层级的全精度RMSE。
- THREE_RUN_RMSE.csv：按骨干汇总的三次均值、SD及范围。
- PAIRED_GAINS.csv / PAIRED_SUMMARY.csv：运行内百分比与等权汇总。
- PROTECTION_CHECKS.csv：未保护违规及受保护路径检查。
- runs/**/results：实际预测、非负表示、检查记录和数值日志；context.npz包含共同参考、观测、权重和候选。
- runs/**/models：复用或新生成的基础/PIR预测、最佳检查点及训练选模记录。
- REGISTRATION.json、AMENDMENT*.json、IMPLEMENTATION_GATES.json：扩展登记、源码版本及实现一致性检查。
- `python check_results.py --self-test`：从保存预测重新进行精确包络与逐前缀检查，另包含人为破坏轨迹的拒绝测试。它不重训骨干，也不声称重下全部AEMO源档案。

结果支持在这个新增月份、既定合同及因果反馈协议下考察保护方法和两种实现。能否推广到更多年份、突发变化或延迟反馈，不能由三次初始化替代验证。本轮未更改研究问题，也未据新结果修改论文。
