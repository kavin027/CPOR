"""Implementation checks only; no method selection from scoring accuracy."""
from aemo_extension_common import *
import compare as cc
from threadpoolctl import threadpool_limits
def main():
    verify();checks=[]
    wide=pd.read_csv(OLD/'observed.csv',parse_dates=['ds']).set_index('ds');global_cal=wide.index.get_loc(pd.Timestamp('2026-09-30 06:30'))
    for bb in ['PatchTST','DLinear']:
      for seed in [42,1,2]:
        d=folder(bb,seed);x=load(d/'context.npz');base=load(d/'models'/bb/'raw.npz')
        assert base['begin']==1296 and base['start']==1440 and len(wide)-int(base['start'])==1488
        np.testing.assert_array_equal(base['truth'],wide.iloc[1296:].to_numpy())
        if seed==42:
            for name in ['raw.npz','pir.npz']:assert sha(d/'models'/bb/name)==sha(OLD/'models'/bb/name)
        # Counterfactual changes only AFTER a chosen issue. Every earlier expert remains unchanged.
        cut=60;changed=wide.copy();changed.iloc[global_cal+cut:]+=12345
        raw=x['raw'].copy();raw[cut:]+=23456
        bank=cc.fresh.expert_bank(changed,raw[:cut+8],x['v'],global_cal)
        baseline=cc.fresh.expert_bank(wide.copy(),x['raw'][:cut+8].copy(),x['v'],global_cal)
        np.testing.assert_array_equal(bank[:cut],baseline[:cut])
        np.testing.assert_allclose(baseline[:cut],x['bank'][:cut],rtol=1e-14,atol=2e-12)
        # The first live publication is the reference and the month has only one reset.
        for method in ['CPOR-Cov','CPOR-ML','CovCommon','MLCommon','CovAllReal','MLAllReal','PIRFull','PIRCommon','PIRTwoGroup']:
            z=load(d/'results'/(method+'.npz'));np.testing.assert_array_equal(z['pred'][0],x['b'][36])
        # Cov timing instrumentation must not change a single stored publication in the prefix.
        short={k:a[:108] if isinstance(a,np.ndarray) and a.ndim and len(a)==1524 else a for k,a in x.items()}
        out=cc.c.kernels('nonnegative')['cov'](short,x['CovTarget'][36:108],'Full')
        np.testing.assert_array_equal(out['pred'],load(d/'results'/'CPOR-Cov.npz')['pred'][:72])
        checks.append(dict(backbone=bb,initialization=seed,exact_original_reuse=seed==42,dates_and_values_equal=True,future_perturbation_prefix_unchanged=True,cov_numerical_path_prefix_bitwise=True,initial_zero_state=True))
    # Freeze-pack hash is obtained without altering the manuscript directory.
    pack=O/'cpor_kais_submission_final_20261107/KAIS_CPOR_Submission_Final_20261107.zip'
    digest=sha(pack);assert digest=='ac34794e478d4a38f3433954d2ec83357c372b69e05ea5520232e0c47d4384ea'
    js(H/'IMPLEMENTATION_GATES.json',dict(passed=True,runs=checks,frozen_submission_sha256=digest,original_study_registration_sha256=sha(OLD/'REGISTRATION.json')))
    print('GATES_PASSED',len(checks),flush=True)
if __name__=='__main__':
    with threadpool_limits(1):main()
