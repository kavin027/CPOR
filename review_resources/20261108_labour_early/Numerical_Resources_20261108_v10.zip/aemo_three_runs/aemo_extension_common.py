"""Registered AEMO October extension; never writes the original study."""
from pathlib import Path
import json,hashlib,sys,datetime,shutil,ast
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent
O=H.parent;ROOT=O.parent;OLD=O/'cpor_aemo_underlying_october_20261107'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,default=str),encoding='utf8')
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def folder(bb,seed):return H/'runs'/bb/str(seed)
def register():
    sources=[Path(__file__),OLD/'predict.py',OLD/'study_common.py',OLD/'observed.csv',
      O/'cpor_external_repetitions_20261020/run.py',O/'rr_recap_strong_baseline_20261006/run.py',
      O/'cpor_classical_repetitions_20261020/run.py',O/'c0_classical_matched_20261017/run.py',
      O/'cpor_envelope_comparison_20261024/run_comparison.py',
      O/'rr_recap_evidence_extension_20261002/frozen_core.py',
      O/'c0_seed_validation_20261016/common.py',O/'cpor_duet_stream_20261106/evaluate.py']
    for bb in ['PatchTST','DLinear']:
        sources.extend([OLD/'models'/bb/'raw.npz',OLD/'models'/bb/'pir.npz'])
    sources.extend(sorted(H.glob('*.py')))
    rec=dict(registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
      status='Retrospective protocol expansion after viewing the original one-run October validation. Not a second untouched confirmation.',
      base_runs=[dict(backbone=b,initialization=s) for b in ['PatchTST','DLinear'] for s in [42,1,2]],
      reuse='Both original initialization-42 raw/PIR streams and their completed PIR publication comparisons; only four new backbone fits.',
      observation='Unadjusted AEMO OPERATIONAL_DEMAND + rooftop PV POWER TYPE=MEASUREMENT; five retained regions and their summed system; no clipping.',
      scoring='2026-10-01 00:30 to 2026-11-01 00:00 AEST; 1488 observations; 108 support and 36 calibration predictions; horizon12/base input24; sequential causal publication.',
      protection='NNLS reference from the same raw base stream; epsilon=.005; rational R=40401/40000; zero once at October start; own actual balances for each arm; never reset within month.',
      selection='Original published candidate, calibration and numerical rules; no October accuracy tuning. Backbone LR=.0001,validation36,validation each update,patience50; PatchTST cap500/internal RevIN,DLinear cap10000/identity. Choose validation MAE checkpoint. Baseline-adapter initialization42 fixed for each backbone stream.',
      methods=['Raw','NNLS','CovTarget','CPOR-Cov','MLTarget','CPOR-ML','CalBest','ProtectedCalBest',
        'WLSstruct','WLSvar','MinTshrink','RollingMinT_Raw','WLSvar_Cov','MinT_Cov','MinT_CalBest',
        'ProtectedWLSstruct','ProtectedWLSvar','ProtectedMinTshrink','ProtectedRollingMinT_Raw','ProtectedWLSvar_Cov','ProtectedMinT_Cov','ProtectedMinT_CalBest',
        'ProCAST','ProtectedProCAST','Ada-Y','ProtectedAda-Y','PIR','PIRCoherent','PIRCommon','PIRTwoGroup','PIRFull'],
      supplementary_matched=['CovCommon','MLCommon','CovAllReal','MLAllReal'],
      primary='Whole-month mean-node RMSE, per-backbone three-run mean and sample SD; paired percentage per run then equal average across two backbones and runs. No claim of six independent datasets.',
      secondary=['system RMSE','five region RMSEs and mean','unprotected target cost','exact prefix and envelope checks','solver failures/repairs','publication elapsed time'],
      scope='Existing fixed-stream primary comparators and covariance-matched controls. DUET retraining, Root learner and unrelated auxiliary regressors are outside this extension.',
      frozen_manuscript_unchanged=True,sources={str(p):sha(p) for p in sorted(set(sources))})
    path=H/'REGISTRATION.json'
    if path.exists():verify();return
    js(path,rec)
def verify():
    rec=json.loads((H/'REGISTRATION.json').read_text())
    for p,h in rec['sources'].items():assert sha(p)==h,p
    for p in H.glob('AMENDMENT*.json'):
        a=json.loads(p.read_text());assert a['registration_sha256']==sha(H/'REGISTRATION.json')
        for f,h in a['sources'].items():assert sha(f)==h,f
def predict(bb,seed):
    verify();d=folder(bb,seed);d.mkdir(parents=True,exist_ok=True)
    src=OLD/'models'/bb;dest=d/'models'/bb;dest.mkdir(parents=True,exist_ok=True)
    if seed==42:
        for name in ['raw.npz','pir.npz','FIT_READY.json','RAW_READY.json','PIR_READY.json','best.ckpt','PIR_checkpoint.pt','validation_curve.csv']:
            if (src/name).exists() and not (dest/name).exists():shutil.copy2(src/name,dest/name)
        js(d/'REUSE_RECEIPT.json',dict(source=str(src),files={n:sha(dest/n) for n in ['raw.npz','pir.npz']},registration_sha256=sha(H/'REGISTRATION.json')))
        return
    for name in ['observed.csv','DATA_READY.json']:
        if not (d/name).exists():shutil.copy2(OLD/name,d/name)
    if not (d/'REGISTRATION.json').exists():shutil.copy2(H/'REGISTRATION.json',d/'REGISTRATION.json')
    sys.path.insert(0,str(OLD))
    text=(OLD/'predict.py').read_text().replace('random_seed=42,','random_seed=SEED,')
    tree=ast.parse(text);tree.body=[n for n in tree.body if not isinstance(n,ast.If)]
    ns={'__name__':'extended_aemo_predict','SEED':seed};exec(compile(tree,str(OLD/'predict.py'),'exec'),ns)
    ns['H']=d;ns['verify']=verify
    wide,base=ns['forecast'](bb);ns['refine'](bb,wide,base)
    js(d/'STREAM_READY.json',dict(raw_sha256=sha(dest/'raw.npz'),pir_sha256=sha(dest/'pir.npz'),initialization=seed,backbone=bb))
if __name__=='__main__':
    if sys.argv[1]=='register':register()
    elif sys.argv[1]=='predict':predict(sys.argv[2],int(sys.argv[3]))
