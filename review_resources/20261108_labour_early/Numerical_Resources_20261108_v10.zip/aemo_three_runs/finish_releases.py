"""Complete release wrappers as frozen baseline target files become ready."""
from aemo_extension_common import *
import subprocess,time
todo=[(b,s) for b in ['PatchTST','DLinear'] for s in [42,1,2]]
while todo:
    completed=[]
    for bb,seed in todo:
        d=folder(bb,seed)
        if not (d/'external'/'ProCAST.json').exists():continue
        if not all((d/'recent'/(a+'.json')).exists() for a in ['LiDiag','LiFactor','Biswas']):continue
        for script in ['external_compare.py','recent_compare.py']:
            with (H/f'final_release_{script[:-3]}_{bb}_{seed}.log').open('w') as f:
                subprocess.run([sys.executable,str(H/script),'release',bb,str(seed)],stdout=f,stderr=subprocess.STDOUT,check=True,cwd=str(ROOT))
        completed.append((bb,seed));print('ALL_RELEASES_READY',bb,seed,flush=True)
    todo=[q for q in todo if q not in completed]
    if todo:time.sleep(10)
subprocess.run([sys.executable,str(H/'summarize.py')],check=True,cwd=str(ROOT))
subprocess.run([sys.executable,str(H/'check_results.py'),'--self-test'],check=True,cwd=str(ROOT))
print('FULL_GRID_AND_INDEPENDENT_CHECK_COMPLETE',flush=True)
