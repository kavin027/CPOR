"""Rebuild current AEMO aggregates from stored forecasts; NumPy + stdlib only."""
from pathlib import Path
import numpy as np,csv,json,hashlib
H=Path(__file__).resolve().parent
def records(p):
    with p.open(encoding='utf8',newline='') as f:return list(csv.DictReader(f))
def load(p):
    with np.load(p,allow_pickle=False) as a:return {k:a[k] for k in a.files}
def main():
    hashes=json.loads((H/'RESULT_HASHES.json').read_text());scores={}
    for rel,digest in hashes.items():
        p=H/rel;assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,rel
        x=load(p.parent.parent/'context.npz');z=load(p)['pred'];bb,run=p.parts[-4:-2];method=p.stem
        err=np.sqrt(((z-x['truth'][36:])**2).mean(0));scope=dict(Overall=err.mean(),Regions=err[1:].mean(),**dict(zip(['SYSTEM','NSW1','QLD1','SA1','TAS1','VIC1'],err)))
        for key,val in scope.items():scores[(bb,int(run),method,key)]=float(val)
    close=lambda a,b:abs(a-b)<=2e-11*max(1,abs(a),abs(b))
    raw=records(H/'RUN_SCOPE_RMSE.csv')
    for r in raw:assert close(scores[(r['backbone'],int(r['run']),r['method'],r['scope'])],float(r['rmse']))
    for r in records(H/'THREE_RUN_RMSE.csv'):
        vals=np.array([scores[(r['backbone'],seed,r['method'],r['scope'])] for seed in [42,1,2]])
        assert close(vals.mean(),float(r['mean'])) and close(vals.std(ddof=1),float(r['std']))
    pairs={}
    for r in records(H/'PAIRED_GAINS.csv'):
        a=scores[(r['backbone'],int(r['run']),r['method'],r['scope'])];b=scores[(r['backbone'],int(r['run']),r['comparator'],r['scope'])]
        effect=100*(1-a/b);assert close(effect,float(r['gain_pct']));pairs.setdefault((r['method'],r['comparator'],r['scope']),[]).append(effect)
    for r in records(H/'PAIRED_SUMMARY.csv'):
        vals=pairs[(r['method'],r['comparator'],r['scope'])];assert len(vals)==6 and close(np.mean(vals),float(r['mean']))
    claim=lambda a,b:float(np.mean(pairs[(a,b,'Overall')]))
    values=dict(Cov_vs_common=claim('CPOR-Cov','CovCommon'),ML_vs_common=claim('CPOR-ML','MLCommon'),Cov_vs_all_real=claim('CPOR-Cov','CovAllReal'),ML_vs_all_real=claim('CPOR-ML','MLAllReal'),Cov_cost=-claim('CPOR-Cov','CovTarget'),ML_cost=-claim('CPOR-ML','MLTarget'),PIR_vs_common=claim('PIRFull','PIRCommon'),PIR_vs_two_group=claim('PIRFull','PIRTwoGroup'),Cov_vs_ProCAST=claim('CPOR-Cov','ProCAST'),ML_vs_ProCAST=claim('CPOR-ML','ProCAST'),Cov_vs_PIR=claim('CPOR-Cov','PIR'),ML_vs_PIR=claim('CPOR-ML','PIR'),Cov_vs_CovMinT=claim('CPOR-Cov','ProtectedMinT_Cov'),ML_vs_CovMinT=claim('CPOR-ML','ProtectedMinT_Cov'))
    expected=json.loads((H/'CURRENT_CLAIMS.json').read_text())
    for k,v in values.items():assert close(v,expected[k]),(k,v,expected[k])
    # Rebuild segment effects from the same uninterrupted stored trajectories.
    spans={'1--7':('2026-10-01','2026-10-08'),'8--14':('2026-10-08','2026-10-15'),'15--21':('2026-10-15','2026-10-22'),'22--31':('2026-10-22','2026-11-01')}
    times=np.arange(np.datetime64('2026-10-01T00:30'),np.datetime64('2026-11-01T00:30'),np.timedelta64(30,'m'))
    weeks=records(H/'AEMO_WEEKLY.csv')
    for r in weeks:
        d=H/'runs'/r['backbone']/r['run'];x=load(d/'context.npz');a,b=spans[r['segment']];ix=(times>np.datetime64(a))&(times<=np.datetime64(b));y=x['truth'][36:][ix]
        impl=r['implementation'];method,common,direct,two={'Cov':('CPOR-Cov','CovCommon','CovTarget',None),'ML':('CPOR-ML','MLCommon','MLTarget',None),'PIR':('PIRFull','PIRCommon','PIRCoherent','PIRTwoGroup')}[impl]
        rmse=lambda m:float(np.sqrt(((load(d/'results'/(m+'.npz'))['pred'][ix]-y)**2).mean(0)).mean())
        p=rmse(method);assert close(100*(1-p/rmse(common)),float(r['common_gain']))
        assert close(100*(p/rmse(direct)-1),float(r['protection_cost']))
        if two:assert close(100*(1-p/rmse(two)),float(r['two_gain']))
    # Timing records are observations; validate their aggregation rather than retime.
    timing=records(H/'CPOR_COST_AND_EVENTS.csv')
    for r in timing:
        d=H/'runs'/r['backbone']/r['run'];meta=json.loads((d/'CONTEXT_READY.json').read_text());key='cov' if r['method']=='CPOR-Cov' else 'ml'
        assert close(meta[key+'_seconds']/1488*1000,float(r['target_combination_mean_ms']))
        assert close(meta['bank_seconds']/1524*1000,float(r['shared_expert_bank_mean_ms']))
        steps=records(d/'diagnostics'/('Cov_steps.csv' if key=='cov' else 'ML_steps.csv'));ms=np.array([float(a['publication_ms']) for a in steps]);assert len(ms)==1488
        assert close(ms.mean(),float(r['publication_mean_ms'])) and close(np.quantile(ms,.95),float(r['publication_p95_ms']))
    out=dict(passed=True,streams=6,method_trajectories=len(hashes),rmse_cells=len(raw),weekly_rows=len(weeks),timing_rows=len(timing),claims=values,operations='Aggregate arithmetic from stored forecasts and timing logs; no retraining, optimization or retiming.')
    (H/'AGGREGATE_CHECK.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
