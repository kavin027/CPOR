"""No fitting: rebuild all tables from saved whole-month predictions."""
from aemo_extension_common import *
import zipfile,csv
NODES=['SYSTEM','NSW1','QLD1','SA1','TAS1','VIC1']
PRIMARY=['Raw','NNLS','PIR','ProCAST','Ada-Y','CovTarget','CPOR-Cov','MLTarget','CPOR-ML','CalBest','ProtectedCalBest','ProtectedProCAST','ProtectedAda-Y','PIRCoherent','PIRCommon','PIRTwoGroup','PIRFull','ProtectedWLSvar','ProtectedMinTshrink','ProtectedRollingMinT_Raw','ProtectedMinT_Cov','ProtectedMinT_CalBest']
def run(require=True):
    verify();rec=json.loads((H/'REGISTRATION.json').read_text());methods=rec['methods']+rec['supplementary_matched']
    for addition in H.glob('AMENDMENT*.json'):methods+=json.loads(addition.read_text()).get('added_methods',[])
    rows=[];checks=[];timing=[];fits=[];missing=[];hashes={}
    for bb in ['PatchTST','DLinear']:
      for seed in [42,1,2]:
        d=folder(bb,seed);x=load(d/'context.npz');y=x['truth'][36:]
        fitted=json.loads((d/'models'/bb/'FIT_READY.json').read_text());fits.append(dict(backbone=bb,run=seed,**{k:fitted[k] for k in ['cap','last_step','best_validation','seconds']}))
        for method in methods:
            p=d/'results'/(method+'.npz');q=p.with_suffix('.json')
            if not q.exists():missing.append(f'{bb}/{seed}/{method}');continue
            receipt=json.loads(q.read_text());assert sha(p)==receipt['sha256'];hashes[str(p.relative_to(H))]=sha(p)
            pred=load(p)['pred'];err=np.sqrt(((pred-y)**2).mean(0))
            scopes={'Overall':err.mean(),'Regions':err[1:].mean(),**dict(zip(NODES,err))}
            for scope,value in scopes.items():rows.append(dict(backbone=bb,run=seed,method=method,scope=scope,rmse=value))
            checks.append(dict(backbone=bb,run=seed,method=method,protected=receipt['protected'],**{k:v for k,v in receipt['audit'].items() if k!='final_allowances'}))
            logs=receipt.get('logs') or [];ms=[a.get('publication_ms',a.get('ms')) for a in logs];ms=[v for v in ms if v is not None]
            if ms:timing.append(dict(backbone=bb,run=seed,method=method,calls=len(ms),mean_ms=np.mean(ms),p95_ms=np.quantile(ms,.95),elapsed_seconds=receipt.get('elapsed_seconds')))
    if require:assert not missing,missing
    frame=pd.DataFrame(rows);frame.to_csv(H/'RUN_SCOPE_RMSE.csv',index=False)
    summary=frame.groupby(['backbone','method','scope']).rmse.agg(['mean','std','min','max']).reset_index();summary.to_csv(H/'THREE_RUN_RMSE.csv',index=False)
    pd.DataFrame(checks).to_csv(H/'PROTECTION_CHECKS.csv',index=False);pd.DataFrame(timing).to_csv(H/'PUBLICATION_TIMING.csv',index=False);pd.DataFrame(fits).to_csv(H/'BACKBONE_FITS.csv',index=False)
    comparisons=[('CPOR-Cov','NNLS'),('CPOR-ML','NNLS'),('CPOR-Cov','CPOR-ML'),('CPOR-Cov','PIR'),('CPOR-ML','PIR'),('CPOR-Cov','ProCAST'),('CPOR-ML','ProCAST'),('CPOR-Cov','Ada-Y'),('CPOR-ML','Ada-Y'),('CPOR-Cov','ProtectedMinTshrink'),('CPOR-ML','ProtectedMinTshrink'),('CPOR-Cov','ProtectedMinT_Cov'),('CPOR-ML','ProtectedMinT_Cov'),('CPOR-Cov','ProtectedCalBest'),('CPOR-ML','ProtectedCalBest'),('CPOR-Cov','CovTarget'),('CPOR-ML','MLTarget'),('CPOR-Cov','CovCommon'),('CPOR-ML','MLCommon'),('CPOR-Cov','CovAllReal'),('CPOR-ML','MLAllReal'),('PIRFull','PIRCommon'),('PIRFull','PIRTwoGroup'),('PIRFull','PIRCoherent')]
    comparisons.extend((a,b) for a in ['CPOR-Cov','CPOR-ML'] for b in ['LiDiag','LiFactor','ProtectedLiDiag','ProtectedLiFactor','Biswas','ProtectedBiswas'])
    pairs=[]
    for a,b in comparisons:
        aa=frame[frame.method==a].rename(columns={'rmse':'method_rmse'}).drop(columns='method');bb=frame[frame.method==b].rename(columns={'rmse':'comparator_rmse'}).drop(columns='method')
        both=aa.merge(bb,on=['backbone','run','scope']);both['gain_pct']=100*(1-both.method_rmse/both.comparator_rmse);both['method']=a;both['comparator']=b;pairs.append(both)
    paired=pd.concat(pairs,ignore_index=True);paired.to_csv(H/'PAIRED_GAINS.csv',index=False)
    gain=paired.groupby(['method','comparator','scope']).gain_pct.agg(['mean','median','min','max',lambda a:(a>0).sum()]).reset_index().rename(columns={'<lambda_0>':'positive_runs'});gain.to_csv(H/'PAIRED_SUMMARY.csv',index=False)
    negative=paired[(paired.scope.isin(NODES))&(paired.gain_pct<0)];negative.to_csv(H/'NEGATIVE_NODE_COMPARISONS.csv',index=False)
    js(H/'RESULT_HASHES.json',hashes)
    js(H/'STATUS.json',dict(complete=not missing,missing=missing,completed_results=len(hashes),expected_results=6*len(methods),registration_sha256=sha(H/'REGISTRATION.json'),frozen_manuscript_modified=False))
    print(summary[(summary.scope=='Overall')&(summary.method.isin(PRIMARY))].to_string(index=False))
    print(gain[gain.scope=='Overall'].to_string(index=False))
if __name__=='__main__':run('--partial' not in sys.argv)
