"""Applicable Li preprint configurations and KDD residual adapter on AEMO."""
from aemo_extension_common import *
import time,subprocess,os,copy
sys.path.insert(0,str(O/'cpor_li_preprint_20261106'));import paired as li
sys.path.insert(0,str(O/'cpor_li_factor_20261106'));from block_solve import make_mapper
NEW=['LiDiag','ProtectedLiDiag','LiFactor','ProtectedLiFactor','Biswas','ProtectedBiswas']
def pin():
    verify();path=H/'AMENDMENT_recent_controls.json'
    sources=[Path(__file__),H/'li_covariances.R',Path(li.__file__),O/'cpor_li_factor_20261106/block_solve.py',O/'cpor_li_factor_20261106/preprint_covEstimation.R',O/'cpor_kdd_comparison_20261105/grid.py']
    r=dict(registration_sha256=sha(H/'REGISTRATION.json'),registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),added_methods=NEW,reason='AEMO supplies all bottom observations, so both existing Li preprint configurations are applicable; also extend the existing KDD residual adapter. Coverage extension frozen before inspecting any of these new results, no change to Cov/ML or existing comparison rules.',
      Li='Existing Separate+eRidge grid, per-issue historical 80/20 split using R seed123; only covariance estimator differs, Diag versus Factor. Use all returned residuals from calibration start, current label excluded. Output both unprotected and NNLS-then-protected. Preprint not CCF A evidence.',
      Biswas='Original two-stage residual iTransformer, 144 pre-score residuals split120/24, L24/H12,10epochs,Adam1e-4,Huber,best validation epoch,scale.05; frozen residual model; update residual input at each 12-point block. Calendar frequency t for native half-hour data. Fixed adapter initialization42. No backbone retraining.',sources={str(p):sha(p) for p in sources})
    if path.exists():assert json.loads(path.read_text())['sources']==r['sources']
    else:js(path,r)
def li_targets(bb,seed):
    pin();d=folder(bb,seed)/'recent';d.mkdir(exist_ok=True);x=load(folder(bb,seed)/'context.npz');raw,y,S=x['raw'],x['truth'],x['S'];v,tr=li.geometry(S)
    if all((d/(k+'.json')).exists() for k in ['LiDiag','LiFactor']):return
    resfile=d/'residuals.csv';np.savetxt(resfile,y[:-1]-raw[:-1],delimiter=',',fmt='%.17g')
    covfile=d/'factor.bin';splitfile=d/'splits.csv'
    if not covfile.exists():
        r=O/'cpor_li_preprint_20261106/runtime/R/app/bin/x64/Rscript.exe'
        subprocess.run([str(r),'--vanilla',str(H/'li_covariances.R'),str(O/'cpor_li_factor_20261106/preprint_covEstimation.R'),str(resfile),str(splitfile),str(covfile)],cwd=str(d),env=dict(os.environ,R_USER=str(d)),check=True)
    assert covfile.stat().st_size==1488*2*6*6*8
    splits=pd.read_csv(splitfile,header=None);splits={int(row.iloc[0]):row.iloc[1:].dropna().to_numpy(int)-1 for _,row in splits.iterrows()}
    original_splits=pd.read_csv(li.HERE/'splits.csv',header=None)
    for _,row in original_splits.iterrows():np.testing.assert_array_equal(splits[int(row.iloc[0])],row.iloc[1:].dropna().to_numpy(int)-1)
    for name in ['LiDiag','LiFactor']:
        if (d/(name+'.json')).exists():continue
        diagnostics=[];f=covfile.open('rb')
        def sigma(res):return np.fromfile(f,dtype='<f8',count=36).reshape(6,6)
        mapping=li.mappings if name=='LiDiag' else make_mapper(sigma,diagnostics)
        pred=[];selected=[];tick=time.perf_counter()
        for t in range(36,len(y)):
            train,val=np.split(splits[t],[int(.8*t)]);res=y[:t]-raw[:t]
            w=mapping(res[train],S,v,tr,li.GRID);vr=li.bottom(raw[val],v,w)@S.T;scores=np.sqrt(((vr-y[val])**2).mean(axis=1)).mean(axis=1)
            lam=li.GRID[scores.argmin()];w=mapping(res,S,v,tr,np.array([lam]));p=(li.bottom(raw[t:t+1],v,w)@S.T)[0,0]
            assert np.isfinite(p).all();pred.append(p);selected.append(lam)
        if name=='LiFactor':assert not f.read(1)
        f.close();p=d/(name+'.npz');np.savez_compressed(p,pred=pred,lambda_values=selected)
        js(p.with_suffix('.json'),dict(sha256=sha(p),seconds=time.perf_counter()-tick,lambda_cap_hits=int((np.array(selected)==1e5).sum()),numerical=diagnostics,preprint=True));print('LI_READY',bb,seed,name,flush=True)
def biswas(bb,seed):
    pin();d=folder(bb,seed)/'recent';d.mkdir(exist_ok=True);p=d/'Biswas.npz'
    if p.with_suffix('.json').exists():assert sha(p)==json.loads(p.with_suffix('.json').read_text())['sha256'];return
    import torch
    from types import SimpleNamespace
    sys.path[:0]=[str(O/'cpor_named_venue_screen_20261105/KDDResidual'),str(O/'cpor_external_20261105/deps')]
    from model.iTransformer import Model
    from utils.timefeatures import time_features
    base=load(folder(bb,seed)/'models'/bb/'raw.npz');dates=pd.DatetimeIndex(base['dates']);raw,y=base['raw'],base['truth'];history=raw[:144]-y[:144];n=144;cut=120;L=24;h=12
    torch.set_num_threads(1);torch.manual_seed(42);mu=history[:cut].mean(0);sd=history[:cut].std(0);sd[sd==0]=1
    dt=time_features(dates,freq='t').T
    tensor=lambda a:torch.as_tensor(a,dtype=torch.float32,device='cuda')
    cfg=SimpleNamespace(seq_len=L,pred_len=h,output_attention=False,use_norm=True,d_model=256,embed='timeF',freq='t',dropout=.1,class_strategy='projection',factor=1,n_heads=8,e_layers=2,d_ff=256,activation='gelu')
    tick=time.perf_counter();m=Model(cfg).cuda();opt=torch.optim.Adam(m.parameters(),lr=.0001);fn=torch.nn.HuberLoss();best=float('inf');logs=[]
    def batch(ids):return [tensor(np.stack(a)) for a in [[(history[i-L:i]-mu)/sd for i in ids],[dt[i-L:i] for i in ids],[(history[i:i+h]-mu)/sd for i in ids]]]
    for ep in range(10):
        m.train()
        for off in range(L,cut-h+1,32):
            a,b,label=batch(range(off,min(off+32,cut-h+1)));opt.zero_grad();fn(m(a,b,None,None),label).backward();opt.step()
        m.eval()
        with torch.no_grad():a,b,label=batch(range(cut,n-h+1));val=float(fn(m(a,b,None,None),label))
        logs.append(dict(epoch=ep+1,validation=val))
        if val<best:best=val;bestep=ep+1;state=copy.deepcopy(m.state_dict())
    m.load_state_dict(state);m.eval();torch.save(state,d/'Biswas_checkpoint.pt');pred=[];hs=history.copy()
    for j in range(144,len(raw),12):
        with torch.no_grad():e=m(tensor((hs[-L:]-mu)/sd)[None],tensor(dt[j-L:j])[None],None,None)[0].cpu().numpy()*sd+mu
        pred.extend(raw[j:j+h]-.05*e);hs=np.concatenate([hs,raw[j:j+h]-y[j:j+h]])
    np.savez_compressed(p,pred=np.array(pred));js(p.with_suffix('.json'),dict(sha256=sha(p),seconds=time.perf_counter()-tick,epochs=logs,best_epoch=bestep,adapter_initialization=42));del m;torch.cuda.empty_cache()
    print('BISWAS_READY',bb,seed,flush=True)
def release(bb,seed):
    import compare as cc
    x=cc.context(bb,seed);d=folder(bb,seed)/'results'
    for name in ['LiDiag','LiFactor','Biswas']:
        path=folder(bb,seed)/'recent'/(name+'.npz');meta=json.loads(path.with_suffix('.json').read_text());assert sha(path)==meta['sha256'];raw=load(path)['pred']
        if not cc.ready(d,name):cc.savearm(d,x,name,raw,raw[:,1:] if name.startswith('Li') and raw.min()>=0 else None,elapsed=meta['seconds'])
        if cc.ready(d,'Protected'+name):continue
        z,u=cc.old.project(x['S'],raw,x['v']);pred,rep,logs,elapsed=cc.publish(x,z);cc.savearm(d,x,'Protected'+name,pred,rep,True,logs,elapsed)
if __name__=='__main__':
    from threadpoolctl import threadpool_limits
    with threadpool_limits(1):
        if sys.argv[1]=='pin':pin()
        elif sys.argv[1]=='release':release(sys.argv[2],int(sys.argv[3]))
        elif sys.argv[1]=='li':li_targets(sys.argv[2],int(sys.argv[3]))
        else:biswas(sys.argv[2],int(sys.argv[3]))
