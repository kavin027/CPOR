"""Independent NumPy-only audit. Run from the extracted experiment directory."""
from pathlib import Path
from fractions import Fraction as F
import numpy as np
import json,hashlib,sys
H=Path(__file__).resolve().parent;R=F(40401,40000);K=R-1
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
    with np.load(p,allow_pickle=False) as a:return {k:a[k] for k in a.files}
def check(x,p,u,domain):
    b,y=x['b'][36:],x['truth'][36:];A=[F(0)]*6
    assert len(y)==1488 and p.shape==y.shape and p.min()>=0 and y.min()>=0
    assert np.isfinite(p).all() and np.isfinite(u).all() and u.min()>=0
    assert np.allclose(p,u@x['S'].T,rtol=1e-8,atol=2e-6)
    for t in range(len(y)):
        for i in range(6):
            beta,z,label=map(lambda a:F.from_float(float(a)),[b[t,i],p[t,i],y[t,i]])
            worst=z*z-R*beta*beta if domain=='nonnegative' and z>R*beta else R*(z-beta)**2/K
            assert worst<=A[i],('envelope',t,i)
            A[i]+=R*(beta-label)**2-(z-label)**2
            assert A[i]>=0,('prefix',t,i)
    return p.size
def main():
    hashes=json.loads((H/'RESULT_HASHES.json').read_text());count=trajectories=0
    for rel,digest in hashes.items():
        path=H/rel;assert sha(path)==digest,rel
        receipt=json.loads(path.with_suffix('.json').read_text());assert receipt['sha256']==digest
        if not receipt['protected']:continue
        x=load(path.parent.parent/'context.npz');z=load(path)
        count+=check(x,z['pred'],z['witness'],receipt['domain']);trajectories+=1
    if '--self-test' in sys.argv:
        path=next(H/p for p in hashes if 'CPOR-Cov.npz' in p);x=load(path.parent.parent/'context.npz');z=load(path);p=z['pred'].copy();p[0,0]+=100
        try:check(x,p,z['witness'],'nonnegative')
        except AssertionError:pass
        else:raise AssertionError('Corruption was not rejected')
    expected=json.loads((H/'STATUS.json').read_text());assert expected['complete']
    result=dict(passed=True,hashed_results=len(hashes),protected_trajectories=trajectories,exact_envelope_node_dates=count,exact_prefix_node_dates=count,resets_per_trajectory=1,month_observations=1488,self_test='--self-test' in sys.argv)
    (H/'INDEPENDENT_CHECK.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
