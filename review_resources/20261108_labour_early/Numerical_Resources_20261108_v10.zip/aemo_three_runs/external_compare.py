"""Same-stream ProCAST and Ada-Y; original adapters, no October tuning."""
from aemo_extension_common import *
import time,random,importlib.util
import torch
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
ext=module('aemo_original_external',O/'cpor_external_repetitions_20261020/run.py')
pro=module('aemo_original_procast',O/'rr_recap_strong_baseline_20261006/run.py')
def pin():
    verify();p=H/'AMENDMENT_external_driver.json'
    files=[Path(__file__),Path(ext.__file__),Path(pro.__file__),Path(ext.aday.__file__),Path(ext.pir.__file__),O/'rr_recap_evidence_extension_20261002/procast_author.py']
    sources={str(f):sha(f) for f in files}
    if p.exists():assert json.loads(p.read_text())['sources']==sources
    else:js(p,dict(registration_sha256=sha(H/'REGISTRATION.json'),reason='Pin length-generalized original external adapters before additional baseline scoring.',sources=sources))
def data(bb,seed):
    wide=pd.read_csv(OLD/'observed.csv',parse_dates=['ds']).set_index('ds');v=wide.to_numpy();base=load(folder(bb,seed)/'models'/bb/'raw.npz')
    begin,start=int(base['begin']),int(base['start']);end=start-36;positions=np.arange(begin,len(v));lib=np.arange(24,end)
    mu=v[:end].mean(0);sd=v[:end].std(0);sd=np.where(sd>0,sd,1.)
    return dict(x=((np.stack([v[t-24:t] for t in positions])-mu)/sd).astype('float32'),raw=((base['raw']-mu)/sd)[:,None,:].astype('float32'),
      y=((v[positions]-mu)/sd)[:,None,:].astype('float32'),encmark=np.stack([ext.pir.calendar(wide.index[t-24:t]) for t in positions]),mark=ext.pir.calendar(wide.index[positions])[:,None,:],
      lib_x=((np.stack([v[t-24:t] for t in lib])-mu)/sd).astype('float32'),lib_y=((v[lib]-mu)/sd)[:,None,:].astype('float32'),library_index=positions-24,mu=mu,sd=sd,train_count=108,score_start=144)
def adapters(bb,seed):
    pin();d=folder(bb,seed)/'external';d.mkdir(parents=True,exist_ok=True);torch.set_num_threads(1)
    p=d/'Ada-Y.npz'
    if not p.with_suffix('.json').exists():
        random.seed(42);np.random.seed(42);torch.manual_seed(42);torch.cuda.manual_seed_all(42)
        tick=time.perf_counter();pred,state,logs=ext.fit_aday(data(bb,seed),'cuda');assert pred.shape==(1488,6)
        np.savez_compressed(p,pred=pred);torch.save(state,d/'Ada-Y_checkpoint.pt')
        js(p.with_suffix('.json'),dict(sha256=sha(p),seconds=time.perf_counter()-tick,adapter_initialization=42,epochs=logs))
        torch.cuda.empty_cache()
    else:assert sha(p)==json.loads(p.with_suffix('.json').read_text())['sha256']
    p=d/'ProCAST.npz'
    if p.with_suffix('.json').exists():assert sha(p)==json.loads(p.with_suffix('.json').read_text())['sha256'];return
    base=load(folder(bb,seed)/'models'/bb/'raw.npz');raw,y,S=base['raw'],base['truth'],base['S']
    torch.manual_seed(42);np.random.seed(42)
    yh=torch.tensor(raw,device='cuda',dtype=torch.float64);yt=torch.tensor(y,device='cuda',dtype=torch.float64);counts=[]
    model=pro._TorchPinv(torch.tensor(S,dtype=torch.float32),masked=False,max_iter=100000,callback=lambda a:counts.append(int(a[1])) if a[0]=='count' else None).to(device='cuda',dtype=torch.float64)
    preds=[];us=[];times=[];start=time.perf_counter()
    for i in range(108,len(raw)):
        tick=time.perf_counter();n=min(72,i);weights=torch.tensor([.5/n]*n+[.5],device='cuda',dtype=torch.float64)
        model.fit(yh[i-n:i+1],torch.cat([yt[i-n:i],yh[i:i+1]]),weights=weights)
        with torch.no_grad():
            u=(yh[i:i+1]@model.pinv).clamp(min=0);preds.append((u@model.mat).cpu().numpy()[0]);us.append(u.cpu().numpy()[0])
        times.append(time.perf_counter()-tick)
        if (i-107)%240==0:print('PROCAST',bb,seed,i-107,1524,flush=True)
    assert len(counts)==1524
    np.savez_compressed(p,pred=np.array(preds)[36:],witness=np.array(us)[36:],cal_pred=np.array(preds)[:36],iterations=counts,seconds=times)
    js(p.with_suffix('.json'),dict(sha256=sha(p),seconds=time.perf_counter()-start,limit_hits=sum(k>=100000 for k in counts),max_iterations=max(counts),adapter_initialization=42))
    del model,yh,yt;torch.cuda.empty_cache()
def publication(bb,seed):
    import compare as cc
    cc.pin();d=folder(bb,seed)/'results';x=cc.context(bb,seed)
    for name in ['ProCAST','Ada-Y']:
        p=folder(bb,seed)/'external'/(name+'.npz');receipt=json.loads(p.with_suffix('.json').read_text());assert sha(p)==receipt['sha256'];raw=load(p)['pred']
        if not cc.ready(d,name):cc.savearm(d,x,name,raw,elapsed=receipt['seconds'])
        if cc.ready(d,'Protected'+name):continue
        z,u=cc.old.project(x['S'],raw,x['v']);pred,rep,logs,elapsed=cc.publish(x,z)
        np.savez_compressed(folder(bb,seed)/'external'/(name+'_coherent.npz'),pred=z,witness=u)
        cc.savearm(d,x,'Protected'+name,pred,rep,True,logs,elapsed)
    js(d/'EXTERNAL_DONE.json',dict(backbone=bb,initialization=seed))
if __name__=='__main__':
    from threadpoolctl import threadpool_limits
    with threadpool_limits(1):
        if sys.argv[1]=='pin':pin()
        elif sys.argv[1]=='release':publication(sys.argv[2],int(sys.argv[3]))
        else:adapters(sys.argv[1],int(sys.argv[2]))
