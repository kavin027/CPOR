from study_common import *
from fractions import Fraction
def risk(p,b,y):
    R=Fraction(40401,40000);A=[Fraction(0)]*p.shape[1];ever=set();events=0
    for pp,bb,yy in zip(p,b,y):
        for i in range(p.shape[1]):
            x,v,z=map(lambda a:Fraction.from_float(float(a)),[pp[i],bb[i],yy[i]])
            A[i]+=R*(v-z)**2-(x-z)**2
            if A[i]<0:ever.add(i);events+=1
    return len(ever),events
def main():
    verify()
    metrics=[];steps=[];audits=[];risks=[];effects=[]
    for bb in ['PatchTST','DLinear']:
        d=H/'results'/bb
        receipt=json.loads((d/'DONE.json').read_text());assert sha(d/'trajectories.npz')==receipt['sha256']
        x=load(d/'trajectories.npz')
        m=pd.read_csv(d/'node_rmse.csv');metrics.append(m)
        steps.append(pd.read_csv(d/'steps.csv').assign(backbone=bb))
        audits.append(pd.read_csv(d/'independent_audit.csv').assign(backbone=bb))
        for method,forecast in [('Reference',x['reference']),('Raw',x['raw']),('PIR',x['pir_raw']),('Candidate',x['candidate']),*[ (name,x[name]) for name in ['Common','TwoGroup','Full']]]:
            ever,events=risk(forecast,x['reference'],x['truth'])
            risks.append(dict(backbone=bb,method=method,ever=ever,events=events,node_sequences=6,node_dates=1488*6))
        for segment in m.segment.unique():
            mm=m.query('segment==@segment')
            for scope,ns in [('all',list(range(6))),('system',[0]),('regions',list(range(1,6)))]:
                g=mm.query('node in @ns').groupby('method').rmse.mean()
                effects.append(dict(backbone=bb,segment=segment,scope=scope,**g.to_dict(),full_vs_common_pct=100*(1-g.Full/g.Common),full_vs_twogroup_pct=100*(1-g.Full/g.TwoGroup),full_cost_pct=100*(g.Full/g.Candidate-1)))
    m=pd.concat(metrics,ignore_index=True);t=pd.concat(steps,ignore_index=True);a=pd.concat(audits,ignore_index=True);r=pd.DataFrame(risks);e=pd.DataFrame(effects)
    m.to_csv(H/'node_rmse.csv',index=False);t.to_csv(H/'publication_steps.csv',index=False);a.to_csv(H/'independent_audit.csv',index=False);r.to_csv(H/'risk.csv',index=False);e.to_csv(H/'effects.csv',index=False)
    timing=t.groupby(['backbone','arm']).ms.agg(mean='mean',p95=lambda v:v.quantile(.95))
    timing.to_csv(H/'timing.csv')
    print('MONTHLY RMSE AND EFFECTS\n',e.query("segment=='Month'").round(5).to_string(index=False))
    print('Mean paired overall gains across backbones\n',e.query("segment=='Month' and scope=='all'")[['full_vs_common_pct','full_vs_twogroup_pct','full_cost_pct']].mean().to_string())
    print('Fixed segments, same ledger\n',e.query("scope=='all'")[['backbone','segment','full_vs_common_pct','full_vs_twogroup_pct','full_cost_pct']].round(5).to_string(index=False))
    print('NODE ERRORS\n',m.query("segment=='Month'").pivot(index=['backbone','node'],columns='method',values='rmse').round(4).to_string())
    print('RISK\n',r.to_string(index=False))
    print('TIMES\n',timing.round(4).to_string())
if __name__=='__main__':main()
