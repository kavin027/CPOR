# AEMO October 2026 frozen temporal validation

Maps to main Table 14 / Sections 5.6 and 6.7 and Supplement S17 / Tables S24--S27.

From the extracted OR2 root:

    python aemo_october/check_current.py
    python aemo_october/check_package.py

The first command needs only Python's standard library. It checks file hashes, node-to-group aggregation, month/segment paired gains, all six timing summaries, and stored violation counts. The second needs NumPy and recalculates exact envelopes and actual cumulative errors from all 6 stored release trajectories (53,568 node-dates); it also rejects injected corruption. It checks coherence with the stated floating tolerances.

`effects.csv` supplies main Table 14 and segment results. `node_effects.csv` supplies S25; `risk.csv`, `timing.csv` and `publication_steps.csv` supply S27. `models/*/FIT_READY.json` pins validation selection and training stops; these checkpoints and all original base forecast blocks remain in the local study archive and are not included in this numerical bundle. These commands do not train the neural models or rerun an optimizer.

`PROTOCOL.md`, `REGISTRATION.json`, both implementation amendments and `registered_source/` preserve the pre-acquisition design and source hashes. `prior_totaldemand/` preserves the earlier ineligible signed outcome attempt. Related TOTALDEMAND was inspected for domain eligibility before the replacement variable was registered; no method accuracies were scored on that attempt.

Outcome: AEMO estimated underlying demand (operational demand + measurement-based rooftop PV estimate), all five NEM regions and their exact system sum. `SOURCE_RECEIPT.json` provides all 520 original source URLs and hashes. Original public ZIPs remain available from those sources and in the local raw archive. They are not duplicated here. All derived outcomes, component values and PV quality summaries needed for the numerical checks are included. Sources: https://www.aemo.com.au/energy-systems/electricity/national-electricity-market-nem/data-nem/operational-demand-data and the AEMO Australian Solar Energy Forecasting System page cited in the paper.

The month is continuous with zero initial allowance and no resets, epsilon=0.005, independent allowances for Common/TwoGroup/Full. Two backbones share the same month's observations. This is a frozen new-outcome temporal validation under finalized sequential-feedback data, not an original-data-arrival replay. Publication times are from this six-node experiment; they are separate from the six-dataset timing grid.
