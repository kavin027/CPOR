from study_common import *
import inspect,torch
from neuralforecast.models import PatchTST,DLinear
import importlib.metadata
def main():
    assert not (H/'source').exists() and not (H/'observed.csv').exists()
    paths=list(H.glob('*.py'))+[H/'PROTOCOL.md',H/'DIRECTORY_INVENTORY.json']
    paths.extend([O/'c0_external_sota_20261014/pir_adapter.py',O/'pir_grouped_release_20261106/grouped.py',O/'cpor_envelope_comparison_20261024/run_comparison.py',O/'cpor_reference_allowance_20261107/audit_trajectories.py'])
    author=O/'c0_external_sota_20261014/author_source/PIR-fc372bb02090da887d4a20b614a6cfecbfd813d0'
    paths.extend(author.rglob('*.py'))
    # Pin the exact existing publication implementation closure before acquisition.
    sys.path.insert(0,str(O/'cpor_envelope_comparison_20261024'))
    import run_comparison as c
    c.kernels('nonnegative')
    for m in list(sys.modules.values()):
        f=getattr(m,'__file__',None)
        if f and str(f).lower().endswith('.py') and str(O).lower() in str(Path(f).resolve()).lower():paths.append(Path(f).resolve())
    paths.extend([Path(inspect.getsourcefile(PatchTST)),Path(inspect.getsourcefile(DLinear))])
    versions={k:importlib.metadata.version(k) for k in ['torch','neuralforecast','numpy','pandas','scipy','pytorch-lightning']}
    reg=dict(registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),registered_before_acquisition=True,score_labels_downloaded=False, prior_signed_TOTALDEMAND_eligibility_inspected=True, target_definition="OPERATIONAL_DEMAND + MEASUREMENT rooftop POWER", previous_registration_sha256=sha(O/"cpor_aemo_october_confirmation_20261107/REGISTRATION.json"),protocol_sha256=sha(H/'PROTOCOL.md'),sources={str(p.resolve()):sha(p) for p in sorted(set(paths))},versions=versions,
      backbone_signatures={k:str(inspect.signature(cls.__init__)) for k,cls in [('PatchTST',PatchTST),('DLinear',DLinear)]},
      regions=REGIONS,score_start=str(START),score_end=str(END),score_observations=1488,reference='unweighted NNLS',allowance='.005',candidate='author-adapted PIR with frozen historical library, then weighted NNLS',methods=['Common','TwoGroup','Full'],backbones=['PatchTST','DLinear'],initializations=[42],no_scored_balance_resets=True,
      prior_frozen_manuscript_sha256=sha(O/'cpor_kais_projection_order_20261107/KAIS_CPOR_Projection_Order_Clean.zip'),
      local_new_period_audit_sha256=sha(O/'cpor_reference_allowance_20261107/new_time_source_status.json'))
    js(H/'REGISTRATION.json',reg)
    archive=H/'registered_source';archive.mkdir()
    for i,p in enumerate(sorted(set(paths))):
        data=p.read_bytes();(archive/f'{i:03d}_{p.name}').write_bytes(data)
    print('REGISTERED BEFORE DATA',sha(H/'REGISTRATION.json'),len(reg['sources']),flush=True)
if __name__=='__main__':main()

