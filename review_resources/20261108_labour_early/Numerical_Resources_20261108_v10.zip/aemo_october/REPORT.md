# AEMO 非负新变量整月冻结验证结果

## 结论
已找到并取得物理含义明确的替代变量，完成了重新冻结后的整月比较。变量采用 AEMO 官方定义的 **underlying demand（估计总用电需求）= OPERATIONAL_DEMAND + 屋顶光伏 MEASUREMENT 发电估计**，单位 MW。该变量不是纯计量的毛负荷，也不是把旧 TOTALDEMAND 负值截断后的序列。

在两个预先固定的骨干上，完整投影的整月 mean-node RMSE 都低于统一收缩与两组收缩；等权平均改善分别为 **3.8235%、2.2574%**。三种规则全部守住同一个逐节点累计合同。未保护候选、局部区域和分段结果同时保留，不能据此声称每个区域、每段时间都更准。

## 数据与登记
- 五区域 NSW1、QLD1、SA1、TAS1、VIC1 全部保留；SYSTEM 为其和。
- 九月历史 1440 点，十月评分 1488 点，每点间隔30分钟；按固定 AEST（UTC+10）区间结束时刻对齐。十月从10月1日00:30至11月1日00:00，连续运行，不逐日/逐周/逐块清零。
- 520份官方原始ZIP、3594份嵌套CSV均保存并核对哈希；两分量均无缺失。最新修订按 LASTCHANGED 合并，冲突不得覆盖。
- 原始运行需求含37个负值（十月30个），原样保存；相加后的五区域底层需求没有负值。十月最低 NSW/QLD/SA/TAS/VIC 分别为6206/5445/1072/910/4313 MW。没有截断、插值、删地区或删日期。
- 光伏为样本外推的估计值。QI=0.7与1的记录均保留，分布见 pv_quality.csv。
- 变量依据官方物理定义选择，获取新分量前登记：2026-11-07T03:26:17.918634+00:00。协议SHA256 `a072f92a05e7dce3eaa2ff774f25b7c88fb2ab974c5240664c9ae0f53e250975`；登记SHA256 `08227dd13274a269bf2ed041fbe427ae9c765c424dbee6473bf5e16e572ce938`。
- 之前已为资格核查查看过同月相关净需求 TOTALDEMAND，其负值与旧登记均保留，未计算方法准确率。此处应称**新变量方案预先冻结的时间外验证**，不声称十月所有相关信息从未被查看。
- 两次实现性补记均保留：补取八月归档中的九月首八个半小时；将日期对象序列化改为Unicode，已核对所有数值预测不变。未改变变量、模型、评分日期、参考、容差、比较规则。

## 固定方案
PatchTST、DLinear各一次初始化，权重只用九月训练/验证；108个支持预测和36个校准预测均在十月之前。PIR模型及检索库在十月冻结，只刷新已返回历史上下文。参考为同一批骨干预测的无权NNLS，候选为同一PIR输出的一次方差加权非负协调。三规则各自维护独立精确余额，月初零额度，epsilon=.005，R=40401/40000。

分组预先固定：NSW/QLD/SA一组，TAS/VIC另一组，不按结果重分组。候选与参考在三臂间逐值相同。

该回放采用冻结的顺序成熟反馈假设。官方屋顶光伏估计延迟约30分钟，且原始需求可事后修订；本实验不还原历史实时数据到达，不构成原时间点已可得所有最终观测的证据。

训练状态：PatchTST达到登记的500步上限，保留验证最优检查点；DLinear在1783步早停（上限10000）。未依据十月表现追加训练。验证曲线、检查点与所有12步基础预测块均保存。

## 整月主要结果
下表为平均节点RMSE（MW）。正改善代表完整投影更准；正代价代表相对直接发布误差增加。百分比先在每个骨干内部配对计算，再等权平均，两个骨干共享同一个月份，不是两个独立数据集。

| 骨干 | 同一候选直接发布 | 统一收缩 | 两组收缩 | 完整投影 | 对统一收缩改善% | 对两组收缩改善% | 对直接发布代价% |
|---|---|---|---|---|---|---|---|
| PatchTST | 580.720 | 587.791 | 571.507 | 550.056 | 6.420 | 3.753 | -5.280 |
| DLinear | 705.218 | 726.351 | 722.942 | 717.437 | 1.227 | 0.761 | 1.733 |

完整投影相对未保护同一候选：PatchTST **降低5.2803%**，DLinear **增加1.7328%**；平均变化为 **-1.7738%**。保护可能改善或损失准确率，不能把此均值解释为固定保护成本。

## 系统与区域
| backbone | scope | Common | TwoGroup | Full | full_vs_common_pct | full_vs_twogroup_pct | full_cost_pct |
|---|---|---|---|---|---|---|---|
| PatchTST | all | 587.791 | 571.507 | 550.056 | 6.420 | 3.753 | -5.280 |
| PatchTST | system | 1407.911 | 1358.550 | 1278.502 | 9.192 | 5.892 | -2.231 |
| PatchTST | regions | 423.767 | 414.099 | 404.367 | 4.578 | 2.350 | -7.112 |
| DLinear | all | 726.351 | 722.942 | 717.437 | 1.227 | 0.761 | 1.733 |
| DLinear | system | 2099.083 | 2088.448 | 2071.663 | 1.306 | 0.804 | 1.852 |
| DLinear | regions | 451.805 | 449.840 | 446.592 | 1.154 | 0.722 | 1.622 |

逐区域完整误差及配对百分比见 node_effects.csv。完整投影存在以下节点退化（极小数值差异也照实保留）：

| backbone | node | candidate | Common | TwoGroup | Full | full_vs_common_pct | full_vs_twogroup_pct | full_cost_pct |
|---|---|---|---|---|---|---|---|---|
| PatchTST | NSW1 | 545.495 | 535.665 | 537.244 | 544.280 | -1.608 | -1.310 | -0.223 |
| PatchTST | QLD1 | 469.086 | 322.851 | 322.855 | 322.854 | -0.001 | 0.000 | -31.174 |

PatchTST在NSW相对统一收缩退化约1.61%，相对两组收缩退化约1.31%；QLD对统一收缩的退化约0.001%。区域累计守约不代表每一区域准确率都更好。

## 连续账户上的预定分段结果
所有段落从同一整月发布序列截取，段起点没有重置余额。

| backbone | segment | full_vs_common_pct | full_vs_twogroup_pct | full_cost_pct |
|---|---|---|---|---|
| PatchTST | Month | 6.420 | 3.753 | -5.280 |
| PatchTST | Oct1-7 | 4.866 | 4.266 | -14.638 |
| PatchTST | Oct8-14 | 7.175 | 6.348 | -4.402 |
| PatchTST | Oct15-21 | 0.073 | -2.680 | -6.288 |
| PatchTST | Oct22-31 | 8.988 | 5.126 | -2.489 |
| DLinear | Month | 1.227 | 0.761 | 1.733 |
| DLinear | Oct1-7 | 4.590 | 2.903 | 7.445 |
| DLinear | Oct8-14 | -0.000 | -0.000 | 0.000 |
| DLinear | Oct15-21 | 0.000 | 0.000 | -0.000 |
| DLinear | Oct22-31 | 0.000 | 0.000 | -0.000 |

PatchTST在10月15—21日相对两组收缩退化2.68%。DLinear后3段的规则输出基本相同：累计额度形成后，候选已可直接发布，额外投影不再带来明显修正。因此整月平均正收益不代表持续每周获益。

## 保护与数值检查
| backbone | method | ever | events | node_sequences | node_dates |
|---|---|---|---|---|---|
| PatchTST | Reference | 0 | 0 | 6 | 8928 |
| PatchTST | Raw | 5 | 4517 | 6 | 8928 |
| PatchTST | PIR | 6 | 2368 | 6 | 8928 |
| PatchTST | Candidate | 6 | 2305 | 6 | 8928 |
| PatchTST | Common | 0 | 0 | 6 | 8928 |
| PatchTST | TwoGroup | 0 | 0 | 6 | 8928 |
| PatchTST | Full | 0 | 0 | 6 | 8928 |
| DLinear | Reference | 0 | 0 | 6 | 8928 |
| DLinear | Raw | 1 | 1 | 6 | 8928 |
| DLinear | PIR | 4 | 7 | 6 | 8928 |
| DLinear | Candidate | 4 | 7 | 6 | 8928 |
| DLinear | Common | 0 | 0 | 6 | 8928 |
| DLinear | TwoGroup | 0 | 0 | 6 | 8928 |
| DLinear | Full | 0 | 0 | 6 | 8928 |

ever指从月初起至少一次越限的节点序列数，events指节点—日期累计合同越限数。三种受保护规则共六条整月路径，独立重算 **53568个节点—日期** 的精确包络与实际前缀误差，全部零违规；同时逐值核对53568个归档有理数余额。每臂跨两骨干17856次检查。人为破坏第一个发布值能被独立检查器检出。

未保护的同一相干PIR候选共有10/12条节点序列曾越限：PatchTST6/6、DLinear4/6。这是同月的相关节点轨迹，不能当作独立样本计数。相干性另按rtol1e-8/atol2e-6验收，不等同于精确有理数相干性。

## 发布时间
单位毫秒/次发布，含最终认证，不含预测/候选生成、余额结算和事后审计。数值线程为1，规则执行次序逐步轮转。

| backbone | arm | mean | p95 |
|---|---|---|---|
| DLinear | Common | 0.141 | 0.150 |
| DLinear | Full | 1.095 | 1.137 |
| DLinear | TwoGroup | 0.123 | 0.186 |
| PatchTST | Common | 0.153 | 0.181 |
| PatchTST | Full | 1.130 | 1.189 |
| PatchTST | TwoGroup | 0.247 | 0.315 |

## 来源与可核查文件
- 官方变量定义：https://www.aemo.com.au/energy-systems/electricity/national-electricity-market-nem/data-nem/operational-demand-data
- 官方光伏估计类型与延迟：https://www.aemo.com.au/energy-systems/electricity/national-electricity-market-nem/nem-forecasting-and-planning/operational-forecasting/solar-and-wind-energy-forecasting/australian-solar-energy-forecasting-system
- 官方光伏字段与结束时刻：https://visualisations.aemo.com.au/aemo/nemweb/MMSDataModelReport/Electricity/MMS%20Data%20Model%20Report_files/MMS_111.htm
- PROTOCOL.md、REGISTRATION.json、AMENDMENT_01/02.json：原方案与实施性补记。
- SOURCE_RECEIPT.json、source/、components.csv：全部原始来源、哈希与逐分量记录。
- effects.csv、node_effects.csv、risk.csv、timing.csv：总体、分层、负面结果、保护、计时。
- results/*/trajectories.npz、allowances.csv：全部发布值、参考、同一候选、观测和逐步余额。
- FINAL_AUDIT.json与check_package.py：文件和精确路径核查入口。

未改论文，未改Figure 1，未改原冻结投稿包。原TOTALDEMAND失败资格登记和原冻结稿均保持原哈希。此次结果支持在这一非负新需求变量、连续整月和指定合约下，完整投影较两种收缩保留更多精度；范围仍是一个新月份、每骨干一次初始化及既定反馈/训练预算。
