from study_common import *
import logging,random,time,copy
import torch
from neuralforecast import NeuralForecast
from neuralforecast.models import PatchTST,DLinear
from pytorch_lightning.callbacks import ModelCheckpoint,Callback

sys.path.insert(0,str(O/'c0_external_sota_20261014'))
import pir_adapter as pir

class History(Callback):
    def __init__(self):self.rows=[]
    def on_validation_end(self,trainer,model):
        if not trainer.sanity_checking:
            self.rows.append(dict(step=int(trainer.global_step),validation_mae=float(trainer.callback_metrics['ptl/val_loss'])))
            if trainer.global_step%500==0:print('FIT_STEP',type(model).__name__,trainer.global_step,self.rows[-1]['validation_mae'],flush=True)

def forecast(bb):
    verify();ready=json.loads((H/'DATA_READY.json').read_text())
    assert sha(H/'observed.csv')==ready['observed_sha256']
    wide=pd.read_csv(H/'observed.csv',parse_dates=['ds']).set_index('ds')
    begin=wide.index.get_loc(BEGIN);start=wide.index.get_loc(START)
    assert start-begin==144 and len(wide)-start==1488
    d=H/'models'/bb;d.mkdir(parents=True,exist_ok=True)
    path=d/'raw.npz'
    if (d/'RAW_READY.json').exists():
        assert sha(path)==json.loads((d/'RAW_READY.json').read_text())['sha256']
        return wide,load(path)
    torch.set_num_threads(1)
    cls=PatchTST if bb=='PatchTST' else DLinear
    if not (d/'FIT_READY.json').exists():
        cb=ModelCheckpoint(dirpath=str(d/'checkpoint'),monitor='ptl/val_loss',save_top_k=1)
        options=dict(h=12,input_size=24,max_steps=500 if bb=='PatchTST' else 10000,learning_rate=.0001,
                     val_check_steps=1,early_stop_patience_steps=50,random_seed=42,scaler_type='identity',
                     callbacks=[cb,History()],enable_checkpointing=True,enable_progress_bar=False,
                     enable_model_summary=False,logger=False,accelerator='gpu',devices=1,default_root_dir=str(d))
        model=cls(**options)
        nf=NeuralForecast(models=[model],freq='30min')
        prefix=wide.iloc[:begin].reset_index().melt(id_vars='ds',var_name='unique_id',value_name='y')
        begun=time.perf_counter();nf.fit(df=prefix,val_size=36)
        callbacks=nf.models[0].trainer_kwargs['callbacks']
        checkpoint=next(c for c in callbacks if isinstance(c,ModelCheckpoint))
        history=next(c for c in callbacks if isinstance(c,History))
        assert checkpoint.best_model_path and history.rows
        pd.DataFrame(history.rows).to_csv(d/'validation_curve.csv',index=False)
        best=d/'best.ckpt'
        state=torch.load(checkpoint.best_model_path,map_location='cpu',weights_only=False)
        state['hyper_parameters']['callbacks']=[]
        torch.save(state,best)
        js(d/'FIT_READY.json',dict(checkpoint_sha256=sha(best),cap=options['max_steps'],
          last_step=history.rows[-1]['step'],best_validation=float(checkpoint.best_model_score),
          seconds=time.perf_counter()-begun,last_fit_label=str(wide.index[begin-1]),last_weight_training_or_validation_label=str(wide.index[begin-1]),registration_sha256=sha(H/'REGISTRATION.json')))
        del nf,model;torch.cuda.empty_cache()
    fitted=json.loads((d/'FIT_READY.json').read_text());assert sha(d/'best.ckpt')==fitted['checkpoint_sha256']
    trained=cls.load_from_checkpoint(str(d/'best.ckpt'),map_location='cpu',weights_only=False,callbacks=[],
        early_stop_patience_steps=0,enable_checkpointing=False,enable_progress_bar=False,enable_model_summary=False,
        logger=False,accelerator='gpu',devices=1,default_root_dir=str(d))
    nf=NeuralForecast(models=[trained],freq='30min');nf._fitted=True
    full=wide.reset_index().melt(id_vars='ds',var_name='unique_id',value_name='y').sort_values(['ds','unique_id'])
    prefix=full.loc[full.ds<BEGIN]
    nf.dataset,nf.uids,nf.last_dates,nf.ds=nf._prepare_fit(prefix,None,False,'unique_id','ds','y')
    nf.models[0].val_size=36;nf.models[0].test_size=0
    pieces=[]
    for offset,i in enumerate(range(begin,len(wide),12)):
        cache=d/'blocks'/f'{i:04}.csv';cache.parent.mkdir(exist_ok=True)
        if cache.exists():f=pd.read_csv(cache,parse_dates=['ds'])
        else:
            f=nf.predict(df=full.loc[full.ds<wide.index[i]])
            if 'unique_id' not in f:f=f.reset_index()
            f.to_csv(cache,index=False)
        pred=f.pivot(index='ds',columns='unique_id',values=bb).reindex(index=wide.index[i:i+12],columns=wide.columns).to_numpy()
        assert pred.shape==(12,6) and np.isfinite(pred).all()
        pieces.append(pred)
        if offset%20==0:print('BASE_BLOCKS',bb,offset+1,136,flush=True)
    raw=np.concatenate(pieces)
    np.savez_compressed(path,raw=raw,truth=wide.iloc[begin:].to_numpy(),S=S,begin=begin,start=start,
                        dates=wide.index[begin:].astype(str).to_numpy(dtype='U'))
    js(d/'RAW_READY.json',dict(sha256=sha(path),fit=fitted,scored_count=1488))
    del nf,trained;torch.cuda.empty_cache()
    return wide,load(path)

def refine(bb,wide,base):
    verify()
    d=H/'models'/bb
    if (d/'PIR_READY.json').exists():
        assert sha(d/'pir.npz')==json.loads((d/'PIR_READY.json').read_text())['sha256']
        return
    begin=int(base['begin']);start=int(base['start']);train_end=start-36
    values=wide.to_numpy();mu=values[:train_end].mean(axis=0);sd=values[:train_end].std(axis=0);sd=np.where(sd>0,sd,1.)
    positions=np.arange(begin,len(wide));libpos=np.arange(24,train_end)
    data=dict(x=((np.stack([values[t-24:t] for t in positions])-mu)/sd).astype('float32'),
       raw=((base['raw']-mu)/sd)[:,None,:].astype('float32'),
       y=((values[positions]-mu)/sd)[:,None,:].astype('float32'),
       encmark=np.stack([pir.calendar(wide.index[t-24:t]) for t in positions]),
       mark=pir.calendar(wide.index[positions])[:,None,:],
       lib_x=((np.stack([values[t-24:t] for t in libpos])-mu)/sd).astype('float32'),
       lib_y=((values[libpos]-mu)/sd)[:,None,:].astype('float32'),library_index=positions-24)
    assert len(data['raw'])==1632 and train_end<start
    random.seed(42);np.random.seed(42);torch.manual_seed(42);torch.cuda.manual_seed_all(42)
    model=pir.CachedPIR(pir.config(6)).float().cuda()
    tensors=pir.tensors(data,'cuda')
    logs,state=pir.fit(model,tensors,108,144)
    torch.save(state,d/'PIR_checkpoint.pt')
    pred=[]
    with torch.no_grad():
        for i in range(144,len(positions)):
            y,_=pir.forward(model,tensors,torch.tensor([i],device='cuda'))
            pred.append(y.cpu().numpy()[0,0]*sd+mu)
    np.savez_compressed(d/'pir.npz',pred=np.array(pred),raw=base['raw'][144:],truth=base['truth'][144:])
    js(d/'PIR_READY.json',dict(sha256=sha(d/'pir.npz'),checkpoint_sha256=sha(d/'PIR_checkpoint.pt'),
      epochs=logs,library_last_label=str(wide.index[train_end-1]),first_score=str(START),
      reference_mu=mu.tolist(),reference_sd=sd.tolist(),registration_sha256=sha(H/'REGISTRATION.json')))
    del model,tensors;torch.cuda.empty_cache()
    print('PIR_READY',bb,flush=True)
if __name__=='__main__':
    logging.getLogger('pytorch_lightning').setLevel(logging.ERROR)
    bb=sys.argv[1]
    wide,base=forecast(bb);refine(bb,wide,base)
