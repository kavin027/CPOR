"""Independent stored-trajectory checker. Requires Python 3 and NumPy only."""
from pathlib import Path
from fractions import Fraction
import argparse,hashlib,json,csv
import numpy as np

def exact(v):
    return [Fraction.from_float(float(x)) for x in v]

def check(x,epsilon,corrupt=False):
    R=(1+Fraction(epsilon))**2
    b,y=x['reference'],x['truth']
    S=x['S']
    assert b.shape==y.shape and b.ndim==2
    assert S.shape[0]==b.shape[1] and np.all(S>=0) and np.all(np.any(S>0,axis=1))
    assert np.isfinite(b).all() and np.isfinite(y).all() and b.min()>=0 and y.min()>=0
    assert np.all(x['reference_u']>=0) and np.allclose(b,x['reference_u']@S.T,rtol=1e-8,atol=2e-6)
    rows=[]
    for arm in ['Common','TwoGroup','Full']:
        p=x[arm].copy()
        if corrupt and arm=='Common':p[0,0]=b[0,0]+max(1.,abs(b[0,0]))
        u=x[arm+'_u']
        assert p.shape==b.shape and u.shape==(len(p),S.shape[1])
        assert np.isfinite(p).all() and np.isfinite(u).all() and u.min()>=0 and p.min()>=0
        balance=[Fraction(0)]*b.shape[1]
        for t in range(len(p)):
            bq,pq,yq=exact(b[t]),exact(p[t]),exact(y[t])
            for i,(beta,v,label) in enumerate(zip(bq,pq,yq)):
                worst=v*v-R*beta*beta if v>R*beta else R*(v-beta)**2/(R-1)
                assert worst<=balance[i],('envelope',arm,t+1,i,balance[i]-worst)
                balance[i]+=R*(beta-label)**2-(v-label)**2
                assert balance[i]>=0,('prefix',arm,t+1,i)
        assert np.allclose(p,u@S.T,rtol=1e-8,atol=2e-6)
        err=np.sqrt(np.mean((p-y)**2,axis=0))
        rows.append(dict(arm=arm,rmse=float(err.mean()),node_checks=p.size,node_sequences=p.shape[1],violations=0))
    return rows

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',default=str(Path(__file__).resolve().parent))
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    root=Path(args.root)
    manifest=json.loads((root/'cases.json').read_text())
    rows=[]
    for case in manifest:
        path=root/case['file']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==case['sha256']
        with np.load(path,allow_pickle=False) as z:
            x={k:z[k] for k in z.files}
        actual=check(x,case['epsilon'])
        for r in actual:
            assert abs(r['rmse']-case['expected_rmse'][r['arm']])<=1e-11*max(1,r['rmse'])
            rows.append(dict(dataset=case['dataset'],backbone=case['backbone'],window=case['window'],run=case['seed'],**r))
    assert len(rows)==66*3
    for arm in ['Common','TwoGroup','Full']:
        selected=[r for r in rows if r['arm']==arm]
        assert sum(r['node_checks'] for r in selected)==431568
        assert sum(r['node_sequences'] for r in selected)==5994
    if args.self_test:
        first=manifest[0]
        with np.load(root/first['file'],allow_pickle=False) as z:
            x={k:z[k] for k in z.files}
        try:check(x,first['epsilon'],corrupt=True)
        except AssertionError as e:
            assert e.args[0][0]=='envelope'
        else:raise AssertionError('Corruption went undetected')
    print(json.dumps(dict(streams=66,arms=3,exact_node_checks_per_arm=431568,node_sequences_per_arm=5994,zero_violations=True,computed_from_forecasts_and_observations=True,corruption_rejected=args.self_test),indent=2))
if __name__=='__main__':main()
