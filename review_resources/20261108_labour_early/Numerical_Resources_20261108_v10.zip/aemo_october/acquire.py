from study_common import *
import requests,zipfile,csv,io,re,time
from concurrent.futures import ThreadPoolExecutor,as_completed

def sources():
    inv=json.loads((H/'DIRECTORY_INVENTORY.json').read_text())
    selected=[dict(url='https://nemweb.com.au/Reports/ARCHIVE/Operational_Demand/ACTUAL_DAILY/PUBLIC_ACTUAL_OPERATIONAL_DEMAND_DAILY_20260801.zip',file='PUBLIC_ACTUAL_OPERATIONAL_DEMAND_DAILY_20260801.zip',kind='operational')]
    for item in inv:
        for url in item.get('links',[]):
            name=url.rsplit('/',1)[-1];dates=re.findall(r'20\d{6}',name)
            if not dates:continue
            day=dates[0]
            if 'Operational_Demand' in url:
                use=('Archive/' in item['url'] and day=='20260901') or ('Current/' in item['url'] and '20260901'<=day<='20261102')
                kind='operational'
            else:
                use='MEASUREMENT' in name and '20260827'<=day<='20261102';kind='pv'
            if use:selected.append(dict(url=url,file=name,kind=kind))
    assert any(x['kind']=='pv' for x in selected)
    return selected

def download(item):
    path=H/'source'/item['file']
    if not path.exists():
        for attempt in range(3):
            try:
                r=requests.get(item['url'],timeout=90);r.raise_for_status()
                assert zipfile.is_zipfile(io.BytesIO(r.content))
                tmp=path.with_suffix('.part');tmp.write_bytes(r.content);tmp.replace(path);break
            except Exception:
                if attempt==2:raise
                time.sleep(2)
    with zipfile.ZipFile(path) as z:assert z.testzip() is None
    return dict(**item,sha256=sha(path),bytes=path.stat().st_size)

def reports(data,depth=0):
    assert depth<=3
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for name in z.namelist():
            if name.lower().endswith('.zip'):yield from reports(z.read(name),depth+1)
            elif name.lower().endswith('.csv'):yield z.read(name).decode('utf-8-sig')

def acquire():
    verify();(H/'source').mkdir(exist_ok=True);items=sources();receipts=[]
    with ThreadPoolExecutor(max_workers=4) as pool:
        for f in as_completed([pool.submit(download,x) for x in items]):
            receipts.append(f.result())
            if len(receipts)%40==0:print('DOWNLOADED',len(receipts),len(items),flush=True)
    js(H/'SOURCE_RECEIPT.json',dict(registration_sha256=sha(H/'REGISTRATION.json'),files=sorted(receipts,key=lambda x:x['file'])))
    print('DOWNLOAD_COMPLETE',len(items),flush=True)

def validate():
    verify();receipt=json.loads((H/'SOURCE_RECEIPT.json').read_text());rows=[];schemas=set();count=0
    for item in receipt['files']:
        file=H/'source'/item['file'];assert sha(file)==item['sha256']
        for text in reports(file.read_bytes()):
            count+=1;headers={}
            for row in csv.reader(io.StringIO(text)):
                if len(row)<4 or row[0] not in ['I','D']:continue
                key=tuple(row[1:4])
                if row[0]=='I':headers[key]={k:i+4 for i,k in enumerate(row[4:])};continue
                h=headers.get(key,{})
                value='OPERATIONAL_DEMAND' if item['kind']=='operational' else 'POWER'
                if value not in h or 'REGIONID' not in h:continue
                get=lambda k:row[h[k]] if k in h else ''
                if get('REGIONID') not in REGIONS:continue
                if item['kind']=='pv' and get('TYPE')!='MEASUREMENT':continue
                datecol=next((k for k in ['INTERVAL_DATETIME','INTERVAL_DATETIME_START','SETTLEMENTDATE'] if k in h),None)
                assert datecol and datecol!='INTERVAL_DATETIME_START',h
                schemas.add((item['kind'],*key,*h.keys()))
                rows.append(dict(ds=get(datecol),region=get('REGIONID'),value=get(value),changed=get('LASTCHANGED'),qi=get('QI'),kind=item['kind'],source=item['file']))
    assert rows,'No matched schema; inspect retained source files without training'
    df=pd.DataFrame(rows);df.ds=pd.to_datetime(df.ds);df['changed']=pd.to_datetime(df.changed,errors='coerce');df.value=pd.to_numeric(df.value,errors='coerce')
    df=df.loc[df.ds.between('2026-09-01 00:30',END)].copy()
    df.to_csv(H/'component_records.csv',index=False)
    keys=['kind','ds','region'];latest=df.groupby(keys).changed.transform('max')
    keep=df.loc[(df.changed==latest)|(df.changed.isna()&latest.isna())]
    conflicts=keep.groupby(keys).value.nunique(dropna=False);conflicts=conflicts[conflicts>1]
    assert conflicts.empty,conflicts.to_string()
    keep=keep.sort_values('source').drop_duplicates(keys,keep='last')
    keep.to_csv(H/'components.csv',index=False)
    grid=pd.date_range('2026-09-01 00:30',END,freq='30min')
    op=keep.query("kind=='operational'").pivot(index='ds',columns='region',values='value').reindex(index=grid,columns=REGIONS)
    pv=keep.query("kind=='pv'").pivot(index='ds',columns='region',values='value').reindex(index=grid,columns=REGIONS)
    y=op+pv
    for name,x in [('operational',op),('rooftop_measured_estimate',pv),('underlying',y)]:x.rename_axis('ds').to_csv(H/(name+'.csv'))
    audit=[]
    for name,x in [('operational',op),('pv',pv),('underlying',y)]:
        for region in REGIONS:
            v=x[region];score=v.loc[START:END]
            audit.append(dict(component=name,region=region,total=len(v),missing=int(v.isna().sum()),negative=int((v<0).sum()),minimum=float(v.min()),score_count=len(score),score_negative=int((score<0).sum()),score_minimum=float(score.min())))
    pd.DataFrame(audit).to_csv(H/'domain_audit.csv',index=False)
    quality=keep.query("kind=='pv'").groupby(['region','qi'],dropna=False).size().reset_index(name='count');quality.to_csv(H/'pv_quality.csv',index=False)
    eligible=np.isfinite(op.to_numpy()).all() and np.isfinite(pv.to_numpy()).all() and np.isfinite(y.to_numpy()).all() and (y.to_numpy()>=0).all()
    js(H/'DOMAIN_ELIGIBILITY.json',dict(eligible=bool(eligible),reports=count,record_count=len(df),unique_count=len(keep),duplicate_records=len(df)-len(keep),schemas=[list(s) for s in sorted(schemas)],quality=quality.to_dict('records'),registration_sha256=sha(H/'REGISTRATION.json'),signed_operational_values_preserved=True,no_clipping=True,no_dropped_regions=True))
    print(pd.DataFrame(audit).to_string(index=False),flush=True)
    assert eligible,'Underlying outcome eligibility failed; do not score or repair values'
    wide=pd.concat([y.sum(axis=1).rename('SYSTEM'),y],axis=1);wide.index.name='ds';wide.to_csv(H/'observed.csv')
    assert len(wide.loc[START:END])==1488 and len(wide)==2928
    js(H/'DATA_READY.json',dict(observed_sha256=sha(H/'observed.csv'),sources_sha256=sha(H/'SOURCE_RECEIPT.json'),target='estimated underlying consumption MW = OPERATIONAL_DEMAND + MEASUREMENT rooftop POWER',score_count=1488,regions=REGIONS,registration_sha256=sha(H/'REGISTRATION.json')))
    print('DATA_ELIGIBLE',sha(H/'observed.csv'),flush=True)

if __name__=='__main__':
    if not (H/'SOURCE_RECEIPT.json').exists() or len(json.loads((H/'SOURCE_RECEIPT.json').read_text())['files'])!=len(sources()):acquire()
    validate()
