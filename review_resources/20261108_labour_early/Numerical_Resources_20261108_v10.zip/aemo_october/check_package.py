"""Replay AEMO envelopes, prefix errors and archived rational allowances."""
from pathlib import Path
import importlib.util,json,hashlib,csv
from fractions import Fraction
import numpy as np
H=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads((H/'PACKAGE_MANIFEST.json').read_text())
for p,h in manifest.items():assert sha(H/p)==h,p
spec=importlib.util.spec_from_file_location('independent',H/'audit_stored_trajectories.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
rows=[];states=0;R=Fraction(40401,40000)
for bb in ['PatchTST','DLinear']:
    with np.load(H/'results'/bb/'trajectories.npz',allow_pickle=False) as z:x={k:z[k] for k in z.files}
    result=module.check(x,'.005');rows.extend(result)
    assert len(x['truth'])==1488
    with (H/'results'/bb/'allowances.csv').open(newline='',encoding='utf8') as f:archive=list(csv.DictReader(f))
    for arm in ['Common','TwoGroup','Full']:
        recorded=[r for r in archive if r['arm']==arm];assert len(recorded)==1488*6
        balance=[Fraction(0)]*6
        for t,(b,p,y) in enumerate(zip(x['reference'],x[arm],x['truth'])):
            for i in range(6):
                beta,pred,truth=map(lambda v:Fraction.from_float(float(v)),[b[i],p[i],y[i]])
                balance[i]+=R*(beta-truth)**2-(pred-truth)**2
                r=recorded[t*6+i];assert int(r['step'])==t+1 and int(r['node'])==i
                assert balance[i]==Fraction(int(r['allowance_numerator']),int(r['allowance_denominator']))
                states+=1
    try:module.check(x,'.005',corrupt=True)
    except AssertionError as exc:assert exc.args[0][0]=='envelope'
    else:raise AssertionError('Corruption not rejected')
assert states==53568
print(json.dumps(dict(paths=len(rows),exact_node_dates=sum(r['node_checks'] for r in rows),archived_rational_states_replayed=states,violations=sum(r['violations'] for r in rows),checks='actual envelope + cumulative prefix + archived balances + coherence; corruption rejected'),indent=2))
