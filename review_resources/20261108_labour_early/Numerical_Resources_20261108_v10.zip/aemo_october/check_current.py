"""Aggregate verification for AEMO Tables 14 and S24--S27. Standard library only."""
from pathlib import Path
import csv,json,hashlib,math
H=Path(__file__).resolve().parent
def rows(name):
    with (H/name).open(encoding='utf8',newline='') as f:return list(csv.DictReader(f))
def close(x,y):assert math.isclose(float(x),float(y),rel_tol=1e-10,abs_tol=1e-9),(x,y)
manifest=json.loads((H/'PACKAGE_MANIFEST.json').read_text())
for p,digest in manifest.items():assert hashlib.sha256((H/p).read_bytes()).hexdigest()==digest,p
node=rows('node_rmse.csv');effects=rows('effects.csv');timing=rows('timing.csv')
for bb in ['PatchTST','DLinear']:
    for seg in ['Month','Oct1-7','Oct8-14','Oct15-21','Oct22-31']:
        for scope,indices in [('all',range(6)),('regions',range(1,6)),('system',[0])]:
            mean={}
            for method in ['Reference','Raw','PIR','Candidate','Common','TwoGroup','Full']:
                group=[float(r['rmse']) for r in node if r['backbone']==bb and r['segment']==seg and r['method']==method and int(r['node']) in indices]
                assert len(group)==len(indices)
                mean[method]=sum(group)/len(group)
            out=next(r for r in effects if (r['backbone'],r['segment'],r['scope'])==(bb,seg,scope))
            for k,v in mean.items():close(v,out[k])
            close(100*(1-mean['Full']/mean['Common']),out['full_vs_common_pct'])
            close(100*(1-mean['Full']/mean['TwoGroup']),out['full_vs_twogroup_pct'])
            close(100*(mean['Full']/mean['Candidate']-1),out['full_cost_pct'])
    for arm in ['Common','TwoGroup','Full']:
        steps=[float(r['ms']) for r in rows('publication_steps.csv') if r['backbone']==bb and r['arm']==arm]
        assert len(steps)==1488
        r=next(r for r in timing if (r['backbone'],r['arm'])==(bb,arm))
        close(sum(steps)/len(steps),r['mean']);steps.sort();position=.95*(len(steps)-1);a=math.floor(position);q=steps[a]+(position-a)*(steps[a+1]-steps[a]);close(q,r['p95'])
means={}
for key in ['full_vs_common_pct','full_vs_twogroup_pct','full_cost_pct']:
    means[key]=sum(float(r[key]) for r in effects if r['segment']=='Month' and r['scope']=='all')/2
assert round(means['full_vs_common_pct'],2)==3.82
assert round(means['full_vs_twogroup_pct'],2)==2.26
audit=json.loads((H/'FINAL_AUDIT.json').read_text());assert audit['exact_envelope_and_prefix_node_checks']==53568 and audit['violations']==0
risk=rows('risk.csv')
for r in risk:
    if r['method'] in ['Common','TwoGroup','Full']:assert int(r['ever'])==int(r['events'])==0
assert sum(int(r['ever']) for r in risk if r['method']=='Candidate')==10
print(json.dumps(dict(scope='stored summaries and timings; exact path replay is a separate command',backbones=2,month_intervals=1488,**means),indent=2))
