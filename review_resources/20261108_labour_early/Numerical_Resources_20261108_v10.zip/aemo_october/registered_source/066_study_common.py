from pathlib import Path
import hashlib,json,sys,datetime
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent
O=H.parent
ROOT=O.parent
REGIONS=['NSW1','QLD1','SA1','TAS1','VIC1']
S=np.vstack((np.ones((1,5)),np.eye(5)))
START=pd.Timestamp('2026-10-01 00:30')
END=pd.Timestamp('2026-11-01 00:00')
BEGIN=pd.Timestamp('2026-09-28 00:30')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(path,data):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(data,indent=2),encoding='utf8')
def verify():
    r=json.loads((H/'REGISTRATION.json').read_text())
    hashes=dict(r['sources'])
    for p in sorted(H.glob('AMENDMENT_*.json')):
        a=json.loads(p.read_text())
        assert a['registration_sha256']==sha(H/'REGISTRATION.json')
        for f,v in a['changes'].items():
            assert hashes[f]==v['old'];hashes[f]=v['new']
    for p,h in hashes.items():assert sha(p)==h,p
    return r
def load(path):
    with np.load(path,allow_pickle=False) as z:return {k:z[k] for k in z.files}
