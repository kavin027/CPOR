from pathlib import Path
import urllib.request,re,json,hashlib,datetime
H=Path(__file__).resolve().parent
base='https://nemweb.com.au/Reports/'
folders=['Archive/Operational_Demand/ACTUAL_DAILY/','Current/Operational_Demand/ACTUAL_DAILY/','Current/Operational_Demand/ACTUAL_UPDATE/','Archive/ROOFTOP_PV/ACTUAL/','Current/ROOFTOP_PV/ACTUAL/']
record=[]
for i,folder in enumerate(folders):
    url=base+folder
    try:
        raw=urllib.request.urlopen(url,timeout=30).read()
        (H/f'directory_{i}.html').write_bytes(raw)
        names=sorted(set(re.findall(r'href=["\x27]([^"\x27]+)["\x27]',raw.decode('utf8',errors='replace'),flags=re.I)))
        links=[]
        for n in names:
            name=n.rsplit('/',1)[-1]
            if name.lower().endswith(('.zip','.csv')):
                date=re.search(r'(20\d{6})',name)
                if date and '20260820'<=date.group(1)<='20261107':
                    links.append(urllib.parse.urljoin(url,n))
        record.append(dict(url=url,sha256=hashlib.sha256(raw).hexdigest(),links=links))
        print(folder,len(links),*[u.rsplit('/',1)[-1] for u in links[-4:]],flush=True)
    except Exception as e:
        record.append(dict(url=url,error=repr(e)));print(folder,repr(e),flush=True)
(H/'DIRECTORY_INVENTORY.json').write_text(json.dumps(record,indent=2))
