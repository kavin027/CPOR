from study_common import *
import time
from fractions import Fraction
from threadpoolctl import threadpool_limits
sys.path.insert(0,str(O/'cpor_duet_stream_20261106'))
import evaluate as duet
sys.path.insert(0,str(O/'pir_grouped_release_20261106'))
from grouped import grouped
sys.path.insert(0,str(O/'cpor_reference_allowance_20261107'))
from audit_trajectories import check as independent_check
c=duet.c;ns=duet.ns
ARMS=['Common','TwoGroup','Full']

def run(bb):
    verify()
    wide=pd.read_csv(H/'observed.csv',parse_dates=['ds']).set_index('ds')
    begin=wide.index.get_loc(BEGIN);start=wide.index.get_loc(START)
    base=load(H/'models'/bb/'raw.npz');pir=load(H/'models'/bb/'pir.npz')
    target_raw=pir['pred'];truth=wide.loc[START:END].to_numpy()
    assert len(truth)==1488
    np.testing.assert_array_equal(pir['truth'],truth)
    raw=base['raw'][144:];b,ub=duet.cpu.old.project(S,raw)
    v=wide.iloc[:start-36].var(ddof=0).to_numpy()
    v=np.maximum(v,max(1e-12,1e-6*np.median(v[v>1e-12])))
    z,u=duet.cpu.old.project(S,target_raw,v)
    k=c.kernels('nonnegative');qp=k['old'].SafeProjection(S,v)
    R=Fraction(40401,40000);K=R-1
    mask=np.array([0,1,2]);SA=S[:,mask]
    A={arm:[Fraction(0)]*6 for arm in ARMS}
    p={arm:[] for arm in ARMS};w={arm:[] for arm in ARMS}
    stepstats=[];accounts=[]
    for j in range(len(truth)):
        bq=ns['exact'](b[j]);order=ARMS[j%3:]+ARMS[:j%3]
        for arm in order:
            tick=time.perf_counter_ns()
            if arm=='Common':
                pred,alpha=ns['ray'](b[j],z[j],bq,A[arm]);rep=(1-alpha)*ub[j]+alpha*u[j]
            elif arm=='TwoGroup':
                pred,rep,_,_=grouped(SA,mask,b[j],ub[j],z[j],u[j],A[arm],bq,1/v,ns,float(R))
            else:pred,rep,_=k['ml'](qp,S,b[j],ub[j],z[j],A[arm])
            assert k['certified'](b[j],pred,A[arm],R,K)
            assert rep.min()>=0 and np.allclose(S@rep,pred,rtol=1e-8,atol=2e-6)
            ms=(time.perf_counter_ns()-tick)/1e6
            p[arm].append(pred);w[arm].append(rep)
            credit=np.array([float(a) for a in A[arm]])
            lo,hi=k['bounds'](b[j],credit);width=hi-lo;free=width>0
            active=free & (np.minimum(abs(pred-lo),abs(hi-pred))<=1e-5*width)
            blocked=sum((zz*zz-R*beta*beta if zz>R*beta else R*(zz-beta)**2/K)>a for beta,zz,a in zip(bq,ns['exact'](z[j]),A[arm]))
            stepstats.append(dict(step=j+1,ds=str(wide.index[start+j]),arm=arm,ms=ms,target_blocked_nodes=blocked,near_boundary_nodes=int(active.sum()),degenerate_nodes=int((~free).sum())))
        for arm in ARMS:
            A[arm]=ns['settle'](bq,ns['exact'](p[arm][-1]),ns['exact'](truth[j]),A[arm])
            for node,a in enumerate(A[arm]):
                accounts.append(dict(step=j+1,arm=arm,node=node,allowance_numerator=str(a.numerator),allowance_denominator=str(a.denominator),allowance_float=float(a)))
        if (j+1)%240==0:print('PUBLICATIONS',bb,j+1,1488,flush=True)
    d=H/'results'/bb;d.mkdir(parents=True,exist_ok=True)
    arrays=dict(S=S,reference=b,reference_u=ub,truth=truth,candidate=z,candidate_u=u,raw=raw,pir_raw=target_raw,v=v,dates=wide.loc[START:END].index.astype(str).to_numpy(dtype='U'))
    for arm in ARMS:arrays[arm]=np.array(p[arm]);arrays[arm+'_u']=np.array(w[arm])
    np.savez_compressed(d/'trajectories.npz',**arrays)
    pd.DataFrame(stepstats).to_csv(d/'steps.csv',index=False)
    pd.DataFrame(accounts).to_csv(d/'allowances.csv',index=False)
    audited=independent_check(arrays,'.005')
    pd.DataFrame(audited).to_csv(d/'independent_audit.csv',index=False)
    metrics=[]
    times=wide.loc[START:END].index
    segments=[('Month',np.ones(len(times),dtype=bool))]
    edges=[('Oct1-7','2026-10-01','2026-10-08'),('Oct8-14','2026-10-08','2026-10-15'),('Oct15-21','2026-10-15','2026-10-22'),('Oct22-31','2026-10-22','2026-11-01')]
    for name,a,e in edges:segments.append((name,(times>pd.Timestamp(a))&(times<=pd.Timestamp(e))))
    forecasts=dict(Reference=b,Raw=raw,PIR=target_raw,Candidate=z,**{arm:arrays[arm] for arm in ARMS})
    for method,pred in forecasts.items():
        for segment,ix in segments:
            err=np.sqrt(((pred[ix]-truth[ix])**2).mean(axis=0))
            metrics.extend(dict(backbone=bb,method=method,segment=segment,node=node,rmse=float(err[node])) for node in range(6))
    pd.DataFrame(metrics).to_csv(d/'node_rmse.csv',index=False)
    js(d/'DONE.json',dict(sha256=sha(d/'trajectories.npz'),score_count=1488,ledger_resets=1,registered_reference='NNLS',epsilon='.005',registration_sha256=sha(H/'REGISTRATION.json')))
    print('MONTH_READY',bb,flush=True)
if __name__=='__main__':
    with threadpool_limits(1):run(sys.argv[1])
