# AEMO October 2026 confirmation — registered eligibility result

## Status
The complete protocol and 83 source-file hashes were registered before downloading observations. Source acquisition and field/time/completeness checks finished. Performance confirmation did not start because the registered outcome-domain eligibility condition failed. No backbone or PIR model was trained, no release strategy was scored, and no forecast ranking is available.

## Frozen design
Five NEM regions plus their system total; all October half-hour interval ends (1,488 observations), one continuous ledger per release rule. NNLS reference, exact R=40401/40000 (0.5% RMSE allowance), one common coherent PIR candidate, Common/TwoGroup/Full release rules. PatchTST/DLinear each use initialization42 with the fixed historical training/validation recipe.

Registered protocol SHA256:
4287d5c58080cf50bdb36e985d5289481b85d1fc9f80f1718362813bb1b2646e

Registration SHA256:
9f2a709dd911e3cea4d5c974d99ba6d68b1e4fdfdb6108412454ab6d0db28533

## Data checks
All 63 official daily DispatchIS archives from 31 August through 1 November were downloaded, ZIP-checked and hashed. Parsed DISPATCH/REGIONSUM table version9; selected RUNNO=1, INTERVENTION=0 and the exact named TOTALDEMAND field. The usable September--October native grid has 17,568 five-minute timestamps per region, no missing times and no repeated region-time keys. Each half-hour contains exactly six source observations. NEM interval ends remain fixed AEST (UTC+10), with no regional daylight-saving shift.

The expected October half-hour grid is complete. All 34 negative half-hour outcomes are in SA1:

| Period | Half-hour observations per node | Negative node-dates | Minimum SA1 demand (MW) |
|---|---:|---:|---:|
| September prior history | 1,440 | 9 | -47.218333 |
| October scored period | 1,488 | 34 | -212.681667 |

October's negative half-hours occur on eight dates, beginning 5 October13:30 and ending 31 October14:00. The lowest mean is on 5 October14:30. The system sum and other four regions are nonnegative, but the contract protects every regional node, so a positive system total does not satisfy the outcome-domain requirement for SA1.

The source records themselves contain the negative numbers; source_negative_examples.csv identifies source archive hashes, table version, keys and raw TOTALDEMAND values. Half-hour averaging preserves negative values. This is not resolved by correcting a column offset or timestamp conversion. AEMO documents the possibility of negative regional electricity demand:
https://www.aemo.com.au/newsroom/news-updates/negative-electricity-demand-in-south-australia
Demand field definitions:
https://www.aemo.com.au/-/media/files/electricity/nem/security_and_reliability/dispatch/policy_and_process/demand-terms-in-emms-data-model.pdf

## Consequence
The frozen CPOR guarantee uses a worst-case envelope over nonnegative outcomes. This month's TOTALDEMAND violates that premise. Negative observations were not clipped, dates or regions were not removed, and no later interval was selected. The registered protocol explicitly stops for this condition. The observation CSV is an audit-only view, not a DATA_READY marker.

The scientific result of this attempt is an applicability limit for the chosen net-demand variable. It does not measure CPOR's predictive accuracy. A new confirmation would require a freshly registered observation definition/source with nonnegative meaning, or an explicitly authorized extension to signed outcomes. The original October TOTALDEMAND registration should remain preserved as ineligible.

## Files
- PROTOCOL.md / REGISTRATION.json: pre-acquisition design and hashes.
- SOURCE_RECEIPT.json: all 63 URLs, hashes and byte sizes; raw archives remain in source/ on H.
- NATIVE_DATA_CHECK.json / DOMAIN_ELIGIBILITY.json: completeness and domain checks.
- negative_native.csv / negative_halfhour.csv: full negative records.
- source_negative_examples.csv: original report-field evidence.
- domain_audit_halfhour.csv: complete aggregated September--October audit values.
- acquire.py / domain_audit.py: parsing and verification code.

The old frozen manuscript and result package remain bytewise unchanged.
