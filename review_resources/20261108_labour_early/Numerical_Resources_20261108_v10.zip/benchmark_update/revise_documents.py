from pathlib import Path
import json,re
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent;D=H/'derived';OLD=H.parent/'cpor_kais_scope_links_20261107';E=H.parent/'cpor_labour_early_three_runs_20261107'
read=lambda n:pd.read_csv(D/(n+'.csv'))
C=json.loads((D/'CLAIMS.json').read_text(encoding='utf8'));G=read('GROUP_RUN_RMSE').pivot(index=['dataset','backbone','seed'],columns='method',values='rmse');M=G.groupby(level=[0,1]).mean();SD=G.groupby(level=[0,1]).std()
L=read('LEVEL_GROUP_RUN').pivot(index=['dataset','backbone','seed','scope'],columns='method',values='rmse');LP=read('LEVEL_PAIRED');PE=read('PIR_GROUP_RUN');PD=read('PIR_DATASET');LG=read('LI_GROUPS');ORDER=[(d,b) for d in ['RH','ECommerce','Traffic','Wiki2','Labour','M5'] for b in ['PatchTST','DLinear']]
URL='https://github.com/kavin027/CPOR/tree/labour-early-v10-20261107/review_resources/20261107_labour_early'
def row(*a):return ' & '.join(map(str,a))+r'\\'+'\n'
def tabular(cols,head,body):return r'\begin{tabular}{'+cols+r'}\toprule'+'\n'+head+r'\\\midrule'+'\n'+body+r'\bottomrule\end{tabular}'+'\n'
def table(label,caption,content,size='small',note=''):
    return '\\begin{table}[htbp]\\centering\\'+size+'\n'+r'\caption{'+caption+r'}\label{'+label+'}\n'+r'\setlength{\tabcolsep}{3pt}'+'\n'+content+('\\par\\smallskip\\begin{minipage}{.97\\linewidth}\\footnotesize\n'+note+'\n\\end{minipage}\n' if note else '')+r'\end{table}'+'\n'
def replace_table(t,label,new):
    ix=t.index('\\label{'+label+'}');start=t.rfind('\\begin{table}',0,ix);end=t.index('\\end{table}',ix)+len('\\end{table}');return t[:start]+new+t[end:]
def span(t,a,b,new):
    start=t.index(a);end=t.index(b,start+len(a));return t[:start]+new+t[end:]
def num(x,p=2):return f'{float(x):.{p}f}'
def boldvals(vals,p=2,sd=None):
    rounded=[num(v,p) for v in vals];low=min(map(float,rounded));out=[]
    for j,v in enumerate(rounded):
        s=v+(r'\,$\pm$\,'+num(sd[j],p) if sd is not None else '')
        out.append(r'\textbf{'+s+'}' if float(v)==low else s)
    return out
def body(methods,p=2,sd=False):
    out=''
    for d,b in ORDER:out+=row(d if b=='PatchTST' else '',b,*boldvals([M.loc[(d,b),m] for m in methods],p,[SD.loc[(d,b),m] for m in methods] if sd else None))
    return out
def paired(m,c):return read('PAIRED_GROUP_RUN').query('method==@m and comparator==@c')
def claim(m,c):return C[m+'__'+c]['mean']
def avglev(impl,scope,key):return LP[(LP.implementation==impl)&(LP.scope==scope)][key].mean()
def levelbody(rows,methods):
    out=''
    for ds,scope in rows:
      for bb in ['PatchTST','DLinear']:
        f=L.xs((ds,bb),level=[0,1]).xs(scope,level='scope');v=f[methods].mean();out+=row(ds+(' / '+scope if scope!='system' else '') if bb=='PatchTST' else '',bb,*boldvals(v,2))
    return out
def main():
    t=(OLD/'source/main.tex').read_text(encoding='utf8');s=(OLD/'source/supplement/main.tex').read_text(encoding='utf8')
    # Protocol: all six benchmarks now have two windows; AEMO remains a continuous-month study.
    t=t.replace('Labour & 57 & 32 & 32 & late','Labour & 57 & 32 & 32 & early, late').replace('Labour & Monthly & Archive unit & -- &','Labour & Monthly & Archive unit & 2008-12-01--2014-11-01 &')
    a='The six benchmark datasets have early and late windows, except Labour,\nwhich has only the late window. They yield\n$2\\times(5\\times2+1)=22$ configurations.'
    assert a in t;t=t.replace(a,'All six benchmarks have early and late windows, giving\n$6\\times2\\times2=24$ configurations and 72 prediction streams across\nthe three training runs.')
    marker='36 calibration observations followed by 72 scored observations in six\nnonoverlapping blocks of 12.'
    t=t.replace(marker,marker+'\nLabour\'s early window was added retrospectively after reviewing the\noriginal results, using the existing fitting, selection and evaluation\nrules. Supplementary Note~S18 reports its separate results and provenance.')
    t=t.replace('For the six benchmark datasets, we use the first archived backbone training run for all 22 configurations.','For the historical COSA, robust-map and residual-correction comparisons, we use the first backbone training run on the original 22-configuration grid, which contains only Labour\'s late window.')
    # Main table: current window-averaged values and within-run paired ratios.
    methods=['Raw','NNLS','ProCAST','Ada-Y','PIR','CovFullFix','ProtectedMLPol'];txt='\\textbf{(a) Three-run mean RMSE}\\par\\smallskip\n'+tabular('llrrrrrrr','Dataset & Backbone & Raw & NNLS & ProCAST & Ada-Y & PIR & CPOR-Cov & CPOR-ML',body(methods))
    txt+='\\par\\medskip\\textbf{(b) Mean paired reductions by backbone (\\%)}\\par\\smallskip\n';bb=read('BACKBONE_GAINS');rows=''
    for m,name in [('CovFullFix','CPOR-Cov'),('ProtectedMLPol','CPOR-ML')]:
      for b in ['PatchTST','DLinear']:rows+=row(name,b,*[num(bb[(bb.method==m)&(bb.comparator==c)&(bb.backbone==b)].gain.iloc[0]) for c in ['Raw','NNLS','ProCAST','Ada-Y','PIR']])
    txt+=tabular('llrrrrr','Implementation & Backbone & vs Raw & vs NNLS & vs ProCAST & vs Ada-Y & vs PIR',rows)
    t=replace_table(t,'tab:main',table('tab:main','Benchmark accuracy and paired reductions.',txt,'footnotesize','ProCAST denotes the adapted learned-oblique branch. Panel (a) averages window RMSE within each run and then runs; panel (b) averages within-run paired percentages equally over the six benchmarks.'))
    t=span(t,'On the six benchmarks, both implementations meet',r'\begin{table}',f'''On the six benchmarks, both implementations meet the prescribed
cumulative limits. Mean-node RMSE decreases relative to NNLS by
{claim('CovFullFix','NNLS'):.2f}\\% for Cov and {claim('ProtectedMLPol','NNLS'):.2f}\\% for ML, with positive mean paired
gains in all twelve dataset--backbone groups. Table~\\ref{{tab:main}}
compares their accuracy with the reference and external postprocessors.

''')
    u=read('UNCERTAINTY').set_index('contrast');cv=u.loc['CovFullFix:PIR'];ml=u.loc['ProtectedMLPol:PIR']
    t=span(t,'The mean reductions relative to adapted ProCAST',r'\paragraph{Matched comparisons with additional baselines.}',f'''The mean reductions relative to adapted ProCAST are {claim('CovFullFix','ProCAST'):.2f}\\% for Cov
and {claim('ProtectedMLPol','ProCAST'):.2f}\\% for ML. Both improve over Ada-Y in all twelve groups.
Relative to PIR, the reductions average {claim('CovFullFix','PIR'):.2f}\\% and {claim('ProtectedMLPol','PIR'):.2f}\\%, with
positive mean paired gains in nine and eight groups, respectively.
PIR has lower mean RMSE on M5 with both backbones and on
Traffic/DLinear. After backbone averaging, both implementations improve
on PIR in four of six datasets. All three run-level mean gains are
positive, although their sizes vary (Supplementary Tables~\\SuppNumber{{tab:pairedruns}}
and~\\SuppNumber{{tab:pirdatasets}}).

The dataset-cluster empirical 95\\% intervals for the PIR gains are
$[{cv.ci_low:.2f},{cv.ci_high:.2f}]\\%$ for Cov and $[{ml.ci_low:.2f},{ml.ci_high:.2f}]\\%$ for ML.
The corresponding Holm-adjusted $p$-values are {cv.p_holm:.4f}. With six
dataset clusters, the smallest two-sided sign-flip $p$ exceeds the initial
Holm threshold for six comparisons (Supplementary Table~\\SuppNumber{{tab:uncertainty}}).
These are retrospective dataset-level comparisons on the expanded grid.

These complete-procedure comparisons also include target construction
and update rules. Relative to raw forecasts, adapted ProCAST and Ada-Y
increase mean RMSE by {100*(G.ProCAST/G.Raw-1).mean():.2f}\\% and {100*(G['Ada-Y']/G.Raw-1).mean():.2f}\\%, whereas PIR reduces it by
{100*(1-G.PIR/G.Raw).mean():.2f}\\%. Matched-target controls in
Section~\\ref{{sec:classical}} separate these choices from protection.
Supplementary Table~\\SuppNumber{{tab:variation}} reports training-run SDs.

''')
    t=t.replace('On the first training run, Cov and ML reduced','On the original 22-configuration grid and first training run, Cov and ML reduced',1)
    t=t.replace('On the first training run, the residual corrector','On the same original grid and first training run, the residual corrector',1)
    # Li: append early-window observations; no rerunning the preprint.
    lc=LG[LG.scope=='all'];gainli=lambda m,c:100*(1-lc[m]/lc[c]).mean()
    t=t.replace('methods on the 14 eligible windows','methods on the 16 eligible windows').replace('than both Li configurations in all 14\nwindows','than both Li configurations in all 16\nwindows')
    t=t.replace('4.20\\% and 4.12\\%',f'{gainli("Cov","Diag"):.2f}\\% and {gainli("ML","Diag"):.2f}\\%').replace('4.51\\% and 4.43\\%',f'{gainli("Cov","Factor"):.2f}\\% and {gainli("ML","Factor"):.2f}\\%')
    # Exact preprint prefix counts are carried forward and augmented by the two initialization-42 early streams.
    checks=pd.read_csv(E/'PROTECTION_CHECKS.csv');counts={m:int(checks[(checks.run==42)&(checks.method==m)].ever_violating_nodes.sum()) for m in ['LiDiag','LiFactor']}
    t=t.replace('1,311 of 1,914',f'{1311+counts["LiDiag"]:,} of 2,028').replace('and 1,365 with factor-target',f'and {1365+counts["LiFactor"]:,} with factor-target').replace('all 1,914','all 2,028')
    # Table8 retains DUET and historical timing; only the current PIR grid expands.
    oldtable=t[t.rfind('\\begin{table}',0,t.index('\\label{tab:duetpaired}')):t.index('\\end{table}',t.index('\\label{tab:duetpaired}'))]
    duet={}
    for line in oldtable.splitlines():
        parts=[p.strip() for p in line.split('&')]
        if len(parts)==6 and parts[0] in ['ECommerce','Labour','M5','RH','Traffic','Wiki2']:duet[parts[0]]=parts[1:4]
    pr=PD[PD.scope=='all'].set_index('dataset');rows=''
    for d in ['ECommerce','Labour','M5','RH','Traffic','Wiki2']:rows+=row(d,*duet[d],num(pr.loc[d,'vs_common']),num(pr.loc[d,'vs_two_group']))
    rows+='\\midrule\n'+row('Equal-weight mean','0.54','6.14','6.32',num(C['PIR__vs_common']),num(C['PIR__vs_two_group']))
    content='\\textbf{(a) RMSE reduction with full projection (\\%)}\\par\\smallskip\n'+tabular('lrrrrr',r' & \multicolumn{3}{c}{DUET vs. common shrinkage} & \multicolumn{2}{c}{Reconciled PIR vs.}\\'+'\n'+r'\cmidrule(lr){2-4}\cmidrule(lr){5-6}'+'\nDataset & Base & Cov & ML & Common & Two-group',rows)
    windowaudit=pd.read_csv(H/'or2_v10/pir_matched/window_audit.csv');evercol='ever' if 'ever' in windowaudit else None
    # Archived direct-candidate count4925; exact early prefix receipts add all six new streams.
    ever=4925+int(checks[checks.method=='PIRCoherent'].ever_violating_nodes.sum())
    rows=row('Direct coherent candidate','0.00',f'{ever:,}','---','---')
    for name,k,tim in [('Common shrinkage','common_cost',('1.86','5.84')),('Two-group shrinkage','two_cost',('2.52','7.69')),('Full projection','full_cost',('5.74','15.39'))]:rows+=row(name,f'${C["PIR__"+k]:+.2f}$','0',*tim)
    content+='\\par\\medskip\\textbf{(b) PIR releases at 0.5\\% tolerance}\\par\\smallskip\n'+tabular('lrrrr',r' & \shortstack[r]{RMSE change vs.\\direct release (\%)} & \shortstack[r]{Sequences ever over\\limit (of 6,336)} & \multicolumn{2}{c}{Time (ms)}\\'+'\n'+r'\cmidrule(lr){4-5}'+'\nRelease & & & Mean & P95',rows)
    t=replace_table(t,'tab:duetpaired',table('tab:duetpaired','Accuracy and publication time at matched protection.',content,note='RMSE contrasts weight the six benchmarks equally. PIR covers 24 configurations and three runs; DUET retains its original windows, including only Labour late. Timing retains the original 4,752-release measurement per protected rule; the added early window was not retimed.'))
    pu=read('PIR_UNCERTAINTY').set_index('contrast');a=pu.loc['vs_common'];b=pu.loc['vs_two_group']
    sysP=PE[(PE.scope=='system')].vs_common.mean();lr=PD[(PD.dataset=='Labour')&(PD.scope=='region')].vs_common.iloc[0]
    t=span(t,'On the PIR streams, two-group shrinkage',r'\paragraph{Protection costs on PatchTST and DLinear forecasts.}',f'''On the expanded PIR grid, two-group shrinkage improves on common
shrinkage by {C['PIR__two_vs_common']:.2f}\\%. Full projection improves by a further
{C['PIR__vs_two_group']:.2f}\\% over two-group shrinkage, with lower error in 65 of 72 streams.
All seven reversals occur on ECommerce, whose mean gain is 0.10\\%.
Against common shrinkage, full projection wins in 64 streams; all eight
losses occur on ECommerce. The system-total reduction averages {sysP:.2f}\\%
over the five labelled totals, while Labour regional RMSE decreases by
{lr:.2f}\\% (Supplementary Table~S20).

Retrospective dataset-cluster bootstrap intervals are
$[{a.ci_low:.2f},{a.ci_high:.2f}]\\%$ against common shrinkage and
$[{b.ci_low:.2f},{b.ci_high:.2f}]\\%$ against two-group shrinkage. Both sign-flip tests have raw
$p=0.03125$ and Holm-adjusted $p=0.0625$ across these two contrasts.
Omitting any one dataset leaves a positive two-group gain of
{b.loo_low:.2f}--{b.loo_high:.2f}\\% (Supplementary Table~S23).

All three protected rules meet every scored node's cumulative limit.
Direct release violates it in {ever:,} of 6,336 node sequences.
Full projection's mean RMSE change relative to direct release is
${C['PIR__full_cost']:+.2f}\\%$: the near-zero mean combines costs on RH, M5, Traffic and
Labour with improvements on Wiki2 and ECommerce. Labour's early window
alone improves on direct release by 14.90\\%, while its late window
incurs a 14.97\\% cost. Averaging their RMSEs before computing ratios
gives a Labour cost of {pr.loc['Labour','full_cost']:.2f}\\%. These opposing effects explain the
change from the original late-only summary. Historical publication time
is 5.74 ms for full projection versus 2.52 ms for two-group shrinkage.

On the original 22-configuration residual-correction comparison, full
release improves RMSE by 0.12\\% over common shrinkage, while system
RMSE increases by 0.05\\%. Its full-set path protects the raw target;
the shrinkage path first reconciles it. Both satisfy the limits.

''')
    # Main protection table and full counts.
    risk=read('RISK_SUMMARY').set_index('method');names={'CovFullFix':'CPOR-Cov','ProtectedMLPol':'CPOR-ML','CovUnprotected':'Unprotected Cov','MLPol':'ML-Pol','ProtectedCalBest':'Protected CalBest'};rows=''
    for m in ['CovFullFix','ProtectedMLPol','ProtectedCalBest','NNLS','CovUnprotected','MLPol','CalBest','ProCAST','Ada-Y','PIR','Raw']:
        v=risk.loc[m];vals=[num(v[k]) for k in ['ever_pct','dates_pct','final_pct']];vals=[r'\textbf{'+x+'}' if float(x)==0 else x for x in vals];rows+=row(names.get(m,m),*vals,num(v.p95,3))
    content=tabular('lrrrr',r' & \multicolumn{3}{c}{Violation rate (\%)} & Final/reference RMSE\\'+'\n'+r'\cmidrule(lr){2-4}'+'\nMethod & Ever & All dates & Final & 95th percentile',rows)
    t=replace_table(t,'tab:risk',table('tab:risk','Prefix compliance and final error ratios.',content,note='The final column pools full-period nodewise RMSE ratios to NNLS across 6,336 node sequences; NNLS divided by itself gives one.'))
    t=t.replace('82.22\\% and 80.60\\%',f'{risk.loc["CovUnprotected","ever_pct"]:.2f}\\% and {risk.loc["MLPol","ever_pct"]:.2f}\\%').replace('5,994 sequences and 431,568 node--date checks','6,336 sequences and 456,192 node--date checks')
    t=t.replace('55.76\\%\nand 58.18\\%','51.48\\%\nand 53.44\\%').replace('23.96\\% for Cov\nand 20.63\\% for ML','23.24\\% for Cov\nand 19.84\\% for ML').replace('$[-0.90,53.27]\\%$ and $[-0.12,56.07]\\%$','$[-0.90,47.13]\\%$ and $[-0.12,49.32]\\%$')
    # Online domain comparison now includes early Labour; the same-state diagnostic remains historical.
    en=read('ENVELOPE_GAINS');ec=read('LEVEL_GROUP_RUN');ew=ec[ec.scope=='all'].pivot(index=['dataset','backbone','seed'],columns='method',values='rmse');rows=''
    for ds,bb in ORDER:
        q=ew.loc[(ds,bb)];vals=[]
        for impl in ['Cov','ML']:
            vals+=boldvals([q[impl].mean(),q[impl+'Real'].mean()],3)+[num(en[(en.dataset==ds)&(en.backbone==bb)&(en.implementation==impl)].gain.mean(),3)]
        rows+=row(ds if bb=='PatchTST' else '',bb,*vals)
    t=replace_table(t,'tab:envelope',table('tab:envelope','Nonnegative and all-real protection.',tabular('llrrrrrr',r' & & \multicolumn{3}{c}{Cov} & \multicolumn{3}{c}{ML}\\'+'\n'+r'\cmidrule(lr){3-5}\cmidrule(lr){6-8}'+'\nDataset & Backbone & Nonnegative & All-real & Gain (\\%) & Nonnegative & All-real & Gain (\\%)',rows),'footnotesize','Three-run mean RMSE after window averaging; gains are mean within-run paired reductions to the all-real control.'))
    t=t.replace('covers all 22 configurations and three','covers all 24 configurations and three')
    t=span(t,'The nonnegative envelope improves mean-node RMSE', 'We further compare the two projections at identical historical states.',f'''The nonnegative envelope improves mean-node RMSE by {C['Cov__domain']['mean']:.3f}\\% for Cov
and {C['ML__domain']['mean']:.3f}\\% for ML. Mean paired gains are positive in eleven
of twelve groups. RH contributes {C['Cov__domain']['rh_share']:.1f}\\% and {C['ML__domain']['rh_share']:.1f}\\% of summed group gains;
the other ten groups average {C['Cov__domain']['other_mean']:.3f}\\% and {C['ML__domain']['other_mean']:.3f}\\%.
Labour/DLinear slightly favors the all-real envelope. Each implementation
has three negative window-averaged run comparisons. The early
ECommerce/PatchTST window also favors the all-real control in every run.

''')
    t=t.replace('We further compare the two projections at identical historical states.','We retain a same-state diagnostic on the original 66 streams.')
    t=t.replace('All 132 nonnegative replays reproduce the archived predictions\nelementwise. Across two envelopes and two implementations, the audit covers\n$2\\times2\\times431{,}568=1{,}726{,}272$ node--date records.','The original 132 nonnegative replays and twelve added Labour early\nreplays reproduce their stored predictions elementwise. Across two\nenvelopes and two implementations, checks cover\n$2\\times2\\times456{,}192=1{,}824{,}768$ node--date records.')
    # Protected classical controls.
    content='\\textbf{(a) Raw backbone targets}\\par\\smallskip\n'+tabular('llrrrrrr','Dataset & Backbone & NNLS & WLS(struct) & WLS(var) & MinT & CPOR-Cov & CPOR-ML',body(['NNLS','WLSstruct','WLSvar','MinTshrink','CovFullFix','ProtectedMLPol'],3))
    content+='\\par\\medskip\\textbf{(b) Cov targets and fixed expert}\\par\\smallskip\n'+tabular('llrrrrr','Dataset & Backbone & WLS(var) & MinT & CalBest & CPOR-Cov & CPOR-ML',body(['WLSvar_Cov','MinT_Cov','ProtectedCalBest','CovFullFix','ProtectedMLPol'],3))
    t=replace_table(t,'tab:classical',table('tab:classical','Target construction and protected classical controls.',content,'footnotesize','Three-run mean RMSE. Every method in this table uses the common protection requirement; classical controls use CPOR publication after their stated target construction.'))
    t=t.replace('6.587\\%\nand 6.609\\%',f'{claim("CovFullFix","MinTshrink"):.3f}\\%\nand {claim("ProtectedMLPol","MinTshrink"):.3f}\\%').replace('0.033\\% and\n0.055\\%',f'{claim("CovFullFix","MinT_Cov"):.3f}\\% and\n{claim("ProtectedMLPol","MinT_Cov"):.3f}\\%')
    t=t.replace('1.252\\% and\n1.272\\%, supporting adaptive combination over fixed expert selection\nunder this protocol.',f'{claim("CovFullFix","ProtectedCalBest"):.3f}\\% and\n{claim("ProtectedMLPol","ProtectedCalBest"):.3f}\\%. This compares complete combination\nprocedures with a fixed expert-selection strategy.')
    t=t.replace('On the evaluated streams, the two orders have similar accuracy.','On the original 66 streams, the two orders have similar accuracy.')
    # Level tables and paired interpretation.
    content='\\textbf{(a) System totals}\\par\\smallskip\n'+tabular('llrrrr','Dataset / level & Backbone & Raw & NNLS & CPOR-Cov & CPOR-ML',levelbody([(d,'system') for d in ['RH','Traffic','Wiki2','Labour','M5']],['Raw','NNLS','Cov','ML']))
    content+='\\par\\medskip\\textbf{(b) Regions and bottom-level series}\\par\\smallskip\n'+tabular('llrrrr','Dataset / level & Backbone & Raw & NNLS & CPOR-Cov & CPOR-ML',levelbody([('Traffic','bottom'),('Wiki2','bottom'),('Labour','region'),('Labour','bottom'),('M5','bottom')],['Raw','NNLS','Cov','ML']))
    t=replace_table(t,'tab:levelsummary',table('tab:levelsummary','RMSE at selected aggregation levels.',content))
    t=t.replace('6.975\\%\nand 6.829\\%',f'{avglev("Cov","system","reference_gain"):.3f}\\%\nand {avglev("ML","system","reference_gain"):.3f}\\%')
    le=read('LEVEL_EFFECTS').set_index(['dataset','scope','implementation'])
    t=t.replace('6.068\\% for Cov and 5.905\\% for ML',f'{le.loc[("Labour","region","Cov"),"reference_gain"]:.3f}\\% for Cov and {le.loc[("Labour","region","ML"),"reference_gain"]:.3f}\\% for ML')
    t=t.replace('2.091\\% for Cov and 1.929\\% for ML',f'{avglev("Cov","system","domain_gain"):.3f}\\% for Cov and {avglev("ML","system","domain_gain"):.3f}\\% for ML').replace('1.091\\% and 1.022\\%',f'{avglev("Cov","bottom","domain_gain"):.3f}\\% and {avglev("ML","bottom","domain_gain"):.3f}\\%')
    t=t.replace('0.020\\% and 0.012\\%',f'{-le.loc[("Labour","region","Cov"),"domain_gain"]:.3f}\\% and {-le.loc[("Labour","region","ML"),"domain_gain"]:.3f}\\%')
    t=t.replace('across the six benchmarks, two backbones and three training runs on one CPU','on the original 22-configuration grid across six benchmarks and three\ntraining runs on one CPU').replace('Postprocessing time across the complete evaluation grid.','Postprocessing time on the original benchmark windows.')
    # Abstract, conclusion and resource references.
    t=t.replace('by 2.09\\% relative\nto common shrinkage and 1.88\\% relative to two-group shrinkage, at a\n2.31\\% RMSE cost relative to direct release.',f'by {C["PIR__vs_common"]:.2f}\\% relative\nto common shrinkage and {C["PIR__vs_two_group"]:.2f}\\% relative to two-group shrinkage. The\nmean change relative to direct PIR release is {C["PIR__full_cost"]:.2f}\\%, with costs and\nbenefits varying across datasets.')
    t=t.replace('2.09\\% relative to common shrinkage and 1.88\\% relative to a fixed\ntwo-group rule; the RMSE cost relative to direct release is 2.31\\%.',f'{C["PIR__vs_common"]:.2f}\\% relative to common shrinkage and {C["PIR__vs_two_group"]:.2f}\\% relative to a fixed\ntwo-group rule. Its mean RMSE change relative to direct PIR release is\n{C["PIR__full_cost"]:.2f}\\%, while the corresponding costs for the Cov and ML targets\naverage {C["Cov__cost"]["mean"]:.2f}\\% and {C["ML__cost"]["mean"]:.2f}\\%.')
    t=t.replace('Direct protection and reconciliation followed by protection have\nsimilar accuracy for Cov and ML on the evaluated streams.','The added Labour early window is a retrospective protocol extension.\nDirect protection and reconciliation followed by protection have\nsimilar accuracy for Cov and ML on the original streams.')
    t=t.replace('version v9 (7 November 2026)','version v10 (7 November 2026)').replace('Tables~8, \\ref{tab:aemo} and S20--S28','Tables~5--11, \\ref{tab:aemo} and the supplementary results').replace('the original AEMO freeze, the three-run extension and stored release trajectories.','the original benchmark records, retrospective Labour early addition,\nAEMO registrations and stored release trajectories.').replace('It supplies aggregate checks for the six benchmarks and exact\nstored-trajectory checks for AEMO.','It supplies expanded benchmark aggregate checks and stored-trajectory\nchecks for Labour early and AEMO.').replace('https://github.com/kavin027/CPOR/tree/dataset-scope-links-20261107/review_resources/20261107_scope_links',URL)
    # Supplementary current-grid tables.
    content=tabular('llrrrrr','Dataset & Backbone & Raw & NNLS & ProCAST & Ada-Y & PIR',body(['Raw','NNLS','ProCAST','Ada-Y','PIR'],2,True))
    content+='\\par\\medskip\n'+tabular('llrrr','Dataset & Backbone & CPOR-Cov & CPOR-ML & Protected CalBest',body(['CovFullFix','ProtectedMLPol','ProtectedCalBest'],3,True))
    s=replace_table(s,'tab:variation',table('tab:variation','Mean RMSE and training-run SD.',content,'scriptsize'))
    content=tabular('llrrr','Dataset & Backbone & WLS(struct) & WLS(var) & MinT',body(['WLSstruct','WLSvar','MinTshrink'],3,True))+'\\par\\medskip\\textbf{Cov-input controls}\\par\\smallskip\n'+tabular('llrr','Dataset & Backbone & WLS(var) & MinT',body(['WLSvar_Cov','MinT_Cov'],3,True))
    s=replace_table(s,'tab:classicaldetails',table('tab:classicaldetails','Protected classical controls: mean RMSE and training-run SD.',content,'footnotesize'))
    content=''
    for ds,bb in ORDER:
        q=ew.loc[(ds,bb)];content+=row(ds if bb=='PatchTST' else '',bb,*[num(q[m].mean(),3)+r'\,$\pm$\,'+num(q[m].std(),3) for m in ['Cov','CovReal','ML','MLReal']])
    s=replace_table(s,'tab:envelope_sd',table('tab:envelope_sd','Outcome-domain comparison across three training runs.',tabular('llrrrr','Dataset & Backbone & Cov & Cov all-real & ML & ML all-real',content),'footnotesize'))
    s=replace_table(s,'tab:protectioncost',table('tab:protectioncost','Mean RMSE before and after protection.',tabular('llrrrr',r' & & \multicolumn{2}{c}{Cov} & \multicolumn{2}{c}{ML-Pol}\\'+'\n'+r'\cmidrule(lr){3-4}\cmidrule(lr){5-6}'+'\nDataset & Backbone & Unprotected & CPOR-Cov & Unprotected & CPOR-ML',body(['CovUnprotected','CovFullFix','MLPol','ProtectedMLPol'],2)),note='Boldface compares protected and unprotected forecasts within each implementation.'))
    # Correct bolding: protection cost table pairs, not the four-column minimum.
    pt=s.index('\\label{tab:protectioncost}');ps=s.rfind('\\begin{table}',0,pt);pe=s.index('\\end{table}',pt);blk=s[ps:pe];
    for ds,bb in ORDER:
        oldline=next(x for x in blk.splitlines() if x.startswith((ds if bb=='PatchTST' else '')+' & '+bb+' & '));vals=[]
        for pair in [['CovUnprotected','CovFullFix'],['MLPol','ProtectedMLPol']]:vals+=boldvals([M.loc[(ds,bb),m] for m in pair],2)
        blk=blk.replace(oldline,row(ds if bb=='PatchTST' else '',bb,*vals).rstrip())
    s=s[:ps]+blk+s[pe:]
    rows=''
    for ds,scope in [('RH','system'),('Traffic','system'),('Traffic','bottom'),('Wiki2','system'),('Wiki2','bottom'),('Labour','system'),('Labour','region'),('Labour','bottom'),('M5','system'),('M5','bottom')]:
        vals=[]
        for impl in ['Cov','ML']:vals += [num(le.loc[(ds,scope,impl),k],3) for k in ['reference_gain','cost','domain_gain']]
        rows+=row(ds,scope,*vals)
    s=replace_table(s,'tab:pairedlevels',table('tab:pairedlevels','Paired regional and system effects (\\%).',tabular('llrrrrrr',r' & & \multicolumn{3}{c}{Cov} & \multicolumn{3}{c}{ML}\\'+'\n'+r'\cmidrule(lr){3-5}\cmidrule(lr){6-8}'+'\nDataset & Level & Ref. gain & Cost & Domain gain & Ref. gain & Cost & Domain gain',rows),'footnotesize','Ref. gain compares CPOR with NNLS; Cost compares with its unprotected combination; Domain gain compares with all-real protection. Window RMSEs are averaged before within-run ratios.'))
    ns=read('NODE_DATASET_SUMMARY').set_index(['dataset','method']);rows=''
    for ds in ['RH','ECommerce','Traffic','Wiki2','Labour','M5']:rows+=row(ds,*[num(ns.loc[(ds,m),k]) for m in ['Cov','ML'] for k in ['improved','median_gain']])
    s=replace_table(s,'tab:nodedistribution',table('tab:nodedistribution','Nodewise accuracy relative to NNLS (\\%).',tabular('lrrrr',r' & \multicolumn{2}{c}{Cov} & \multicolumn{2}{c}{ML}\\'+'\n'+r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}'+'\nDataset & Improved nodes & Median gain & Improved nodes & Median gain',rows),note='Each node is compared after window averaging within a run; entries average fractions or medians over two backbones and three runs.'))
    s=s.replace('17.60\\% for Cov and\n16.55\\% for ML',f'{C["Cov__cost"]["trimmed"]:.2f}\\% for Cov and\n{C["ML__cost"]["trimmed"]:.2f}\\% for ML')
    runs=read('RUN_GAINS');rows=''
    for impl,m in [('Cov','CovFullFix'),('ML','ProtectedMLPol')]:
      for co in ['NNLS','ProCAST','PIR']:
        rr=runs[(runs.method==m)&(runs.comparator==co)].set_index('seed').gain;rows+=row(impl,co,*[num(rr.loc[seed],3) for seed in [42,1,2]],num(rr.mean(),3),num(rr.std(),3))
    s=replace_table(s,'tab:pairedruns',table('tab:pairedruns','Overall paired gains by training run (\\%).',tabular('llrrrrr','Implementation & Comparator & Run 1 & Run 2 & Run 3 & Mean & SD',rows)))
    s=s.replace('Against PIR, both implementations have positive gains in runs 1 and 3\nbut negative gains in run 2.','Against PIR, both implementations now have positive mean gains in all\nthree runs after the retrospective Labour early addition.')
    rows=''
    for impl,m in [('Cov','CovFullFix'),('ML','ProtectedMLPol')]:
      for co in ['NNLS','ProCAST','PIR']:
        q=u.loc[m+':'+co];rows+=row(impl,co,num(q['mean'],3),f'[{q.ci_low:.3f}, {q.ci_high:.3f}]',f'{q.p_raw:.5f}',f'{q.p_holm:.4f}')
    s=replace_table(s,'tab:uncertainty',table('tab:uncertainty','Paired gains and dataset-cluster uncertainty.',tabular('llrrrr',r'Impl. & Comparator & Mean (\%) & \shortstack{Unadjusted empirical\\95\% interval (\%)} & Raw $p$ & Holm $p$',rows)))
    s=s.replace('three are positive against PIR','four are positive against PIR').replace('$[0.335,4.476]\\%$ for Cov and\n$[0.383,4.456]\\%$','$[0.337,4.477]\\%$ for Cov and\n$[0.384,4.456]\\%$')
    s=s.replace('records. The 22 configurations','records from the original grid. The 22 configurations').replace('over both backbones, three runs and all windows within each dataset.','over both backbones, three runs and the original windows within each dataset.')
    dr=read('DATASET_RUN_GAINS');rows=''
    for ds in ['RH','ECommerce','Traffic','Wiki2','Labour','M5']:
      for impl,m in [('Cov','CovFullFix'),('ML','ProtectedMLPol')]:
        q=dr[(dr.dataset==ds)&(dr.method==m)&(dr.comparator=='PIR')].set_index('seed').gain;rows+=row(ds if impl=='Cov' else '',impl,*[num(q.loc[z],3) for z in [42,1,2]],num(q.mean(),3),str(int((q>0).sum()))+'/3')
    s=replace_table(s,'tab:pirdatasets',table('tab:pirdatasets','Paired RMSE reductions relative to PIR (\\%).',tabular('llrrrrr','Dataset & Impl. & Run 1 & Run 2 & Run 3 & Mean & Positive runs',rows)))
    s=s.replace('ECommerce and Wiki2, and negative means on Traffic, Labour and M5.','ECommerce, Wiki2 and Labour, and negative means on Traffic and M5.')
    # Li supplementary table (other ineligible rows stay visible with their existing first-run RMSE).
    lirow=''
    for ds,bb in ORDER:
        q=lc[(lc.dataset==ds)&(lc.backbone==bb)]
        if len(q):vals=boldvals(q[['Diag','Factor','Cov','ML']].iloc[0],3)
        else:vals=['---','---',num(G.loc[(ds,bb,42),'CovFullFix'],3),num(G.loc[(ds,bb,42),'ProtectedMLPol'],3)]
        lirow+=row(ds if bb=='PatchTST' else '',bb,*vals)
    s=replace_table(s,'tab:li',table('tab:li','Mean-node RMSE on the common forecast streams.',tabular('llrrrr','Dataset & Backbone & Li (Diag) & Li (Factor) & CPOR-Cov & CPOR-ML',lirow)))
    cap=0
    for bb in ['PatchTST','DLinear']:
        cap+=json.loads((E/'runs'/bb/'42/recent/LiFactor.json').read_text(encoding='utf8'))['lambda_cap_hits']
    s=s.replace('In 173 of the 1,008','In '+str(173+cap)+' of the 1,152').replace('14 windows and one of eight groups','16 windows and one of eight groups')
    lw=read('LI_WINDOWS');countwin=int(((lw[lw.scope=='all'].Factor)<lw[lw.scope=='all'].Diag).sum());s=s.replace('in two of\n16 windows',f'in {countwin} of\n16 windows')
    s=s.replace('0.33\\% increase',f'{100*(lc.Factor/lc.Diag-1).mean():.2f}\\% increase')
    for c,original in [('Factor',[3.87,3.68,3.85,3.76,5.37,5.34]),('Diag',[4.21,4.03,3.51,3.43,4.89,4.86])]:
        values=[]
        for scope in ['system','middle','bottom']:
            q=LG[LG.scope==scope]
            for m in ['Cov','ML']:values.append(100*(1-q[m]/q[c]).mean())
        # Replace only within Li's own paragraph, never numbers in unrelated results.
        st=s.index('Relative to Factor, Cov and ML reduced');ed=s.index('\\clearpage',st);block=s[st:ed]
        for old,v in zip(original,values):block=block.replace(f'{old:.2f}\\%',f'{v:.2f}\\%')
        s=s[:st]+block+s[ed:]
    # PIR supplementary absolute and level results.
    rows=''
    for ds,scope in [(d,'all') for d in ['ECommerce','Labour','M5','RH','Traffic','Wiki2']]+[(d,'system') for d in ['Labour','M5','RH','Traffic','Wiki2']]+[('Labour','region'),('M5','state')]+[(d,'bottom') for d in ['Labour','M5','Traffic','Wiki2']]:
        q=PD[(PD.dataset==ds)&(PD.scope==scope)]
        if len(q):
            q=q.iloc[0];rows+=row(ds,{'all':'All','system':'System total','region':'Region','state':'State','bottom':'Bottom'}[scope],num(q.Candidate,3),num(q.Ray,3),num(q.Full,3),num(q.full_cost),num(q.vs_common))
    s=replace_table(s,'tab:pirpaired',table('tab:pirpaired','Accuracy and protection cost for the same reconciled PIR forecast.',tabular('llrrrrr','Dataset & Level & Direct & Common & Full & Cost (\\%) & Gain (\\%)',rows),'footnotesize','Absolute RMSE averages windows within runs, then backbones and runs. Cost and Gain average their paired percentages after window averaging.'))
    s=s.replace('4,925 of 5,994',f'{ever:,} of 6,336').replace('all 431,568 stored node--date','all 456,192 stored node--date').replace('in 431,568 node--date checks per rule','in 456,192 node--date checks per rule')
    # Keep original timing values but update grouped accuracy columns.
    ix=s.index('\\label{tab:groupedpir}');start=s.rfind('\\begin{table}',0,ix);end=s.index('\\end{table}',ix);block=s[start:end]
    for ds in ['ECommerce','Labour','M5','RH','Traffic','Wiki2']:
        line=next(l for l in block.splitlines() if l.startswith(ds+' & '));fields=line.split(' & ');q=pr.loc[ds];fields[1:4]=[num(q.Ray,3),num(q.Group,3),num(q.Full,3)];block=block.replace(line,' & '.join(fields))
    s=s[:start]+block+s[end:]
    s=s.replace('Relative to two-group shrinkage, full projection reduced RMSE on all 54 streams outside ECommerce and on five of the twelve ECommerce streams. The mean reductions were 1.73\\% on PatchTST and 2.03\\% on DLinear.',f'Relative to two-group shrinkage, full projection reduced RMSE on all 60 streams outside ECommerce and on five of twelve ECommerce streams. The mean reductions were {PE[(PE.scope=="all")&(PE.backbone=="PatchTST")].vs_two_group.mean():.2f}\\% on PatchTST and {PE[(PE.scope=="all")&(PE.backbone=="DLinear")].vs_two_group.mean():.2f}\\% on DLinear. Timing in this table retains the original 66-stream measurement.')
    # Updated matched-PIR uncertainty.
    rows=''
    for ds in ['ECommerce','Labour','M5','RH','Traffic','Wiki2']:rows+=row(ds,num(pr.loc[ds,'vs_common'],6),num(pr.loc[ds,'vs_two_group'],6))
    content=tabular('lrr','Dataset & vs Common (\\%) & vs Two-group (\\%)',rows)+'\\par\\medskip\n';rows=''
    for name,k in [('Common','vs_common'),('Two-group','vs_two_group')]:
        q=pu.loc[k];rows+=row(name,num(q['mean'],6),f'[{q.ci_low:.6f}, {q.ci_high:.6f}]',f'{q.p_raw:.5f}',f'{q.p_holm:.4f}')
    content+=tabular('lrrrr','Comparator & Mean (\\%) & 95\\% interval (\\%) & Raw $p$ & Holm $p$',rows)
    s=replace_table(s,'tab:piruncertainty',table('tab:piruncertainty','Dataset-level uncertainty for full projection on PIR candidates.',content,'footnotesize'))
    pruns=read('PIR_RUNS').set_index('seed');s=span(s,'For full projection versus common shrinkage, the three run means',r'\section{AEMO continuous-month study}',f'''For full projection versus common shrinkage, the three run means are
{pruns.loc[42,'vs_common']:.4f}\\%, {pruns.loc[1,'vs_common']:.4f}\\% and {pruns.loc[2,'vs_common']:.4f}\\%.
Against two-group shrinkage they are {pruns.loc[42,'vs_two_group']:.4f}\\%,
{pruns.loc[1,'vs_two_group']:.4f}\\% and {pruns.loc[2,'vs_two_group']:.4f}\\%.
Removing any dataset leaves gains of {a.loo_low:.4f}--{a.loo_high:.4f}\\% against common
shrinkage and {b.loo_low:.4f}--{b.loo_high:.4f}\\% against two-group shrinkage.
The runs share observation dates. Labour now averages early and late
window RMSE before computing either paired contrast.

\\FloatBarrier
''')
    s=s.replace('OR2 v9','OR2 v10')
    # Historical scopes are deliberately not expanded by fictitious new results.
    s=s.replace('All 66 archived streams are included for Cov and ML.','The original 66 streams are retained for this historical projection-order analysis.')
    s=s.replace('Table~\\ref{tab:events} is computed from','Table~\\ref{tab:events} retains the original-grid measurements computed from')
    appendix='''
\\FloatBarrier
\\section{Retrospective Labour early-window addition}\\label{sec:labourearly}
The early scoring window covers December 2008--November 2014, with
36 preceding calibration months. The same 57 observed nodes, including
eight regions and the system total, and the same aggregation matrix are
used as in the late window. Each backbone has three training runs under
the existing validation-MAE selection and early-stopping rules. Of 42
required fitting stages, 18 matching stages were reused and 24 were
newly fitted before this manuscript revision. Every new fit stopped below
its cap; the maximum stopping steps were 438 for PatchTST and 1,308 for
DLinear. The addition was registered after the earlier benchmark results
had been examined and is retrospective.

All methods share each base stream, the 0.5\\% allowance, reference,
weights and feedback order. Each protected path settles its own actual
releases, starting from zero at scoring. The early extension contains
41 rules across six streams. Its 138 protected trajectories pass
566,352 exact envelope and the same number of prefix checks; Cov and ML
alone contribute 49,248 such checks each in total across the two
implementations. Stored aggregation representations satisfy the same
floating-point coherence tolerances as the main study.

'''
    # Correct the implementation-specific count: six streams per implementation.
    appendix=appendix.replace('alone contribute 49,248 such checks each in total across the two\nimplementations','together contribute 49,248 such checks')
    earlym=pd.read_csv(E/'THREE_RUN_RMSE.csv');rows=''
    for bb in ['PatchTST','DLinear']:
      for method in ['NNLS','CPOR-Cov','CPOR-ML','ProtectedCalBest','ProtectedMinT_Cov']:
        vals=[]
        for scope in ['Overall','Regions','System']:
            q=earlym[(earlym.backbone==bb)&(earlym.method==method)&(earlym.scope==scope)].iloc[0];vals.append(f'{q["mean"]:.3f}'+r'\,$\pm$\,'+f'{q["std"]:.3f}')
        rows+=row(bb,{'ProtectedCalBest':'Protected fixed expert','ProtectedMinT_Cov':'Protected MinT (Cov)'}.get(method,method),*vals)
    appendix+=table('tab:labourearly','Labour early-window RMSE over three runs.',tabular('llrrr','Backbone & Method & All nodes & Regions & System',rows),'footnotesize')
    appendix+='''
On the early window alone, Cov and ML reduce mean-node RMSE relative
to NNLS by 10.05\\% and 10.13\\%, and relative to same-target common
shrinkage by 6.04\\% and 6.14\\%. Their costs relative to unprotected
targets are 44.92\\% and 46.24\\%. The matched nonnegative envelope gains
are only 0.020\\% and 0.026\\%, positive in three of six streams each.
Protected Cov-input MinT is essentially tied. For PatchTST's system,
Cov and ML are worse than the protected fixed expert by 0.23\\% and
0.68\\%. These negative results remain in the run- and node-level records.

Main benchmark tables combine each method's early and late RMSE within
dataset, backbone and run before taking ratios. This keeps six datasets
and twelve dataset--backbone groups, with no extra weight for the added
window. Historical DUET, COSA/robust/MCGrad, same-state geometry,
projection-order and dedicated timing records retain their original
window coverage. The AEMO continuous month remains separate.

OR2 v10 retains the older resources and adds
\\texttt{labour\\_early} for stored trajectories and
\\texttt{benchmark\\_update} for current tables and statistical summaries.
From its extracted root:
\\begin{quote}\\footnotesize\\ttfamily
python benchmark\\_update/check\\_current.py\\\\
python labour\\_early/check\\_bundle.py
\\end{quote}
These commands rebuild aggregate results and check stored predictions;
they do not train a backbone or execute a new projection experiment.
'''
    s=s.replace('\\end{document}',appendix+'\n\\end{document}')
    t=t.replace('CPOR dataset-scope and source-link revision, 7 November 2026','CPOR Labour early retrospective update, 7 November 2026')
    (H/'source/main.tex').write_text(t,encoding='utf8');(H/'source/supplement/main.tex').write_text(s,encoding='utf8')
    # Cover letter: update only claims and resource version; no changes to the frozen letter.
    cv=(OLD/'correspondence/Cover_Letter.tex').read_text(encoding='utf8')
    cv=cv.replace('by 2.09\\% relative to common shrinkage and 1.88\\% relative','by 1.94\\% relative to common shrinkage and 1.75\\% relative').replace('Full projection incurs a 2.31\\% cost relative to direct release and takes','Its mean RMSE change relative to direct release is -0.07\\%; costs and\nbenefits vary across datasets. Historical timing is')
    cv=cv.replace('The AEMO study now covers','We have also incorporated Labour\'s early window (December 2008--November\n2014), with the existing training and parameter-selection rules. This is\na retrospective addition. The six-benchmark summaries first average the\ntwo windows within each backbone and run; all datasets retain equal\nweight. Protection costs and system-level reversals remain explicit.\n\nThe AEMO study covers')
    cv=cv.replace('Online Resource 2 v9','Online Resource 2 v10').replace('the OR2 v9 release','the OR2 v10 release').replace('https://github.com/kavin027/CPOR/tree/dataset-scope-links-20261107/review_resources/20261107_scope_links',URL)
    cv=cv.replace('CPOR dataset-scope and source-link revision, 7 November 2026','CPOR Labour early retrospective update, 7 November 2026')
    (H/'correspondence/Cover_Letter.tex').write_text(cv,encoding='utf8');print('DOCUMENTS_UPDATED')
if __name__=='__main__':main()
