"""Current benchmark arithmetic from included window records; NumPy+pandas."""
from pathlib import Path
import itertools,json
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent
def main():
    c=pd.read_csv(H/'ALL_CELL_METRICS.csv');gr=['dataset','backbone','seed'];key=gr+['window','method'];assert not c.duplicated(key).any() and len(c)==72*16
    old=pd.read_csv(H/'original/ALL_CELL_METRICS.csv');m=old.merge(c,on=key,suffixes=('_old','_new'));np.testing.assert_array_equal(m.rmse_old,m.rmse_new)
    new=c.groupby(gr+['method'],as_index=False).rmse.mean();stored=pd.read_csv(H/'GROUP_RUN_RMSE.csv');a=new.merge(stored,on=gr+['method'],suffixes=('_a','_b'));np.testing.assert_allclose(a.rmse_a,a.rmse_b,rtol=1e-13,atol=1e-10)
    w=new.pivot(index=gr,columns='method',values='rmse');pairs=pd.read_csv(H/'PAIRED_GROUP_RUN.csv')
    for r in pairs.itertuples():assert np.isclose(r.gain,100*(1-w.loc[(r.dataset,r.backbone,r.seed),r.method]/w.loc[(r.dataset,r.backbone,r.seed),r.comparator]),rtol=1e-12,atol=1e-10)
    risk=pd.read_csv(H/'RISK_CELLS.csv');summary=pd.read_csv(H/'RISK_SUMMARY.csv');ratios=pd.read_csv(H/'FINAL_NODE_RATIOS.csv')
    for r in summary.itertuples():
        a=risk[risk.method==r.method];assert a.node_sequences.sum()==r.node_sequences==6336 and a.prefixes.sum()==r.prefixes==456192
        assert a.ever.sum()==r.ever and a.all_dates.sum()==r.all_dates and a.final.sum()==r.final
        assert np.isclose(np.quantile(ratios[ratios.method==r.method].final_ratio,.95),r.p95)
    p=pd.read_csv(H/'PIR_WINDOW_RMSE.csv');pg=pd.read_csv(H/'PIR_GROUP_RUN.csv');cols=['Candidate','PIR','Ray','Group','Full'];calc=p.groupby(gr+['scope'],as_index=False)[cols].mean();joined=calc.merge(pg,on=gr+['scope'],suffixes=('_a','_b'))
    for k in cols:np.testing.assert_allclose(joined[k+'_a'],joined[k+'_b'],equal_nan=True)
    draws=np.array(list(itertools.product(range(6),repeat=6)));signs=np.array(list(itertools.product([-1,1],repeat=6)))
    for file,pir in [('UNCERTAINTY.csv',False),('PIR_UNCERTAINTY.csv',True)]:
      stats=pd.read_csv(H/file);raw=[]
      for r in stats.itertuples():
        if pir:q=pg[pg.scope=='all'].rename(columns={r.contrast:'gain'})
        else:
            method,comp=r.contrast.split(':');q=pairs[(pairs.method==method)&(pairs.comparator==comp)]
        x=q.groupby('dataset').gain.mean().sort_index().to_numpy();boot=x[draws].mean(1);pv=np.mean(abs((signs*x).mean(1))>=abs(x.mean())-1e-12);raw.append(pv)
        assert np.isclose(x.mean(),r.mean) and np.isclose(np.quantile(boot,.025),r.ci_low) and np.isclose(np.quantile(boot,.975),r.ci_high) and np.isclose(pv,r.p_raw)
      order=np.argsort(raw);adj=np.minimum(1,np.maximum.accumulate(np.array(raw)[order]*(len(raw)-np.arange(len(raw)))));np.testing.assert_allclose(stats.p_holm.to_numpy()[order],adj)
    output=dict(passed=True,configurations=24,streams=72,methods=16,windows_per_benchmark=2,old_rows_preserved=len(old),primary_node_sequences=6336,primary_node_dates=456192,uncertainty_recomputed=True,experiments_run=0)
    (H/'AGGREGATE_CHECK_V10.json').write_text(json.dumps(output,indent=2),encoding='utf8');print(json.dumps(output,indent=2))
if __name__=='__main__':main()
