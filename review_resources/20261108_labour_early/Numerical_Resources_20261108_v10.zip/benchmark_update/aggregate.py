"""Reaggregate saved records only. No fitting, optimization or prediction."""
from pathlib import Path
import json,hashlib,itertools,shutil
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent;O=H.parent;B=H/'historical_base';E=O/'cpor_labour_early_three_runs_20261107';D=H/'derived';A=H/'or2_v10'
KEY=['dataset','backbone','window','seed'];GR=['dataset','backbone','seed'];NKEY=KEY+['method','node']
MM={'CPOR-Cov':'CovFullFix','CPOR-ML':'ProtectedMLPol','CovTarget':'CovUnprotected','MLTarget':'MLPol','ProtectedWLSstruct':'WLSstruct','ProtectedWLSvar':'WLSvar','ProtectedMinTshrink':'MinTshrink','ProtectedWLSvar_Cov':'WLSvar_Cov','ProtectedMinT_Cov':'MinT_Cov'}
LM={'Raw':'Raw','NNLS':'NNLS','CPOR-Cov':'Cov','CPOR-ML':'ML','CovTarget':'CovU','MLTarget':'MLU','CovAllReal':'CovReal','MLAllReal':'MLReal'}
SC={'Overall':'all','Regions':'region','System':'system','Bottom':'bottom','SexRegion':'middle'}
def js(p,x):p.write_text(json.dumps(x,indent=2,default=lambda a:a.item() if isinstance(a,np.generic) else str(a)),encoding='utf8')
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def save(f,name):f.to_csv(D/(name+'.csv'),index=False);return f
def boot(pairs,family):
    draws=np.array(list(itertools.product(range(6),repeat=6)));signs=np.array(list(itertools.product([-1,1],repeat=6)));out=[]
    for name,x in family.items():
        arr=x.groupby('dataset').gain.mean().sort_index().to_numpy();assert len(arr)==6
        samples=arr[draws].mean(1);raw=np.mean(abs((signs*arr).mean(1))>=abs(arr.mean())-1e-12)
        out.append(dict(contrast=name,mean=arr.mean(),ci_low=np.quantile(samples,.025),ci_high=np.quantile(samples,.975),p_raw=raw,positive_datasets=int((arr>0).sum()),loo_low=min(np.delete(arr,i).mean() for i in range(6)),loo_high=max(np.delete(arr,i).mean() for i in range(6))))
    f=pd.DataFrame(out);order=np.argsort(f.p_raw.to_numpy());f.loc[order,'p_holm']=np.minimum(1,np.maximum.accumulate(f.p_raw.to_numpy()[order]*(len(f)-np.arange(len(f)))));return f
def main():
    assert json.loads((E/'INDEPENDENT_CHECK.json').read_text(encoding='utf8'))['passed']
    early=pd.read_csv(E/'RUN_SCOPE_RMSE.csv').rename(columns={'run':'seed'});early['dataset']='Labour';early['window']='early'
    old=pd.read_csv(B/'ALL_CELL_METRICS.csv');allowed=list(MM)+['Raw','NNLS','CalBest','ProtectedCalBest','ProCAST','Ada-Y','PIR'];add=early[(early.scope=='Overall')&early.method.isin(allowed)].copy();add['method']=add.method.replace(MM);add=add[add.method.isin(old.method.unique())];add['nodes']=57;add['observations']=72
    cells=pd.concat([old,add[old.columns.intersection(add.columns)]],ignore_index=True);assert not cells.duplicated(KEY+['method']).any();assert len(cells)==72*16
    save(cells,'ALL_CELL_METRICS');groups=save(cells.groupby(GR+['method'],as_index=False).rmse.mean(),'GROUP_RUN_RMSE');wide=groups.pivot(index=GR,columns='method',values='rmse');means=wide.groupby(level=[0,1]).mean();sd=wide.groupby(level=[0,1]).std()
    save(means.reset_index(),'GROUP_MEANS');save(sd.reset_index(),'GROUP_SD')
    pairs=[]
    for impl in ['CovFullFix','ProtectedMLPol']:
      for comp in [m for m in wide if m!=impl]:
        f=(100*(1-wide[impl]/wide[comp])).rename('gain').reset_index();f['method']=impl;f['comparator']=comp;pairs.append(f)
    paired=save(pd.concat(pairs,ignore_index=True),'PAIRED_GROUP_RUN');save(paired.groupby(['method','comparator','backbone'],as_index=False).gain.mean(),'BACKBONE_GAINS');save(paired.groupby(['method','comparator','seed'],as_index=False).gain.mean(),'RUN_GAINS')
    save(paired.groupby(['method','comparator','dataset','seed'],as_index=False).gain.mean(),'DATASET_RUN_GAINS')
    families={f'{m}:{c}':paired[(paired.method==m)&(paired.comparator==c)] for m in ['CovFullFix','ProtectedMLPol'] for c in ['NNLS','ProCAST','PIR']};unc=save(boot(paired,families),'UNCERTAINTY')
    lvl=pd.read_csv(B/'matched_envelope/analysis/LEVEL_CELL_METRICS.csv');el=early[early.method.isin(LM)&early.scope.isin(SC)].copy();el['method']=el.method.map(LM);el['scope']=el.scope.map(SC)
    lc=save(pd.concat([lvl,el[lvl.columns.intersection(el.columns)]],ignore_index=True),'LEVEL_CELLS');lg=save(lc.groupby(GR+['scope','method'],as_index=False).rmse.mean(),'LEVEL_GROUP_RUN');lw=lg.pivot(index=GR+['scope'],columns='method',values='rmse')
    levelpairs=[]
    for impl in ['Cov','ML']:
        f=lw.reset_index()[GR+['scope']].copy();f['implementation']=impl
        for key,num,den in [('reference_gain',impl,'NNLS'),('cost',impl,impl+'U'),('domain_gain',impl,impl+'Real')]:f[key]=100*((lw[num]/lw[den]-1) if key=='cost' else (1-lw[num]/lw[den])).to_numpy()
        levelpairs.append(f)
    lp=save(pd.concat(levelpairs,ignore_index=True),'LEVEL_PAIRED');save(lp.groupby(['dataset','scope','implementation'],as_index=False)[['reference_gain','cost','domain_gain']].mean(),'LEVEL_EFFECTS')
    en=lp[lp.scope=='all'].rename(columns={'domain_gain':'gain'});save(en,'ENVELOPE_GAINS');save(boot(en,{m:en[en.implementation==m] for m in ['Cov','ML']}),'ENVELOPE_UNCERTAINTY')
    nodes=pd.read_csv(B/'matched_envelope/analysis/NODE_METRICS.csv');oldrisk=Path(O/'cpor_window_clarity_20261024/submission_package/CURRENT_RESULTS_20261022/derived');riskold=pd.read_csv(oldrisk/'RISK_CELLS.csv');ratioold=pd.read_csv(oldrisk/'FINAL_NODE_RATIOS.csv')
    shutil.copy2(oldrisk/'RISK_CELLS.csv',D/'ORIGINAL_RISK_CELLS.csv');shutil.copy2(oldrisk/'FINAL_NODE_RATIOS.csv',D/'ORIGINAL_FINAL_NODE_RATIOS.csv')
    rn=[];ratios=[];nn=[]
    for bb in ['PatchTST','DLinear']:
     for seed in [42,1,2]:
      d=E/'runs'/bb/str(seed);x=load(d/'context.npz');y=x['truth'][36:];b=x['b'][36:];Berr=np.cumsum((b-y)**2,0);ref=np.sqrt(Berr[-1]/72)
      for name in json.loads((E/'REGISTRATION.json').read_text(encoding='utf8'))['methods']:
        m=MM.get(name,name);p=load(d/'results'/(name+'.npz'))['pred'];sse=np.cumsum((p-y)**2,0);rm=np.sqrt(sse[-1]/72);ratio=rm/ref;bad=sse>(1.005**2)*Berr+1e-8*np.maximum(1,Berr);key=dict(dataset='Labour',backbone=bb,window='early',seed=seed)
        if m in riskold.method.unique():
            rn.append(dict(**key,method=m,node_sequences=57,prefixes=4104,ever=bad.any(0).sum(),all_dates=bad.sum(),final=bad[-1].sum()))
            for i,v in enumerate(ratio):ratios.append(dict(**key,method=m,node=i,final_ratio=v))
        if name in LM:
            for i,value in enumerate(rm):nn.append(dict(**key,method=LM[name],node=i,rmse=value,reference_rmse=ref[i],ever=bool(bad[:,i].any()),worst_excess_sse=np.max(sse[:,i]-1.005**2*Berr[:,i])))
    risk=save(pd.concat([riskold,pd.DataFrame(rn)],ignore_index=True),'RISK_CELLS');rat=save(pd.concat([ratioold,pd.DataFrame(ratios)],ignore_index=True),'FINAL_NODE_RATIOS')
    rs=risk[risk.method.isin(pd.read_csv(B/'RISK_SUMMARY.csv').method)].groupby('method')[['node_sequences','prefixes','ever','all_dates','final']].sum();rs['ever_pct']=100*rs.ever/rs.node_sequences;rs['dates_pct']=100*rs.all_dates/rs.prefixes;rs['final_pct']=100*rs.final/rs.node_sequences;rs['p95']=rat.groupby('method').final_ratio.quantile(.95);save(rs.reset_index(),'RISK_SUMMARY')
    nd=save(pd.concat([nodes,pd.DataFrame(nn)],ignore_index=True),'NODE_METRICS');ng=nd.groupby(GR+['method','node'],as_index=False)[['rmse','reference_rmse']].mean();ng['gain']=100*(1-ng.rmse/ng.reference_rmse)
    ns=[]
    for key,q in ng[ng.method.isin(['Cov','ML'])].groupby(GR+['method']):ns.append(dict(zip(GR+['method'],key))|dict(improved=100*(q.gain>1e-8).mean(),median_gain=q.gain.median()))
    ns=pd.DataFrame(ns);save(ns,'NODE_DISTRIBUTION');save(ns.groupby(['dataset','method'],as_index=False)[['improved','median_gain']].mean(),'NODE_DATASET_SUMMARY')
    # Main figure averages within-run, window-averaged RMSE ratios; prefix counts retain every window.
    costs=[]
    for m,u in [('CovFullFix','CovUnprotected'),('ProtectedMLPol','MLPol')]:
        f=wide.reset_index()[GR].copy();f['method']=m;f['cost']=100*(wide[m]/wide[u]-1).to_numpy();costs.append(f)
    costs=save(pd.concat(costs,ignore_index=True),'PROTECTION_COST_RUNS');save(costs.groupby(['dataset','method'],as_index=False).cost.mean(),'PROTECTION_COST_DATASET')
    # PIR matched candidates: append exact saved new-window metrics, retaining archived windows verbatim.
    pir=pd.read_csv(A/'pir_matched/window_rmse.csv');pe=early[early.method.isin(['PIR','PIRCoherent','PIRCommon','PIRTwoGroup','PIRFull'])&early.scope.isin(SC)].copy();pe['scope']=pe.scope.map(SC);pe['method']=pe.method.replace({'PIRCoherent':'Candidate','PIRCommon':'Ray','PIRTwoGroup':'Group','PIRFull':'Full'});pe=pe.pivot(index=KEY+['scope'],columns='method',values='rmse').reset_index()
    # Original matched archive has no Group column; merge it from grouped records.
    gg=pd.read_csv(A/'pir_grouped/stream_metrics.csv');gg=gg[gg.arm=='Group'][KEY+['rmse']].rename(columns={'rmse':'Group'});pir=pir.merge(gg,on=KEY,how='left');pir.loc[pir.scope!='all','Group']=np.nan
    pir=save(pd.concat([pir,pe],ignore_index=True),'PIR_WINDOW_RMSE');pg=pir.groupby(GR+['scope'],as_index=False)[['Candidate','PIR','Ray','Group','Full']].mean()
    for key,num,den in [('vs_common','Full','Ray'),('vs_two_group','Full','Group'),('two_vs_common','Group','Ray'),('full_cost','Full','Candidate'),('common_cost','Ray','Candidate'),('two_cost','Group','Candidate')]:pg[key]=100*((pg[num]/pg[den]-1) if 'cost' in key else (1-pg[num]/pg[den]))
    save(pg,'PIR_GROUP_RUN');save(pg.groupby(['dataset','scope'],as_index=False).mean(numeric_only=True),'PIR_DATASET');pall=pg[pg.scope=='all'];pf={k:pall.rename(columns={k:'gain'}) for k in ['vs_common','vs_two_group']};save(boot(pall,pf),'PIR_UNCERTAINTY');save(pall.groupby('seed',as_index=False)[['vs_common','vs_two_group','full_cost']].mean(),'PIR_RUNS')
    # Li comparisons remain one backbone initialization, now16 eligible windows.
    li=pd.read_csv(A/'li_factor/windows.csv');ef=early[(early.seed==42)&early.method.isin(['LiDiag','LiFactor','CPOR-Cov','CPOR-ML'])&early.scope.isin(SC)].copy();ef['scope']=ef.scope.map(SC);ef['method']=ef.method.replace({'LiDiag':'Diag','LiFactor':'Factor','CPOR-Cov':'Cov','CPOR-ML':'ML'});ef=ef.pivot(index=['dataset','backbone','window','scope'],columns='method',values='rmse').reset_index();li=save(pd.concat([li,ef],ignore_index=True),'LI_WINDOWS');lg=li.groupby(['dataset','backbone','scope'],as_index=False)[['Factor','Diag','Cov','ML']].mean();save(lg,'LI_GROUPS')
    # Aggregate numbers used by prose; source scopes always explicit.
    claims={}
    for m in ['CovFullFix','ProtectedMLPol']:
      for comp in ['Raw','NNLS','ProCAST','Ada-Y','PIR','MinTshrink','MinT_Cov','ProtectedCalBest']:
        z=paired[(paired.method==m)&(paired.comparator==comp)];claims[m+'__'+comp]=dict(mean=z.gain.mean(),positive_groups=int((z.groupby(['dataset','backbone']).gain.mean()>0).sum()),positive_datasets=int((z.groupby('dataset').gain.mean()>0).sum()))
    for k in ['vs_common','vs_two_group','two_vs_common','full_cost','common_cost','two_cost']:claims['PIR__'+k]=float(pall[k].mean())
    claims['PIR_common_positive_windows']=int((100*(1-pir[pir.scope=='all'].Full/pir[pir.scope=='all'].Ray)>0).sum());claims['PIR_two_positive_windows']=int((100*(1-pir[pir.scope=='all'].Full/pir[pir.scope=='all'].Group)>0).sum())
    for m in ['Cov','ML']:
        z=en[en.implementation==m];gg=z.groupby(['dataset','backbone']).gain.mean();x=costs[costs.method=={'Cov':'CovFullFix','ML':'ProtectedMLPol'}[m]].cost
        claims[m+'__domain']=dict(mean=z.gain.mean(),median=gg.median(),positive_groups=int((gg>0).sum()),rh_share=100*gg.loc['RH'].sum()/gg.sum(),other_mean=gg.drop('RH',level=0).mean(),negative_group_runs=int((z.gain<0).sum()))
        claims[m+'__cost']=dict(mean=x.mean(),median=x.median(),q25=x.quantile(.25),q75=x.quantile(.75),trimmed=np.sort(x.to_numpy())[3:-3].mean())
    js(D/'CLAIMS.json',claims);js(D/'REAGGREGATION_SCOPE.json',dict(configurations=24,streams=72,benchmarks=6,datasets_total=7,node_sequences_per_primary=6336,node_dates_per_primary=456192,early_window='2008-12 through2014-11',historical_scopes=['DUET11windows','COSA/robust/MCGrad22configurations','projection-order66streams','same-state-domain66streams','dedicated-timing66streams'],AEMO_unchanged=True,experiments_added=0))
    print(json.dumps(claims,indent=2))
if __name__=='__main__':main()
