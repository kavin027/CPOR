from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
H=Path(__file__).resolve().parent;D=H/'derived'
order=['RH','ECommerce','Traffic','Wiki2','Labour','M5'];risk=pd.read_csv(D/'RISK_CELLS.csv');cost=pd.read_csv(D/'PROTECTION_COST_DATASET.csv');data=[]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,2,figsize=(11.5,4.1),sharey=True)
for j,(protected,unprotected,color,name) in enumerate([('CovFullFix','CovUnprotected','#0072B2','Cov'),('ProtectedMLPol','MLPol','#D55E00','ML')]):
    offset=(-.13 if j==0 else .13);yy=np.arange(6)+offset
    rates=[];costs=[]
    for ds in order:
        a=risk[(risk.dataset==ds)&(risk.method==unprotected)];b=risk[(risk.dataset==ds)&(risk.method==protected)];before=100*a.ever.sum()/a.node_sequences.sum();after=100*b.ever.sum()/b.node_sequences.sum();v=cost[(cost.dataset==ds)&(cost.method==protected)].cost.iloc[0];rates.append(before);costs.append(v);data.append(dict(dataset=ds,implementation=name,unprotected_ever_pct=before,protected_ever_pct=after,protection_cost_pct=v))
    axes[0].hlines(yy,0,rates,color=color,linewidth=1.7,alpha=.6);axes[0].scatter(rates,yy,c=color,s=35,zorder=3);axes[0].scatter(np.zeros(6),yy,edgecolors=color,facecolors='white',s=35,zorder=4)
    axes[1].hlines(yy,0,costs,color=color,linewidth=1.7,alpha=.6);axes[1].scatter(costs,yy,c=color,s=35,zorder=3)
    for y,x,v in zip(yy,rates,costs):
        axes[0].annotate(f'{x:.1f}',(x,y),xytext=(5,0),textcoords='offset points',va='center',fontsize=8,color=color)
        axes[1].annotate(f'{v:+.1f}',(v,y),xytext=(5 if v>=0 else -5,0),textcoords='offset points',ha='left' if v>=0 else 'right',va='center',fontsize=8,color=color)
axes[0].set_yticks(np.arange(6),order);axes[0].invert_yaxis();axes[0].set_xlim(-4,111);axes[0].set_xlabel('Node sequences ever over limit (%)');axes[0].set_title('(a) Cumulative protection',loc='left',fontweight='bold',fontsize=11)
axes[1].set_xlim(-85,155);axes[1].axvline(0,color='.45',linewidth=.7);axes[1].set_xlabel('RMSE change after protection (%)');axes[1].set_title('(b) Accuracy cost',loc='left',fontweight='bold',fontsize=11)
for ax in axes:ax.grid(axis='x',color='.9',linewidth=.6);ax.set_axisbelow(True);ax.tick_params(axis='y',length=0)
legend=[Line2D([0],[0],marker='o',color='#0072B2',label='Cov'),Line2D([0],[0],marker='o',color='#D55E00',label='ML'),Line2D([0],[0],marker='o',linestyle='None',markerfacecolor='white',markeredgecolor='.3',label='Protected: zero violations')]
fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.5,-.015),ncol=3,frameon=False,fontsize=9);fig.subplots_adjust(left=.10,right=.98,top=.91,bottom=.19,wspace=.18)
for ext in ['pdf','svg']:fig.savefig(H/'source/images'/('Fig2_Protection_Tradeoffs.'+ext),bbox_inches='tight')
fig.savefig(H/'qa/Figure2.png',dpi=160,bbox_inches='tight');pd.DataFrame(data).to_csv(D/'FIGURE2_DATA.csv',index=False)
print('FIGURE2_UPDATED')
