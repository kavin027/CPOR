# OR2 v7: evidence scope and local freeze clarification

This version accompanies the AEMO minor revision, 7 November 2026. Current manuscript: 29 pages; supplement: 20 pages. Main Sections 5.6/6.4/6.7, Eq. (24) and Table 14 map to Supplement S15/S17 and Tables S22/S24--S27.

## Meaning of the freeze

The pre-acquisition freeze is author-recorded: local protocol, timestamp, implementation/dependency hashes and amendment records. It is not a third-party preregistration or externally certified timestamp. The 86 hashed files are 84 Python implementation/dependency files, one directory inventory and one protocol. The 520 original data ZIP URLs and their post-download hashes are in the separate SOURCE_RECEIPT.json. Original registrations and protocols are retained unchanged.

## What is checked

The six benchmark datasets have aggregate arithmetic checks, source maps and replay drivers; complete optimizer replay requires their original input archives and software environment. For AEMO, the included reference, candidate, released forecast, observation, S and nonnegative representations allow exact saved-path verification. From the extracted OR2 root:

    python aemo_october/check_current.py
    python aemo_october/check_package.py

The first uses the standard library for hashes, arithmetic and timing summaries. The second needs NumPy and recomputes all 53,568 envelope/prefix checks, all 53,568 stored rational allowance states and floating coherence; deliberately invalid releases are rejected. Neither command executes projection solvers or retrains neural models. Those are separate reproduction operations.

## Validation and comparison scope

AEMO evaluates the publication rules, not new Cov/ML or external-method rankings. It uses estimated underlying demand, finalized sequential feedback, the fixed NNLS reference and 0.5% allowance. Earlier inspection of related signed TOTALDEMAND is retained as an eligibility-only attempt. It is one continuous month shared by two backbones, not independent month-level repetitions.

Direct protection and two-stage protection use different ideal objectives with their own evolving allowance states; actual releases pass their implementation's certification. Similar accuracy is observed on the evaluated streams. The two-stage version provides a common coherent-candidate interface, without a claim of mathematical equivalence between the two orders.

All numerical records, stored arrays, checkers and prior evidence files from OR2 v6 are retained byte-for-byte. Only the current index and this scope note are added/updated. No model, candidate, scoring rule or experimental result changes in this revision.
