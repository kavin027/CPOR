"""Verify the projection-order addendum and Table 8 intervals; standard library only."""
import csv,itertools,json,hashlib
from collections import defaultdict
from math import isclose
from pathlib import Path
from statistics import mean
H=Path(__file__).resolve().parent
def read(name):
    with (H/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def quantile(values,q):
    a=sorted(values);p=(len(a)-1)*q;i=int(p)
    return a[i]+(p-i)*(a[min(i+1,len(a)-1)]-a[i])
def key(r):
    return tuple(r[k] for k in ('dataset','backbone','seed','implementation','scope'))
cells=read('cell_rmse.csv')
groups=defaultdict(lambda:defaultdict(list))
for r in cells:groups[key(r)][r['arm']].append(float(r['rmse']))
paired={}
for k,a in groups.items():
    assert set(a)=={'Direct','TwoStage'} and len(a['Direct'])==len(a['TwoStage'])==(1 if k[0]=='Labour' else 2)
    direct,two=mean(a['Direct']),mean(a['TwoStage'])
    paired[k]=(direct,two,100*(1-direct/two))
published=read('paired_rmse.csv')
assert len(published)==len(paired)
for r in published:
    values=paired[key(r)]
    for col,v in zip(['Direct','TwoStage','direct_gain_pct'],values):
        assert isclose(float(r[col]),v,rel_tol=1e-11,abs_tol=1e-10)
datasets=defaultdict(list)
for (ds,bb,seed,impl,scope),v in paired.items():datasets[ds,impl,scope].append(v)
published=read('dataset_rmse.csv')
for r in published:
    v=list(map(mean,zip(*datasets[r['dataset'],r['implementation'],r['scope']])))
    for col,value in zip(['Direct','TwoStage','direct_gain_pct'],v):assert isclose(float(r[col]),value,rel_tol=1e-11,abs_tol=1e-10)
for impl in ['Cov','ML']:
    a=[r for r in read('cell_audit.csv') if r['implementation']==impl]
    for arm in ['Direct','TwoStage']:
        rows=[r for r in a if r['arm']==arm]
        assert len(rows)==66
        assert [sum(int(r[k]) for r in rows) for k in ['nodes','exact_node_checks','ever','events']]==[5994,431568,0,0]
replays=read('baseline_replay.csv')
assert len(replays)==132 and all(r['replay_bitwise']=='True' and float(r['replay_max'])==0 for r in replays)
effects=read('table8_dataset_effects.csv')
runs=read('table8_run_effects.csv')
summary=read('table8_uncertainty.csv')
assert len(effects)==6 and len(runs)==3 and len(summary)==2
pvalues=[]
for r in summary:
    contrast=r['contrast'];v=[float(e[contrast]) for e in effects]
    boots=[mean(v[i] for i in ids) for ids in itertools.product(range(6),repeat=6)]
    tests=[abs(mean(s*x for s,x in zip(sign,v))) for sign in itertools.product([-1,1],repeat=6)]
    p=mean(x>=abs(mean(v))-1e-12 for x in tests)
    for col,value in [('mean',mean(v)),('lower',quantile(boots,.025)),('upper',quantile(boots,.975)),('raw_p',p),('leave_one_out_min',min(mean(v[:i]+v[i+1:]) for i in range(6))),('leave_one_out_max',max(mean(v[:i]+v[i+1:]) for i in range(6)))]:
        assert isclose(float(r[col]),value,abs_tol=1e-10)
    assert isclose(mean(float(x[contrast]) for x in runs),mean(v),abs_tol=1e-10)
    pvalues.append(p)
idx=sorted(range(2),key=lambda i:pvalues[i]);last=0
for j,i in enumerate(idx):
    last=max(last,(2-j)*pvalues[i])
    assert isclose(float(summary[i]['holm_p']),min(1,last),abs_tol=1e-12)
if (H/'MANIFEST.json').exists():
    for name,digest in json.loads((H/'MANIFEST.json').read_text()).items():
        assert hashlib.sha256((H/name).read_bytes()).hexdigest()==digest,name
print('PASS: 66 streams per target family, paired overall/layer errors, original release replay, zero violation totals, and both dataset-level bootstrap/sign-flip analyses.')
