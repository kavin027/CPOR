from pathlib import Path
import itertools,json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent
O=H.parent
k=['dataset','backbone','seed']
g=pd.read_csv(O/'pir_grouped_release_20261106/stream_metrics.csv')
w=g.pivot(index=k+['window'],columns='arm',values='rmse').groupby(k).mean()
d=pd.DataFrame({'Full_vs_Common':100*(1-w.Full/w.Ray),'Full_vs_TwoGroup':100*(1-w.Full/w.Group)})
effects=d.groupby('dataset').mean()
runs=d.groupby('seed').mean()
samples=np.array(list(itertools.product(range(6),repeat=6)))
signs=np.array(list(itertools.product([-1,1],repeat=6)))
rows=[]
for contrast in effects:
    v=effects[contrast].to_numpy()
    boot=v[samples].mean(axis=1)
    low,high=np.quantile(boot,[.025,.975],method='linear')
    p=np.mean(abs((signs*v).mean(axis=1))>=abs(v.mean())-1e-12)
    loo=[np.delete(v,i).mean() for i in range(6)]
    rows.append(dict(contrast=contrast,mean=v.mean(),lower=low,upper=high,raw_p=p,leave_one_out_min=min(loo),leave_one_out_max=max(loo)))
order=sorted(range(2),key=lambda i:rows[i]['raw_p'])
maximum=0.
for j,i in enumerate(order):
    maximum=max(maximum,(2-j)*rows[i]['raw_p'])
    rows[i]['holm_p']=min(1.,maximum)
effects.to_csv(H/'table8_dataset_effects.csv')
runs.to_csv(H/'table8_run_effects.csv')
pd.DataFrame(rows).to_csv(H/'table8_uncertainty.csv',index=False)
print(effects.to_string());print(pd.DataFrame(rows).to_string(index=False));print(runs.to_string())
