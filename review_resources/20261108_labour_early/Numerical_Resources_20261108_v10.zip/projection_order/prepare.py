from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

H=Path(__file__).resolve().parent
O=H.parent
sys.path.insert(0,str(O/'cpor_envelope_comparison_20261024'))
import run_comparison as c
sys.path.insert(0,str(O/'c0_seed_validation_20261016'))
import common
old=common.old
keys=['dataset','backbone','window','seed']

def recover_bank(r,x,ctx):
    sources={}
    if 'bank' in ctx:
        return ctx['bank'],sources
    if r.dataset!='M5':
        p=O/'rr_recap_error_dependence_20261003/results'/r.dataset/r.backbone/r.window/str(r.seed)/'bank.npz'
        sources[str(p)]=c.sha(p)
        return c.load(p)['bank'],sources
    p=O/'c0_frozen_m5_20261014/observed.csv'
    wide=pd.read_csv(p,parse_dates=['ds']).set_index('ds')
    y=wide.to_numpy()
    starts=np.flatnonzero(np.all(y==x['truth'][0],axis=1))
    matches=[i for i in starts if np.array_equal(y[i:i+108],x['truth'])]
    assert len(matches)==1
    bank=common.fresh.expert_bank(wide,x['raw'],x['v'],matches[0])
    sources[str(p)]=c.sha(p)
    return bank,sources

def prepare(r):
    rel=Path(r.dataset)/r.backbone/r.window/str(r.seed)
    d=H/'targets'/rel;d.mkdir(parents=True,exist_ok=True)
    if (d/'receipt.json').exists():return
    src=Path(r.source)
    sources={str(src/n):c.sha(src/n) for n in ['endpoints.npz','contexts.npz','controls.npz','CovFullFix.npz']}
    x=c.load(src/'endpoints.npz');ctx=c.load(src/'contexts.npz');ctrl=c.load(src/'controls.npz')
    bank,extra=recover_bank(r,x,ctx);sources.update(extra)
    if 'mixed' in ctx:
        cov=ctx['mixed'][36:]
    elif r.dataset!='M5':
        p=O/'rr_recap_error_dependence_20261003/results'/r.dataset/r.backbone/r.window/str(r.seed)/'CovFull.npz'
        sources[str(p)]=c.sha(p)
        saved=c.load(p)
        cov=saved['raw_target'] if 'raw_target' in saved else np.sum(bank[36:]*saved['weights'],axis=2)
    else:
        mix=[]
        for t in range(36,108):
            w=common.fresh.weights(old.cov.moment(bank[:t],x['truth'][:t],x['v'],t),old.cov)
            mix.append((bank[t]*w).sum(axis=1))
        cov=np.asarray(mix)
    # Replay the archived ML-Pol update on the frozen expert/label history.
    n,J=bank.shape[1:]
    w=np.full((n,J),1/J);regrets=np.zeros_like(w);squares=np.zeros_like(w);ml=[]
    scaled=bank/np.sqrt(x['v'])[None,:,None];labels=x['truth']/np.sqrt(x['v'])[None,:]
    for t in range(108):
        p=(scaled[t]*w).sum(axis=1);ml.append(p*np.sqrt(x['v']))
        gain=2*(p-labels[t])[:,None]*(p[:,None]-scaled[t])
        regrets+=gain;squares+=gain*gain
        q=np.maximum(regrets,0)/(1+squares);total=q.sum(axis=1,keepdims=True)
        w=np.divide(q,total,out=np.full_like(q,1/J),where=total>0)
    ml=np.asarray(ml)[36:]
    stored={'Cov':ctx['D'][36:],'ML':ctrl['MLPol']}
    metrics={}
    for name,raw in [('Cov',cov),('ML',ml)]:
        projected,u=old.project(x['S'],raw,x['v'])
        np.testing.assert_allclose(projected,stored[name],rtol=1e-8,atol=2e-6,err_msg=str((rel,name)))
        metrics[name]=dict(target_max_abs_difference=float(abs(projected-stored[name]).max()),raw_coherence_change=float(abs(projected-raw).max()),negative_raw=int((raw<0).sum()),zero_reconciled=int((projected==0).sum()))
    np.savez_compressed(d/'targets.npz',CovRaw=cov,MLRaw=ml,CovCoherent=stored['Cov'],MLCoherent=stored['ML'])
    receipt=dict(**{k:getattr(r,k) for k in keys},sources=sources,targets=c.sha(d/'targets.npz'),checks=metrics)
    c.js(d/'receipt.json',receipt)
    print('READY',str(rel),metrics,flush=True)

if __name__=='__main__':
    df=pd.read_csv(c.INDEX)
    with threadpool_limits(1):
        for r in df.itertuples():prepare(r)
