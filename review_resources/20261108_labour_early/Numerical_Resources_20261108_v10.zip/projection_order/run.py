from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import sys,json,warnings
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
H=Path(__file__).resolve().parent
O=H.parent
sys.path.insert(0,str(O/'cpor_envelope_comparison_20261024'))
import run_comparison as c
key=['dataset','backbone','window','seed']
mapping=pd.read_csv(O/'kais_review_v2_revision_20261017/Online_Resource_3/review_evidence/node_map.csv')

def run(r):
    with threadpool_limits(1):
        warnings.filterwarnings('ignore',message='Solution may be inaccurate')
        rel=Path(r['dataset'])/r['backbone']/r['window']/str(r['seed'])
        src=Path(r['source']);d=H/'runs'/rel;d.mkdir(parents=True,exist_ok=True)
        if (d/'DONE.json').exists():return str(rel)
        receipts=json.loads((H/'targets'/rel/'receipt.json').read_text())
        for path,hash_ in receipts['sources'].items():assert c.sha(path)==hash_
        targets=H/'targets'/rel/'targets.npz'
        assert c.sha(targets)==receipts['targets']
        a=c.load(targets);x=c.load(src/'endpoints.npz');ctrl=c.load(src/'controls.npz');cov=c.load(src/'CovFullFix.npz')
        scores=[];audits=[];arrays={};replay=[]
        nodes=mapping.query("dataset==@r['dataset']") if False else mapping.loc[mapping.dataset==r['dataset']].sort_values('node')
        np.testing.assert_array_equal(nodes.node,np.arange(len(x['v'])))
        for impl in ['Cov','ML']:
            baseline=cov['pred'] if impl=='Cov' else ctrl['ProtectedMLPol']
            result={}
            for arm,kind in [('TwoStage','Coherent'),('Direct','Raw')]:
                out=c.run(x,a[impl+kind],impl,r['dataset'],'nonnegative')
                result[arm]=out
                _,audit=c.states_and_audit(x,out['pred'],out['witness'],'nonnegative')
                rows=dict(**{k:r[k] for k in key},implementation=impl,arm=arm,ever=0,events=0,nodes=len(x['v']),**audit)
                audits.append(rows)
                err=np.sqrt(((out['pred']-x['truth'][36:108])**2).mean(axis=0))
                for scope in sorted(set(';'.join(nodes.scopes).split(';'))):
                    ix=nodes.loc[nodes.scopes.str.split(';').map(lambda z:scope in z),'node'].to_numpy(int)
                    scores.append(dict(**{k:r[k] for k in key},implementation=impl,arm=arm,scope=scope,rmse=float(err[ix].mean())))
                arrays[impl+arm]=out['pred'];arrays[impl+arm+'Witness']=out['witness']
            p=result['TwoStage']['pred']
            np.testing.assert_allclose(p,baseline,rtol=1e-8,atol=2e-6)
            metric=lambda z:float(np.sqrt(((z-x['truth'][36:])**2).mean(axis=0)).mean())
            assert abs(metric(p)-metric(baseline))<1e-8*max(1,metric(baseline))
            replay.append(dict(implementation=impl,replay_max=float(abs(p-baseline).max()),replay_bitwise=bool(np.array_equal(p,baseline))))
        np.savez_compressed(d/'releases.npz',**arrays)
        pd.DataFrame(scores).to_csv(d/'rmse.csv',index=False)
        pd.DataFrame(audits).to_csv(d/'audit.csv',index=False)
        c.js(d/'DONE.json',dict(inputs=receipts,release_sha256=c.sha(d/'releases.npz'),replay=replay))
        return str(rel)

if __name__=='__main__':
    index=pd.read_csv(c.INDEX)
    # Preparation receipt for all targets is required before either policy is scored.
    assert len(list((H/'targets').rglob('receipt.json')))==66
    with ProcessPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(run,r) for r in index.to_dict('records')]
        for n,f in enumerate(as_completed(futures),1):
            print(n,len(futures),f.result(),flush=True)
