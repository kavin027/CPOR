from pathlib import Path
import json
import numpy as np
import pandas as pd

H=Path(__file__).resolve().parent
keys=['dataset','backbone','window','seed']
receipts=list((H/'runs').rglob('DONE.json'))
assert len(receipts)==66
cells=pd.concat([pd.read_csv(p.parent/'rmse.csv') for p in receipts],ignore_index=True)
audit=pd.concat([pd.read_csv(p.parent/'audit.csv') for p in receipts],ignore_index=True)
cells.to_csv(H/'cell_rmse.csv',index=False);audit.to_csv(H/'cell_audit.csv',index=False)
w=cells.pivot(index=keys+['implementation','scope'],columns='arm',values='rmse')
group=w.groupby(['dataset','backbone','seed','implementation','scope']).mean()
group['direct_gain_pct']=100*(1-group.Direct/group.TwoStage)
group.reset_index().to_csv(H/'paired_rmse.csv',index=False)
dataset=group.groupby(['dataset','implementation','scope']).mean()
dataset.to_csv(H/'dataset_rmse.csv')
print('Six datasets, paired direct improvement vs two-stage (%); positive favors direct:')
print(dataset.xs('all',level='scope').round(8).to_string())
print('Average',dataset.xs('all',level='scope').groupby('implementation').mean().to_string())
print('Each backbone',group.xs('all',level='scope').groupby(['backbone','implementation']).direct_gain_pct.mean().to_string())
print('Signs and equivalence:')
for impl in ['Cov','ML']:
    a=w.xs((impl,'all'),level=['implementation','scope'])
    gains=100*(1-a.Direct/a.TwoStage)
    print(impl,'direct better',int((gains>1e-8).sum()),'direct worse',int((gains < -1e-8).sum()),'within 1e-8 percentage point',int((abs(gains)<=1e-8).sum()),'max gain',gains.max(),'max regression',gains.min())
    print(gains.sort_values().head(4).to_string())
print('Audit',audit.groupby(['implementation','arm'])[['nodes','exact_node_checks','ever','events']].sum().to_string())
replay=[dict(**json.loads(p.read_text())['inputs'],**r) for p in receipts for r in json.loads(p.read_text())['replay']]
pd.DataFrame([{k:r[k] for k in keys+['implementation','replay_max','replay_bitwise']} for r in replay]).to_csv(H/'baseline_replay.csv',index=False)
print('Replay bitwise',sum(r['replay_bitwise'] for r in replay),'of',len(replay),'max diff',max(r['replay_max'] for r in replay))
print('Full scope-level contrasts:')
print(dataset.groupby(['implementation','scope']).direct_gain_pct.mean().round(8).to_string())
