"""Portable result-level checker: Python+NumPy+pandas, no project imports."""
from pathlib import Path
from fractions import Fraction as F
import numpy as np,pandas as pd,json,hashlib
H=Path(__file__).resolve().parent;R=F(40401,40000);K=R-1
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def audit(x,p,u,domain):
    assert np.isfinite(p).all() and np.isfinite(u).all() and p.min()>=0 and u.min()>=0
    assert np.allclose(p,u@x['S'].T,rtol=1e-8,atol=2e-6)
    A=[F(0)]*57
    for t in range(72):
     for i in range(57):
        b,z,y=[F.from_float(float(a)) for a in [x['b'][t+36,i],p[t,i],x['truth'][t+36,i]]]
        assert (z*z-R*b*b if domain=='nonnegative' and z>R*b else R*(z-b)**2/K)<=A[i]
        A[i]+=R*(b-y)**2-(z-y)**2;assert A[i]>=0
    return p.size
def main():
    hashes=json.loads((H/'RESULT_HASHES.json').read_text(encoding='utf8'));assert len(hashes)==246
    frame=pd.read_csv(H/'RUN_SCOPE_RMSE.csv');tot=trajectories=0;sample=None
    reg=json.loads((H/'REGISTRATION.json').read_text(encoding='utf8'));data=H/'inputs/Labour.csv'
    original_hash=next(h for p,h in reg['inputs'].items() if p.endswith('Labour.csv'));assert sha(data)==original_hash
    wide=pd.read_csv(data,parse_dates=['ds']).set_index('ds')
    for rel,digest in hashes.items():
        path=H/rel;assert sha(path)==digest,rel;meta=json.loads(path.with_suffix('.json').read_text(encoding='utf8'));assert meta['sha256']==digest
        x=load(path.parent.parent/'context.npz');z=load(path);np.testing.assert_array_equal(x['truth'],wide.iloc[334:442].to_numpy())
        p=z['pred'];assert p.shape==(72,57);err=np.sqrt(((p-x['truth'][36:])**2).mean(0))
        scope={'Overall':err.mean(),'Regions':err[1:9].mean(),'System':err[0],'SexRegion':err[9:25].mean(),'Bottom':err[25:].mean()}
        bb,seed=path.parents[2].name,int(path.parents[1].name)
        for key,value in scope.items():
            row=frame[(frame.backbone==bb)&(frame.run==seed)&(frame.method==path.stem)&(frame.scope==key)]
            assert len(row)==1 and np.isclose(row.rmse.iloc[0],value,rtol=1e-13,atol=1e-12)
        if meta['protected']:
            tot+=audit(x,p,z['witness'],meta['domain']);trajectories+=1
            if sample is None:sample=(x,z,meta['domain'])
    assert trajectories==138 and tot==566352
    x,z,domain=sample;p=z['pred'].copy();p[0,0]+=10
    try:audit(x,p,z['witness'],domain)
    except AssertionError:pass
    else:raise AssertionError('Corruption not detected')
    rec=dict(passed=True,results=246,protected_trajectories=trajectories,exact_envelope_checks=tot,exact_prefix_checks=tot,metrics_recomputed=True,corruption_self_test=True,scope='Stored-prediction and metric verification; does not retrain neural models or resolve original source-code dependencies.')
    (H/'BUNDLE_CHECK.json').write_text(json.dumps(rec,indent=2),encoding='utf8');print(json.dumps(rec,indent=2))
if __name__=='__main__':main()
