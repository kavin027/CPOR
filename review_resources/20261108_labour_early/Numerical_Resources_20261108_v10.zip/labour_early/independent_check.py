"""Prediction-based exact auditing and boundary verification; no training imports."""
from pathlib import Path
from fractions import Fraction as F
import numpy as np,pandas as pd,json,hashlib
H=Path(__file__).resolve().parent;R=F(40401,40000);K=R-1
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(x,z,domain):
    y=x['truth'][36:];p,u=z['pred'],z['witness'];assert p.shape==y.shape==(72,57)
    assert p.min()>=0 and u.min()>=0 and np.isfinite(p).all() and np.isfinite(u).all()
    assert np.allclose(p,u@x['S'].T,rtol=1e-8,atol=2e-6)
    E=[F(0)]*57;B=[F(0)]*57;A=[F(0)]*57
    for t in range(72):
      for i in range(57):
        b,pv,yv=map(lambda a:F.from_float(float(a)),[x['b'][t+36,i],p[t,i],y[t,i]])
        g=pv*pv-R*b*b if domain=='nonnegative' and pv>R*b else R*(pv-b)**2/K
        assert g<=A[i],('envelope',t,i)
        E[i]+=(pv-yv)**2;B[i]+=(b-yv)**2;A[i]=R*B[i]-E[i]
        assert A[i]>=0,('prefix',t,i)
    return p.size
def main():
    reg=json.loads((H/'REGISTRATION.json').read_text(encoding='utf8'));checks=trajectories=total=0;fitcount=reused=0;boundaries=[]
    for path,digest in reg['inputs'].items():assert sha(path)==digest,path
    wide=pd.read_csv(next(p for p in reg['inputs'] if p.endswith('Labour.csv')),parse_dates=['ds']).set_index('ds')
    for bb in ['PatchTST','DLinear']:
     for seed in [42,1,2]:
      d=H/'runs'/bb/str(seed);raw=load(d/'raw.npz');full=load(d/'full_stream.npz');x=load(d/'context.npz')
      np.testing.assert_array_equal(raw['truth'],wide.iloc[334:442].to_numpy());np.testing.assert_array_equal(full['raw'][216:],raw['raw'])
      np.testing.assert_array_equal(x['raw'],raw['raw']);np.testing.assert_array_equal(x['truth'],raw['truth'])
      np.testing.assert_array_equal(raw['S'],x['S']);np.testing.assert_array_equal(raw['truth'][-72:],wide.loc['2008-12-01':'2014-11-01'].to_numpy())
      parts=[]
      for ix,count in [(118,72),(190,72),(262,72),(334,12),(346,12),(358,12),(370,72)]:
        fd=d/'fits'/f'{ix:04d}';m=json.loads((fd/'run.json').read_text(encoding='utf8'));assert sha(fd/'predictions.csv')==m['predictions_sha256']
        meta=m.get('source_run',m);assert meta['seed']==seed and pd.Timestamp(meta['prediction_start'])==wide.index[ix]
        assert pd.Timestamp(meta['gradient_train_end'])==wide.index[ix-37] and pd.Timestamp(meta['validation_end'])==wide.index[ix-1]
        f=pd.read_csv(fd/'predictions.csv',parse_dates=['ds','origin']);assert (f.origin<f.ds).all()
        expected_origins=[wide.index[ix+off-1] for off in range(0,count,12)];assert list(f.origin.drop_duplicates())==expected_origins
        a=f.pivot(index='ds',columns='unique_id',values=bb).reindex(index=wide.index[ix:ix+count],columns=wide.columns).to_numpy();parts.append(a)
        if m['new_fit']:
            curve=pd.read_csv(fd/'validation_curve.csv');assert curve.step.iloc[-1]==m['last_step']
            assert int(curve.iloc[curve.validation_mae.argmin()].step)==m['best_step'];assert sha(fd/'best.ckpt')==m['checkpoint_sha256'];fitcount+=1
        else:
            reused+=1;src=Path(m['reused_from']);sf=pd.read_csv(src/'predictions.csv',parse_dates=['ds'])
            sa=sf.pivot(index='ds',columns='unique_id',values=bb).reindex(index=wide.index[ix:ix+count],columns=wide.columns).to_numpy();np.testing.assert_array_equal(a,sa)
        boundaries.append(dict(backbone=bb,seed=seed,ix=ix,count=count,new_fit=m['new_fit'],best_step=meta.get('best_step'),last_step=meta.get('last_step'),best_validation=meta.get('best_val'),reused_from=m.get('reused_from'),gradient_train_end=meta['gradient_train_end'],validation_end=meta['validation_end']))
      np.testing.assert_array_equal(np.concatenate(parts),full['raw'])
      for method in reg['methods']:
        path=d/'results'/(method+'.npz');receipt=json.loads(path.with_suffix('.json').read_text(encoding='utf8'));assert sha(path)==receipt['sha256'];total+=1
        z=load(path)
        if receipt['protected']:checks+=check(x,z,receipt['domain']);trajectories+=1
    path=H/'runs/PatchTST/42/results/CPOR-Cov.npz';z=load(path);x=load(path.parent.parent/'context.npz');z['pred']=z['pred'].copy();z['pred'][0,0]+=10
    try:check(x,z,'nonnegative')
    except AssertionError:pass
    else:raise AssertionError('Corruption not detected')
    pd.DataFrame(boundaries).to_csv(H/'FIT_BOUNDARIES.csv',index=False)
    rec=dict(passed=True,result_trajectories=total,protected_trajectories=trajectories,exact_envelope_checks=checks,exact_prefix_checks=checks,new_fits=fitcount,reused_fits=reused,corruption_self_test=True,source_reuse_bitwise=True,frozen_archives_unchanged=True)
    (H/'INDEPENDENT_CHECK.json').write_text(json.dumps(rec,indent=2),encoding='utf8');print(json.dumps(rec,indent=2))
if __name__=='__main__':main()
