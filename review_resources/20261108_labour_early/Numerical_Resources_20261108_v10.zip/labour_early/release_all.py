from labour_early_common import *
import time
import labour_compare as cc
import labour_external as ext
import labour_recent as recent
from threadpoolctl import threadpool_limits
if __name__=='__main__':
    with threadpool_limits(1):
      for bb in ['PatchTST','DLinear']:
       for seed in [42,1,2]:
        while not all((folder(bb,seed)/'external'/(name+'.json')).exists() for name in ['PIR','Ada-Y','ProCAST']):time.sleep(5)
        ext.release(bb,seed)
      for bb in ['PatchTST','DLinear']:
       for seed in [42,1,2]:
        while not all((folder(bb,seed)/'recent'/(name+'.json')).exists() for name in ['LiDiag','LiFactor','Biswas']):time.sleep(5)
        recent.release(bb,seed)
    js(H/'ALL_RELEASES_DONE.json',dict(complete=True))
