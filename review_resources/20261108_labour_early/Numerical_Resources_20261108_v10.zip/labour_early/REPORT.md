# Labour早窗三次实验报告

评分期：2008年12月—2014年11月，72个月。完整保留57节点，包括系统总量、8地区、16性别×地区和32底层序列。两种骨干各三次初始化，41种规则，共246条发布轨迹。原冻结稿和投稿包未修改。

## 1. 固定协议与复用

三段独立12个月校准预测及一段72个月评分预测；外部适配器沿用216个月历史支持。共42个必要拟合阶段，复用18个、训练24个。PatchTST上限500，DLinear上限10000，均按原验证MAE及早停规则选模。每条轨迹评分前余额清零一次，随后用实际发布误差独立更新，不在窗口内清零。参考、0.5%容差、日期和反馈顺序相同。

这是已开发数据集上补齐遗漏窗口的回顾性扩展；三次初始化共享同一观测期，不是六个独立数据集。外部适配器每条基础预测流固定一次初始化，不声称复现原论文的协议或性能。

## 2. 绝对RMSE

三次实验均值±样本标准差，保持数据原单位。Overall等权平均57个节点RMSE，Regions等权平均8个地区RMSE，System是总量节点RMSE。

| backbone | method | Overall | Regions | System |
|---|---|---|---|---|
| DLinear | Raw | 16.312 ± 0.836 | 24.284 ± 1.433 | 157.220 ± 12.333 |
| DLinear | NNLS | 16.286 ± 0.821 | 24.250 ± 1.412 | 157.417 ± 12.462 |
| DLinear | ProCAST | 21.680 ± 1.031 | 29.212 ± 2.901 | 134.940 ± 10.075 |
| DLinear | PIR | 18.677 ± 0.789 | 29.815 ± 1.412 | 217.218 ± 11.243 |
| DLinear | Ada-Y | 20.307 ± 0.591 | 40.726 ± 1.662 | 146.598 ± 11.625 |
| DLinear | Biswas | 16.046 ± 0.780 | 23.769 ± 1.352 | 153.715 ± 11.704 |
| DLinear | LiDiag | 16.284 ± 0.844 | 24.290 ± 1.484 | 157.542 ± 13.968 |
| DLinear | LiFactor | 16.278 ± 0.847 | 24.282 ± 1.509 | 157.527 ± 14.525 |
| DLinear | CovTarget | 9.045 ± 0.222 | 12.574 ± 0.474 | 78.339 ± 5.462 |
| DLinear | CPOR-Cov | 14.194 ± 0.599 | 20.862 ± 1.054 | 130.800 ± 9.765 |
| DLinear | MLTarget | 8.986 ± 0.184 | 12.471 ± 0.377 | 78.395 ± 4.542 |
| DLinear | CPOR-ML | 14.190 ± 0.596 | 20.840 ± 1.044 | 130.724 ± 9.596 |
| DLinear | ProtectedCalBest | 14.329 ± 0.638 | 21.039 ± 1.198 | 132.016 ± 11.621 |
| DLinear | PIRFull | 16.092 ± 0.802 | 24.064 ± 1.415 | 158.187 ± 12.532 |
| DLinear | ProtectedMinTshrink | 16.296 ± 0.822 | 24.273 ± 1.419 | 157.952 ± 12.771 |
| DLinear | ProtectedMinT_Cov | 14.170 ± 0.621 | 20.805 ± 1.101 | 130.184 ± 10.231 |
| PatchTST | Raw | 11.656 ± 0.085 | 15.138 ± 0.177 | 80.128 ± 2.462 |
| PatchTST | NNLS | 11.612 ± 0.096 | 15.187 ± 0.186 | 79.350 ± 2.226 |
| PatchTST | ProCAST | 19.086 ± 0.457 | 22.166 ± 1.053 | 77.164 ± 2.598 |
| PatchTST | PIR | 13.630 ± 0.242 | 18.849 ± 0.336 | 111.823 ± 1.127 |
| PatchTST | Ada-Y | 18.149 ± 0.025 | 33.750 ± 0.229 | 118.710 ± 3.054 |
| PatchTST | Biswas | 11.714 ± 0.082 | 15.204 ± 0.176 | 80.631 ± 2.422 |
| PatchTST | LiDiag | 11.807 ± 0.125 | 15.516 ± 0.199 | 82.079 ± 2.088 |
| PatchTST | LiFactor | 12.246 ± 0.133 | 16.186 ± 0.240 | 88.676 ± 2.998 |
| PatchTST | CovTarget | 8.099 ± 0.082 | 10.781 ± 0.135 | 58.816 ± 1.732 |
| PatchTST | CPOR-Cov | 10.766 ± 0.092 | 14.102 ± 0.182 | 75.216 ± 2.469 |
| PatchTST | MLTarget | 7.988 ± 0.085 | 10.619 ± 0.139 | 59.483 ± 1.830 |
| PatchTST | CPOR-ML | 10.751 ± 0.090 | 14.092 ± 0.183 | 75.555 ± 2.439 |
| PatchTST | ProtectedCalBest | 10.856 ± 0.091 | 14.174 ± 0.177 | 75.037 ± 2.217 |
| PatchTST | PIRFull | 11.543 ± 0.090 | 15.103 ± 0.160 | 78.938 ± 1.854 |
| PatchTST | ProtectedMinTshrink | 11.551 ± 0.078 | 15.078 ± 0.138 | 79.009 ± 1.694 |
| PatchTST | ProtectedMinT_Cov | 10.770 ± 0.098 | 14.106 ± 0.196 | 75.202 ± 2.561 |

## 3. 配对收益与保护代价

下表先在每条预测流计算100×(1−方法RMSE/对照RMSE)，再对两骨干×三次运行等权平均。正值为改善，负值为退化。以未保护目标为分母的负值，其绝对值即保护代价。方法间完整流程比较不能全部归因于保护算子；同候选Common/Full及相同数值路径的Nonnegative/AllReal比较更直接检验发布约束的影响，各臂仍有自己的历史余额。

| method | comparator | Overall | Regions | System |
|---|---|---|---|---|
| CPOR-Cov | Ada-Y | 35.398% | 53.502% | 23.645% |
| CPOR-Cov | Biswas | 9.807% | 9.728% | 10.811% |
| CPOR-Cov | CPOR-ML | -0.085% | -0.090% | 0.199% |
| CPOR-Cov | CovAllReal | 0.020% | -0.096% | -0.111% |
| CPOR-Cov | CovCommon | 6.041% | 6.253% | 6.806% |
| CPOR-Cov | CovTarget | -44.920% | -48.359% | -47.407% |
| CPOR-Cov | LiDiag | 10.808% | 11.591% | 12.632% |
| CPOR-Cov | LiFactor | 12.426% | 13.453% | 16.014% |
| CPOR-Cov | PIR | 22.496% | 27.598% | 36.275% |
| CPOR-Cov | ProCAST | 39.039% | 32.300% | 2.795% |
| CPOR-Cov | ProtectedCalBest | 0.881% | 0.658% | 0.302% |
| CPOR-Cov | ProtectedMinT_Cov | -0.073% | -0.129% | -0.258% |
| CPOR-Cov | Raw | 10.296% | 10.451% | 11.461% |
| CPOR-ML | Ada-Y | 35.450% | 53.545% | 23.527% |
| CPOR-ML | Biswas | 9.884% | 9.808% | 10.622% |
| CPOR-ML | LiDiag | 10.885% | 11.670% | 12.447% |
| CPOR-ML | LiFactor | 12.500% | 13.531% | 15.844% |
| CPOR-ML | MLAllReal | 0.026% | -0.124% | -0.100% |
| CPOR-ML | MLCommon | 6.135% | 6.360% | 6.744% |
| CPOR-ML | MLTarget | -46.238% | -49.888% | -46.835% |
| CPOR-ML | PIR | 22.562% | 27.663% | 36.139% |
| CPOR-ML | ProCAST | 39.088% | 32.361% | 2.600% |
| CPOR-ML | ProtectedCalBest | 0.965% | 0.747% | 0.101% |
| CPOR-ML | ProtectedMinT_Cov | 0.012% | -0.039% | -0.458% |
| CPOR-ML | Raw | 10.373% | 10.531% | 11.270% |
| PIRFull | PIRCoherent | 14.896% | 20.218% | 29.933% |
| PIRFull | PIRCommon | 0.951% | 0.773% | 0.213% |
| PIRFull | PIRTwoGroup | 0.899% | 0.685% | 0.254% |

## 4. 保护核验

| method | protected | ever_violating_nodes | violating_node_dates | envelope_failures | node_date_checks |
|---|---|---|---|---|---|
| CPOR-Cov | True | 0 | 0 | 0 | 24624 |
| CPOR-ML | True | 0 | 0 | 0 | 24624 |
| CovTarget | False | 270 | 1871 | 15470 | 24624 |
| LiDiag | False | 283 | 10356 | 15356 | 24624 |
| LiFactor | False | 313 | 11759 | 16889 | 24624 |
| MLTarget | False | 262 | 1651 | 15212 | 24624 |
| NNLS | True | 0 | 0 | 0 | 24624 |
| PIR | False | 329 | 15270 | 21259 | 24624 |
| PIRCoherent | False | 328 | 15025 | 21140 | 24624 |
| PIRCommon | True | 0 | 0 | 0 | 24624 |
| PIRFull | True | 0 | 0 | 0 | 24624 |
| PIRTwoGroup | True | 0 | 0 | 0 | 24624 |
| Raw | False | 277 | 9152 | 12955 | 24624 |

独立预测级核验：138条保护轨迹，共566,352次节点一步包络及相同数量的累计前缀检查，均通过；聚合一致性按rtol=1e-8、atol=2e-6检查。违规序列计数把同一节点在不同骨干/运行分别计数，不能视为独立样本。未保护目标的包络失败不等于实际前缀违规。

## 5. 各地区及负面结果

| backbone | scope | CPOR-Cov | CPOR-ML | NNLS | PIRFull | ProtectedCalBest |
|---|---|---|---|---|---|---|
| DLinear | ['Australian Capital Territory'] | 4.199 ± 0.092 | 4.208 ± 0.084 | 4.722 ± 0.141 | 4.744 ± 0.141 | 4.215 ± 0.121 |
| DLinear | ['New South Wales'] | 51.096 ± 3.959 | 51.245 ± 3.826 | 60.114 ± 5.008 | 59.831 ± 4.992 | 51.409 ± 4.031 |
| DLinear | ['Northern Territory'] | 3.548 ± 0.096 | 3.548 ± 0.087 | 3.762 ± 0.108 | 3.706 ± 0.083 | 3.609 ± 0.163 |
| DLinear | ['Queensland'] | 34.036 ± 1.179 | 33.548 ± 1.128 | 39.178 ± 1.532 | 38.860 ± 1.475 | 34.536 ± 1.770 |
| DLinear | ['South Australia'] | 16.951 ± 0.890 | 17.006 ± 0.850 | 20.892 ± 1.281 | 20.551 ± 1.322 | 17.110 ± 1.035 |
| DLinear | ['Tasmania'] | 6.647 ± 0.244 | 6.674 ± 0.247 | 8.097 ± 0.324 | 7.750 ± 0.345 | 6.688 ± 0.236 |
| DLinear | ['Victoria'] | 31.714 ± 1.900 | 31.690 ± 1.908 | 36.652 ± 2.441 | 36.833 ± 2.455 | 31.730 ± 2.140 |
| DLinear | ['Western Australia'] | 18.705 ± 0.874 | 18.798 ± 0.963 | 20.581 ± 0.954 | 20.239 ± 0.907 | 19.012 ± 0.979 |
| PatchTST | ['Australian Capital Territory'] | 4.169 ± 0.013 | 4.212 ± 0.018 | 4.558 ± 0.021 | 4.363 ± 0.023 | 4.293 ± 0.019 |
| PatchTST | ['New South Wales'] | 27.469 ± 0.691 | 27.385 ± 0.696 | 29.337 ± 0.724 | 29.173 ± 0.656 | 26.903 ± 0.696 |
| PatchTST | ['Northern Territory'] | 3.660 ± 0.032 | 3.634 ± 0.027 | 3.952 ± 0.034 | 3.972 ± 0.034 | 3.803 ± 0.029 |
| PatchTST | ['Queensland'] | 22.876 ± 0.179 | 22.892 ± 0.172 | 24.710 ± 0.113 | 24.826 ± 0.110 | 23.445 ± 0.167 |
| PatchTST | ['South Australia'] | 8.294 ± 0.068 | 8.312 ± 0.086 | 8.635 ± 0.056 | 8.623 ± 0.061 | 8.363 ± 0.092 |
| PatchTST | ['Tasmania'] | 5.274 ± 0.137 | 5.287 ± 0.138 | 5.954 ± 0.172 | 5.846 ± 0.169 | 5.399 ± 0.143 |
| PatchTST | ['Victoria'] | 18.387 ± 0.564 | 18.427 ± 0.559 | 18.762 ± 0.599 | 18.533 ± 0.418 | 18.332 ± 0.532 |
| PatchTST | ['Western Australia'] | 22.689 ± 0.117 | 22.583 ± 0.131 | 25.587 ± 0.217 | 25.487 ± 0.207 | 22.851 ± 0.226 |

相对指定受保护对照的较大退化如下。逐节点、逐运行完整正负结果均在NODE_PAIRED_GAINS.csv；不能把零违规解释为地区精度普遍领先。

| backbone | run | method | comparator | scope | gain_pct |
|---|---|---|---|---|---|
| PatchTST | 1 | CPOR-Cov | ProtectedCalBest | ['New South Wales'] | -2.299% |
| PatchTST | 42 | CPOR-Cov | ProtectedCalBest | ['New South Wales'] | -2.107% |
| PatchTST | 1 | CPOR-ML | ProtectedCalBest | ['New South Wales'] | -1.915% |
| PatchTST | 2 | CPOR-Cov | ProtectedCalBest | ['New South Wales'] | -1.911% |
| PatchTST | 42 | CPOR-ML | ProtectedCalBest | ['New South Wales'] | -1.794% |
| PatchTST | 2 | CPOR-ML | ProtectedCalBest | ['New South Wales'] | -1.673% |
| DLinear | 1 | CPOR-ML | MLAllReal | ['Western Australia'] | -1.587% |
| DLinear | 1 | CPOR-Cov | CovAllReal | ['Western Australia'] | -1.481% |
| DLinear | 1 | CPOR-ML | ProtectedCalBest | ['New South Wales'] | -1.454% |
| PatchTST | 2 | CPOR-ML | MLAllReal | ['South Australia'] | -1.348% |
| DLinear | 1 | CPOR-ML | ProtectedMinT_Cov | ['Tasmania'] | -1.305% |
| DLinear | 1 | CPOR-ML | ProtectedCalBest | ['Australian Capital Territory'] | -1.302% |
| DLinear | 42 | CPOR-ML | ProtectedMinT_Cov | ['New South Wales'] | -1.282% |
| DLinear | 42 | CPOR-ML | ProtectedMinT_Cov | System | -1.045% |
| DLinear | 42 | CPOR-Cov | ProtectedMinT_Cov | ['Queensland'] | -1.021% |
| DLinear | 1 | CPOR-ML | ProtectedMinT_Cov | ['New South Wales'] | -0.985% |
| PatchTST | 2 | CPOR-Cov | CovAllReal | ['South Australia'] | -0.977% |
| PatchTST | 2 | CPOR-ML | MLAllReal | ['Western Australia'] | -0.936% |
| DLinear | 42 | CPOR-Cov | ProtectedMinT_Cov | System | -0.932% |
| DLinear | 42 | CPOR-ML | ProtectedMinT_Cov | ['South Australia'] | -0.913% |

## 6. 文件入口

REGISTRATION.json为评分前固定的协议。FIT_BOUNDARIES.csv记录训练/验证边界、复用和停止步数；RUN_SCOPE_RMSE.csv及NODE_RMSE.csv给出未舍入结果；THREE_RUN_RMSE.csv给出均值/SD；PAIRED_GAINS.csv、BACKBONE_PAIRED_SUMMARY.csv给出配对差异；PROTECTION_CHECKS.csv和INDEPENDENT_CHECK.json给出保护核验；PUBLICATION_TIMING.csv保留发布耗时。核验入口：在项目根目录运行`./RUN_RESEARCH.ps1 output/cpor_labour_early_three_runs_20261107/independent_check.py`。


## 7. 结果判断

1. 两种实现相对同流NNLS参考均有整体、地区平均和系统误差改善，且本轮所有57节点×6条流的最终RMSE均低于参考。这是本窗口的观测结果；理论保证仍是累计误差不超过参考的1.005倍，并不保证普遍逐节点更准确。
2. 同一Cov/ML目标下，完整发布相对统一收缩的整体改善为6.041%/6.135%，支持本窗口上更灵活保护发布的经验价值。换成外部PIR候选后，完整投影对统一/两组收缩改善0.951%/0.899%，均在6条流中为正；系统层仅3/6条流更好。
3. 非负精确包络相对全实数保守包络仅改善0.020%/0.026%，各仅3/6条流为正；DLinear整体略退化，不能主张该数据窗口证实非负几何有稳定精度优势。
4. 相对各自未保护目标，Cov/ML的平均保护代价为44.920%/46.238%。未保护目标分别有270/342、262/342条节点序列至少一次越限；与之对应的保护实现均零越限。保护是有明显精度代价的约束，而非对未保护候选的普遍增益。
5. 相对完整外部流程的改善较大，但候选构造也不同，不能全归因于保护。相对同Cov输入的受保护MinT，Cov平均退化0.073%、ML改善0.012%，基本持平。相对受保护固定专家，整体改善0.881%/0.965%；PatchTST系统层反而分别退化0.232%/0.685%，保留这一反例。
6. Cov与ML精度接近；两种实现相对NNLS的早窗收益均成立。本轮只补齐早窗，尚未改写原文六基准汇总；若之后更新论文，应保留原注册网格，并单独标识这次回顾性扩展。

## 8. 数值核验与复算范围

完整原实现重放确认Cov和ML发布值逐值一致；未来标签扰动不会改变此前候选；24个新拟合阶段的实际超参数和最佳检查点均通过核对。24个新阶段均在上限前早停，最晚停止步数为PatchTST438、DLinear1308。完整42阶段中18阶段复用，预测逐值核验通过。

CPOR两实现共864次评分发布没有共同收缩修补或额外求解尝试，存储舍入修补仍有发生；具体计数和幅度见CPOR_NUMERICAL_EVENTS.csv。不能把零越限解释成没有数值修补。

PUBLICATION_TIMING.csv仅保留本轮运行记录，含每条保护循环均摊时间及可取得的动作内计时。Cov未另测动作内P95；目标生成不在该计时内。它不是新的跨方法正式效率基准。

压缩包含已有预测、逐方法发布结果、上下文、数值检查脚本和汇总；选定神经模型检查点仍保存在本地runs目录，未放入精简数值包。解压后可直接运行`python check_bundle.py`复算指标及精确保护检查；该命令不重训模型。
