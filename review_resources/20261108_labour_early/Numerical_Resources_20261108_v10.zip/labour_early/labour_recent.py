from labour_early_common import *
import time,subprocess,os,copy
sys.path.insert(0,str(O/'cpor_li_preprint_20261106'));import paired as li
sys.path.insert(0,str(O/'cpor_li_factor_20261106'));from block_solve import make_mapper
def li_targets(bb,seed):
    verify();d=folder(bb,seed)/'recent';d.mkdir(exist_ok=True);x=load(folder(bb,seed)/'context.npz');raw,y,S=x['raw'],x['truth'],x['S'];v,tr=li.geometry(S)
    if all((d/(k+'.json')).exists() for k in ['LiDiag','LiFactor']):return
    resfile=d/'residuals.csv';np.savetxt(resfile,y[:-1]-raw[:-1],delimiter=',',fmt='%.17g')
    covfile=d/'factor.bin';splitfile=d/'splits.csv'
    if not covfile.exists():
        r=O/'cpor_li_preprint_20261106/runtime/R/app/bin/x64/Rscript.exe'
        subprocess.run([str(r),'--vanilla',str(O/'cpor_aemo_full_three_runs_20261107/li_covariances.R'),str(O/'cpor_li_factor_20261106/preprint_covEstimation.R'),str(resfile),str(splitfile),str(covfile)],cwd=str(d),env=dict(os.environ,R_USER=str(d)),check=True)
    assert covfile.stat().st_size==72*2*57*57*8
    splits=pd.read_csv(splitfile,header=None);splits={int(row.iloc[0]):row.iloc[1:].dropna().to_numpy(int)-1 for _,row in splits.iterrows()}
    for _,row in pd.read_csv(li.HERE/'splits.csv',header=None).iterrows():np.testing.assert_array_equal(splits[int(row.iloc[0])],row.iloc[1:].dropna().to_numpy(int)-1)
    for name in ['LiDiag','LiFactor']:
        if (d/(name+'.json')).exists():continue
        diagnostics=[];f=covfile.open('rb')
        def sigma(res):return np.fromfile(f,dtype='<f8',count=57*57).reshape(57,57)
        mapping=li.mappings if name=='LiDiag' else make_mapper(sigma,diagnostics)
        pred=[];selected=[];tick=time.perf_counter()
        for t in range(36,108):
            train,val=np.split(splits[t],[int(.8*t)]);res=y[:t]-raw[:t]
            w=mapping(res[train],S,v,tr,li.GRID);vr=li.bottom(raw[val],v,w)@S.T;scores=np.sqrt(((vr-y[val])**2).mean(axis=1)).mean(axis=1)
            lam=li.GRID[scores.argmin()];w=mapping(res,S,v,tr,np.array([lam]));p=(li.bottom(raw[t:t+1],v,w)@S.T)[0,0]
            assert np.isfinite(p).all();pred.append(p);selected.append(lam)
        if name=='LiFactor':assert not f.read(1)
        f.close();p=d/(name+'.npz');np.savez_compressed(p,pred=pred,lambda_values=selected)
        js(p.with_suffix('.json'),dict(sha256=sha(p),seconds=time.perf_counter()-tick,lambda_cap_hits=int((np.array(selected)==1e5).sum()),numerical=diagnostics,preprint=True));print('LI_DONE',bb,seed,name,flush=True)
def biswas(bb,seed):
    verify();d=folder(bb,seed)/'recent';d.mkdir(exist_ok=True);p=d/'Biswas.npz'
    if p.with_suffix('.json').exists():assert sha(p)==json.loads(p.with_suffix('.json').read_text(encoding='utf8'))['sha256'];return
    import torch
    from types import SimpleNamespace
    sys.path[:0]=[str(O/'cpor_named_venue_screen_20261105/KDDResidual'),str(O/'cpor_external_20261105/deps')]
    from model.iTransformer import Model
    from utils.timefeatures import time_features
    base=load(folder(bb,seed)/'full_stream.npz');dates=pd.DatetimeIndex(base['dates']);raw,y=base['raw'],base['truth'];history=raw[108:252]-y[108:252];n=144;cut=120;L=24;h=12
    torch.set_num_threads(1);torch.manual_seed(42);mu=history[:cut].mean(0);sd=history[:cut].std(0);sd[sd==0]=1
    dt=time_features(dates,freq='m').T;tensor=lambda a:torch.as_tensor(a,dtype=torch.float32,device='cuda')
    cfg=SimpleNamespace(seq_len=L,pred_len=h,output_attention=False,use_norm=True,d_model=256,embed='timeF',freq='m',dropout=.1,class_strategy='projection',factor=1,n_heads=8,e_layers=2,d_ff=256,activation='gelu')
    tick=time.perf_counter();m=Model(cfg).cuda();opt=torch.optim.Adam(m.parameters(),lr=.0001);fn=torch.nn.HuberLoss();best=float('inf');logs=[]
    histdt=dt[108:252]
    def batch(ids):return [tensor(np.stack(a)) for a in [[(history[i-L:i]-mu)/sd for i in ids],[histdt[i-L:i] for i in ids],[(history[i:i+h]-mu)/sd for i in ids]]]
    for ep in range(10):
        m.train()
        for off in range(L,cut-h+1,32):
            a,b,label=batch(range(off,min(off+32,cut-h+1)));opt.zero_grad();fn(m(a,b,None,None),label).backward();opt.step()
        m.eval()
        with torch.no_grad():a,b,label=batch(range(cut,n-h+1));val=float(fn(m(a,b,None,None),label))
        logs.append(dict(epoch=ep+1,validation=val))
        if val<best:best=val;bestep=ep+1;state=copy.deepcopy(m.state_dict())
    m.load_state_dict(state);m.eval();torch.save(state,d/'Biswas_checkpoint.pt');pred=[];hs=history.copy()
    for j in range(252,324,12):
        with torch.no_grad():e=m(tensor((hs[-L:]-mu)/sd)[None],tensor(dt[j-L:j])[None],None,None)[0].cpu().numpy()*sd+mu
        pred.extend(raw[j:j+h]-.05*e);hs=np.concatenate([hs,raw[j:j+h]-y[j:j+h]])
    np.savez_compressed(p,pred=np.array(pred));js(p.with_suffix('.json'),dict(sha256=sha(p),seconds=time.perf_counter()-tick,epochs=logs,best_epoch=bestep,adapter_initialization=42,frequency='m'));del m;torch.cuda.empty_cache()
    print('BISWAS_DONE',bb,seed,flush=True)
def release(bb,seed):
    import labour_compare as cc
    x=cc.context(bb,seed);d=folder(bb,seed)/'results'
    for name in ['LiDiag','LiFactor','Biswas']:
        path=folder(bb,seed)/'recent'/(name+'.npz');meta=json.loads(path.with_suffix('.json').read_text(encoding='utf8'));assert sha(path)==meta['sha256'];raw=load(path)['pred']
        if not cc.ready(d,name):cc.savearm(d,x,name,raw,raw[:,-32:] if name.startswith('Li') and raw.min()>=0 else None,elapsed=meta['seconds'])
        if not cc.ready(d,'Protected'+name):
            z,u=cc.old.project(x['S'],raw,x['v']);pred,rep,logs,elapsed=cc.publish(x,z);cc.savearm(d,x,'Protected'+name,pred,rep,True,logs,elapsed)
if __name__=='__main__':
    from threadpoolctl import threadpool_limits
    with threadpool_limits(1):
      mode=sys.argv[1]
      for bb in ['PatchTST','DLinear']:
       for seed in [42,1,2]:
        if mode=='li':
            while not (folder(bb,seed)/'CONTEXT_READY.json').exists():time.sleep(5)
            li_targets(bb,seed)
        elif mode=='biswas':biswas(bb,seed)
        else:release(bb,seed)
