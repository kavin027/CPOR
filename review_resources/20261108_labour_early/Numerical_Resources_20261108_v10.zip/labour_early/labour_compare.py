from labour_early_common import *
import time,ast,inspect
from fractions import Fraction as F
from threadpoolctl import threadpool_limits
sys.path.insert(0,str(O/'cpor_duet_stream_20261106'))
import evaluate as duet
sys.path.insert(0,str(O/'pir_grouped_release_20261106'))
from grouped import grouped,partition
c=duet.c;old=duet.cpu.old;fresh=duet.cpu.fresh;ns=duet.ns;R=F(40401,40000);K=R-1
def pin():
    verify();path=H/'IMPLEMENTATION_CLOSURE.json'
    if path.exists():
        for f,h in json.loads(path.read_text(encoding='utf8')).items():assert sha(f)==h,f
        return
    files={Path(m.__file__).resolve() for m in list(sys.modules.values()) if getattr(m,'__file__',None)}
    files={f for f in files if f.is_file() and f.suffix=='.py' and f.is_relative_to(ROOT) and '.runtime' not in f.parts}
    files.update([O/'rr_recap_evidence_extension_20261002/frozen_core.py',O/'c0_frozen_confirmation_20261014/run.py'])
    js(path,{str(f):sha(f) for f in sorted(files)})
def context(bb,seed):
    d=folder(bb,seed);p=d/'context.npz'
    if p.exists():return load(p)
    raw=load(d/'raw.npz');x,D,expert,bank,mixed=duet.cpu.contexts({'dataset':'Labour'},d/'canonical_context',raw)
    controls=d/'canonical_controls';controls.mkdir(exist_ok=True);prev=duet.cpu.saved.H
    try:
        duet.cpu.saved.H=H;duet.cpu.saved.controls(controls,x,expert,bank)
    finally:duet.cpu.saved.H=prev
    z=load(controls/'controls.npz');ml=z['MLPol'];um=old.project(x['S'],ml,x['v'])[1]
    # The archived controls expose scored outputs; reconstruct all108 causal ML targets for fixed calibration controls.
    scaled=bank/np.sqrt(x['v'])[None,:,None];labels=x['truth']/np.sqrt(x['v'])[None,:]
    w=np.full((57,9),1/9);regrets=np.zeros_like(w);squares=np.zeros_like(w);mlraw=[]
    for t in range(108):
        pm=(scaled[t]*w).sum(1);mlraw.append(pm*np.sqrt(x['v']))
        r=2*(pm-labels[t])[:,None]*(pm[:,None]-scaled[t]);regrets+=r;squares+=r*r
        q=np.maximum(regrets,0)/(1+squares);tot=q.sum(1,keepdims=True);w=np.divide(q,tot,out=np.full_like(q,1/9),where=tot>0)
    mlraw=np.array(mlraw);mlfull,umfull=old.project(x['S'],mlraw,x['v']);np.testing.assert_array_equal(mlfull[36:],ml)
    chosen=int(np.argmin(np.sqrt(((expert[:36]-x['truth'][:36,:,None])**2).mean(0)).mean(0)))
    cb,ucb=old.project(x['S'],bank[:,:,chosen],x['v']);cov,uc=old.project(x['S'],mixed,x['v']);np.testing.assert_array_equal(cov,D)
    x.update(bank=bank,CovRaw=mixed,CovTarget=D,CovU=uc,MLRaw=mlraw,MLTarget=mlfull,MLU=umfull,CalBest=cb,CalBestU=ucb,chosen=np.array(chosen))
    np.savez_compressed(p,**x);js(d/'CONTEXT_READY.json',dict(sha256=sha(p),chosen_expert=chosen,registration_sha256=sha(H/'REGISTRATION.json')))
    return x
def numeric(v):
    if isinstance(v,dict):return {str(k):numeric(z) for k,z in v.items()}
    if isinstance(v,(list,tuple)):return [numeric(z) for z in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,F):return str(v)
    return v
def audit(x,p,u=None,protected=False,domain='nonnegative'):
    A=[F(0)]*57;ever=set();events=env=0;maxratio=0.
    for t,(b,row,y) in enumerate(zip(x['b'][36:],p,x['truth'][36:])):
        for i,(beta,z,label) in enumerate(zip(ns['exact'](b),ns['exact'](row),ns['exact'](y))):
            g=z*z-R*beta*beta if domain=='nonnegative' and z>R*beta else R*(z-beta)**2/K
            env+=int(g>A[i]);A[i]+=R*(beta-label)**2-(z-label)**2
            if A[i]<0:events+=1;ever.add(i)
    if protected:assert p.min()>=0 and events==env==0,(events,env)
    coh=None
    if u is not None:
        assert u.min()>=0 and np.allclose(p,u@x['S'].T,rtol=1e-8,atol=2e-6)
        coh=float(np.max(abs(p-u@x['S'].T)))
    return dict(node_date_checks=p.size,ever_violating_nodes=len(ever),violating_node_dates=events,envelope_failures=env,max_coherence_abs=coh,final_allowances=[float(a) for a in A])
def publish(x,z,rule='Full',domain='nonnegative',u=None):
    k=c.kernels(domain);S=x['S'];qp=k['old'].SafeProjection(S,x['v']);A=[F(0)]*57
    if rule=='Cov':
        tick=time.perf_counter();out=k['cov'](x,z,'Full')
        logs=out['stats']
        for key in ['contraction','rounding_move','gap']:
            if key in out:
                for i,r in enumerate(logs):r[key]=numeric(out[key][i])
        return out['pred'],out['witness'],logs,time.perf_counter()-tick
    if u is None:u=old.project(S,z,x['v'])[1]
    mask=partition(S);ps=[];us=[];logs=[];start=time.perf_counter()
    for j in range(72):
        t=j+36;b=x['b'][t];bq=ns['exact'](b);tick=time.perf_counter_ns()
        if rule=='Common':
            p,w=ns['ray'](b,z[j],bq,A);rep=(1-w)*x['ub'][t]+w*u[j];info=dict(contraction=w)
        elif rule=='TwoGroup':p,rep,w,repair=grouped(S[:,mask],mask,b,x['ub'][t],z[j],u[j],A,bq,1/x['v'],ns,float(R));info=dict(weights=w,repair=repair)
        else:p,rep,info=k['ml'](qp,S,b,x['ub'][t],z[j],A)
        assert k['certified'](b,p,A,R,K);info['publication_ms']=(time.perf_counter_ns()-tick)/1e6
        ps.append(p);us.append(rep);logs.append(info);A=ns['settle'](bq,ns['exact'](p),ns['exact'](x['truth'][t]),A)
    return np.array(ps),np.array(us),logs,time.perf_counter()-start
def ready(d,name):
    p=d/(name+'.json')
    if not p.exists():return False
    assert sha(d/(name+'.npz'))==json.loads(p.read_text(encoding='utf8'))['sha256'];return True
def savearm(d,x,name,p,u=None,protected=False,logs=None,elapsed=None,domain='nonnegative'):
    assert p.shape==(72,57) and np.isfinite(p).all();checks=audit(x,p,u,protected,domain)
    path=d/(name+'.npz');arrays=dict(pred=p)
    if u is not None:arrays['witness']=u
    np.savez_compressed(path,**arrays);js(path.with_suffix('.json'),dict(sha256=sha(path),audit=checks,protected=protected,domain=domain,logs=numeric(logs),elapsed_seconds=elapsed))
    print('ARM_DONE',d.parent.parent.name,d.parent.name,name,flush=True)
def run(bb,seed):
    pin();d=folder(bb,seed)/'results';d.mkdir(parents=True,exist_ok=True);x=context(bb,seed)
    for name,key,uk in [('Raw','raw',None),('NNLS','b','ub'),('CovTarget','CovTarget','CovU'),('MLTarget','MLTarget','MLU'),('CalBest','CalBest','CalBestU')]:
        if not ready(d,name):savearm(d,x,name,x[key][36:],x[uk][36:] if uk else None,name=='NNLS')
    for name,key,rule,domain in [('CPOR-Cov','CovTarget','Cov','nonnegative'),('CPOR-ML','MLTarget','Full','nonnegative'),('ProtectedCalBest','CalBest','Full','nonnegative'),('CovCommon','CovTarget','Common','nonnegative'),('MLCommon','MLTarget','Common','nonnegative'),('CovAllReal','CovTarget','Cov','real'),('MLAllReal','MLTarget','Full','real')]:
        if not ready(d,name):
            p,u,logs,elapsed=publish(x,x[key][36:],rule,domain);savearm(d,x,name,p,u,True,logs,elapsed,domain)
    W,C,lam,floor=duet.cpu.classic.covariance(x['raw'][:36]-x['truth'][:36])
    for arm in ['WLSstruct','WLSvar','MinTshrink','RollingMinT_Raw','WLSvar_Cov','MinT_Cov','MinT_CalBest']:
        if ready(d,arm):z=load(d/(arm+'.npz'))['pred']
        else:
            tick=time.perf_counter()
            if arm=='RollingMinT_Raw':
                zz=[];uu=[]
                for t in range(36,108):
                    WW,*_=duet.cpu.classic.covariance(x['raw'][t-36:t]-x['truth'][t-36:t]);p,u,_=duet.cpu.classic.target(x['S'],x['raw'][t:t+1],WW);zz.append(p[0]);uu.append(u[0])
                z,u=np.array(zz),np.array(uu)
            else:
                if arm in ['WLSstruct','WLSvar','MinTshrink']:
                    Z=x['raw'];WW={'WLSstruct':np.diag(x['S'].sum(1)),'WLSvar':np.diag(np.maximum(np.diag(C),floor)),'MinTshrink':W}[arm]
                else:
                    Z=x['CovRaw'] if arm.endswith('_Cov') else x['bank'][:,:,int(x['chosen'])]
                    WW,CC,ll,ff=duet.cpu.classic.covariance(Z[:36]-x['truth'][:36])
                    if arm.startswith('WLS'):WW=np.diag(np.maximum(np.diag(CC),ff))
                z,u,_=duet.cpu.classic.target(x['S'],Z[36:],WW)
            savearm(d,x,arm,z,u,elapsed=time.perf_counter()-tick)
        if not ready(d,'Protected'+arm):
            p,u,logs,elapsed=publish(x,z);savearm(d,x,'Protected'+arm,p,u,True,logs,elapsed)
    js(d/'CPU_DONE.json',dict(backbone=bb,seed=seed,covariance_shrinkage=lam,registration_sha256=sha(H/'REGISTRATION.json')))
if __name__=='__main__':
    with threadpool_limits(1):
        if sys.argv[1]=='pin':pin()
        else:run(sys.argv[1],int(sys.argv[2]))
