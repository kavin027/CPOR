from labour_early_common import *
import torch,inspect
import labour_compare as cc
from threadpoolctl import threadpool_limits
def run():
    verify();source={str(p):sha(p) for p in H.glob('*.py')}
    for f in [Path(inspect.getfile(cc.old)),Path(inspect.getfile(cc.fresh)),O/'c0_seed_validation_20261016/common.py',O/'cpor_external_repetitions_20261020/run.py',O/'rr_recap_strong_baseline_20261006/run.py',O/'c0_external_sota_20261014/pir_adapter.py',O/'cpor_kdd_comparison_20261105/grid.py',O/'cpor_li_preprint_20261106/paired.py',O/'cpor_li_factor_20261106/block_solve.py']:
        source[str(f)]=sha(f)
    js(H/'FINAL_IMPLEMENTATION_MANIFEST.json',source)
    receipts=[];modelsettings=[]
    wide=pd.read_csv(DATA,parse_dates=['ds']).set_index('ds')
    for bb in ['PatchTST','DLinear']:
     for seed in [42,1,2]:
      d=folder(bb,seed);x=load(d/'context.npz');saved=load(d/'canonical_controls/controls.npz')
      p=load(d/'results/CPOR-ML.npz')['pred'];np.testing.assert_array_equal(p,saved['ProtectedMLPol'])
      rep=cc.c.run(x,x['CovTarget'][36:],'Cov','Labour','nonnegative')['pred'];original=load(d/'results/CPOR-Cov.npz')['pred'];np.testing.assert_array_equal(rep,original)
      # Perturb all labels from one future issue onward, holding preissue observations and forecasts fixed.
      cut=50;a=wide.copy();a.iloc[CAL+cut:]=a.iloc[CAL+cut:]*1.1+123
      baseline=cc.fresh.expert_bank(wide,x['raw'].copy(),x['v'],CAL);changed=cc.fresh.expert_bank(a,x['raw'].copy(),x['v'],CAL)
      np.testing.assert_array_equal(baseline[:cut+1],changed[:cut+1])
      receipts.append(dict(backbone=bb,seed=seed,native_ml_bitwise=True,native_cov_bitwise=True,expert_future_label_gate=True))
      for fd in sorted((d/'fits').iterdir()):
        m=json.loads((fd/'run.json').read_text(encoding='utf8'))
        if not m['new_fit']:continue
        ck=torch.load(fd/'best.ckpt',map_location='cpu',weights_only=False);hp=ck['hyper_parameters']
        assert hp['h']==12 and hp['input_size']==24 and hp['learning_rate']==.0001 and hp['val_check_steps']==1
        assert hp['max_steps']==(500 if bb=='PatchTST' else 10000) and hp['random_seed']==seed
        assert int(ck['global_step'])==m['best_step']
        modelsettings.append(dict(backbone=bb,seed=seed,fit=fd.name,h=hp['h'],input_size=hp['input_size'],lr=hp['learning_rate'],max_steps=hp['max_steps'],loss=str(hp['loss']),scaler_type=hp.get('scaler_type'),revin=hp.get('revin'),best_step=m['best_step'],last_step=m['last_step'],stopped_before_cap=m['stopped_before_cap']))
    pd.DataFrame(modelsettings).to_csv(H/'ACTUAL_MODEL_SETTINGS.csv',index=False)
    js(H/'IMPLEMENTATION_GATES.json',dict(passed=True,receipts=receipts,model_settings=len(modelsettings)))
    print('IMPLEMENTATION_GATES_PASSED',len(receipts),len(modelsettings))
if __name__=='__main__':
    with threadpool_limits(1):run()
