from labour_early_common import *
import time
import labour_compare as cc
from threadpoolctl import threadpool_limits
if __name__=='__main__':
    with threadpool_limits(1):
      for bb in ['PatchTST','DLinear']:
       for seed in [42,1,2]:
        while not (folder(bb,seed)/'RAW_READY.json').exists():time.sleep(5)
        cc.run(bb,seed)
