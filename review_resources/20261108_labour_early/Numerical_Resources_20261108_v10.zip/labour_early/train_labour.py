from labour_early_common import *
import time,logging,shutil
import torch
from neuralforecast import NeuralForecast
from neuralforecast.models import PatchTST,DLinear
from pytorch_lightning.callbacks import Callback
class Capture(Callback):
    def __init__(self,d):self.d=d;self.rows=[];self.best=float('inf');self.best_step=None
    def on_validation_end(self,trainer,model):
        if trainer.sanity_checking:return
        value=float(trainer.callback_metrics['ptl/val_loss']);step=int(trainer.global_step)
        self.rows.append(dict(step=step,validation_mae=value))
        if value<self.best:
            trainer.save_checkpoint(str(self.d/'best.ckpt'));self.best=value;self.best_step=step
        if step%1000==0:print('FIT_PROGRESS',self.d,step,value,flush=True)
def fit(wide,bb,seed,ix,count):
    d=folder(bb,seed)/'fits'/f'{ix:04d}';d.mkdir(parents=True,exist_ok=True)
    if (d/'run.json').exists():
        rec=json.loads((d/'run.json').read_text(encoding='utf8'));assert sha(d/'predictions.csv')==rec['predictions_sha256'];return
    src=reuse(bb,seed,ix)
    if src:
        meta=json.loads((src/'run.json').read_text(encoding='utf8'));assert meta['seed']==seed
        assert pd.Timestamp(meta['prediction_start'])==wide.index[ix] and pd.Timestamp(meta['validation_end'])==wide.index[ix-1]
        assert pd.Timestamp(meta['gradient_train_end'])==wide.index[ix-37]
        f=pd.read_csv(src/'predictions.csv',parse_dates=['ds','origin']);f=f[f.ds.isin(wide.index[ix:ix+count])].copy()
        assert len(f)==57*count and (f.origin<f.ds).all()
        f.to_csv(d/'predictions.csv',index=False)
        js(d/'run.json',dict(backbone=bb,seed=seed,ix=ix,count=count,reused_from=str(src),source_run=meta,predictions_sha256=sha(d/'predictions.csv'),new_fit=False))
        print('REUSED',bb,seed,ix,count,flush=True);return
    torch.set_num_threads(1);cls=PatchTST if bb=='PatchTST' else DLinear;cap=500 if bb=='PatchTST' else 10000
    tick=time.perf_counter();capture=Capture(d)
    opts=dict(h=12,input_size=24,val_check_steps=1,early_stop_patience_steps=50,random_seed=seed,max_steps=cap,
      enable_checkpointing=True,callbacks=[capture],enable_progress_bar=False,enable_model_summary=False,logger=False,accelerator='gpu',devices=1,default_root_dir=str(d))
    if bb=='PatchTST':opts['n_series']=57
    nf=NeuralForecast(models=[cls(**opts)],freq='MS')
    full=wide.reset_index().melt(id_vars='ds',var_name='unique_id',value_name='y').sort_values(['ds','unique_id'])
    print('FIT_START',bb,seed,ix,count,flush=True);nf.fit(df=full[full.ds<wide.index[ix]],val_size=36)
    cb=next(c for c in nf.models[0].trainer_kwargs['callbacks'] if isinstance(c,Capture))
    pd.DataFrame(cb.rows).to_csv(d/'validation_curve.csv',index=False)
    ck=torch.load(d/'best.ckpt',map_location='cpu',weights_only=False);ck['hyper_parameters']['callbacks']=[];torch.save(ck,d/'best.ckpt')
    trained=cls.load_from_checkpoint(str(d/'best.ckpt'),map_location='cpu',weights_only=False,callbacks=[],early_stop_patience_steps=0,enable_checkpointing=False,enable_progress_bar=False,enable_model_summary=False,logger=False,default_root_dir=str(d))
    nf.models=[trained];parts=[]
    for offset in range(0,count,12):
        t=ix+offset;z=nf.predict(df=full[full.ds<wide.index[t]])
        if 'unique_id' not in z:z=z.reset_index()
        z['origin']=wide.index[t-1];parts.append(z)
    frame=pd.concat(parts,ignore_index=True);assert len(frame)==count*57 and (frame.origin<frame.ds).all()
    frame.to_csv(d/'predictions.csv',index=False)
    js(d/'run.json',dict(backbone=bb,seed=seed,ix=ix,count=count,new_fit=True,max_steps=cap,best_val=cb.best,best_step=cb.best_step,last_step=cb.rows[-1]['step'],stopped_before_cap=cb.rows[-1]['step']<cap,
      gradient_train_end=wide.index[ix-37],validation_end=wide.index[ix-1],prediction_start=wide.index[ix],prediction_end=wide.index[ix+count-1],
      checkpoint_sha256=sha(d/'best.ckpt'),predictions_sha256=sha(d/'predictions.csv'),seconds=time.perf_counter()-tick,registration_sha256=sha(H/'REGISTRATION.json')))
    print('FIT_DONE',bb,seed,ix,cb.best_step,cb.rows[-1]['step'],flush=True);del nf,trained;torch.cuda.empty_cache()
def run(bb,seed):
    verify();wide=pd.read_csv(DATA,parse_dates=['ds']).set_index('ds');S=load(LATE)['S'];plan=[(118,72),(190,72),(262,72),(334,12),(346,12),(358,12),(370,72)]
    d=folder(bb,seed);parts=[]
    for ix,count in plan:
        fit(wide,bb,seed,ix,count)
        f=pd.read_csv(d/'fits'/f'{ix:04d}'/'predictions.csv',parse_dates=['ds','origin'])
        a=f.pivot(index='ds',columns='unique_id',values=bb).reindex(index=wide.index[ix:ix+count],columns=wide.columns).to_numpy()
        assert a.shape==(count,57) and np.isfinite(a).all();parts.append(a)
    raw=np.concatenate(parts);assert raw.shape==(324,57)
    np.savez_compressed(d/'full_stream.npz',raw=raw,truth=wide.iloc[BEGIN:END].to_numpy(),S=S,begin=BEGIN,start=START,cal_start=CAL,dates=wide.index[BEGIN:END].astype(str).to_numpy(dtype='U'))
    np.savez_compressed(d/'raw.npz',raw=raw[216:],truth=wide.iloc[CAL:END].to_numpy(),S=S,start=START,cal_start=CAL)
    js(d/'RAW_READY.json',dict(full_sha256=sha(d/'full_stream.npz'),raw_sha256=sha(d/'raw.npz'),backbone=bb,seed=seed,registration_sha256=sha(H/'REGISTRATION.json')))
    print('STREAM_DONE',bb,seed,flush=True)
if __name__=='__main__':
    logging.getLogger('pytorch_lightning').setLevel(logging.ERROR)
    for bb in ['PatchTST','DLinear']:
      for seed in [42,1,2]:run(bb,seed)
