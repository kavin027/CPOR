from labour_early_common import *
import time,random,importlib.util,logging
import torch
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
ext=module('labour_original_external',O/'cpor_external_repetitions_20261020/run.py')
pro=module('labour_original_procast',O/'rr_recap_strong_baseline_20261006/run.py')
def reset():
    random.seed(42);np.random.seed(42);torch.manual_seed(42);torch.cuda.manual_seed_all(42);torch.set_num_threads(1)
def data(bb,seed):
    wide=pd.read_csv(DATA,parse_dates=['ds']).set_index('ds');v=wide.to_numpy();base=load(folder(bb,seed)/'full_stream.npz')
    pos=np.arange(BEGIN,END);lib=np.arange(24,CAL);mu=v[:CAL].mean(0);sd=v[:CAL].std(0);sd=np.where(sd>0,sd,1.)
    return dict(x=((np.stack([v[t-24:t] for t in pos])-mu)/sd).astype('float32'),raw=((base['raw']-mu)/sd)[:,None,:].astype('float32'),
      y=((v[pos]-mu)/sd)[:,None,:].astype('float32'),encmark=np.stack([ext.pir.calendar(wide.index[t-24:t]) for t in pos]),mark=ext.pir.calendar(wide.index[pos])[:,None,:],
      lib_x=((np.stack([v[t-24:t] for t in lib])-mu)/sd).astype('float32'),lib_y=((v[lib]-mu)/sd)[:,None,:].astype('float32'),library_index=pos-24,mu=mu,sd=sd,train_count=216,score_start=252)
def adapters(bb,seed):
    verify();d=folder(bb,seed)/'external';d.mkdir(parents=True,exist_ok=True)
    for name in ['PIR','Ada-Y']:
        path=d/(name+'.npz')
        if path.with_suffix('.json').exists():assert sha(path)==json.loads(path.with_suffix('.json').read_text(encoding='utf8'))['sha256'];continue
        reset();tick=time.perf_counter();dd=data(bb,seed)
        if name=='PIR':
            model=ext.pir.CachedPIR(ext.pir.config(57)).float().cuda();tensors=ext.pir.tensors(dd,'cuda');logs,state=ext.pir.fit(model,tensors,216,252);pred=[]
            with torch.no_grad():
                for i in range(252,324):
                    y,_=ext.pir.forward(model,tensors,torch.tensor([i],device='cuda'));pred.append(y.cpu().numpy()[0,0]*dd['sd']+dd['mu'])
            pred=np.array(pred);del model,tensors
        else:pred,state,logs=ext.fit_aday(dd,'cuda')
        assert pred.shape==(72,57);np.savez_compressed(path,pred=pred);torch.save(state,d/(name+'_checkpoint.pt'))
        js(path.with_suffix('.json'),dict(sha256=sha(path),seconds=time.perf_counter()-tick,adapter_initialization=42,epochs=logs,training_end='2005-11-01',calibration_end='2008-11-01'));torch.cuda.empty_cache()
        print('ADAPTER_DONE',bb,seed,name,flush=True)
    path=d/'ProCAST.npz'
    if path.with_suffix('.json').exists():assert sha(path)==json.loads(path.with_suffix('.json').read_text(encoding='utf8'))['sha256'];return
    reset();base=load(folder(bb,seed)/'full_stream.npz');raw,y,S=base['raw'],base['truth'],base['S']
    yh=torch.tensor(raw,device='cuda',dtype=torch.float64);yt=torch.tensor(y,device='cuda',dtype=torch.float64);counts=[]
    model=pro._TorchPinv(torch.tensor(S,dtype=torch.float32),masked=False,max_iter=100000,callback=lambda a:counts.append(int(a[1])) if a[0]=='count' else None).to(device='cuda',dtype=torch.float64)
    ps=[];us=[];tick=time.perf_counter()
    for i in range(216,324):
        n=72;weights=torch.tensor([.5/n]*n+[.5],device='cuda',dtype=torch.float64)
        model.fit(yh[i-n:i+1],torch.cat([yt[i-n:i],yh[i:i+1]]),weights=weights)
        with torch.no_grad():
            u=(yh[i:i+1]@model.pinv).clamp(min=0);ps.append((u@model.mat).cpu().numpy()[0]);us.append(u.cpu().numpy()[0])
        if (i-215)%36==0:print('PROCAST_PROGRESS',bb,seed,i-215,flush=True)
    assert len(counts)==108;np.savez_compressed(path,pred=np.array(ps)[36:],witness=np.array(us)[36:],iterations=counts)
    js(path.with_suffix('.json'),dict(sha256=sha(path),seconds=time.perf_counter()-tick,adapter_initialization=42,limit_hits=sum(i>=100000 for i in counts),max_iterations=max(counts)))
    del model,yh,yt;torch.cuda.empty_cache();print('ADAPTER_DONE',bb,seed,'ProCAST',flush=True)
def release(bb,seed):
    import labour_compare as cc
    cc.pin();x=cc.context(bb,seed);d=folder(bb,seed)/'results'
    for name in ['ProCAST','Ada-Y','PIR']:
        path=folder(bb,seed)/'external'/(name+'.npz');meta=json.loads(path.with_suffix('.json').read_text(encoding='utf8'));assert sha(path)==meta['sha256'];raw=load(path)['pred']
        if not cc.ready(d,name):cc.savearm(d,x,name,raw,elapsed=meta['seconds'])
        z,u=cc.old.project(x['S'],raw,x['v'])
        if name=='PIR':
            if not cc.ready(d,'PIRCoherent'):cc.savearm(d,x,'PIRCoherent',z,u)
            arms=[('PIRCommon','Common'),('PIRTwoGroup','TwoGroup'),('PIRFull','Full')]
        else:arms=[('Protected'+name,'Full')]
        for arm,rule in arms:
            if not cc.ready(d,arm):
                pred,rep,logs,elapsed=cc.publish(x,z,rule,u=u);cc.savearm(d,x,arm,pred,rep,True,logs,elapsed)
    js(d/'EXTERNAL_DONE.json',dict(backbone=bb,seed=seed))
if __name__=='__main__':
    logging.getLogger('pytorch_lightning').setLevel(logging.ERROR)
    if sys.argv[1]=='release':release(sys.argv[2],int(sys.argv[3]))
    else:
      for bb in ['PatchTST','DLinear']:
       for seed in [42,1,2]:adapters(bb,seed)
