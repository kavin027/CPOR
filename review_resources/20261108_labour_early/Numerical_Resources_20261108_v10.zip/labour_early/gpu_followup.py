from labour_early_common import *
import time,subprocess,os
if __name__=='__main__':
    while not all((folder(bb,s)/'RAW_READY.json').exists() for bb in ['PatchTST','DLinear'] for s in [42,1,2]):time.sleep(5)
    for script,args in [('labour_external.py',['adapters']),('labour_recent.py',['biswas'])]:
        print('GPU_FOLLOWUP',script,flush=True)
        subprocess.run([sys.executable,str(H/script),*args],cwd=str(ROOT),env=dict(os.environ),check=True)
    js(H/'GPU_COMPARATORS_DONE.json',dict(complete=True))
