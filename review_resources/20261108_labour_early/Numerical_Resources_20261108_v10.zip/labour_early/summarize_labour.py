from labour_early_common import *
import zipfile
def summarize(require=True):
    reg=verify();rows=[];nodes=[];checks=[];timings=[];missing=[];hashes={}
    names=pd.read_csv(DATA,nrows=1).columns[1:].tolist()
    for bb in ['PatchTST','DLinear']:
     for seed in [42,1,2]:
      d=folder(bb,seed)
      if not (d/'context.npz').exists():missing.append(f'{bb}/{seed}/context');continue
      x=load(d/'context.npz');y=x['truth'][36:]
      for method in reg['methods']:
        path=d/'results'/(method+'.npz')
        if not path.with_suffix('.json').exists():missing.append(f'{bb}/{seed}/{method}');continue
        meta=json.loads(path.with_suffix('.json').read_text(encoding='utf8'));assert sha(path)==meta['sha256'];hashes[str(path.relative_to(H))]=sha(path)
        p=load(path)['pred'];rmse=np.sqrt(((p-y)**2).mean(0));assert p.shape==(72,57)
        scopes={'Overall':rmse.mean(),'Regions':rmse[1:9].mean(),'System':rmse[0],'SexRegion':rmse[9:25].mean(),'Bottom':rmse[25:].mean()}
        scopes.update({names[i]:rmse[i] for i in range(1,9)})
        for scope,value in scopes.items():rows.append(dict(backbone=bb,run=seed,method=method,scope=scope,rmse=value))
        for i,value in enumerate(rmse):nodes.append(dict(backbone=bb,run=seed,method=method,node=i,name=names[i],rmse=value))
        checks.append(dict(backbone=bb,run=seed,method=method,protected=meta['protected'],negative_values=int((p<0).sum()),**{k:v for k,v in meta['audit'].items() if k!='final_allowances'}))
        logs=meta.get('logs') or [];ms=[r.get('publication_ms',r.get('ms')) for r in logs];ms=[v for v in ms if v is not None]
        timings.append(dict(backbone=bb,run=seed,method=method,elapsed_seconds=meta.get('elapsed_seconds'),release_mean_ms=np.mean(ms) if ms else (meta['elapsed_seconds']/72*1000 if meta.get('elapsed_seconds') is not None else None),release_p95_ms=np.quantile(ms,.95) if ms else None))
    if require:assert not missing,missing
    frame=pd.DataFrame(rows);frame.to_csv(H/'RUN_SCOPE_RMSE.csv',index=False)
    nf=pd.DataFrame(nodes);nf.to_csv(H/'NODE_RMSE.csv',index=False)
    summary=frame.groupby(['backbone','method','scope']).rmse.agg(['mean','std','min','max']).reset_index();summary.to_csv(H/'THREE_RUN_RMSE.csv',index=False)
    pd.DataFrame(checks).to_csv(H/'PROTECTION_CHECKS.csv',index=False);pd.DataFrame(timings).to_csv(H/'PUBLICATION_TIMING.csv',index=False)
    comparisons=[(a,b) for a in ['CPOR-Cov','CPOR-ML'] for b in ['Raw','NNLS','PIR','Ada-Y','ProCAST','Biswas','LiDiag','LiFactor','ProtectedPIR','PIRFull','ProtectedProCAST','ProtectedAda-Y','ProtectedBiswas','ProtectedLiDiag','ProtectedLiFactor','ProtectedCalBest','ProtectedMinTshrink','ProtectedMinT_Cov','ProtectedRollingMinT_Raw','CPOR-Cov','CPOR-ML'] if a!=b]
    comparisons += [('CPOR-Cov','CovTarget'),('CPOR-ML','MLTarget'),('CPOR-Cov','CovCommon'),('CPOR-ML','MLCommon'),('CPOR-Cov','CovAllReal'),('CPOR-ML','MLAllReal'),('PIRFull','PIRCommon'),('PIRFull','PIRTwoGroup'),('PIRFull','PIRCoherent')]
    pairs=[];nodepairs=[]
    for a,b in comparisons:
        aa=frame[frame.method==a].drop(columns='method').rename(columns={'rmse':'method_rmse'});bb=frame[frame.method==b].drop(columns='method').rename(columns={'rmse':'comparator_rmse'})
        f=aa.merge(bb,on=['backbone','run','scope']);f['method']=a;f['comparator']=b;f['gain_pct']=100*(1-f.method_rmse/f.comparator_rmse);pairs.append(f)
        aa=nf[nf.method==a].drop(columns='method').rename(columns={'rmse':'method_rmse'});bb=nf[nf.method==b].drop(columns='method').rename(columns={'rmse':'comparator_rmse'})
        f=aa.merge(bb,on=['backbone','run','node','name']);f['method']=a;f['comparator']=b;f['gain_pct']=100*(1-f.method_rmse/f.comparator_rmse);nodepairs.append(f)
    paired=pd.concat(pairs,ignore_index=True);paired.to_csv(H/'PAIRED_GAINS.csv',index=False)
    gs=paired.groupby(['method','comparator','scope']).gain_pct.agg(['mean','median','min','max','count',lambda x:(x>0).sum()]).reset_index().rename(columns={'<lambda_0>':'positive_streams'});gs.to_csv(H/'PAIRED_SUMMARY.csv',index=False)
    gb=paired.groupby(['backbone','method','comparator','scope']).gain_pct.agg(['mean','std','min','max']).reset_index();gb.to_csv(H/'BACKBONE_PAIRED_SUMMARY.csv',index=False)
    npair=pd.concat(nodepairs,ignore_index=True);npair.to_csv(H/'NODE_PAIRED_GAINS.csv',index=False)
    npair[npair.gain_pct<0].to_csv(H/'NEGATIVE_NODE_COMPARISONS.csv',index=False)
    js(H/'RESULT_HASHES.json',hashes);js(H/'STATUS.json',dict(complete=not missing,missing=missing,trajectories=len(hashes),expected=246,frozen_manuscript_modified=False))
    return summary,paired,gs,pd.DataFrame(checks)
def mdtable(df):
    return '| '+' | '.join(map(str,df.columns))+' |\n|'+'|'.join(['---']*len(df.columns))+'|\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in df.itertuples(index=False,name=None))
def report():
    summary,pair,gain,checks=summarize();audit=json.loads((H/'INDEPENDENT_CHECK.json').read_text(encoding='utf8'));fits=pd.read_csv(H/'FIT_BOUNDARIES.csv')
    def form(a,b):return f'{a:.3f} ± {b:.3f}'
    ss=summary[summary.scope.isin(['Overall','Regions','System'])].copy();ss['Mean ± SD']=ss.apply(lambda r:form(r['mean'],r['std']),axis=1)
    tab=ss.pivot(index=['backbone','method'],columns='scope',values='Mean ± SD').reset_index()
    ordered=['Raw','NNLS','ProCAST','PIR','Ada-Y','Biswas','LiDiag','LiFactor','CovTarget','CPOR-Cov','MLTarget','CPOR-ML','ProtectedCalBest','PIRFull','ProtectedMinTshrink','ProtectedMinT_Cov']
    tab=tab[tab.method.isin(ordered)].copy();tab['order']=tab.method.map({v:i for i,v in enumerate(ordered)});tab=tab.sort_values(['backbone','order']).drop(columns='order')
    gp=gain[gain.scope.isin(['Overall','Regions','System'])&gain.comparator.isin(['Raw','PIR','ProCAST','Ada-Y','Biswas','LiDiag','LiFactor','ProtectedMinT_Cov','ProtectedCalBest','CPOR-ML','CovCommon','MLCommon','CovAllReal','MLAllReal','CovTarget','MLTarget','PIRCommon','PIRTwoGroup','PIRCoherent'])].copy()
    gt=gp.pivot(index=['method','comparator'],columns='scope',values='mean').reset_index()
    for k in ['Overall','Regions','System']:gt[k]=gt[k].map(lambda a:f'{a:.3f}%')
    selected=checks[checks.method.isin(['Raw','NNLS','CovTarget','CPOR-Cov','MLTarget','CPOR-ML','PIR','PIRCoherent','PIRCommon','PIRTwoGroup','PIRFull','LiDiag','LiFactor'])]
    ct=selected.groupby(['method','protected'])[['ever_violating_nodes','violating_node_dates','envelope_failures','node_date_checks']].sum().reset_index()
    regional=summary[summary.scope.isin(pd.read_csv(DATA,nrows=1).columns[2:10])&summary.method.isin(['CPOR-Cov','CPOR-ML','NNLS','PIRFull','ProtectedCalBest'])].copy();regional['Mean ± SD']=regional.apply(lambda r:form(r['mean'],r['std']),axis=1)
    rt=regional.pivot(index=['backbone','scope'],columns='method',values='Mean ± SD').reset_index()
    negative=pair[(pair.gain_pct<0)&pair.method.isin(['CPOR-Cov','CPOR-ML'])&pair.comparator.isin(['NNLS','CovCommon','MLCommon','CovAllReal','MLAllReal','ProtectedMinT_Cov','ProtectedCalBest'])]
    negative=negative.sort_values('gain_pct').head(20)[['backbone','run','method','comparator','scope','gain_pct']].copy();negative['gain_pct']=negative.gain_pct.map(lambda a:f'{a:.3f}%')
    text='# Labour早窗三次实验报告\n\n'
    text+='评分期：2008年12月—2014年11月，72个月。完整保留57节点，包括系统总量、8地区、16性别×地区和32底层序列。两种骨干各三次初始化，41种规则，共246条发布轨迹。原冻结稿和投稿包未修改。\n\n'
    text+='## 1. 固定协议与复用\n\n'
    text+=f'三段独立12个月校准预测及一段72个月评分预测；外部适配器沿用216个月历史支持。共42个必要拟合阶段，复用{audit["reused_fits"]}个、训练{audit["new_fits"]}个。PatchTST上限500，DLinear上限10000，均按原验证MAE及早停规则选模。每条轨迹评分前余额清零一次，随后用实际发布误差独立更新，不在窗口内清零。参考、0.5%容差、日期和反馈顺序相同。\n\n'
    text+='这是已开发数据集上补齐遗漏窗口的回顾性扩展；三次初始化共享同一观测期，不是六个独立数据集。外部适配器每条基础预测流固定一次初始化，不声称复现原论文的协议或性能。\n\n'
    text+='## 2. 绝对RMSE\n\n三次实验均值±样本标准差，保持数据原单位。Overall等权平均57个节点RMSE，Regions等权平均8个地区RMSE，System是总量节点RMSE。\n\n'+mdtable(tab)+'\n\n'
    text+='## 3. 配对收益与保护代价\n\n下表先在每条预测流计算100×(1−方法RMSE/对照RMSE)，再对两骨干×三次运行等权平均。正值为改善，负值为退化。以未保护目标为分母的负值，其绝对值即保护代价。方法间完整流程比较不能全部归因于保护算子；同候选Common/Full及相同数值路径的Nonnegative/AllReal比较更直接检验发布约束的影响，各臂仍有自己的历史余额。\n\n'+mdtable(gt)+'\n\n'
    text+='## 4. 保护核验\n\n'+mdtable(ct)+'\n\n'
    text+=f'独立预测级核验：{audit["protected_trajectories"]}条保护轨迹，共{audit["exact_envelope_checks"]:,}次节点一步包络及相同数量的累计前缀检查，均通过；聚合一致性按rtol=1e-8、atol=2e-6检查。违规序列计数把同一节点在不同骨干/运行分别计数，不能视为独立样本。未保护目标的包络失败不等于实际前缀违规。\n\n'
    text+='## 5. 各地区及负面结果\n\n'+mdtable(rt)+'\n\n'
    text+='相对指定受保护对照的较大退化如下。逐节点、逐运行完整正负结果均在NODE_PAIRED_GAINS.csv；不能把零违规解释为地区精度普遍领先。\n\n'+mdtable(negative)+'\n\n'
    text+='## 6. 文件入口\n\nREGISTRATION.json为评分前固定的协议。FIT_BOUNDARIES.csv记录训练/验证边界、复用和停止步数；RUN_SCOPE_RMSE.csv及NODE_RMSE.csv给出未舍入结果；THREE_RUN_RMSE.csv给出均值/SD；PAIRED_GAINS.csv、BACKBONE_PAIRED_SUMMARY.csv给出配对差异；PROTECTION_CHECKS.csv和INDEPENDENT_CHECK.json给出保护核验；PUBLICATION_TIMING.csv保留发布耗时。核验入口：在项目根目录运行`./RUN_RESEARCH.ps1 output/cpor_labour_early_three_runs_20261107/independent_check.py`。\n'
    (H/'REPORT.md').write_text(text,encoding='utf8')
    print(tab.to_string(index=False));print(gt.to_string(index=False));print(audit)
def package():
    verify();p=H/'Labour_Early_Three_Runs_20261107.zip'
    files=[f for f in H.rglob('*') if f.is_file() and f!=p and f.suffix not in ['.ckpt','.pt','.zip','.pyc'] and '__pycache__' not in f.parts and f.name not in ['factor.bin']]
    with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as z:
        for f in sorted(files):z.write(f,f.relative_to(H))
    js(H/'DELIVERY.json',dict(package=p.name,sha256=sha(p),files=len(files),bytes=p.stat().st_size,checkpoint_policy='Selected neural checkpoints retained on H under runs/*/*/fits; omitted from compact numeric package.',frozen_manuscript_unchanged=True))
    print(p,sha(p))
if __name__=='__main__':
    if '--report' in sys.argv:report()
    elif '--package' in sys.argv:package()
    else:summarize('--partial' not in sys.argv)
