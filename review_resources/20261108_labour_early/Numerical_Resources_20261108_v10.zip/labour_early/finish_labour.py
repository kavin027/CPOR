from labour_early_common import *
import shutil
def main():
    verify();audit=json.loads((H/'INDEPENDENT_CHECK.json').read_text(encoding='utf8'));assert audit['passed']
    (H/'inputs').mkdir(exist_ok=True);shutil.copy2(DATA,H/'inputs/Labour.csv');assert sha(DATA)==sha(H/'inputs/Labour.csv')
    g=pd.read_csv(H/'PAIRED_SUMMARY.csv');s=pd.read_csv(H/'THREE_RUN_RMSE.csv');n=pd.read_csv(H/'NODE_PAIRED_GAINS.csv')
    def val(method,comp,scope='Overall'):
        return float(g[(g.method==method)&(g.comparator==comp)&(g.scope==scope)]['mean'].iloc[0])
    facts=[]
    for method,target,ray,real in [('CPOR-Cov','CovTarget','CovCommon','CovAllReal'),('CPOR-ML','MLTarget','MLCommon','MLAllReal')]:
        facts.append(dict(method=method,vs_NNLS=val(method,'NNLS'),vs_PIR=val(method,'PIR'),vs_ProCAST=val(method,'ProCAST'),vs_Biswas=val(method,'Biswas'),vs_LiDiag=val(method,'LiDiag'),vs_LiFactor=val(method,'LiFactor'),vs_same_target_common=val(method,ray),vs_all_real=val(method,real),protection_cost=-val(method,target),vs_protected_MInT_Cov=val(method,'ProtectedMinT_Cov'),vs_protected_CalBest=val(method,'ProtectedCalBest')))
    pd.DataFrame(facts).to_csv(H/'KEY_FINDINGS.csv',index=False)
    ev=[]
    for p in H.glob('runs/*/*/results/CPOR-*.json'):
        m=json.loads(p.read_text(encoding='utf8'));logs=m['logs'];ev.append(dict(backbone=p.parents[2].name,run=p.parents[1].name,method=p.stem,contractions=sum(r.get('contraction',1)<1 for r in logs),rounding_moves=sum(r.get('rounding_move',0)>0 for r in logs),extra_solver_attempts=sum(max(0,r.get('attempts',1)-1) for r in logs),status_optimal=sum(r.get('status')=='optimal' for r in logs),status_inaccurate=sum('inaccurate' in str(r.get('status','')) for r in logs),status_absent=sum('status' not in r for r in logs),max_rounding_move=max(r.get('rounding_move',0) for r in logs)))
    pd.DataFrame(ev).to_csv(H/'CPOR_NUMERICAL_EVENTS.csv',index=False)
    timing=pd.read_csv(H/'PUBLICATION_TIMING.csv');timing['loop_mean_ms']=timing.elapsed_seconds/72*1000
    timing=timing.rename(columns={'release_mean_ms':'recorded_action_mean_ms','release_p95_ms':'recorded_action_p95_ms'})
    timing.loc[timing.method.isin(['CPOR-Cov','CovAllReal']),'recorded_action_mean_ms']=np.nan
    timing.to_csv(H/'PUBLICATION_TIMING.csv',index=False)
    note='''\n\n## 7. 结果判断\n\n1. 两种实现相对同流NNLS参考均有整体、地区平均和系统误差改善，且本轮所有57节点×6条流的最终RMSE均低于参考。これは本窗口的观测结果；理论保证仍是累计误差不超过参考的1.005倍，并不保证普遍逐节点更准确。\n2. 同一Cov/ML目标下，完整发布相对统一收缩的整体改善为6.041%/6.135%，支持本窗口上更灵活保护发布的经验价值。换成外部PIR候选后，完整投影对统一/两组收缩改善0.951%/0.899%，均在6条流中为正；系统层仅3/6条流更好。\n3. 非负精确包络相对全实数保守包络仅改善0.020%/0.026%，各仅3/6条流为正；DLinear整体略退化，不能主张该数据窗口证实非负几何有稳定精度优势。\n4. 相对各自未保护目标，Cov/ML的平均保护代价为44.920%/46.238%。未保护目标分别有270/342、262/342条节点序列至少一次越限；与之对应的保护实现均零越限。保护是有明显精度代价的约束，而非对未保护候选的普遍增益。\n5. 相对完整外部流程的改善较大，但候选构造也不同，不能全归因于保护。相对同Cov输入的受保护MinT，Cov平均退化0.073%、ML改善0.012%，基本持平。相对受保护固定专家，整体改善0.881%/0.965%；PatchTST系统层反而分别退化0.232%/0.685%，保留这一反例。\n6. Cov与ML精度接近；两种实现相对NNLS的早窗收益均成立。本轮只补齐早窗，尚未改写原文六基准汇总；若之后更新论文，应保留原注册网格，并单独标识这次回顾性扩展。\n\n## 8. 数值核验与复算范围\n\n完整原实现重放确认Cov和ML发布值逐值一致；未来标签扰动不会改变此前候选；24个新拟合阶段的实际超参数和最佳检查点均通过核对。24个新阶段均在上限前早停，最晚停止步数为PatchTST438、DLinear1308。完整42阶段中18阶段复用，预测逐值核验通过。\n\nCPOR两实现共864次评分发布没有共同收缩修补或额外求解尝试，存储舍入修补仍有发生；具体计数和幅度见CPOR_NUMERICAL_EVENTS.csv。不能把零越限解释成没有数值修补。\n\nPUBLICATION_TIMING.csv仅保留本轮运行记录，含每条保护循环均摊时间及可取得的动作内计时。Cov未另测动作内P95；目标生成不在该计时内。它不是新的跨方法正式效率基准。\n\n压缩包含已有预测、逐方法发布结果、上下文、数值检查脚本和汇总；选定神经模型检查点仍保存在本地runs目录，未放入精简数值包。解压后可直接运行`python check_bundle.py`复算指标及精确保护检查；该命令不重训模型。\n'''
    note=note.replace('これは','这是')
    p=H/'REPORT.md';text=p.read_text(encoding='utf8');p.write_text(text+note,encoding='utf8')
    js(H/'REPORTING_ADDITION_MANIFEST.json',dict(reason='Post-computation reporting and portable audit only; no model, candidate, publication, account or prediction changes.',sources={str(p):sha(p) for p in [Path(__file__),H/'check_bundle.py']},result_hashes_sha256=sha(H/'RESULT_HASHES.json')))
    print('REPORT_COMPLETE')
if __name__=='__main__':main()
