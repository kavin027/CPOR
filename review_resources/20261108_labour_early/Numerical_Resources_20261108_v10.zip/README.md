# OR2 v10: Labour early retrospective update

CURRENT_VERSION.json maps current tables and numerical files. Current six-benchmark results cover two windows per dataset, both backbones and three training runs. Window RMSEs are averaged before ratios. AEMO remains outside these six-dataset means and tests. No experiment was added during manuscript revision: this package incorporates the completed early-window experiment.

From the extracted root:

    python benchmark_update/check_current.py
    python labour_early/check_bundle.py
    python aemo_three_runs/check_current.py
    python aemo_three_runs/check_results.py --self-test

The first rebuilds the expanded aggregate tables and uncertainty. The second independently checks all 246 stored early-window results, including 138 protected trajectories, using the included observations and contexts. The AEMO checkers retain their previous scope. These commands do not retrain backbones or rerun projection optimizers. Neural checkpoints remain outside this numerical attachment.

Original v9 records, registrations and checkers are preserved. Their historical grid is 22 configurations; CURRENT_VERSION_v9_history.json and README_v8_history.md are provenance, not the current benchmark grid. DUET, COSA/robust/MCGrad, the same-state diagnostic, projection order and dedicated timing retain their original windows. The early extension's raw event/timing records are not a new dedicated runtime benchmark.
