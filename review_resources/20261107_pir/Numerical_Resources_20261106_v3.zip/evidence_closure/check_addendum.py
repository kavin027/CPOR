"""Aggregate reconstruction using the standard library; no private caches needed."""
from pathlib import Path
import csv,io,zipfile,json,hashlib,itertools,math,collections
H=Path(__file__).resolve().parent
Z=H.parent/'CPOR_CovML_Results_Minor_20261024.zip'
if not Z.exists():Z=H.parent/'cpor_cov_ml_20261024'/Z.name
def read(p):
 with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def mean(x):return sum(x)/len(x)
def close(a,b):assert math.isclose(float(a),float(b),rel_tol=1e-9,abs_tol=1e-8),(a,b)
def quantile(x,q):
 x=sorted(x);k=(len(x)-1)*q;i=int(k);return x[i]+(x[min(i+1,len(x)-1)]-x[i])*(k-i)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(Z)=='a75e6d4ee796925707886e51775275e42a10f5ccdc20ff5c68a754124c03a023'
with zipfile.ZipFile(Z) as z:
 names=z.namelist()
 def table(name):
  matched=[p for p in names if p==name or p.endswith('/'+name)];assert len(matched)==1,matched
  return list(csv.DictReader(io.StringIO(z.read(matched[0]).decode('utf-8-sig'))))
 raw=table('GROUP_RUN_RMSE.csv');domain=table('matched_envelope/analysis/ENVELOPE_GROUP_RUN.csv');times=table('timing_full/ISSUE_TIMES.csv')
values=collections.defaultdict(dict)
for r in raw:values[(r['dataset'],r['backbone'],r['seed'])][r['method']]=float(r['rmse'])
calc=[];draws=list(itertools.product(range(6),repeat=6));signs=list(itertools.product([-1,1],repeat=6))
def interval(g):
 x=[mean(g[k]) for k in sorted(g)];assert len(x)==6
 b=[mean([x[i] for i in d]) for d in draws]
 return x,quantile(b,.025),quantile(b,.975)
for impl,m in [('Cov','CovFullFix'),('ML','ProtectedMLPol')]:
 for comp in ['NNLS','ProCAST','PIR']:
  g=collections.defaultdict(list)
  for (d,b,s),v in values.items():g[d].append(100*(v[comp]-v[m])/v[comp])
  x,lo,hi=interval(g);p=mean([int(abs(mean([a*b for a,b in zip(sign,x)]))>=abs(mean(x))-1e-12) for sign in signs])
  calc.append(dict(implementation=impl,comparator=comp,mean=mean(x),ci_low=lo,ci_high=hi,p_raw=p,positive_datasets=sum(a>0 for a in x)))
order=sorted(range(6),key=lambda i:calc[i]['p_raw']);v=0
for j,i in enumerate(order):v=max(v,(6-j)*calc[i]['p_raw']);calc[i]['p_holm']=min(1,v)
v=1
for j in reversed(range(6)):
 i=order[j];v=min(v,6*calc[i]['p_raw']/(j+1));calc[i]['q_bh']=v
for a,b in zip(calc,read(H/'UNCERTAINTY.csv')):
 assert (a['implementation'],a['comparator'])==(b['implementation'],b['comparator'])
 for k in a:
  if k not in ['implementation','comparator']:close(a[k],b[k])
for row in read(H/'DOMAIN_INTERVALS.csv'):
 g=collections.defaultdict(list)
 for r in domain:
  if r['implementation']==row['implementation']:g[r['dataset']].append(float(r['gain_pct']))
 x,lo,hi=interval(g)
 for k,v in [('mean',mean(x)),('ci_low',lo),('ci_high',hi)]:close(v,row[k])
for r in read(H/'COST_SUMMARY.csv'):
 m,un=('CovFullFix','CovUnprotected') if r['implementation']=='Cov' else ('ProtectedMLPol','MLPol')
 x=sorted(100*(v[m]-v[un])/v[un] for v in values.values())
 for k,v in [('mean',mean(x)),('median',quantile(x,.5)),('trimmed_three_each_tail',mean(x[3:-3])),('minimum',min(x)),('maximum',max(x))]:close(v,r[k])
for r in read(H/'TIMING_TAILS.csv'):
 x=[1000*float(t['total_s']) for t in times if (t['dataset'],t['implementation'])==(r['dataset'],r['implementation'])]
 assert len(x)==int(r['releases']);close(quantile(x,.99),r['p99_ms']);close(max(x),r['maximum_ms'])
events=read(H/'EVENTS.csv');assert len(events)==9504
for r in read(H/'EVENT_SUMMARY.csv'):
 a=[e for e in events if (e['dataset'],e['implementation'])==(r['dataset'],r['implementation'])]
 assert len(a)==int(r['releases'])
 for col in ['collapsed','slsqp_fallback','guard_contraction','anchor_fallback','projection_exhaustion','clipped_coordinates','ulp_operations','clarabel_calls','clarabel_exceptions','slsqp_calls']:close(sum(int(e[col]) for e in a),r[col])
 close(sum(int(e['clarabel_calls'])>1 for e in a),r['retry_releases'])
 close(sum(int(e['clipped_coordinates'])>0 or int(e['ulp_operations'])>0 for e in a),r['coordinate_repair_releases'])
 for i in range(1,6):close(sum(int(e['accepted_attempt'])==i for e in a),r[f'accepted_attempt_{i}'])
 for col in ['clarabel_max_iter','slsqp_max_iter','coherence_max']:close(max(float(e[col]) for e in a),r[col])
 close(quantile([float(e['coherence_max']) for e in a],.95),r['coherence_p95'])
receipts=list((H/'runs').rglob('DONE.json'));assert len(receipts)==66
for f in receipts:
 r=json.loads(f.read_text());assert len(r['checks'])==2 and all(x['bitwise'] and x['max_abs_difference']==0 for x in r['checks'])
 assert sha(f.parent/'EVENTS.csv')==r['events_sha256'];assert sha(H/'replay_events.py')==r['driver_sha256']
mp=read(H/'M5_PATH_SENSITIVITY.csv');assert len(mp)==12
g=collections.defaultdict(list)
for r in mp:g[(r['backbone'],r['seed'])].append(r)
gains=[100*(mean([float(x['original_rmse']) for x in a])-mean([float(x['repaired_rmse']) for x in a]))/mean([float(x['original_rmse']) for x in a]) for a in g.values()]
summary=json.loads((H/'M5_PATH_SUMMARY.json').read_text())
close(mean(gains),summary['mean_group_gain_pct']);close(max(map(abs,gains)),summary['max_absolute_group_gain_pct'])
close(max(float(x['max_abs_publication_difference']) for x in mp),summary['max_abs_publication_difference'])
assert sum(int(x['node_envelope_checks']) for x in mp)==summary['exact_envelope_checks']==38016
assert sum(int(x['prefix_checks']) for x in mp)==summary['prefix_checks']==38016
matrix=read(H/'MATRIX_CHECKS.csv');assert len(matrix)==66 and all(int(x['zero_rows'])==0 and x['nonnegative']=='True' for x in matrix)
manifest=H/'MANIFEST_SHA256.json'
if manifest.exists():
 for name,digest in json.loads(manifest.read_text()).items():assert sha(H/name)==digest,name
print(json.dumps(dict(status='PASS',uncertainty_comparisons=6,bootstrap_draws=46656,sign_patterns=64,event_releases=9504,bitwise_receipts=132,m5_sensitivity_trajectories=12,scope='Recomputes aggregate arithmetic and validates stored receipts/hashes; does not re-execute input-level prediction or exact-rational audit without archived inputs.'),indent=2))
