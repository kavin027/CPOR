from pathlib import Path
import numpy as np,pandas as pd,json,hashlib,itertools
H=Path(__file__).resolve().parent
E=H.parent/'cpor_minor_covml_20261024/evidence'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw=pd.read_csv(E/'GROUP_RUN_RMSE.csv')
w=raw.pivot(index=['dataset','backbone','seed'],columns='method',values='rmse')
draws=np.array(list(itertools.product(range(6),repeat=6)))
signs=np.array(list(itertools.product([-1,1],repeat=6)))
def summary(g):
 x=g.groupby('dataset').gain_pct.mean().sort_index().to_numpy();assert len(x)==6
 boot=x[draws].mean(axis=1)
 p=float(np.mean(abs((signs*x).mean(axis=1))>=abs(x.mean())-1e-12))
 return dict(mean=float(x.mean()),ci_low=float(np.quantile(boot,.025)),ci_high=float(np.quantile(boot,.975)),p_raw=p,positive_datasets=int(sum(x>0)))
rows=[];details=[]
for impl,method in [('Cov','CovFullFix'),('ML','ProtectedMLPol')]:
 for comp in ['NNLS','ProCAST','PIR']:
  g=(100*(w[comp]-w[method])/w[comp]).rename('gain_pct').reset_index()
  g['implementation']=impl;g['comparator']=comp;details.append(g)
  rows.append(dict(implementation=impl,comparator=comp,**summary(g)))
out=pd.DataFrame(rows);p=out.p_raw.to_numpy();order=np.argsort(p);m=len(p)
holm=np.minimum(1,np.maximum.accumulate(p[order]*(m-np.arange(m))))
bh=np.minimum(1,np.minimum.accumulate((p[order]*m/(np.arange(m)+1))[::-1])[::-1])
out.loc[order,'p_holm']=holm;out.loc[order,'q_bh']=bh
out.to_csv(H/'UNCERTAINTY.csv',index=False)
pd.concat(details).to_csv(H/'PAIRED_EFFECTS.csv',index=False)
domain=pd.read_csv(E/'matched_envelope/analysis/ENVELOPE_GROUP_RUN.csv')
d=[]
for impl,g in domain.groupby('implementation'):
 r=summary(g);r.pop('p_raw');d.append(dict(implementation=impl,**r))
pd.DataFrame(d).to_csv(H/'DOMAIN_INTERVALS.csv',index=False)
# Protection costs: one observation per dataset/backbone, averaged across runs.
c=[]
for impl,protected,unprotected in [('Cov','CovFullFix','CovUnprotected'),('ML','ProtectedMLPol','MLPol')]:
 g=(100*(w[protected]-w[unprotected])/w[unprotected]).rename('cost_pct').reset_index()
 a=g.cost_pct.to_numpy()
 c.append(dict(implementation=impl,comparisons=len(a),mean=float(a.mean()),median=float(np.median(a)),trimmed_three_each_tail=float(np.sort(a)[3:-3].mean()),minimum=float(a.min()),maximum=float(a.max())))
pd.DataFrame(c).to_csv(H/'COST_SUMMARY.csv',index=False)
t=pd.read_csv(E/'timing_full/ISSUE_TIMES.csv')
tails=[]
for (dataset,impl),g in t.groupby(['dataset','implementation']):
 tails.append(dict(dataset=dataset,implementation=impl,releases=len(g),p99_ms=float(g.total_s.quantile(.99)*1000),maximum_ms=float(g.total_s.max()*1000)))
pd.DataFrame(tails).to_csv(H/'TIMING_TAILS.csv',index=False)
(H/'STAT_PROVENANCE.json').write_text(json.dumps(dict(design_sha256=sha(H/'DESIGN.md'),driver_sha256=sha(__file__),inputs={str(f.relative_to(E)):sha(f) for f in [E/'GROUP_RUN_RMSE.csv',E/'matched_envelope/analysis/ENVELOPE_GROUP_RUN.csv',E/'timing_full/ISSUE_TIMES.csv']},clusters=6,bootstrap_draws=len(draws),sign_patterns=len(signs),family_size=m,percentile_method='numpy linear',no_temporal_or_population_guarantee=True),indent=2))
print(out.to_string(index=False));print(pd.DataFrame(d).to_string(index=False));print(pd.DataFrame(c).to_string(index=False))
