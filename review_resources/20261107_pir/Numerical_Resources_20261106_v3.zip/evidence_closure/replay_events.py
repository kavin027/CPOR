"""Arithmetic-neutral observation of the original protected release functions."""
from pathlib import Path
import ast, inspect, textwrap, sys, json, hashlib, argparse, time
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
H=Path(__file__).resolve().parent; O=H.parent; R=O.parent
sys.path.insert(0,str(O/'c0_seed_validation_20261016'))
import common, engine, rollout, precision_release
import cvxpy as cp
old=common.old
INDEX=O/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2),encoding='utf-8')
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files if k!='dates'}
CURRENT=None; EVENTS=[]
def begin(i,t):
 global CURRENT
 CURRENT=dict(issue=i+1,clarabel_calls=0,clarabel_exceptions=0,clarabel_max_iter=0,slsqp_calls=0,slsqp_max_iter=0,qp_calls=0,collapsed=0,accepted_attempt=0,slsqp_fallback=0,clipped_coordinates=0,ulp_operations=0,guard_calls=0,guard_contraction=0,anchor_fallback=0,projection_exhaustion=0,guard_factor=1.)
def finish(p,u,S):
 CURRENT['coherence_max']=float(np.max(abs(p-u@S.T)))
 EVENTS.append(dict(CURRENT))
def clipped(p,pp):CURRENT['clipped_coordinates']+=int(np.count_nonzero(p!=pp))
def ulp():CURRENT['ulp_operations']+=1
def wrap_guard(fn):
 def observed(*a,**kw):
  result=fn(*a,**kw);factor=float(result[2])
  CURRENT['guard_calls']+=1;CURRENT['guard_factor']=factor
  CURRENT['guard_contraction']+=int(factor<1);CURRENT['anchor_fallback']+=int(factor==0)
  return result
 return observed
original_cp=cp.Problem.solve
def cp_solve(self,*a,**kw):
 if CURRENT is not None:CURRENT['clarabel_calls']+=1
 try:return original_cp(self,*a,**kw)
 except Exception:
  if CURRENT is not None:CURRENT['clarabel_exceptions']+=1
  raise
 finally:
  if CURRENT is not None and self.solver_stats is not None:
   CURRENT['clarabel_max_iter']=max(CURRENT['clarabel_max_iter'],int(self.solver_stats.num_iters or 0))
cp.Problem.solve=cp_solve
original_min=engine.minimize
def observed_min(*a,**kw):
 result=original_min(*a,**kw)
 if CURRENT is not None:
  CURRENT['slsqp_calls']+=1;CURRENT['slsqp_max_iter']=max(CURRENT['slsqp_max_iter'],int(result.nit))
 return result
engine.minimize=observed_min
original_qp=old.SafeProjection.solve
def qp_solve(self,b,m,ub,lo,hi):
 CURRENT['qp_calls']+=1;CURRENT['collapsed']+=int(not np.any(hi>lo))
 try:result=original_qp(self,b,m,ub,lo,hi)
 except Exception:
  CURRENT['projection_exhaustion']+=1;raise
 info=result[2]
 CURRENT['slsqp_fallback']+=int(info.get('solver')=='SLSQP_checked_fallback')
 if not CURRENT['slsqp_fallback']:CURRENT['accepted_attempt']=CURRENT['clarabel_calls']
 return result
old.SafeProjection.solve=qp_solve
class Counters(ast.NodeTransformer):
 def visit_Assign(self,node):
  node=self.generic_visit(node);src=ast.unparse(node)
  if src.startswith('pp = np.clip('):return [node,*ast.parse('__clipped(p,pp)').body]
  if 'np.nextafter(' in src:return [node,*ast.parse('__ulp()').body]
  return node
def clone(fn,outer=False,extra=None):
 tree=Counters().visit(ast.parse(textwrap.dedent(inspect.getsource(fn))))
 f=tree.body[0]
 if outer:
  loop=next(x for x in f.body if isinstance(x,ast.For))
  loop.body=ast.parse('__begin(i,t)').body+loop.body+ast.parse('__finish(p,u,x["S"])').body
 ns=dict(fn.__globals__);ns.update(__clipped=clipped,__ulp=ulp,__begin=begin,__finish=finish)
 for name in ['guard','numerical_guard']:
  if name in ns:ns[name]=wrap_guard(ns[name])
 if extra:ns.update(extra)
 ast.fix_missing_locations(tree);exec(compile(tree,inspect.getsourcefile(fn),'exec'),ns)
 return ns[fn.__name__]
one=clone(old.one_action)
action=clone(rollout.action)
cov_old=clone(old.cov.release,True,dict(action=action))
cov_repaired=clone(precision_release.release_repaired,True)
def ml(x,target):
 A=[old.Fraction(0) for _ in x['v']];qp=old.SafeProjection(x['S'],x['v']);rows=[];us=[]
 for j,t in enumerate(range(36,108)):
  begin(j,t)
  if j:A=old.advance(A,x['b'][t-1],rows[-1],x['truth'][t-1])
  p,u,info=one(qp,x['S'],x['b'][t],x['ub'][t],target[j],A)
  if not CURRENT['qp_calls']:CURRENT['collapsed']=1
  assert old.certified(x['b'][t],p,A,old.RR,old.K,True)
  finish(p,u,x['S']);rows.append(p);us.append(u)
 old.advance(A,x['b'][-1],rows[-1],x['truth'][-1])
 return dict(pred=np.asarray(rows),witness=np.asarray(us))
def run(row):
 global EVENTS,CURRENT
 d=Path(row.source);x=load(d/'endpoints.npz');c=load(d/'contexts.npz');controls=load(d/'controls.npz')
 dest=H/'runs'/row.dataset/row.backbone/row.window/str(row.seed)
 if (dest/'DONE.json').exists():return
 checks=[];allrows=[]
 for impl in ['Cov','ML']:
  EVENTS=[];CURRENT=None
  target=c['D'][36:] if impl=='Cov' else controls['MLPol']
  expected=load(d/'CovFullFix.npz')['pred'] if impl=='Cov' else controls['ProtectedMLPol']
  out=(cov_old(x,target,'CovFull') if row.dataset=='M5' else cov_repaired(x,target,'Full')) if impl=='Cov' else ml(x,target)
  equal=np.array_equal(out['pred'],expected)
  check=dict(implementation=impl,bitwise=bool(equal),max_abs_difference=float(np.max(abs(out['pred']-expected))))
  checks.append(check)
  assert equal,check
  assert len(EVENTS)==72
  for event in EVENTS:allrows.append(dict(dataset=row.dataset,backbone=row.backbone,window=row.window,seed=int(row.seed),implementation=impl,**event))
 dest.mkdir(parents=True,exist_ok=True);pd.DataFrame(allrows).to_csv(dest/'EVENTS.csv',index=False)
 dump(dest/'DONE.json',dict(checks=checks,driver_sha256=sha(__file__),inputs={str(d/f):sha(d/f) for f in ['endpoints.npz','contexts.npz','controls.npz','CovFullFix.npz']},events_sha256=sha(dest/'EVENTS.csv')))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int);args=ap.parse_args();idx=pd.read_csv(INDEX)
 sources=[inspect.getsourcefile(f) for f in [original_qp,old.one_action,old.cov.release,precision_release.release_repaired,rollout.action,engine.numerical_guard,engine.SafeProjection.solve]]
 dump(H/'REPLAY_PROVENANCE.json',dict(index_sha256=sha(INDEX),design_sha256=sha(H/'DESIGN.md'),sources={str(f):sha(f) for f in sources},python=sys.version))
 with threadpool_limits(1):
  for i,row in idx.iterrows():
   if args.limit is not None and i>=args.limit:break
   start=time.perf_counter();run(row);print(f'{i+1}/{len(idx)} {row.dataset} {row.backbone} {row.window} {row.seed}: {time.perf_counter()-start:.2f}s',flush=True)
 if args.limit is None:
  fs=list((H/'runs').rglob('EVENTS.csv'));assert len(fs)==66
  pd.concat([pd.read_csv(f) for f in fs],ignore_index=True).to_csv(H/'EVENTS.csv',index=False)
if __name__=='__main__':main()
