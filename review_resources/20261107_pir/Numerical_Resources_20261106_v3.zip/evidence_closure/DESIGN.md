# Evidence closure, fixed before computation

No new backbone training or target selection. Preserve all original results.

## Numerical events
Replay the 66 archived configurations for each Cov and ML implementation (132 trajectories, 72 scored issues each). Use archived targets, references, observations and variances. Retain the original M5 Cov release path. Instrument arithmetic-neutral counters around the original solver and repair functions. Require bitwise equality of replayed publications to stored publications; report any exceptions, never replace regenerated output with stored output to force agreement.

Count per scored release: collapsed-interval bypass, Clarabel attempts and accepted attempt, SLSQP invocation, coordinate clipping, nextafter coordinate operations, guard invocation, guard contraction (factor below one), anchor fallback (guard returns factor zero), and projection exhaustion. Record solver iterations. These events can overlap. A nonzero clipping/repair count is not a solver failure. Count actual attempts, not attempts inferred from the success flag. No wall-time timeout is introduced. The replay is an event audit, not a new timing benchmark.

## Uncertainty
Use GROUP_RUN_RMSE.csv in the unchanged Minor evidence archive. Within each training run and dataset-backbone group compute 100*(comparator-implementation)/comparator. Average both backbones and three runs within each dataset. Six datasets, not twelve backbone groups or 36 runs, are the resampling units. Enumerate all 6^6 ordered empirical cluster bootstrap draws; report percentile 95% intervals. These conditional empirical intervals describe benchmark heterogeneity under exchangeable independent dataset clusters and do not establish external generalization.

Primary test family: Cov and ML against NNLS, adapted ProCAST and PIR (six comparisons). Enumerate all 2^6 signs for the absolute equal-dataset mean; two-sided sign-flip p values require independent symmetric dataset effects under the null. Apply Holm familywise and Benjamini-Hochberg FDR adjustment to this fixed six-comparison family. Report all tests regardless of result. Matched nonnegative/all-real comparison receives descriptive cluster intervals only, not an additional selected significance claim.

Reuse existing issue timing records for P99/max; they include recorded retries but impose no timeout. Reuse complete matched-domain audits for coherence residual summaries. No unrecorded peak-memory measurement is invented. The three initialization means/SD remain separate from dataset-cluster intervals.
