"""Sensitivity replay of the same archived Cov targets with the repaired path."""
import replay_events as e
import pandas as pd,numpy as np,json
from threadpoolctl import threadpool_limits
H=e.H
design='Only M5 Cov publication wrapper changes from archived earlier path to release_repaired; same targets, reference, chronological labels, variances and initial allowance. Each path maintains its own realized allowance. This is a full trajectory sensitivity, not a fixed-state causal effect. No retraining or retuning; original results remain primary.'
(H/'M5_PATH_DESIGN.txt').write_text(design)
rows=[]
with threadpool_limits(1):
 for row in pd.read_csv(e.INDEX).query("dataset=='M5'").itertuples():
  d=e.Path(row.source);x=e.load(d/'endpoints.npz');target=e.load(d/'contexts.npz')['D'][36:];original=e.load(d/'CovFullFix.npz')['pred']
  e.EVENTS=[];out=e.cov_repaired(x,target,'Full');pred=out['pred'];A=[e.old.Fraction(0) for _ in x['v']]
  for j,t in enumerate(range(36,108)):
   assert e.old.certified(x['b'][t],pred[j],A,e.old.RR,e.old.K,True)
   A=e.old.advance(A,x['b'][t],pred[j],x['truth'][t]);assert min(A)>=0
  metric=lambda p:float(np.sqrt(((p-x['truth'][36:])**2).mean(axis=0)).mean())
  mo,mn=metric(original),metric(pred)
  rows.append(dict(dataset='M5',backbone=row.backbone,window=row.window,seed=row.seed,original_rmse=mo,repaired_rmse=mn,gain_pct=100*(mo-mn)/mo,max_abs_publication_difference=float(abs(original-pred).max()),node_envelope_checks=pred.size,prefix_checks=pred.size,guard_contractions=sum(q['guard_contraction'] for q in e.EVENTS),coordinate_repair_releases=sum(q['clipped_coordinates']>0 or q['ulp_operations']>0 for q in e.EVENTS),anchor_fallbacks=sum(q['anchor_fallback'] for q in e.EVENTS)))
  dest=H/'m5_path'/row.backbone/row.window/str(row.seed);dest.mkdir(parents=True,exist_ok=True);np.savez_compressed(dest/'REPAIRED.npz',pred=pred,witness=out['witness'])
  e.dump(dest/'PROVENANCE.json',dict(driver_sha256=e.sha(__file__),inputs={str(d/f):e.sha(d/f) for f in ['endpoints.npz','contexts.npz','CovFullFix.npz']},output_sha256=e.sha(dest/'REPAIRED.npz')))
out=pd.DataFrame(rows);out.to_csv(H/'M5_PATH_SENSITIVITY.csv',index=False)
g=out.groupby(['backbone','seed'])[['original_rmse','repaired_rmse']].mean();gain=100*(g.original_rmse-g.repaired_rmse)/g.original_rmse
e.dump(H/'M5_PATH_SUMMARY.json',dict(scope=design,trajectories=len(out),mean_group_gain_pct=float(gain.mean()),max_absolute_group_gain_pct=float(abs(gain).max()),max_abs_publication_difference=float(out.max_abs_publication_difference.max()),exact_envelope_checks=int(out.node_envelope_checks.sum()),prefix_checks=int(out.prefix_checks.sum()),anchor_fallbacks=int(out.anchor_fallbacks.sum())))
print(out.to_string(index=False));print((H/'M5_PATH_SUMMARY.json').read_text())
