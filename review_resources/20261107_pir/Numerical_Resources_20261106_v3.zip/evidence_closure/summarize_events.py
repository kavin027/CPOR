from pathlib import Path
import json,hashlib
import pandas as pd,numpy as np
H=Path(__file__).resolve().parent
x=pd.read_csv(H/'EVENTS.csv');assert len(x)==9504
rows=[]
for (dataset,impl),g in x.groupby(['dataset','implementation']):
 r=dict(dataset=dataset,implementation=impl,releases=len(g))
 for col in ['collapsed','slsqp_fallback','guard_contraction','anchor_fallback','projection_exhaustion']:
  r[col]=int(g[col].sum())
 r['coordinate_repair_releases']=int(((g.clipped_coordinates>0)|(g.ulp_operations>0)).sum())
 r['clipped_coordinates']=int(g.clipped_coordinates.sum());r['ulp_operations']=int(g.ulp_operations.sum())
 r['retry_releases']=int((g.clarabel_calls>1).sum())
 for attempt in range(1,6):r[f'accepted_attempt_{attempt}']=int((g.accepted_attempt==attempt).sum())
 for col in ['clarabel_calls','clarabel_exceptions','slsqp_calls']:
  r[col]=int(g[col].sum())
 for col in ['clarabel_max_iter','slsqp_max_iter','coherence_max']:r[col]=float(g[col].max())
 r['coherence_p95']=float(g.coherence_max.quantile(.95))
 rows.append(r)
out=pd.DataFrame(rows);out.to_csv(H/'EVENT_SUMMARY.csv',index=False)
checks=[]
for f in (H/'runs').rglob('DONE.json'):
 j=json.loads(f.read_text());assert all(a['bitwise'] for a in j['checks'])
 assert hashlib.sha256((f.parent/'EVENTS.csv').read_bytes()).hexdigest()==j['events_sha256'];checks+=j['checks']
assert len(checks)==132
summary=dict(trajectories=132,releases=9504,bitwise_identical=len(checks),projection_exhaustion=int(x.projection_exhaustion.sum()),slsqp_fallback=int(x.slsqp_fallback.sum()),anchor_fallback=int(x.anchor_fallback.sum()),guard_contraction=int(x.guard_contraction.sum()),coordinate_repair_releases=int(((x.clipped_coordinates>0)|(x.ulp_operations>0)).sum()),retry_releases=int((x.clarabel_calls>1).sum()),accepted_attempt_histogram={str(i):int((x.accepted_attempt==i).sum()) for i in range(6)},max_clarabel_iterations=int(x.clarabel_max_iter.max()),max_slsqp_iterations=int(x.slsqp_max_iter.max()),coherence_max=float(x.coherence_max.max()))
(H/'REPLAY_SUMMARY.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2));print(out.to_string(index=False))
