"""Verify reported paired effects and prefix counts from the included window records."""
from pathlib import Path
from collections import defaultdict
import csv
from statistics import mean
from math import isclose

root=Path(__file__).resolve().parent
def read(name):
    with (root/name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

windows=read("windows.csv")
counts=read("audit.csv")
summary=read("paired_summary.csv")
group_rows=read("groups.csv")
for row in group_rows:
    stream=[r for r in windows if all(r[k]==row[k] for k in ("dataset","backbone","scope"))]
    assert len(stream)==(1 if row["dataset"]=="Labour" else 2)
    for method in ("Cov","ML","Li"):
        if method=="Li" and row["dataset"] in ("RH","ECommerce"):
            assert row[method]=="" and all(not r[method] for r in stream)
        else:
            assert isclose(mean(float(r[method]) for r in stream), float(row[method]),rel_tol=1e-12)
for row in summary:
    method=row["method"]
    groups=defaultdict(list)
    for r in windows:
        if r["scope"]==row["scope"] and r["Li"]:
            groups[r["dataset"],r["backbone"]].append(100*(1-float(r[method])/float(r["Li"])))
    assert len(groups)==int(row["groups"])
    assert sum(mean(v)>0 for v in groups.values())==int(row["wins"])
    assert isclose(mean(mean(v) for v in groups.values()),float(row["mean_pct"]),abs_tol=1e-10)
    if row["scope"]=="all":
        assert all(v>0 for vs in groups.values() for v in vs)
        assert sum(map(len,groups.values()))==14 and len(groups)==8
        assert round(float(row["mean_pct"]),2)=={"Cov":4.31,"ML":4.27}[method]
for method in ("Cov","ML","Li"):
    paired=[r for r in counts if r["dataset"] not in ("RH","ECommerce") and r["method"]==method]
    assert sum(int(r["nodes"]) for r in paired)==1914
    assert sum(int(r["ever"]) for r in paired)==(1311 if method=="Li" else 0)
assert len(read("M5_R_check.csv"))==4
print("Li preprint: group RMSE, all paired summaries and prefix counts verified.")
