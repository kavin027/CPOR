from fractions import Fraction
import hashlib
from pathlib import Path
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
OUT=HERE.parent
INDEX=OUT/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv'
MAP=OUT/'kais_review_v2_revision_20261017/Online_Resource_3/review_evidence/node_map.csv'
GRID=np.r_[0.,10.**np.arange(-1,5.01,.25)]

def geometry(s):
    n,b=s.shape
    a=n-b
    np.testing.assert_array_equal(s[a:],np.eye(b))
    assert np.all(s[0]==1) and np.isin(s,[0,1]).all()
    v=np.column_stack([np.eye(a),-s[:a]])
    transforms=np.broadcast_to(np.eye(a),(b,a,a)).copy()
    for i in range(b):
        collateral=s[:a,i]==0
        transforms[i,collateral]*=-1
        transforms[i,collateral,0]+=1
    # Each transform is its own inverse and preserves full row rank.
    np.testing.assert_array_equal(transforms@transforms,np.broadcast_to(np.eye(a),transforms.shape))
    np.testing.assert_array_equal(v@s,np.zeros((a,b)))
    return v,transforms

def estimate_sigma(res):
    t=len(res)
    norm=np.sqrt(np.mean(res**2,axis=0))
    x=res[:,norm>0]/norm[norm>0]
    cor=x.T@x/t
    variance=((x*x).T@(x*x)-t*cor**2)/(t*(t-1))
    np.fill_diagonal(cor,0)
    np.fill_diagonal(variance,0)
    den=(cor**2).sum()
    intensity=np.clip(variance.sum()/den,0,1) if den else 1.
    cov=np.cov(res,rowvar=False)
    return intensity*np.diag(np.diag(cov))+(1-intensity)*cov

def mappings(res,s,v,tr,lambdas):
    # Block diagonal of the authors' Qh, reduced by Z before solving.
    b,a=tr.shape[:2]
    sigma=estimate_sigma(res)
    vs=v@sigma
    scale=(s*s).sum(axis=0)
    h=(tr@(vs@v.T)@tr.transpose(0,2,1))*scale[:,None,None]
    half_g=(tr@vs[:,a:].T[:,:,None])[:,:,0]*scale[:,None]
    eig,vec=np.linalg.eigh((h+h.transpose(0,2,1))*.5)
    values=lambdas[:,None,None]
    rhs=-half_g[None,:,:]+values/(a+1)
    denom=eig[None,:,:]+values
    # R's fallback clips eigenvalues only when the unregularized solve fails.
    ill=eig[:,0]<=np.finfo(float).eps*np.maximum(eig[:,-1],1)
    if np.any(lambdas==0):
        denom[np.ix_(lambdas==0,ill,np.arange(a))]=np.maximum(eig[ill],1e-8)
    assert (denom>0).all()
    coeff=np.einsum('bij,lbi->lbj',vec,rhs)/denom
    rho=np.einsum('bij,lbj->lbi',vec,coeff)
    return np.einsum('lbi,bij->lbj',rho,tr)

def bottom(raw,v,w):
    return raw[None,:,len(v):]+np.einsum('ta,lba->ltb',raw@v.T,w)

def prefix_counts(y,anchor,p):
    ratio=Fraction(40401,40000)
    bad=np.zeros(y.shape[1],bool)
    allowance=[Fraction(0)]*len(bad)
    for obs,ref,released in zip(y,anchor,p):
        for i,(yi,bi,pi) in enumerate(zip(obs,ref,released)):
            yy,bb,pp=map(Fraction.from_float,(float(yi),float(bi),float(pi)))
            allowance[i]+=ratio*(bb-yy)**2-(pp-yy)**2
            bad[i]|=allowance[i]<0
    return int(bad.sum())

def main():
    levels=pd.read_csv(MAP)
    grid=pd.read_csv(INDEX).query("seed==42 and dataset in ['Labour','Wiki2','Traffic']")
    assert len(grid)==10
    splits=pd.read_csv(HERE/'splits.csv',header=None)
    splits={int(row.iloc[0]):row.iloc[1:].dropna().to_numpy(int)-1 for _,row in splits.iterrows()}
    receipts,metrics=[],[]
    for rec in grid.itertuples():
        src=Path(rec.source); stem=f'{rec.dataset}_{rec.backbone}_{rec.window}'
        key=dict(dataset=rec.dataset,backbone=rec.backbone,window=rec.window)
        files=[src/f for f in ['endpoints.npz','CovFullFix.npz','controls.npz']]
        with np.load(files[0]) as z:
            raw,y,s,ref=(z[name] for name in ['raw','truth','S','b'])
        with np.load(files[1]) as z: cov=z['pred']
        with np.load(files[2]) as z: ml=z['ProtectedMLPol']
        v,tr=geometry(s)
        preds=[]; selected=[]; checks=[]
        for t in range(36,108):
            perm=splits[t]
            np.testing.assert_array_equal(np.sort(perm),np.arange(t))
            train,val=np.split(perm,[int(.8*t)])
            res=y[:t]-raw[:t]
            ws=mappings(res[train],s,v,tr,GRID)
            vr=bottom(raw[val],v,ws)@s.T
            scores=np.sqrt(((vr-y[val])**2).mean(axis=1)).mean(axis=1)
            lam=GRID[np.argmin(scores)]
            selected.append(lam)
            w=mappings(res,s,v,tr,np.array([lam]))
            p=(bottom(raw[t:t+1],v,w)@s.T)[0,0]
            assert np.isfinite(p).all()
            preds.append(p)
            if t==36:
                checks.append(w[0]@v+np.eye(len(p))[len(v):])
        li=np.array(preds)
        dest=HERE/'releases'; dest.mkdir(exist_ok=True)
        np.savez_compressed(dest/(stem+'.npz'),li=li,lambda_values=selected,first_map=checks[0])
        nodes=levels[levels.dataset==rec.dataset]
        for method,p in [('Li',li),('Cov',cov),('ML',ml)]:
            assert p.shape==y[36:].shape
            e=np.sqrt(np.mean((p-y[36:])**2,axis=0))
            coherence=np.max(np.abs(p-p[:,-s.shape[1]:]@s.T))
            np.testing.assert_allclose(p,p[:,-s.shape[1]:]@s.T,atol=2e-6,rtol=1e-8)
            receipts.append(dict(**key,method=method,nodes=len(e),ever=prefix_counts(y[36:],ref[36:],p),max_coherence_error=coherence,negative_releases=int((p<0).sum()),**{f.stem+'_sha256':hashlib.sha256(f.read_bytes()).hexdigest() for f in files}))
            for level in ['all','system','bottom','region']:
                ix=nodes[nodes.scopes.str.split(';').map(lambda ss:level in ss)].node.to_numpy(int)
                if len(ix): metrics.append(dict(**key,method=method,scope=level,rmse=e[ix].mean()))
        print(stem,'done',flush=True)
    cells=pd.DataFrame(metrics).pivot(index=['scope','dataset','backbone','window'],columns='method',values='rmse')
    for m in ['Cov','ML']: cells[m+'_gain_pct']=100*(1-cells[m]/cells.Li)
    cells.to_csv(HERE/'cells.csv')
    groups=cells.groupby(level=['scope','dataset','backbone']).mean()
    groups.to_csv(HERE/'groups.csv')
    pd.DataFrame(receipts).to_csv(HERE/'audit.csv',index=False)
    print(groups.loc['all'])
if __name__=='__main__': main()
