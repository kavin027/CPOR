from pathlib import Path
import hashlib
import sys
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
PILOT=HERE.parent/'cpor_li_preprint_20261106'
sys.path.insert(0,str(PILOT))
import paired

KEY=['dataset','backbone','window']
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def run_new(raw,y,s,splits,path):
    v,tr=paired.geometry(s)
    preds=[]; selected=[]
    for t in range(36,108):
        perm=splits[t]
        np.testing.assert_array_equal(np.sort(perm),np.arange(t))
        train,val=np.split(perm,[int(.8*t)])
        res=y[:t]-raw[:t]
        weights=paired.mappings(res[train],s,v,tr,paired.GRID)
        validation=paired.bottom(raw[val],v,weights)@s.T
        scores=np.sqrt(((validation-y[val])**2).mean(axis=1)).mean(axis=1)
        lam=paired.GRID[np.argmin(scores)]
        w=paired.mappings(res,s,v,tr,np.array([lam]))
        preds.append((paired.bottom(raw[t:t+1],v,w)@s.T)[0,0])
        selected.append(lam)
        if t==36: first_map=w[0]@v+np.eye(len(s))[len(v):]
    path.parent.mkdir(exist_ok=True)
    np.savez_compressed(path,li=np.array(preds),lambda_values=selected,first_map=first_map)

def main():
    grid=pd.read_csv(paired.INDEX).query('seed==42')
    assert len(grid)==22 and not grid.duplicated(KEY).any()
    old=pd.read_csv(PILOT/'audit.csv').set_index(KEY+['method'])
    levels=pd.read_csv(paired.MAP)
    split_rows=pd.read_csv(PILOT/'splits.csv',header=None)
    splits={int(row.iloc[0]):row.iloc[1:].dropna().to_numpy(int)-1 for _,row in split_rows.iterrows()}
    metrics=[]; audit=[]; receipt=[]
    for rec in grid.itertuples():
        k=tuple(getattr(rec,col) for col in KEY)
        key=dict(zip(KEY,k)); stem='_'.join(k)+'.npz'
        src=Path(rec.source)
        files=[src/name for name in ['endpoints.npz','CovFullFix.npz','controls.npz']]
        hashes={f.stem+'_sha256':sha(f) for f in files}
        with np.load(files[0]) as z: raw,y,s,anchor=(z[name] for name in ['raw','truth','S','b'])
        with np.load(files[1]) as z: cov=z['pred']
        with np.load(files[2]) as z: ml=z['ProtectedMLPol']
        n,b=s.shape
        assert raw.shape==y.shape==anchor.shape==(108,n)
        compatible=n>b and np.array_equal(s[-b:],np.eye(b)) and np.all(s[0]==1)
        rank=np.linalg.matrix_rank(s)
        predictions={'Cov':cov,'ML':ml}
        li_path=None
        if (PILOT/'releases'/stem).exists():
            status='reused pilot'
            assert compatible and k+('Li',) in old.index
            for h,v in hashes.items(): assert old.loc[k+('Li',),h]==v
            li_path=PILOT/'releases'/stem
        elif compatible:
            assert rec.dataset=='M5'
            status='new M5'
            li_path=HERE/'releases'/stem
            run_new(raw,y,s,splits,li_path)
        else:
            assert n==rank and n<b and rec.dataset in ['RH','ECommerce']
            status='not applicable: missing observed bottom forecasts'
        if li_path:
            with np.load(li_path) as z: predictions['Li']=z['li']
        receipt.append(dict(**key,source=str(src),status=status,n=n,b=b,rank=rank,li_path=str(li_path or ''),li_sha256=sha(li_path) if li_path else '',**hashes))
        nodes=levels[levels.dataset==rec.dataset].sort_values('node')
        np.testing.assert_array_equal(nodes.node,np.arange(n))
        scope_masks={scope:nodes.scopes.str.split(';').map(lambda tags:scope in tags).to_numpy() for scope in ('all','system','bottom','region','state','store')}
        if compatible: scope_masks['middle']=~(scope_masks['system']|scope_masks['bottom'])
        if rec.dataset=='RH': scope_masks['non_system_observed']=~scope_masks['system']
        for m,p in predictions.items():
            assert p.shape==(72,n) and np.isfinite(p).all()
            if compatible: np.testing.assert_allclose(p,p[:,-b:]@s.T,rtol=1e-8,atol=2e-6)
            ever=paired.prefix_counts(y[36:],anchor[36:],p)
            if k+(m,) in old.index: assert ever==old.loc[k+(m,),'ever']
            audit.append(dict(**key,method=m,nodes=n,ever=ever,negative_entries=int((p<0).sum())))
            error=np.sqrt(((p-y[36:])**2).mean(axis=0))
            for scope,mask in scope_masks.items():
                if mask.any(): metrics.append(dict(**key,scope=scope,method=m,rmse=error[mask].mean()))
        print(*k,status,flush=True)
    wide=pd.DataFrame(metrics).pivot(index=KEY+['scope'],columns='method',values='rmse')
    for m in ['Cov','ML']: wide[m+'_gain_pct']=100*(1-wide[m]/wide.Li)
    for row in pd.read_csv(PILOT/'cells.csv').itertuples():
        actual=wide.loc[(row.dataset,row.backbone,row.window,row.scope)]
        for col in wide.columns: np.testing.assert_allclose(actual[col],getattr(row,col),rtol=1e-12,atol=1e-12)
    wide.to_csv(HERE/'windows.csv')
    groups=wide.groupby(level=['dataset','backbone','scope']).mean()
    groups.to_csv(HERE/'groups.csv')
    audits=pd.DataFrame(audit); audits.to_csv(HERE/'audit.csv',index=False)
    audits.groupby(['dataset','method'])[['ever','nodes']].sum().to_csv(HERE/'protection_by_dataset.csv')
    pd.DataFrame(receipt).to_csv(HERE/'streams.csv',index=False)
    rows=[]
    for scope,sub in groups.dropna(subset=['Li']).groupby(level='scope'):
        for m in ['Cov','ML']:
            vals=sub[m+'_gain_pct']
            rows.append(dict(scope=scope,method=m,groups=len(vals),wins=(vals>0).sum(),mean_pct=vals.mean(),median_pct=vals.median()))
    pd.DataFrame(rows).to_csv(HERE/'paired_summary.csv',index=False)
if __name__=='__main__': main()
