from run_factor import HERE,SIX,p as paired,np,pd,Path
PILOT=paired.HERE
import os, subprocess
import tempfile
r=PILOT/'runtime/R/app/bin/x64/Rscript.exe'
template=(PILOT/'full_first.R').read_text(encoding='utf-8-sig')
functions=(PILOT/'parity.R').read_text(encoding='utf-8-sig').split('out <- list()')[0]
functions=functions.replace('author/main_experiment.R',(PILOT/'author/main_experiment.R').as_posix())
program=functions+'\nd<-\u0022.\u0022\nS<-readmat'+template.split('S<-readmat',1)[1]
program=program.replace('parity/smoke_', 'smoke_').replace('parity/full_first_release.csv','check.csv')
program="source("+repr((HERE/"preprint_covEstimation.R").as_posix())+")\n"+program.replace('"shr"','"fac"')
program=program.replace('out<-data.frame(chosen=', 'py_pred<-as.numeric(readmat("smoke_first.csv")); abs_delta<-abs(c(p)-py_pred); scaled<-max(abs_delta/(1+abs(c(p)))); out<-data.frame(max_scaled_diff=scaled,chosen=').replace('diff<1e-6','all(abs_delta <= 1e-6 + 1e-9*abs(c(p)))')
rows=[]
for rec in pd.read_csv(paired.INDEX).query("seed==42 and dataset in ['Labour','M5','Wiki2','Traffic']").itertuples():
    stem=f'{rec.dataset}_{rec.backbone}_{rec.window}'
    diag=pd.read_csv(HERE/'verified_releases'/(stem+'.csv'))
    anomalous=np.flatnonzero(diag.query('grid_length>1').indefinite)
    checks=sorted({0,*([int(anomalous[0])] if len(anomalous) else [])})
    for offset in checks:
      with tempfile.TemporaryDirectory(dir=HERE) as folder:
        folder=Path(folder); t=36+offset; nt=int(.8*t); prog=program.replace('1:36;', f'1:{t};').replace('ord[1:28]',f'ord[1:{nt}]').replace('ord[29:36]',f'ord[{nt+1}:{t}]').replace('raw[37,',f'raw[{t+1},'); (folder/'check.R').write_text(prog)
        with np.load(Path(rec.source)/'endpoints.npz') as z:
            for name,field in [('s','S'),('smoke_raw','raw'),('smoke_truth','truth')]:
                np.savetxt(folder/(name+'.csv'),z[field] if field=='S' else z[field][:t+1],delimiter=',',fmt='%.17g')
        with np.load(HERE/'verified_releases'/(stem+'.npz')) as z:
            np.savetxt(folder/'smoke_first.csv',z['li'][offset],fmt='%.17g')
            np.savetxt(folder/'lambda.csv',z['lambda_values'][offset:offset+1],fmt='%.17g')
        subprocess.run([str(r),'--vanilla','check.R'],cwd=folder,env=dict(os.environ,R_USER=str(folder),R_LIBS_USER=str(folder)),check=True)
        rows.append(dict(stream=stem,release=offset+1,**pd.read_csv(folder/'check.csv').iloc[0].to_dict()))
pd.DataFrame(rows).to_csv(HERE/'R_check.csv',index=False)





