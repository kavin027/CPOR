"""Rebuild the current Li percentages from full-precision window RMSEs (standard library)."""
import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean
from math import isclose
base=Path(__file__).resolve().parent
def read(name):
    with (base/name).open(encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))
groups=defaultdict(list)
for row in read("windows.csv"):
    groups[row["scope"],row["dataset"],row["backbone"]].append(row)
expected={("all","Diag"):(4.20,4.12),("all","Factor"):(4.51,4.43),
          ("system","Diag"):(4.21,4.03),("system","Factor"):(3.87,3.68),
          ("middle","Diag"):(3.51,3.43),("middle","Factor"):(3.85,3.76),
          ("bottom","Diag"):(4.89,4.86),("bottom","Factor"):(5.37,5.34)}
methods=("Diag","Factor","Cov","ML")
means={k:{m:mean(float(r[m]) for r in rows) for m in methods} for k,rows in groups.items()}
for r in read("groups.csv"):
    for m in methods:
        assert isclose(means[r["scope"],r["dataset"],r["backbone"]][m],float(r[m]),rel_tol=1e-12)
def gain(row,m,ref):
    return 100*(1-row[m]/row[ref])
for (scope,ref),reported in expected.items():
    rows=[v for (s,ds,b),v in means.items() if s==scope]
    assert len(rows)==8
    values=[mean(gain(v,m,ref) for v in rows) for m in ("Cov","ML")]
    assert tuple(round(v,2) for v in values)==reported
    print(scope,ref,*(f"{v:.6f}%" for v in values))
v=[gain(row,"Factor","Diag") for k,row in means.items() if k[0]=="all"]
assert sum(x>0 for x in v)==1 and round(mean(v),2)==-.33
assert [round(gain(means["system","Traffic","DLinear"],m,"Factor"),2) for m in ("Cov","ML")]==[-.15,-.24]
wins=[tuple(float(r[m]) for m in methods) for r in read("windows.csv") if r["scope"]=="all"]
assert len(wins)==14 and all(max(c,m)<min(d,f) for d,f,c,m in wins)
assert sum(f<d for d,f,c,m in wins)==2
print("Fourteen paired windows verified. All four overall percentages and the reported level comparisons match.")
