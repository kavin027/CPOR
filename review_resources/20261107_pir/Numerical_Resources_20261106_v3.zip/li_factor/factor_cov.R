args <- commandArgs(trailingOnly=TRUE)
source(args[1])
res <- as.matrix(read.csv(args[2],header=FALSE))
splits <- read.csv(args[3],header=FALSE)
out <- file(args[4],"wb")
for(t in 36:107) {
  idx<-as.integer(splits[t-35,2:(t+1)])
  for (rows in list(idx[seq_len(floor(.8*t))],seq_len(t))) {
    sigma<-covEstimation(res[rows,,drop=FALSE],control=list(type="large"))
    stopifnot(all(is.finite(sigma)),isSymmetric(unname(sigma),tol=1e-9))
    writeBin(as.double(t(sigma)),out,size=8,endian="little")
  }
}
close(out)
