from pathlib import Path
import sys,os,tempfile,subprocess
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
SIX=HERE.parent/'cpor_li_preprint_six_20261106'
sys.path.insert(0,str(SIX))
import extend
from block_solve import make_mapper
p=extend.paired
r=p.HERE/'runtime/R/app/bin/x64/Rscript.exe'
split_file=p.HERE/'splits.csv'
keys=['dataset','backbone','window']
def score():
    streams=pd.read_csv(SIX/'streams.csv').dropna(subset=['li_path'])
    assert len(streams)==14
    splits={int(row.iloc[0]):row.iloc[1:].dropna().to_numpy(int)-1 for _,row in pd.read_csv(split_file,header=None).iterrows()}
    old=pd.read_csv(SIX/'windows.csv').dropna(subset=['Li']).set_index(keys+['scope'])
    levels=pd.read_csv(p.MAP)
    out=[];audit=[]
    for row in streams.itertuples():
        key={k:getattr(row,k) for k in keys}
        stem='_'.join(key.values())
        src=Path(row.source)
        ep=src/'endpoints.npz'
        for f in [ep,src/'CovFullFix.npz',src/'controls.npz']:
            assert extend.sha(f)==getattr(row,f.stem+'_sha256')
        assert extend.sha(Path(row.li_path))==row.li_sha256
        with np.load(ep) as z: raw,y,s,anchor=(z[k] for k in ['raw','truth','S','b'])
        n,b=s.shape
        path=HERE/'verified_releases'/(stem+'.npz')
        if not path.exists():
            with tempfile.TemporaryDirectory(dir=HERE) as td:
                folder=Path(td)
                np.savetxt(folder/'res.csv',y[:107]-raw[:107],delimiter=',',fmt='%.17g')
                covfile=folder/'cov.bin'
                subprocess.run([str(r),'--vanilla',str(HERE/'factor_cov.R'),str(HERE/'preprint_covEstimation.R'),str(folder/'res.csv'),str(split_file),str(covfile)],env=dict(os.environ,R_USER=td),check=True)
                assert covfile.stat().st_size==144*n*n*8
                with covfile.open('rb') as fo:
                    def read_cov(res):
                        return np.fromfile(fo,dtype='<f8',count=n*n).reshape(n,n)
                    original=p.mappings; diagnostics=[]
                    try:
                        p.mappings=make_mapper(read_cov,diagnostics)
                        extend.run_new(raw,y,s,splits,path)
                    finally: p.mappings=original
                    pd.DataFrame(diagnostics,columns=['grid_length','indefinite','repairs']).to_csv(path.with_suffix('.csv'),index=False)
                    assert not fo.read(1)
        with np.load(path) as z:
            pred=z['li']; lam=z['lambda_values']
        assert pred.shape==(72,n) and np.isfinite(pred).all() and np.isin(lam,p.GRID).all()
        np.testing.assert_allclose(pred,pred[:,-b:]@s.T,atol=2e-6,rtol=1e-8)
        nodes=levels[levels.dataset==row.dataset].sort_values('node')
        np.testing.assert_array_equal(nodes.node,np.arange(n))
        e=np.sqrt(((pred-y[36:])**2).mean(axis=0))
        sub=old.loc[tuple(key.values())]
        for scope,record in sub.iterrows():
            mask=nodes.scopes.str.split(';').map(lambda tags:scope in tags).to_numpy()
            if scope=='middle': mask=~nodes.scopes.str.contains('system|bottom').to_numpy()
            out.append(dict(**key,scope=scope,Factor=e[mask].mean(),Diag=record.Li,Cov=record.Cov,ML=record.ML))
        audit.append(dict(**key,ever=p.prefix_counts(y[36:],anchor[36:],pred),nodes=n,negative_entries=int((pred<0).sum()),cap=int((lam==1e5).sum()),input_hash=row.endpoints_sha256,release_hash=extend.sha(path)))
        print(stem,flush=True)
    df=pd.DataFrame(out)
    for a,ref in [('Factor','Diag'),('Cov','Factor'),('ML','Factor'),('Cov','Diag'),('ML','Diag')]:df[a+'_vs_'+ref]=100*(1-df[a]/df[ref])
    df.to_csv(HERE/'windows.csv',index=False)
    gs=df.groupby(['dataset','backbone','scope']).mean(numeric_only=True)
    gs.to_csv(HERE/'groups.csv')
    pd.DataFrame(audit).to_csv(HERE/'audit.csv',index=False)
    print(gs.xs('all',level='scope').round(4))
if __name__=='__main__': score()

