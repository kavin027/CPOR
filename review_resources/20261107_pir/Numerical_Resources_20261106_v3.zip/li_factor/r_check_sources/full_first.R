source("parity.R")
d<-"parity/Traffic_PatchTST_early"
S<-readmat(file.path(d,"s.csv")); raw<-readmat("parity/smoke_raw.csv"); y<-readmat("parity/smoke_truth.csv")
n<-nrow(S); b<-ncol(S); a<-n-b; V<-cbind(diag(a),-S[seq_len(a),])
blocks<-lapply(seq_len(b),function(i){
 direct<-diag(n)[a+i,]; diff<-V
 for(j in seq_len(a)) if(S[j,i]==0) diff[j,]<-V[1,]-V[j,]
 rbind(direct,sweep(diff,2,direct,"+"))
})
predict_r<-function(cov,fore,lambda){
 bot<-matrix(NA,nrow(fore),b)
 for(i in seq_len(b)){
  ci<-blocks[[i]]; q<-build_Qh(cov,ci,S[,i,drop=FALSE],a,1)
  rho<-solve_sep(q,a,1,"eridge",lambda)
  bot[,i]<-fore%*%t(ci)%*%rho_to_w(rho,a,1)
 }
 bot%*%t(S)
}
history<-1:36; set.seed(123); ord<-sample(history); train<-ord[1:28]; valid<-ord[29:36]
res<-y-raw; sigma<-estimate_sigma("shr",res[train,])
grid<-c(0,10^seq(-1,5,.25))
score<-sapply(grid,function(l)mean(sqrt(colMeans((predict_r(sigma,raw[valid,],l)-y[valid,])^2))))
lambda<-grid[which.min(score)]
p<-predict_r(estimate_sigma("shr",res[history,]),raw[37,,drop=FALSE],lambda)
diff<-max(abs(c(p)-as.numeric(readmat("parity/smoke_first.csv"))))
out<-data.frame(chosen=lambda,python_lambda=readmat(file.path(d,"lambda.csv"))[1,1],max_prediction_diff=diff)
write.csv(out,"parity/full_first_release.csv",row.names=FALSE)
print(out); stopifnot(abs(out$chosen-out$python_lambda)<1e-8,diff<1e-6)
