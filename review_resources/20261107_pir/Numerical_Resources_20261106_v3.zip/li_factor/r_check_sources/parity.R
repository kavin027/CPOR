keep <- c("lamb_estimate","estimate_sigma","est_var_cov","make_Z_c","solve_sep","make_psd","rho_to_w","construct_Phi_from_w","reconcile","build_Qh")
for(expr in parse("author/main_experiment.R")){
  if(is.call(expr) && identical(expr[[1]],as.name("<-")) && as.character(expr[[2]])[1] %in% keep) eval(expr)
}
readmat <- function(f) as.matrix(read.csv(f,header=FALSE,check.names=FALSE))
out <- list()
for(d in list.dirs("parity",recursive=FALSE)){
  S<-readmat(file.path(d,"s.csv")); sig<-estimate_sigma("shr",readmat(file.path(d,"res.csv")))
  w<-readmat(file.path(d,"weights.csv")); lam<-readmat(file.path(d,"lambda.csv"))[1,1]
  b<-ncol(S); a<-nrow(S)-b
  for(i in c(1,floor(b/2)+1,b)){
    ci<-readmat(file.path(d,paste0("C_",i,".csv")))
    q<-build_Qh(sig,ci,S[,i,drop=FALSE],a,1)
    rho<-solve_sep(q,a,1,"eridge",lam)
    wr<-rho_to_w(rho,a,1)%*%ci
    err<-max(abs(wr-w[i,]))
    out[[length(out)+1]]<-data.frame(stream=basename(d),bottom=i,lambda=lam,max_abs_diff=err)
  }
}
out<-do.call(rbind,out)
write.csv(out,"parity/r_weights.csv",row.names=FALSE)
print(max(out$max_abs_diff))
stopifnot(nrow(out)==30, max(out$max_abs_diff)<1e-6)
