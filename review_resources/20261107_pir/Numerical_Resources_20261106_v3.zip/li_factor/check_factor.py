"""Check both covariance variants in Table S19 from the paired window records."""
import csv
from collections import defaultdict
from math import isclose
from pathlib import Path
from statistics import mean
root = Path(__file__).resolve().parent
def read(name):
    with (root/name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))
windows=read('windows.csv')
groups=read('groups.csv')
scopes=defaultdict(list)
for g in groups:
    cells=[r for r in windows if all(g[k]==r[k] for k in ('dataset','backbone','scope'))]
    assert len(cells)==(1 if g['dataset']=='Labour' else 2)
    for m in ('Diag','Factor','Cov','ML'):
        assert isclose(mean(float(r[m]) for r in cells),float(g[m]),rel_tol=1e-12)
    for m,ref in [('Factor','Diag'),('Cov','Diag'),('ML','Diag'),('Cov','Factor'),('ML','Factor')]:
        field=m+'_vs_'+ref
        pct=mean(100*(1-float(r[m])/float(r[ref])) for r in cells)
        assert isclose(pct,float(g[field]),abs_tol=1e-10)
        scopes[g['scope'],field].append(pct)
eligible=[r for r in windows if r['scope']=='all']
assert len(eligible)==14 and all(max(float(r['Cov']),float(r['ML']))<min(float(r['Diag']),float(r['Factor'])) for r in eligible)
for fld,expected in [('Factor_vs_Diag',-.51),('Cov_vs_Factor',4.78),('ML_vs_Factor',4.75),('Cov_vs_Diag',4.31),('ML_vs_Diag',4.27)]:
    g=scopes['all',fld]
    assert len(g)==8 and round(mean(g),2)==expected
assert sum(x>0 for x in scopes['all','Factor_vs_Diag'])==1
assert sum(float(r['Factor'])<float(r['Diag']) for r in eligible)==2
audit=read('audit.csv')
assert len(audit)==14 and sum(int(r['nodes']) for r in audit)==1914 and sum(int(r['ever']) for r in audit)==1365
checks=read('R_check.csv')
assert len({r['stream'] for r in checks})==14 and all(isclose(float(r['chosen']),float(r['python_lambda']),abs_tol=1e-8,rel_tol=1e-12) for r in checks)
print('Table S19: four-method RMSE, paired contrasts and Factor prefix totals verified.')
