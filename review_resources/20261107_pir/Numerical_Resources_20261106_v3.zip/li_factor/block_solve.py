"""Algebraic block solves for Li's separate eRidge rule (including indefinite inputs)."""
import numpy as np
from scipy.linalg.lapack import dgetrf, dgecon

def make_mapper(get_sigma, diagnostics):
    def mappings(res, s, v, tr, lambdas):
        a = len(v)
        vs = v @ get_sigma(res)
        scales = np.square(s).sum(axis=0)
        h = (tr @ (vs @ v.T) @ tr.transpose(0, 2, 1)) * scales[:, None, None]
        g = (tr @ vs[:, a:].T[:, :, None])[:, :, 0] * scales[:, None]
        h = (h + h.transpose(0, 2, 1)) / 2
        eig, vec = np.linalg.eigh(h)
        denom = eig[None] + lambdas[:, None, None]
        eps = np.finfo(float).eps
        size = abs(denom).max(axis=2)
        near = abs(denom).min(axis=2) <= size * eps * (8*a)
        indefinite = np.any(denom.min(axis=2) < -size*eps*(8*a))
        repairs = 0
        for k, j in zip(*np.where(near)):
            block = h[j] + lambdas[k]*np.eye(a)
            lu, piv, info = dgetrf(block)
            rcond = 0 if info else dgecon(lu, np.linalg.norm(block,1))[0]
            if rcond < eps:
                denom[k,j] = np.maximum(denom[k,j], 1e-8)
                repairs += 1
        diagnostics.append((len(lambdas), int(indefinite), repairs))
        rhs = -g[None] + lambdas[:,None,None]/(a+1)
        coeff = np.einsum('bij,lbi->lbj', vec, rhs) / denom
        rho = np.einsum('bij,lbj->lbi', vec, coeff)
        return np.einsum('lbi,bij->lbj', rho, tr)
    return mappings
