"""Recompute this revision's aggregates; does not replay forecasts or ledgers."""
from pathlib import Path
import csv,io,zipfile,json,hashlib,math,collections
H=Path(__file__).resolve().parent
P=H.parent
Z=P/'CPOR_CovML_Results_Minor_20261024.zip'
A=P/'evidence_closure'
if not Z.exists():
 Z=P/'cpor_cov_ml_20261024'/Z.name
 A=P/'cpor_evidence_closure_20261024'
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def mean(x):return sum(x)/len(x)
def q(x,p):
 x=sorted(x);k=(len(x)-1)*p;i=int(k)
 return x[i]+(x[min(i+1,len(x)-1)]-x[i])*(k-i)
def close(a,b):assert math.isclose(float(a),float(b),rel_tol=1e-9,abs_tol=1e-10),(a,b)
assert hashlib.sha256(Z.read_bytes()).hexdigest()=='a75e6d4ee796925707886e51775275e42a10f5ccdc20ff5c68a754124c03a023'
with zipfile.ZipFile(Z) as z:
 names=z.namelist()
 f=[n for n in names if n=='GROUP_RUN_RMSE.csv' or n.endswith('/GROUP_RUN_RMSE.csv')];assert len(f)==1
 raw=list(csv.DictReader(io.StringIO(z.read(f[0]).decode('utf-8-sig'))))
 maxima={'nonnegative':0.,'all_real':0.}
 for n in names:
  if 'matched_envelope/runs/' in n and n.endswith('/DONE.json'):
   for r in json.loads(z.read(n))['records']:
    for label,key in [('nonnegative','exact_audit'),('all_real','real_audit')]:maxima[label]=max(maxima[label],r[key]['max_coherence_abs'])
v=collections.defaultdict(dict)
for r in raw:v[(r['dataset'],r['backbone'],r['seed'])][r['method']]=float(r['rmse'])
for r in read(H/'COST_DISTRIBUTION.csv'):
 impl=r['implementation'];m,u=('CovFullFix','CovUnprotected') if impl=='Cov' else ('ProtectedMLPol','MLPol')
 x=sorted(100*(a[m]-a[u])/a[u] for a in v.values());n=len(x);k=int(.1*n)
 for col,y in [('n',n),('trim_each_tail',k),('retained',n-2*k),('trimmed_mean',mean(x[k:-k])),('median',q(x,.5)),('q1',q(x,.25)),('q3',q(x,.75))]:close(y,r[col])
 ranks=[a for a in read(H/'COST_ORDER_AND_TRIM.csv') if a['implementation']==impl]
 assert len(ranks)==n
 for j,a in enumerate(ranks,1):
  vals=v[(a['dataset'],a['backbone'],a['seed'])]
  close(a['cost'],100*(vals[m]-vals[u])/vals[u]);close(a['cost'],x[j-1]);assert int(a['rank'])==j
  assert (a['trimmed'].lower()=='true')==(j<=k or j>n-k)
for r in read(H/'PIR_DATASET_RUNS.csv'):
 m='CovFullFix' if r['implementation']=='Cov' else 'ProtectedMLPol';runs=[]
 for j,s in enumerate(['42','1','2'],1):
  g=[100*(a['PIR']-a[m])/a['PIR'] for (d,b,seed),a in v.items() if d==r['dataset'] and seed==s];assert len(g)==2
  runs.append(mean(g));close(r[f'run{j}'],runs[-1])
 close(r['mean'],mean(runs));assert int(r['positive_runs'])==sum(a>0 for a in runs)
events=read(A/'EVENTS.csv');cl=[e for e in events if int(e['clipped_coordinates'])>0 or int(e['ulp_operations'])>0]
check=json.loads((H/'EVIDENCE_CHECK.json').read_text())
assert len(cl)==check['clipped_releases']==3073
close(q([float(e['coherence_max']) for e in cl],.95),check['clipped_residual_p95'])
close(max(float(e['coherence_max']) for e in cl),check['clipped_residual_max'])
assert sum(int(e['guard_contraction']) for e in cl)==check['guard_after_clipping']==0
for k,y in maxima.items():close(y,check['matched_audit_maxima'][k])
print(json.dumps({'status':'PASS','cost_groups_per_implementation':36,'pir_dataset_implementation_rows':12,'clipped_releases':len(cl),'coherence_domains':maxima,'new_prediction_runs':0},indent=2))
