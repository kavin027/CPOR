"""Recalculate paired RMSE effects from the included per-window records (standard library)."""
from pathlib import Path
import csv,statistics,math
from collections import defaultdict
here=Path(__file__).resolve().parent
def read(path):
    with path.open(encoding='utf-8-sig',newline='') as stream:
        return list(csv.DictReader(stream))
def check(folder,cells,paired,expected):
    raw=read(folder/cells);summary=read(folder/paired)
    obs=defaultdict(list)
    for row in raw:
        key=(row.get('external','DUET'),row['scope'],row['dataset'],row.get('backbone','DUET'))
        obs[key,row['method']].append(float(row['rmse']))
    for row in summary:
        ext=row.get('external','DUET')
        effects=[100*(1-statistics.mean(vals)/statistics.mean(obs[key,row['comparator']])) for (key,m),vals in list(obs.items()) if m==row['method'] and key[:2]==(ext,row['scope'])]
        assert len(effects)==int(row['groups'])
        assert math.isclose(statistics.mean(effects),float(row['mean_pct']),abs_tol=1e-8)
        assert math.isclose(statistics.median(effects),float(row['median_pct']),abs_tol=1e-8)
    print('Verified',len(summary),'paired summaries in',folder.name)
    for method,nodes,ever in expected:
        rr=[x for x in read(folder/('protection_checks.csv' if folder.name=='duet' else 'risk.csv')) if x['method']==method and (x.get('external','DUET') in ('DUET','KDDResidual'))]
        assert sum(int(x['nodes']) for x in rr)==nodes and sum(int(x['ever']) for x in rr)==ever
check(here/'duet','window_RMSE.csv','paired.csv',[('CPORCov',999,0),('CPORML',999,0),('TargetCov',999,781),('TargetML',999,776)])
check(here/'kdd2026','cells.csv','paired.csv',[('Full',1998,0),('Ray',1998,0),('Direct',1998,1497)])
for name,direct in [('MCGradRegression',1385),('MCGradRegressionBlockRefit',1542)]:
    rs=[r for r in read(here/'kdd2026/risk.csv') if r['external']==name]
    assert all(sum(int(r['ever']) for r in rs if r['method']==m)==v for m,v in [('Direct',direct),('Ray',0),('Full',0)])
print('Published violation counts verified.')

