from protocol import *
import ast,time
from fractions import Fraction
from threadpoolctl import threadpool_limits
from scipy.optimize import nnls
import cpu
sys.path.insert(0,str(o/'cpor_envelope_comparison_20261024'))
import run_comparison as c
src=o/'cpor_kdd_safe_controls_20261105/replay.py'
ns=dict(np=np,Fraction=Fraction,R=c.RR)
tree=ast.parse(src.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[f for f in tree.body if isinstance(f,ast.FunctionDef)],type_ignores=[]),str(src),'exec'),ns)
mapping=pd.read_csv(o/'kais_review_v2_revision_20261017/Online_Resource_3/review_evidence/node_map.csv')
def shrink(x,z,u):
    bal=[Fraction(0)]*z.shape[1];ps=[];us=[]
    for j,t in enumerate(range(36,108)):
        b=x['b'][t];bq=ns['exact'](b)
        p,w=ns['ray'](b,z[j],bq,bal)
        bal=ns['settle'](bq,ns['exact'](p),ns['exact'](x['truth'][t]),bal)
        ps.append(p);us.append((1-w)*x['ub'][t]+w*u[j])
    return np.array(ps),np.array(us)
def risk(p,b,y):
    bal=[Fraction(0)]*y.shape[1];ever=set();events=0
    for pp,bb,yy in zip(p,b,y):
        for i,(a,v,z) in enumerate(zip(ns['exact'](pp),ns['exact'](bb),ns['exact'](yy))):
            bal[i]+=c.RR*(v-z)**2-(a-z)**2
            if bal[i]<0:ever.add(i);events+=1
    return len(ever),events
def evaluate(row):
    ds=row.dataset;win=row.window
    d=q/'scores'/ds/win;d.mkdir(parents=True,exist_ok=True)
    if (d/'done.json').exists():return
    src=q/'streams'/ds/(win+'.npz');meta=json.loads((src.parent/'complete.json').read_text())
    assert sha(src)==meta['streams'][win]
    with np.load(src) as f:x,D,expert,bank,mixed=cpu.contexts({'dataset':ds},d,dict(f))
    np.testing.assert_array_equal(np.load(src)['raw'],x['raw'])
    with np.load(Path(row.source)/'endpoints.npz') as ref:
        np.testing.assert_allclose(ref['truth'],x['truth'],rtol=1e-12,atol=1e-8)
    cpu.saved.controls(d,x,expert,bank)
    S=x['S'];raw=x['raw'][36:];b=x['b'][36:];y=x['truth'][36:]
    main=c.run(x,D[36:],'Cov',ds,'nonnegative')
    ml=c.load(d/'controls.npz')
    zs,uz=cpu.old.project(S,raw,x['v'])
    mls=ml['MLPol'];cv=D[36:]
    feat={'Raw':(raw,None),'NNLS':(b,x['ub'][36:]),'TargetCov':(cv,None),'TargetML':(mls,None),'CPORCov':(main['pred'],main['witness']),'CPORML':(ml['ProtectedMLPol'],ml['MLPolWitness']),'TargetDirect':(zs,uz)}
    # Recover a nonnegative representation only to check coherence. The target itself is unchanged.
    for key,z,u in [('Direct',zs,uz),('Cov',cv,None),('ML',mls,None)]:
        if u is None:
            u=np.array([nnls(S,v,maxiter=10*S.shape[1])[0] for v in z]);np.testing.assert_allclose(u@S.T,z,rtol=1e-8,atol=2e-6)
        feat['Ray'+key]=shrink(x,z,u)
    m=c.run(x,zs,'ML',ds,'nonnegative')
    feat['FullDirect']=(m['pred'],m['witness'])
    W,C,lam,floor=cpu.classic.covariance(x['raw'][:36]-x['truth'][:36])
    for key,weight in [('WLS',np.diag(np.maximum(np.diag(C),floor))),('MinT',W)]:
        z,u,_=cpu.classic.target(S,raw,weight)
        pp,up,_=cpu.classic.protect(x,z)
        feat[key]=(z,u);feat['Protected'+key]=(pp,up)
    scopes=mapping[mapping.dataset==ds];scores=[];checks=[];stored={}
    guarded=['CPORCov','CPORML','RayCov','RayML','RayDirect','FullDirect','ProtectedWLS','ProtectedMinT','NNLS']
    for key,(p,u) in feat.items():
        assert np.isfinite(p).all() and p.shape==y.shape
        if key in guarded:
            _,check=c.states_and_audit(x,p,u,'nonnegative');ever=events=0
        else:
            ever,events=risk(p,b,y);check={}
        stored[key]=p
        if u is not None:stored[key+'_u']=u
        checks.append(dict(method=key,nodes=y.shape[1],node_dates=y.size,ever=ever,events=events,**check))
        rmse=np.sqrt(np.mean((p-y)**2,axis=0))
        for scope in sorted(set(';'.join(scopes.scopes).split(';'))):
            ix=scopes.loc[scopes.scopes.str.split(';').map(lambda a:scope in a),'node'].to_numpy(int)
            scores.append(dict(dataset=ds,window=win,scope=scope,method=key,rmse=float(rmse[ix].mean())))
    np.savez_compressed(d/'predictions.npz',**stored)
    pd.DataFrame(scores).to_csv(d/'metrics.csv',index=False)
    pd.DataFrame(checks).assign(dataset=ds,window=win).to_csv(d/'checks.csv',index=False)
    js(d/'done.json',dict(stream_sha256=sha(src),published_sha256=sha(d/'predictions.npz'),shrinkage=lam))
    print('SCORED',ds,win,flush=True)
if __name__=='__main__':
    with threadpool_limits(1):
        for row in grid.itertuples():
            while not (q/'streams'/row.dataset/'complete.json').exists():time.sleep(2)
            evaluate(row)

