from protocol import *
import time
os.environ['CUDA_CACHE_PATH']=str(q/'cuda_cache')
os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
sys.path.insert(0,str(q/'DUET'))
sys.path.append(str(o/'cpor_external_20261105/deps'))
import torch
from ts_benchmark.baselines.duet.duet import DUET
def seed(value):
    random.seed(value);np.random.seed(value);torch.manual_seed(value);torch.cuda.manual_seed_all(value)
class LoggedDUET(DUET):
    def validate(self,*args):
        loss=super().validate(*args)
        self.validation.append(float(loss))
        return loss
settings=dict(seq_len=24,horizon=12,norm=True,d_model=64,d_ff=128,hidden_size=64,e_layers=1,n_heads=1,num_experts=2,k=1,lr=.0005,lradj='type1',loss='MAE',batch_size=16,num_epochs=100,patience=5)
if __name__=='__main__':
    for ds in grid.dataset.unique():
        wide,rows=inputs(ds);wide.index.name='date';end=min(start for _,start,_ in rows)-36
        folder=q/'streams'/ds;folder.mkdir(exist_ok=True,parents=True)
        if (folder/'complete.json').exists():continue
        seed(2021);model=LoggedDUET(**settings);model.validation=[]
        print('START',ds,end,flush=True);clock=time.monotonic()
        model.forecast_fit(wide.iloc[:end],train_ratio_in_tv=.8)
        assert model.check_point is not None and np.isfinite(model.validation).all()
        torch.save(dict(state_dict=model.check_point,mean=model.scaler.mean_,scale=model.scaler.scale_),folder/'model.pt')
        preds={}
        for window,start,S in rows:
            for i in range(start-36,start+72,12):
                if i not in preds:
                    seed(2021+i)
                    preds[i]=model.forecast(12,wide.iloc[i-24:i])
                    assert preds[i].shape==(12,S.shape[0]) and np.isfinite(preds[i]).all()
            np.savez_compressed(folder/(window+'.npz'),raw=np.concatenate([preds[i] for i in range(start-36,start+72,12)]).astype('float64'),start=start,S=S)
        js(folder/'complete.json',dict(dataset=ds,settings=settings,seed=2021,validation=model.validation,train_rows=int(.8*end),fit_end_exclusive=end,first_calibration=str(wide.index[end]),validation_last=str(wide.index[end-1]),seconds=time.monotonic()-clock,data_sha256=sha(datafile(ds)),model_sha256=sha(folder/'model.pt'),streams={w:sha(folder/(w+'.npz')) for w,_,_ in rows}))
        print('DONE',ds,flush=True)


