from pathlib import Path
import sys,os,json,random
import numpy as np,pandas as pd
q=Path(__file__).resolve().parent
o=q.parent
sys.path.insert(0,str(o/'dlinear_5000_comparison_20261021'))
from shared import datafile,js,sha
fits=pd.read_csv(o/'cpor_kdd_comparison_20261105/fits.csv').query("backbone=='PatchTST'")
idx=pd.read_csv(o/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv').query("backbone=='PatchTST' and seed==42")
grid=fits.merge(idx,on=['dataset','window','backbone'],validate='one_to_one')
def inputs(ds):
    wide=pd.read_csv(datafile(ds),parse_dates=['ds']).set_index('ds')
    assert wide.index.is_unique and wide.index.is_monotonic_increasing
    rows=[]
    for row in grid[grid.dataset==ds].itertuples():
        start=wide.index.get_loc(pd.Timestamp(row.score_start))
        with np.load(Path(row.source)/'endpoints.npz') as f:
            np.testing.assert_allclose(wide.iloc[start-36:start+72].values,f['truth'],rtol=1e-12,atol=1e-8)
            rows.append((row.window,start,f['S']))
    return wide,rows
if __name__=='__main__':
    for ds in grid.dataset.unique():
        wide,r=inputs(ds);print(ds,wide.shape,pd.infer_freq(wide.index),[(w,s) for w,s,_ in r])

