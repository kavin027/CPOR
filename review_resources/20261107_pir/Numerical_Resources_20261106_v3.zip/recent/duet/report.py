from protocol import *
import zipfile
def run():
    records=[];checks=[];sources=[]
    for row in grid.itertuples():
        ds,w=row.dataset,row.window
        d=q/'scores'/ds/w;stream=q/'streams'/ds
        receipt=json.loads((d/'done.json').read_text())
        assert sha(d/'predictions.npz')==receipt['published_sha256']
        assert sha(stream/(w+'.npz'))==receipt['stream_sha256']
        a=pd.read_csv(d/'metrics.csv');checks.append(pd.read_csv(d/'checks.csv'))
        with np.load(d/'endpoints.npz') as x,np.load(d/'predictions.npz') as p:
            np.testing.assert_array_equal(x['raw'][36:],p['Raw'])
            for r in a.query("scope=='all'").itertuples():
                np.testing.assert_allclose(r.rmse,np.mean(np.sqrt(np.mean((p[r.method]-x['truth'][36:])**2,axis=0))),rtol=1e-12)
        records.append(a);sources.append(dict(dataset=ds,window=w,**receipt))
    a=pd.concat(records);r=pd.concat(checks)
    assert len(a.query("scope=='all'"))==15*11
    x=a.groupby(['scope','dataset','method']).rmse.mean().unstack('method')
    eff=[];summary=[]
    for scope,m in x.groupby(level='scope'):
        m=m.droplevel('scope')
        pairs=[(main,baseline) for main,kind in [('CPORCov','Cov'),('CPORML','ML')] for baseline in ['Raw','NNLS','WLS','MinT','ProtectedWLS','ProtectedMinT','Ray'+kind,'Target'+kind]]
        pairs.extend([('FullDirect','RayDirect'),('FullDirect','TargetDirect'),('CPORCov','CPORML')])
        for method,comp in pairs:
            z=100*(1-m[method]/m[comp])
            for ds,val in z.items():eff.append(dict(scope=scope,dataset=ds,method=method,comparator=comp,gain=val))
            loo=[z.drop(ds).mean() for ds in z.index] if len(z)>1 else [np.nan]
            summary.append(dict(scope=scope,method=method,comparator=comp,wins=int((z>0).sum()),groups=len(z),mean_pct=z.mean(),median_pct=z.median(),leave_one_out_min=min(loo),leave_one_out_max=max(loo)))
    s=pd.DataFrame(summary);e=pd.DataFrame(eff)
    checks=r.groupby('method')[['nodes','node_dates','ever','events']].sum()
    for df,name in [(a,'window_RMSE'),(x.reset_index(),'dataset_RMSE'),(s,'paired'),(e,'per_dataset_gains'),(r,'protection_checks'),(checks.reset_index(),'risk_totals'),(pd.DataFrame(sources),'sources')]:
        df.to_csv(q/(name+'.csv'),index=False)
    def table(df):
        cols=list(df.columns)
        def fmt(v):return f'{v:.3f}' if isinstance(v,(float,np.floating)) else str(v)
        return '\n'.join(['| '+' | '.join(cols)+' |','|'+'---|'*len(cols)]+['| '+' | '.join(fmt(v) for v in row)+' |' for row in df.itertuples(index=False,name=None)])
    n=json.loads((q/'native_ILI.json').read_text())
    native=f"作者 ILI、24 步脚本的一次固定初始化检查，{n['origins']} 个滚动起点。标准化 MSE {n['mse']:.4f}，MAE {n['mae']:.4f}。论文表 3 为 1.584 和 0.775。原生检查与六数据集结果单独统计。使用本地 966×7 ILI 数据副本；数据哈希、脚本设置和验证曲线见 native_ILI.json。"
    report=['# DUET 共同预测流上的 CPOR 配对实验','一个 KDD 2025 基础模型，每个数据集训练一次。全体 11 个窗口均使用同一初始化，36 个校准点，72 个评分点。一个数据集内的早晚窗共享在最早校准开始前已由验证集选定的模型。各预测块一次产生未来 12 点，每次发布后才向后处理器返回该点真实观测。研究问题、数据与窗口和既有实验相同；本次采用统一的 DUET 24 步输入及 12 步输出。','## 全节点配对','先对每个数据集内的窗口 RMSE 平均，再求相对对照的降幅，对六个数据集等权。正值表示改善。leave_one_out_min/max 是去掉任一数据集的均值范围。',table(s.query("scope=='all'").drop(columns='scope')),'## 各数据集，同一目标完整投影相对简单收缩',table(e[((e.method=='CPORCov')&(e.comparator=='RayCov')|(e.method=='CPORML')&(e.comparator=='RayML')|(e.method=='FullDirect')&(e.comparator=='RayDirect'))&(e.scope=='all')].pivot(index='dataset',columns='method',values='gain').reset_index()),'## 区域、系统和底层',table(s.query("scope!='all' and comparator in ['RayML','RayCov','ProtectedMinT','Raw']").iloc[:,:7]),'## 每一节点、每一评分前缀','nodes 按节点×窗口计数，ever 为至少一次超出 0.5% 累计 RMSE 额度的节点序列数。各受保护方法采用相同起点、NNLS 参考与额度，各自按实际发布误差更新。对所有受保护输出另以有理数逐点验证发布前包络，核对非负底层表示在浮点容差内与发布值相符。',table(checks.reset_index()),'## 比较解释','Raw 为原始 DUET；WLS、MinT 及各自的保护版均在相同 DUET 残差上估计。TargetCov/TargetML 为原始规则产生并协调后的同一目标，Ray 用一个跨节点系数沿参考到该目标收缩。CPORCov/CPORML 与各自 Ray 的差异来自保护发布策略和随之改变的余额轨迹。FullDirect/RayDirect 是双方直接使用相同的方差加权非负协调 DUET 目标的对照。将 CPOR 与原始 DUET 或经典协调的差距解释为完整流程效果。','## 作者实现校验',native,'[KDD 论文](https://doi.org/10.1145/3690624.3709325) · [作者固定提交](https://github.com/decisionintelligence/DUET/tree/dcc6e6780a9138731b64b9b5398a94a1d97033f0) · [原生指标表](https://arxiv.org/html/2412.10859v1)']
    report[2:2]=['## 实验判断','在相同目标、相同逐节点保护要求下，相对只沿一个方向收缩，CPOR-Cov 与 CPOR-ML 在六个数据集全部降低全节点 RMSE，等权平均降幅为 6.14% 和 6.32%。RH 的收益最大；排除 RH 后其余五组仍平均改善 3.09% 和 2.98%。直接对 DUET 的协调目标施加保护时，匹配优势缩小到 0.54%；四组明显改善、ECommerce 差约 6e-11 个百分点、RH 退化 0.012%。', '保护有实际代价。与各自无保护目标相比，Cov、ML 的均值 RMSE 代价分别为 18.49% 与 20.90%（数据集配对百分比均值），中位数为 3.18% 与 3.85%。两种原始目标分别有 781 和 776 条节点序列至少一次超限。两种 CPOR 各完成 71,928 个节点前缀检查，均为零超限。两次 Wiki2 求解日志出现精度警告；报告采用最终发布值的逐点检验，未量化投影最优性误差。一次初始化，数据及评分日期沿用已有网格；六数据集结果反映更换基础模型后的配对效果。']
    (q/'REPORT.md').write_text('\n\n'.join(report)+'\n',encoding='utf-8')
    files=list(q.glob('*.csv'))+list(q.glob('*.py'))+[q/'REPORT.md',q/'PROTOCOL.txt',q/'native_ILI.json']+list((q/'streams').rglob('complete.json'))+list((q/'scores').rglob('done.json'))
    files+=list((q/'streams').rglob('*.npz'))+list((q/'streams').rglob('model.pt'))+[p for name in ['predictions.npz','endpoints.npz'] for p in (q/'scores').rglob(name)]+[q/'evaluate.log',q/'train.log',q/'native.log']
    with zipfile.ZipFile(q/'DUET_paired_results.zip','w',compression=zipfile.ZIP_DEFLATED) as f:
        for p in files:f.write(p,p.relative_to(q))
    print(s.query("scope=='all'").to_string(index=False));print(checks)
if __name__=='__main__':run()


