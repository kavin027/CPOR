from pathlib import Path
from fractions import Fraction
from collections import defaultdict
import ast,json,sys,hashlib,time
import numpy as np
import pandas as pd
from scipy.optimize import nnls

h=Path(__file__).resolve().parent;o=h.parent
sys.path.insert(0,str(o/"cpor_envelope_comparison_20261024"))
import run_comparison as c
old_source=(o/"cpor_kdd_safe_controls_20261105/replay.py").read_text(encoding="utf-8-sig")
tree=ast.parse(old_source)
funcs=[n for n in tree.body if isinstance(n,ast.FunctionDef)]
namespace=dict(np=np,Fraction=Fraction,R=c.RR)
exec(compile(ast.Module(body=funcs,type_ignores=[]),"<frozen-safe-controls>","exec"),namespace)
ray=namespace["ray"]
exact=namespace["exact"]
feasible=namespace["feasible"]
settle=namespace["settle"]
idx=pd.read_csv(c.INDEX).query("seed==42")
mapping=pd.read_csv(o/"kais_review_v2_revision_20261017/Online_Resource_3/review_evidence/node_map.csv")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def risk(pred,b,y):
    bq=[Fraction(0)]*pred.shape[1];ever=set();events=0
    for p,ref,obs in zip(pred,b,y):
        for i,(a,v,z) in enumerate(zip(exact(p),exact(ref),exact(obs))):
            bq[i]+=c.RR*(v-z)**2-(a-z)**2
            if bq[i]<0:ever.add(i);events+=1
    return len(ever),events

records=[];risks=[];node_records=[];receipts=[]
selected_methods=sys.argv[1:] or ["KDDResidual","MCGradRegression","MCGradRegressionBlockRefit"]
if sys.argv[1:]:
    for filename,dest in [("cells.csv",records),("risk.csv",risks),("nodes.csv",node_records),("sources.csv",receipts)]:
        old=pd.read_csv(h/filename)
        dest.extend(old[~old.external.isin(selected_methods)].to_dict("records"))
for name in selected_methods:
    for row in idx.itertuples():
        key=dict(dataset=row.dataset,backbone=row.backbone,window=row.window)
        source=Path(row.source);x=c.load(source/"endpoints.npz");S=x["S"];b=x["b"][36:];y=x["truth"][36:]
        loc=(o/"cpor_kdd_comparison_20261105/runs" if name=="KDDResidual" else h/"runs"/name)/row.dataset/row.backbone/row.window
        target=np.load(loc/"target.npz")["pred"];release=np.load(loc/"release.npz")
        pred=release["pred"];us=release["witness"]
        _,audit=c.states_and_audit(x,pred,us,"nonnegative")
        if name=="KDDResidual":
            prior=o/"cpor_kdd_safe_controls_20261105"/f"{row.dataset}_{row.backbone}_{row.window}.npz"
            rp=np.load(prior)["ray"]
        else:
            dest=loc/"ray.npz"
            if not dest.exists():
                D=S/np.sqrt(x["v"][:,None]);norm=np.linalg.norm(D,axis=0);valid=norm>0;D=D[:,valid]/norm[valid]
                balance=[Fraction(0)]*len(b[0]);rays=[];weights=[]
                for z,v,t in zip(target,b,y):
                    u=np.zeros(S.shape[1]);u[valid]=nnls(D,z/np.sqrt(x["v"]),maxiter=10*len(norm))[0]/norm[valid]
                    q,w=ray(v,S@u,exact(v),balance)
                    assert feasible(exact(v),exact(q),balance)
                    balance=settle(exact(v),exact(q),exact(t),balance)
                    rays.append(q);weights.append(w)
                np.savez_compressed(dest,pred=rays,weight=weights)
            rp=np.load(dest)["pred"]
        for ref,actual in [(b,x["ub"][36:]@S.T)]:
            np.testing.assert_allclose(ref,actual,rtol=1e-8,atol=2e-6)
        methods=dict(Direct=target,Full=pred,Ray=rp,Anchor=b,Raw=x["raw"][36:],
                     Cov=np.load(source/"CovFullFix.npz")["pred"],
                     ML=np.load(source/"controls.npz")["ProtectedMLPol"])
        selected=mapping[mapping.dataset==row.dataset]
        scopes=sorted(set(";".join(selected.scopes).split(";")))
        for method,forecasts in methods.items():
            assert forecasts.shape==y.shape and np.isfinite(forecasts).all()
            errors=np.sqrt(((forecasts-y)**2).mean(0))
            for scope in scopes:
                node=selected.loc[selected.scopes.str.split(";").map(lambda s:scope in s),"node"].to_numpy(int)
                records.append(dict(external=name,**key,method=method,scope=scope,rmse=float(errors[node].mean())))
            for i,e in enumerate(errors): node_records.append(dict(external=name,**key,method=method,node=i,rmse=e))
            if method in ["Direct","Full","Ray","Anchor"]:
                ever,events=risk(forecasts,b,y)
                if method!="Direct":assert ever==events==0
                risks.append(dict(external=name,**key,method=method,ever=ever,events=events,nodes=y.shape[1],dates=y.size))
        meta=json.loads((loc/("fit.json" if name=="KDDResidual" else "receipt.json")).read_text(encoding="utf-8-sig"))
        assert meta["endpoint_hash"]==sha(source/"endpoints.npz")
        receipt=dict(external=name,**key,source=str(loc),endpoint_hash=meta["endpoint_hash"],target_hash=sha(loc/"target.npz"),release_hash=sha(loc/"release.npz"))
        if name=="MCGradRegression":
            saved=json.loads((loc/"model.json").read_text())
            receipt["selected_rounds"]=len(saved["mcgrad"]);receipt["zero_adjustment"]=meta["zero_adjustment"]
        if name=="MCGradRegressionBlockRefit":
            receipt["zero_adjustment"]=meta["zero_adjustment"]
            receipt["selected_rounds_per_block"]=",".join(str(s["selected_rounds"]) for s in meta["stages"])
        receipts.append(receipt)
        print(name,*key.values(),flush=True)
pd.DataFrame(records).to_csv(h/"cells.csv",index=False)
pd.DataFrame(risks).to_csv(h/"risk.csv",index=False)
pd.DataFrame(node_records).to_csv(h/"nodes.csv",index=False)
pd.DataFrame(receipts).to_csv(h/"sources.csv",index=False)
g=pd.DataFrame(records).groupby(["external","scope","dataset","backbone","method"]).rmse.mean().unstack()
g.to_csv(h/"groups.csv")
rows=[]
for (ext,scope),v in g.groupby(level=["external","scope"]):
    v=v.droplevel(["external","scope"])
    for a,b0 in [("Cov","Direct"),("ML","Direct"),("Cov","Full"),("ML","Full"),("Full","Direct"),("Full","Ray"),("Full","Anchor"),("Direct","Raw")]:
        z=100*(1-v[a]/v[b0]); clusters=z.groupby(level="dataset").mean()
        if len(clusters)==6:
            rng=np.random.default_rng(20261106);draws=rng.choice(clusters.values,size=(10000,6),replace=True).mean(1)
            lo,hi=np.quantile(draws,[.025,.975])
        else:lo=hi=float("nan")
        rows.append(dict(external=ext,scope=scope,method=a,comparator=b0,groups=len(v),wins=int((z>0).sum()),mean_pct=z.mean(),median_pct=z.median(),dataset_bootstrap_low=lo,dataset_bootstrap_high=hi))
summary=pd.DataFrame(rows);summary.to_csv(h/"paired.csv",index=False)
print(summary.query("scope=='all'").to_string(index=False))



