from pathlib import Path
import sys,json,time,logging
import numpy as np
import pandas as pd
import mcgrad_grid as frozen
from mcgrad.methods import RegressionMCGrad
h=Path(__file__).resolve().parent
c=frozen.c
grid=frozen.grid
frame=frozen.frame
logging.disable(logging.WARNING)
for r in grid.idx.itertuples():
    dest=h/"runs/MCGradRegressionBlockRefit"/r.dataset/r.backbone/r.window
    if (dest/"receipt.json").exists(): continue
    original=h/"runs/MCGradRegression"/r.dataset/r.backbone/r.window
    x,residual,dates,info=grid.get(r)
    saved=np.load(info["history_file"])
    a=saved["raw"][:-72] if r.backbone=="DLinear" or r.dataset=="M5" else saved["raw"]
    y=saved["truth"][:-72] if r.backbone=="DLinear" or r.dataset=="M5" else saved["truth"]
    a=a[-len(residual):].astype(float);y=y[-len(residual):]
    np.testing.assert_array_equal(a-y,residual)
    target=[]; stages=[];dest.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter()
    for j in range(0,72,12):
        raw=np.concatenate([a,x["raw"][36:36+j]])[-144:]
        truth=np.concatenate([y,x["truth"][36:36+j]])[-144:]
        n=len(raw);cut=n-(12 if n<60 else 24)
        if j==0:
            model=RegressionMCGrad.deserialize((original/"model.json").read_text())
        else:
            data=frame(raw,j-n);data["y"]=truth.flatten()
            model=RegressionMCGrad(early_stopping_use_crossvalidation=False,early_stopping_timeout=None,lightgbm_params={"num_threads":1,"verbosity":-1},random_state=42)
            model.fit(data.iloc[:cut*raw.shape[1]].copy(),label_column_name="y",df_val=data.iloc[cut*raw.shape[1]:].copy(),prediction_column_name="raw",categorical_feature_column_names=["node"],numerical_feature_column_names=["h"])
        pred=model.predict(frame(x["raw"][36+j:48+j],j),prediction_column_name="raw",categorical_feature_column_names=["node"],numerical_feature_column_names=["h"]).reshape(12,-1)
        if j==0:np.testing.assert_array_equal(pred,np.load(original/"target.npz")["pred"][:12])
        target.extend(pred);stages.append(dict(issue=j,history=n,fit_dates=cut,val_dates=n-cut,selected_rounds=len(model.mr),latest_returned_scored_index=j-1,first_forecast_scored_index=j))
        (dest/f"model_{j}.json").write_text(model.serialize())
    target=np.array(target);fit_s=time.perf_counter()-start
    assert target.shape==x["truth"][36:].shape
    release=c.run(x,target,"ML",r.dataset,"nonnegative")
    _,audit=c.states_and_audit(x,release["pred"],release["witness"],"nonnegative")
    np.savez_compressed(dest/"target.npz",pred=target)
    np.savez_compressed(dest/"release.npz",pred=release["pred"],witness=release["witness"])
    meta=json.loads((original/"receipt.json").read_text())
    receipt=dict(**info,method="MCGrad author regression extension with block-start chronological refits",commit=meta["commit"],fit_predict_seconds=fit_s,protect_seconds=release["elapsed_seconds"],audit=audit,stages=stages,zero_adjustment=bool(np.array_equal(target,x["raw"][36:])),target_sha256=frozen.sha(dest/"target.npz"),release_sha256=frozen.sha(dest/"release.npz"))
    (dest/"receipt.json").write_text(json.dumps(receipt,indent=2))
    print(r.dataset,r.backbone,r.window,[s["selected_rounds"] for s in stages],flush=True)

