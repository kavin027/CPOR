from pathlib import Path
import sys,json,hashlib,logging,csv,collections,statistics
import numpy as np
import pandas as pd

h=Path(__file__).resolve().parent;o=h.parent
deps=o/"cpor_named_venue_screen_20261105"
sys.path[:0]=[str(deps/"MCGrad/src"),str(deps/"deps")]
from mcgrad.methods import RegressionMCGrad
logging.disable(logging.WARNING)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
index=pd.read_csv(o/"cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv").query("seed==42")
verified=[]
for ext in ["MCGradRegression","MCGradRegressionBlockRefit"]:
    for r in index.itertuples():
        d=h/"runs"/ext/r.dataset/r.backbone/r.window
        meta=json.loads((d/"receipt.json").read_text())
        assert sha(Path(r.source)/"endpoints.npz")==meta["endpoint_hash"]
        for file,key in [("target.npz","target_sha256"),("release.npz","release_sha256")]:assert sha(d/file)==meta[key]
        x=np.load(Path(r.source)/"endpoints.npz");raw=x["raw"][36:]
        rows=[];rounds=[]
        for j in ([0] if ext=="MCGradRegression" else range(0,72,12)):
            f="model.json" if ext=="MCGradRegression" else f"model_{j}.json"
            model=RegressionMCGrad.deserialize((d/f).read_text())
            a=raw if ext=="MCGradRegression" else raw[j:j+12]
            n=a.shape[1]
            frame=pd.DataFrame({"raw":a.flatten().astype(float),"node":np.tile([f"n{i}" for i in range(n)],len(a)),"h":np.repeat(1+(j+np.arange(len(a)))%12,n)})
            rows.extend(model.predict(frame,prediction_column_name="raw",categorical_feature_column_names=["node"],numerical_feature_column_names=["h"]).reshape(a.shape))
            rounds.append(len(model.mr))
        np.testing.assert_array_equal(rows,np.load(d/"target.npz")["pred"])
        verified.append(dict(external=ext,dataset=r.dataset,backbone=r.backbone,window=r.window,model_replay_exact=True,selected_rounds=",".join(map(str,rounds)),zero_adjustment=meta["zero_adjustment"]))
# Independently reaggregate using stdlib from configuration rows.
with (h/"cells.csv").open() as f:rows=list(csv.DictReader(f))
values=collections.defaultdict(list)
for r in rows:values[r["external"],r["scope"],r["dataset"],r["backbone"],r["method"]].append(float(r["rmse"]))
means={k:statistics.mean(v) for k,v in values.items()}
with (h/"paired.csv").open() as f:
    for r in csv.DictReader(f):
        d=[100*(1-value/means[ext,scope,ds,bb,r["comparator"]]) for (ext,scope,ds,bb,method),value in means.items() if ext==r["external"] and scope==r["scope"] and method==r["method"]]
        assert len(d)==int(r["groups"])
        assert sum(x>0 for x in d)==int(r["wins"])
        assert abs(statistics.mean(d)-float(r["mean_pct"]))<1e-10
        assert abs(statistics.median(d)-float(r["median_pct"]))<1e-10
# Protecting the stored target and anchor independently are verified by score.py.
risk=pd.read_csv(h/"risk.csv")
assert len(risk)==264
assert risk[risk.method!="Direct"].ever.sum()==0
print(risk.groupby(["external","method"])[["ever","events","nodes","dates"]].sum().to_string())
pd.DataFrame(verified).to_csv(h/"model_replay_checks.csv",index=False)
(h/"verification.json").write_text(json.dumps({"trajectories_replayed_exactly":len(verified),"serialized_models_checked":154,"comparison_rows_checked":len(pd.read_csv(h/"paired.csv")),"single_initialization":True,"zero_adjustments":sum(r["zero_adjustment"] for r in verified)},indent=2))
print("PASS 154 saved fixed/block MCGrad models reproduce target predictions exactly; every paired summary recomputed independently.")


