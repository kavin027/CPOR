from pathlib import Path
from fractions import Fraction
import hashlib
import json
import sys
import numpy as np
import pandas as pd
from scipy.optimize import nnls

here = Path(__file__).resolve().parent
out = here.parent
kdd = out / "cpor_kdd_comparison_20261105"
sys.path.insert(0, str(out / "cpor_envelope_comparison_20261024"))
import run_comparison as project

R = Fraction(40401,40000)
def exact(a):
    return [Fraction.from_float(float(x)) for x in a]
def feasible(b, p, bal):
    return all((x*x-R*v*v if x>R*v else R*(x-v)**2/(R-1))<=a for v,x,a in zip(b,p,bal))
def settle(b,p,y,bal):
    delta = [a+R*(v-z)**2-(x-z)**2 for v,x,z,a in zip(b,p,y,bal)]
    assert min(delta)>=0
    return delta

def ray(b,z,bq,bal):
    # Invert the scalar envelope; exact tests below certify the stored vector.
    a = np.array([float(v) for v in bal])
    r = float(R)
    width = np.sqrt(a*(r-1)/r)
    lo = np.maximum(0,b-width)
    hi = np.where(a<=r*(r-1)*b*b, b+width, np.sqrt(a+r*b*b))
    direction = z-b
    ratios = np.ones_like(b)
    up,down = direction>0,direction<0
    ratios[up] = (hi[up]-b[up])/direction[up]
    ratios[down] = (lo[down]-b[down])/direction[down]
    t = min(1.,max(0.,float(ratios.min())))
    for contraction in [1.,1.-1e-12,1.-1e-10,1.-1e-8,1.-1e-6,1.-1e-4]:
        w = t*contraction
        p = z if w==1 else (1-w)*b+w*z
        if feasible(bq,exact(p),bal): return p,w
    # Rounding very close to the anchor can mask the effect of the backoff.
    l,h=0.,t
    for _ in range(45):
        w=(l+h)*0.5
        if feasible(bq,exact((1-w)*b+w*z),bal): l=w
        else: h=w
    return (1-l)*b+l*z,l

mapping = pd.read_csv(out/"kais_review_v2_revision_20261017/Online_Resource_3/review_evidence/node_map.csv")
idx = pd.read_csv(project.INDEX).query("seed==42")
assert len(idx)==22
rows=[]
checks=[]
for row in idx.itertuples():
    ds,bb,w = row.dataset,row.backbone,row.window
    folder=kdd/"runs"/ds/bb/w
    ep=Path(row.source)/"endpoints.npz"
    assert hashlib.sha256(ep.read_bytes()).hexdigest()==json.loads((folder/"fit.json").read_bytes())["endpoint_hash"]
    x=project.load(ep)
    raw=np.load(folder/"target.npz")["pred"]
    protected=np.load(folder/"release.npz")
    S=x["S"]; base=x["b"][36:]; obs=x["truth"][36:]; ub=x["ub"][36:]; v=x["v"]
    np.testing.assert_allclose(base,ub@S.T,rtol=1e-8,atol=2e-6)
    assert ub.min()>=0
    D=S/np.sqrt(v[:,None]); norm=np.linalg.norm(D,axis=0); keep=norm>0; D=D[:,keep]/norm[keep]
    histories={arm:[] for arm in ("gate","ray","full","anchor")}
    allowances={arm:[Fraction(0)]*len(v) for arm in histories}
    wt=[]; accepts=0
    for j,(target,b,y) in enumerate(zip(raw,base,obs)):
        u=np.zeros(S.shape[1])
        u[keep]=nnls(D,target/np.sqrt(v),maxiter=10*len(norm))[0]/norm[keep]
        z=S@u
        bq,yq=exact(b),exact(y)
        passes=feasible(bq,exact(z),allowances["gate"])
        g=z if passes else b; accepts+=int(passes)
        p,t=ray(b,z,bq,allowances["ray"]); wt.append(t)
        for arm,forecast,witness in [("gate",g,u if passes else ub[j]),("ray",p,(1-t)*ub[j]+t*u),("full",protected["pred"][j],protected["witness"][j]),("anchor",b,ub[j])]:
            assert min(witness)>=0
            np.testing.assert_allclose(forecast,S@witness,rtol=1e-8,atol=2e-6)
            fq=exact(forecast)
            assert feasible(bq,fq,allowances[arm])
            allowances[arm]=settle(bq,fq,yq,allowances[arm])
            histories[arm].append(forecast)
    np.savez_compressed(here/f"{ds}_{bb}_{w}.npz",gate=histories["gate"],ray=histories["ray"],ray_fraction=wt)
    checks.append((ds,bb,w,accepts,len(wt),len(v),np.mean(wt)))
    nodes=mapping[mapping.dataset==ds]
    for scope in sorted(set(';'.join(nodes.scopes).split(';'))):
        ind=nodes.loc[nodes.scopes.str.split(';').map(lambda li:scope in li),"node"].to_numpy(int)
        rows.append(dict(dataset=ds,backbone=bb,window=w,scope=scope,**{arm:np.sqrt(np.mean((np.array(arr)-obs)**2,axis=0))[ind].mean() for arm,arr in histories.items()}))
frame=pd.DataFrame(rows)
frame.to_csv(here/"cells.csv",index=False)
checks=pd.DataFrame(checks,columns=["dataset","backbone","window","gate_accept","issues","nodes","mean_ray_weight"])
checks.to_csv(here/"checks.csv",index=False)
group=frame.groupby(["scope","dataset","backbone"]).mean(numeric_only=True)
group.to_csv(here/"groups.csv")
results=[]
for scope in group.index.unique(level=0):
    g=group.xs(scope)
    for comp in ["ray","gate","anchor"]:
        gains=100*(1-g.full/g[comp])
        results.append(dict(scope=scope,comparator=comp,groups=len(g),wins=int((gains>0).sum()),mean_pct=gains.mean(),median_pct=gains.median()))
summary=pd.DataFrame(results);summary.to_csv(here/"paired.csv",index=False)
print(summary[summary.scope.isin(["all","bottom","region","system"])].to_string(index=False))
print("gate accepts",checks.gate_accept.sum(),"of",checks.issues.sum(),"checked per arm",(checks.nodes*checks.issues).sum())

