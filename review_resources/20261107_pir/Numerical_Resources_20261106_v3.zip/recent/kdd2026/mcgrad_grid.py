from pathlib import Path
import sys,json,logging,time,hashlib,subprocess
import numpy as np
import pandas as pd
h=Path(__file__).resolve().parent;o=h.parent
repo=o/"cpor_named_venue_screen_20261105"
sys.path[:0]=[str(repo/"MCGrad/src"),str(repo/"deps"),str(o/"cpor_kdd_comparison_20261105"),str(o/"cpor_envelope_comparison_20261024")]
from mcgrad.methods import RegressionMCGrad
import ast
from types import SimpleNamespace
import run_comparison as c
logging.disable(logging.INFO)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(o/"cpor_kdd_comparison_20261105/grid.py").read_text(encoding="utf8")
tree=ast.parse(source)
getter=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="get")
namespace=dict(Path=Path,np=np,pd=pd,O=o,sha=sha,json=json)
exec(compile(ast.Module(body=[getter],type_ignores=[]),"<frozen-history-getter>","exec"),namespace)
grid=SimpleNamespace(get=namespace["get"],idx=pd.read_csv(c.INDEX).query("seed==42"))
def frame(a,offset):
    count,n=a.shape
    return pd.DataFrame(dict(raw=a.flatten().astype(float),node=np.tile([f"n{i}" for i in range(n)],count),h=np.repeat(1+(np.arange(count)+offset)%12,n)))
def main():
    # Pin all author dependencies used in the local harness.
    commit=subprocess.check_output(["git","-C",str(repo/"MCGrad"),"rev-parse","HEAD"],text=True).strip()
    assert commit=="00d3fcce645c13e4b9b13cceaccb4543a0c6146e"
    import pytest
    result=pytest.main([str(repo/"MCGrad/src/mcgrad/tests/test_methods.py"),"-k","RegressionMCGrad and (fit_transform_identical or deserialized_mcgrad_fits_correct)","-q","-o","cache_dir="+str(h/"pytest_cache")])
    assert result==0
    for r in grid.idx.itertuples():
        dest=h/"runs"/"MCGradRegression"/r.dataset/r.backbone/r.window
        if (dest/"receipt.json").exists():continue
        x,residual,dates,meta=grid.get(r)
        z=np.load(meta["history_file"])
        a=z["raw"][:-72] if r.backbone=="DLinear" or r.dataset=="M5" else z["raw"]
        y=z["truth"][:-72] if r.backbone=="DLinear" or r.dataset=="M5" else z["truth"]
        a=a[-len(residual):].astype(float);y=y[-len(residual):]
        np.testing.assert_array_equal(a-y,residual)
        n=len(a);cut=n-(12 if n<60 else 24)
        data=frame(a,-n);data["y"]=y.flatten()
        tr=data.iloc[:cut*a.shape[1]].copy();valid=data.iloc[cut*a.shape[1]:].copy()
        model=RegressionMCGrad(early_stopping_use_crossvalidation=False,early_stopping_timeout=None,lightgbm_params={"num_threads":1,"verbosity":-1},random_state=42)
        kw=dict(prediction_column_name="raw",categorical_feature_column_names=["node"],numerical_feature_column_names=["h"])
        start=time.perf_counter()
        model.fit(tr,label_column_name="y",df_val=valid,**kw)
        fit_s=time.perf_counter()-start
        start=time.perf_counter();prediction=model.predict(frame(x["raw"][36:],0),**kw).reshape(72,-1);predict_s=time.perf_counter()-start
        assert np.isfinite(prediction).all()
        release=c.run(x,prediction,"ML",r.dataset,"nonnegative")
        _,audit=c.states_and_audit(x,release["pred"],release["witness"],"nonnegative")
        dest.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(dest/"target.npz",pred=prediction)
        np.savez_compressed(dest/"release.npz",pred=release["pred"],witness=release["witness"])
        (dest/"model.json").write_text(model.serialize(),encoding="utf8")
        receipt=dict(**meta,method="RegressionMCGrad author extension",commit=commit,fit_dates=cut,validation_dates=n-cut,fit_seconds=fit_s,predict_seconds=predict_s,protect_seconds=release["elapsed_seconds"],zero_adjustment=bool(np.array_equal(prediction,x["raw"][36:])),rounds=str(getattr(model,"num_rounds",None)),audit=audit,target_sha256=sha(dest/"target.npz"),release_sha256=sha(dest/"release.npz"))
        (dest/"receipt.json").write_text(json.dumps(receipt,indent=2),encoding="utf8")
        print(r.dataset,r.backbone,r.window,"done",receipt["zero_adjustment"],receipt["rounds"],flush=True)
if __name__=="__main__":main()



