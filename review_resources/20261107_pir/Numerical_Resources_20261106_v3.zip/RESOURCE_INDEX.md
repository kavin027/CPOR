# CPOR final-v2 resource index

Knowledge and Information Systems; 25 October 2026. This archive is Online Resource 2 (ESM_2.zip). Online Resource 1 (ESM_1.pdf) contains the 8-page supplement. The main manuscript has 23 pages.

## Result locations

| Current paper location | Supplied evidence |
|---|---|
| Main Table 6; supplementary Table S4 | Base archive: GROUP_RUN_RMSE.csv, ALL_CELL_METRICS.csv, EXPECTED_SUMMARY.json |
| Main Table 7 | Base archive: RISK_SUMMARY.csv and protection receipts |
| Main Figure 2; supplementary Tables S7-S9 | Base archive: matched_envelope/analysis/PAIRED_GROUP_RUN.csv, PAIRED_GROUP.csv, PAIRED_LEVEL_RUN.csv, NODE_DISTRIBUTION.csv |
| Main Table 8; supplementary S3 / Table S6 | Base archive: matched_envelope/analysis/ENVELOPE_GROUP_RUN.csv, ENVELOPE_GROUP.csv, MECHANISM_CELLS.csv |
| Main Table 9; supplementary Table S5 | Base archive: GROUP_RUN_RMSE.csv, classical-control records |
| Main Table 10 | Base archive: LEVEL_RUNS.csv, LEVEL_MEAN_SD.csv |
| Main Table 11; supplementary Table S13 | Base archive: timing_full/ISSUE_TIMES.csv, TIMING_SUMMARY.csv; evidence_closure/TIMING_TAILS.csv |
| Supplementary Table S10 | paired_run_addendum/PAIRED_RUN_GAINS.csv |
| Supplementary S5 / Table S11 | evidence_closure/UNCERTAINTY.csv, PAIRED_EFFECTS.csv, DOMAIN_INTERVALS.csv |
| Supplementary S6 / Table S12 | evidence_closure/EVENTS.csv, EVENT_SUMMARY.csv and runs/ receipts |
| Supplementary S7 | evidence_closure/M5_PATH_SENSITIVITY.csv, M5_PATH_SUMMARY.json and m5_path/ receipts |
| Supplementary S8 / Table S14 | review_followup/PIR_DATASET_RUNS.csv |
| Protection cost distributions | evidence_closure/COST_SUMMARY.csv; review_followup/COST_DISTRIBUTION.csv, COST_ORDER_AND_TRIM.csv |
| Configuration, training and source correspondence | Base archive: CONFIG_INDEX/, ALL_FITTING_STAGES.csv, ALL_EXTERNAL_RECEIPTS.csv, source_map.json, archived_source/ |

## Run the aggregate checks

Extract CPOR_CovML_Results_Minor_20261024.zip into base_results/ without adding another directory level. With Python 3, run the following from this archive's root:

```text
python base_results/check_results.py
python paired_run_addendum/check_paired_run_gains.py
python evidence_closure/check_addendum.py
python review_followup/check_followup.py
```

The scripts use the Python standard library and supplied files. The base checker also checks matched-envelope and timing aggregates. These checks verify arithmetic and recorded hashes/receipts; they do not regenerate neural predictions or rerun protection trajectories. The frozen base archive SHA256 is a75e6d4ee796925707886e51775275e42a10f5ccdc20ff5c68a754124c03a023.

## Source and replay scope

The public code repository is https://github.com/kavin027/CPOR . The historical base-resource commit is f197beef1b713c8d0cb9b43f9b5b6fc0ae46bcaa; the current delivery is fixed by PACKAGE_MANIFEST_SHA256.json, not attributed to that older commit.

Original-path replay drivers and receipts retain their provenance paths. Replay requires the recorded project layout and archived targets, references, observations, variance weights and aggregation matrices; those arrays are not all present in this aggregate resource. Source/data conditions remain as stated in the base archive's REPRODUCTION.md. Requests for missing replay inputs should be addressed to the corresponding author subject to source terms.

The addenda preserve scientific result records and replay drivers. Editorial-review checks were removed from the delivery copies of check_addendum.py and check_followup.py because simulated-review records are not submission evidence. Their new hashes are recorded in the delivery manifests. The author's frozen copies remain unchanged.
