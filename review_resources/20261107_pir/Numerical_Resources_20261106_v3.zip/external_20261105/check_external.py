"""Check all aggregate cells used by the extension, using Python's standard library."""
from pathlib import Path
from collections import defaultdict
from statistics import mean,median
import csv,json,math
H=Path(__file__).resolve().parent
def read(n):return list(csv.DictReader((H/n).open(encoding='utf-8-sig')))
cells=defaultdict(list)
for r in read('cells.csv'):
 cells[(r['dataset'],r['backbone'],r['scope'],r['method'])].append(float(r['rmse']))
g={k:mean(v) for k,v in cells.items()}
for r in read('paired.csv'):
 a=r['method'];b=r['comparator'];ss=r['scope']
 d=[100*(1-v/g[(ds,bb,ss,b)]) for (ds,bb,s,m),v in g.items() if s==ss and m==a]
 assert len(d)==int(r['groups']) and sum(x>0 for x in d)==int(r['wins'])
 assert math.isclose(mean(d),float(r['mean_pct']),abs_tol=1e-8) and math.isclose(median(d),float(r['median_pct']),abs_tol=1e-8)
risk=defaultdict(lambda:[0,0,0])
for r in read('risk.csv'):
 for i,k in enumerate(['sequences','ever','final']):risk[r['method']][i]+=int(r[k])
assert risk['COSA']==[1998,1565,520] and risk['RobustMN']==[1998,1995,1949]
assert all(risk[k]==[1998,0,0] for k in risk if k.endswith('+P'))
assert json.loads((H/'audit.json').read_text())['checks']==3*1998*72
print('PASS: all paired means, medians, win counts, and published risk counts verified from configuration-level records.')
