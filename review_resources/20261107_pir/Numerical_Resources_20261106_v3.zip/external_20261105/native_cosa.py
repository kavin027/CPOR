from pathlib import Path
import os,sys,subprocess
h=Path(__file__).resolve().parent; native=h/'native'
e=dict(os.environ,PYTHONPATH=str(h/'deps'),TORCH_HOME=str(h/'native/torch'),TORCHINDUCTOR_CACHE_DIR=str(h/'native/torchinductor'),CUDA_CACHE_PATH=str(h/'native/cuda'))
args=['DATA.BASE_DIR',str(native/'data'),'DATA.NAME','ETTh1','DATA.PRED_LEN','96','MODEL.NAME','DLinear','MODEL.pred_len','96','DATA_LOADER.NUM_WORKERS','0','TRAIN.CHECKPOINT_DIR','./checkpoints/DLinear/ETTh1_96/','RESULT_DIR','./results/COSA/']
for tag,extra in [('train',['TRAIN.ENABLE','True']),('adapt',['TRAIN.ENABLE','False','TTA.ENABLE','True','TTA.SOLVER.BASE_LR','0.001','TTA.SOLVER.WEIGHT_DECAY','0.0001','TTA.COSA.BUFFER_CONTEXT_SIZE','10','TTA.COSA.STEPS','3','TTA.COSA.BATCH_SIZE','48','TTA.COSA.PAAS','True','TTA.COSA.PERIOD_N','1','TTA.COSA.FAST_ADAPTATION','True','TTA.COSA.ADAPTIVE_LR','True','TTA.COSA.PER_BATCH_LR_RESET','True','TTA.COSA.MAX_LR','0.005','TTA.COSA.MIN_LR','0.0001','TTA.COSA.POGT','True','TTA.COSA.PARTIAL_ADAPT','True','TTA.COSA.ADJUST_PRED','True'])]:
 with (native/(tag+'.log')).open('w') as f:subprocess.run([sys.executable,'-u',str(h/'COSA/main.py'),*args,*extra],cwd=native,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
