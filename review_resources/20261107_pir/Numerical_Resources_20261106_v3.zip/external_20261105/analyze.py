from pathlib import Path
import numpy as np,pandas as pd,json,hashlib
from fractions import Fraction as F
H=Path(__file__).resolve().parent;O=H.parent
idx=pd.read_csv(O/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv').query('seed==42')
mm=pd.read_csv(O/'kais_review_v2_revision_20261017/Online_Resource_3/review_evidence/node_map.csv')
R=F(40401,40000);rows=[];risk=[];tim=[];events=[];checks=0
def exact(y,b,p,protected):
 global checks
 ever=set();last=set();A=[F(0)]*y.shape[1]
 for t in range(len(y)):
  last=set()
  for i,(actual,anchor,pub) in enumerate(zip(y[t],b[t],p[t])):
   actual,anchor,pub=map(lambda v:F.from_float(float(v)),(actual,anchor,pub))
   if protected:
    gamma=(pub**2-R*anchor**2 if pub>R*anchor else R*(pub-anchor)**2/(R-1))
    assert gamma<=A[i];checks+=1
   A[i]+=R*(actual-anchor)**2-(actual-pub)**2
   if A[i]<0:ever.add(i);last.add(i)
 if protected:assert not ever
 return len(ever),len(last)
for r in idx.itertuples():
 d=Path(r.source);f=H/'runs'/r.dataset/r.backbone/r.window;z=np.load(d/'endpoints.npz');y=z['truth'][36:];b=z['b'][36:];s=z['S'];sp=json.loads((f/'spec.json').read_text()); assert sp['input_sha256']==hashlib.sha256((d/'endpoints.npz').read_bytes()).hexdigest()
 arms={'Cov':np.load(d/'CovFullFix.npz')['pred'],'ML':np.load(d/'controls.npz')['ProtectedMLPol'],'Raw':z['raw'][36:],'NNLS':b}
 for m,a in np.load(f/'targets.npz').items():
  pp=np.load(f/(m+'.npz'))
  p,u=pp['pred'],pp['witness'];np.testing.assert_allclose(p,u@s.T,atol=2e-6,rtol=1e-8);assert u.min()>=0
  arms[m]=a;arms[m+'+P']=p
  audit=json.loads((f/(m+'.json')).read_text());tim.append(dict(dataset=r.dataset,backbone=r.backbone,window=r.window,method=m,release_s=audit['release_seconds'],target_s=sp['cosa_scored_seconds'] if m=='COSA' else np.nan,fit_s=sp['cosa_cal_seconds'] if m=='COSA' else sp['robust_fit_apply_seconds']))
 for m,p in arms.items():
  node=((p-y)**2).mean(0)**.5;assert len(p)==72 and np.all(np.isfinite(node))
  ever,final=exact(y,b,p,m.endswith('+P')) if m not in ('Cov','ML','NNLS','Raw') else (None,None)
  if ever is not None:risk.append(dict(dataset=r.dataset,backbone=r.backbone,window=r.window,method=m,sequences=len(node),ever=ever,final=final))
  mloc=mm[mm.dataset==r.dataset]
  for scope in sorted(set(';'.join(mloc.scopes).split(';'))):
   ii=mloc.loc[mloc.scopes.apply(lambda z:scope in z.split(';')),'node'].astype(int)
   rows.append(dict(dataset=r.dataset,backbone=r.backbone,window=r.window,scope=scope,method=m,rmse=node[ii].mean()))
rs=pd.DataFrame(rows);rs.to_csv(H/'cells.csv',index=False)
g=rs.groupby(['dataset','backbone','scope','method']).rmse.mean().unstack();g.to_csv(H/'groups.csv')
w=g.xs('all',level='scope'); print(w.round(3).to_string())
p=[]
for scope in g.index.get_level_values('scope').unique():
 v=g.xs(scope,level='scope')
 for b in ['COSA','COSA+P','RobustMN','RobustMN+P','RobustOrth','RobustOrth+P']:
  for a in ['Cov','ML']:
   diff=100*(1-v[a]/v[b]);p.append(dict(scope=scope,method=a,comparator=b,groups=len(v),mean_pct=diff.mean(),median_pct=diff.median(),wins=int((diff>0).sum())))
p=pd.DataFrame(p);p.to_csv(H/'paired.csv',index=False);print(p[p.scope=='all'].round(3).to_string(index=False))
risk=pd.DataFrame(risk);risk.to_csv(H/'risk.csv',index=False);print(risk.groupby('method')[['sequences','ever','final']].sum())
print('checks',checks);print('median group paired protection cost')
for m in ['COSA','RobustMN','RobustOrth']:
 cost=100*(w[m+'+P']/w[m]-1);print(m,cost.mean(),cost.median())
pd.DataFrame(tim).to_csv(H/'timing.csv',index=False)
(H/'audit.json').write_text(json.dumps(dict(cells=len(idx),checks=checks,scope='independent exact envelope and prefix replay plus released representation tolerances on all protected external arms (including tie-break sensitivity)'),indent=2))
