from grid import *
r=next(pd.read_csv(rollout.INDEX).query("seed==42 and dataset=='RH'").itertuples()); x=rollout.load(Path(r.source)/'endpoints.npz')
saved=np.load(H/'runs'/r.dataset/r.backbone/r.window/'targets.npz')['COSA'];y=x['truth'].copy();y[42:]+=1000
q,*_=cosa(x['raw'],y)
np.testing.assert_array_equal(saved[:7],q[:7]);assert np.max(abs(saved[7:]-q[7:]))>0
print('Causal perturbation: changing the observation at scored issue 7 and later left publications 1..7 identical.')
