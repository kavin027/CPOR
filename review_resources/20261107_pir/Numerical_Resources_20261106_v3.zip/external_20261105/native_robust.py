from pathlib import Path
import sys,os,json,ast,subprocess
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H/'deps'));sys.path.insert(0,str(H/'ROBUST'))
import numpy as np,pandas as pd,cvxpy as cp
if not hasattr(np,'float_'):np.float_=np.float64
from prophet import Prophet
from hierarchical_forecast.proposal import var_matrix
from threadpoolctl import threadpool_limits
from types import SimpleNamespace
# Use authors' actual base routine without importing unrelated tree-model dependencies.
path=H/'ROBUST/hierarchical_forecast/base_forecast.py';node=next(v for v in ast.parse(path.read_text()).body if getattr(v,'name','')=='base_prophet')
exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'))
df=pd.read_csv(H/'ROBUST/data/1_birth.csv',index_col=0);df.index=pd.to_datetime(df.index)
df.insert(0,'total',df.sum(axis=1));ntrain=sum(df.index<'2018-01-01');assert ntrain==516 and len(df)-ntrain==60
cache=H/'native/birth_predictions.csv'
if not cache.exists():base_prophet(df,ntrain).to_csv(cache)
base=pd.read_csv(cache,index_col=0).to_numpy();y=df.to_numpy(); x=base[:ntrain]; yy=y[:ntrain];s=np.vstack([np.ones(9),np.eye(9)])
beta=np.linalg.pinv(x)@yy
p=base[ntrain:]@beta
# Independent small SDP using authors' bootstrap bounds, the paper's birth alpha and a compressed time axis.
# Decompose Y into row-space fit and orthogonal residual. Parameter D moves the fitted coherent coordinates; residual scatter changes by S D D' S'.
lo,hi=var_matrix(pd.DataFrame(x-yy),516,9,1,5000,1.0)
sc=np.mean(abs(lo))+np.mean(abs(hi));lo/=sc;hi/=sc
er=yy-x@beta; rr=er.T@er;rr/=np.linalg.norm(rr)
l=cp.Variable((10,10),PSD=True);u=cp.Variable((10,10),PSD=True);D=cp.Variable((9,10))
C=[l>=0,u>=0,cp.bmat([[u-l-rr,s@D],[D.T@s.T,np.eye(10)]])>>0]
obj=cp.trace(hi.T@u)-cp.trace(lo.T@l)
pr=cp.Problem(cp.Minimize(obj),C);v=pr.solve(solver='CLARABEL')
pf=cp.Problem(cp.Minimize(obj),C+[D==0]);v0=pf.solve(solver='CLARABEL')
assert abs(v-v0)<1e-5*max(1,abs(v0))
rb=np.mean((base[ntrain:]-y[ntrain:])**2,axis=0)**.5
ratio=np.mean((p-y[ntrain:])**2,axis=0)**.5/rb
out=dict(data='Australian births',paper_ratios=[.968,.973],measured=[ratio[0],ratio[1:].mean()],source_alpha=1,sdps=[v,v0],relative_gap=abs(v-v0)/max(abs(v0),1e-10),status=[pr.status,pf.status],note='Paper-selected alpha; new Prophet fits, independent equivalent solver; no MOSEK run or claim of exact environment replication.')
print(out);(H/'native/robust_check.json').write_text(json.dumps(out,indent=2))
