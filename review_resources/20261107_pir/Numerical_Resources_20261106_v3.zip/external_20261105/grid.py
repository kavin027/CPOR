from pathlib import Path
import sys,time,json,traceback,hashlib,types,warnings
from collections import deque,defaultdict
import numpy as np,pandas as pd,torch
H=Path(__file__).resolve().parent; O=H.parent
sys.path[:0]=[str(H/'deps'),str(H/'COSA'),str(O/'cpor_envelope_comparison_20261024')]
from tta.cosa import SimpleOutputAdapter,SimpleAdapter
sys.path.remove(str(H/'COSA'))
for name in list(sys.modules):
 if name=='models' or name.startswith('models.'): del sys.modules[name]
import run_comparison as rollout
torch.set_num_threads(1)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cosa(raw,truth):
 # Only calibration statistics are accessed up front, before any scored issue.
 mu=truth[:36].mean(0);sd=truth[:36].std(0);sd=np.where(sd>1e-12,sd,1)
 torch.manual_seed(0)
 a=types.SimpleNamespace()
 a.output_adapter=SimpleOutputAdapter(12,10,raw.shape[1],True)
 a.optimizer=torch.optim.Adam(a.output_adapter.parameters(),lr=.001,weight_decay=.0001)
 a.fast_adaptation=a.adaptive_lr=a.per_batch_lr_reset=True
 a.max_lr=.005;a.min_lr=.0001;a.current_lr=.001;a.adapt_steps=3;a.l2_reg=.0001;a.convergence_threshold=1e-5
 a.cfg=types.SimpleNamespace(TTA=types.SimpleNamespace(SOLVER=types.SimpleNamespace(BASE_LR=.001)))
 a.loss_history=deque(maxlen=5);a.n_adapt=0;a.time_stats=defaultdict(float);a.time_counts=defaultdict(int)
 a.switch_model_to_train=a.output_adapter.train;a.switch_model_to_eval=a.output_adapter.eval
 a._adaptive_learning_rate=types.MethodType(SimpleAdapter._adaptive_learning_rate,a)
 hist=[];out=[];dt=[]
 for t in range(0,len(raw),12):
  # Entire raw horizon available at the block start. No future ground truth in the input.
  pred=torch.tensor((raw[t:t+12]-mu)/sd,dtype=torch.float32)[None]
  past=hist[-10:][::-1];ctx=torch.tensor((past+[past[-1]]*(10-len(past))) if past else [0.]*10,dtype=torch.float32)[None]
  observed=[]
  for j in range(12):
   st=time.perf_counter()
   with torch.no_grad(): out.append(a.output_adapter(pred,ctx)[0,j].numpy().astype(float)*sd+mu)
   observed.append((truth[t+j]-mu)/sd)
   gt=torch.zeros_like(pred);gt[0,:j+1]=torch.as_tensor(np.array(observed),dtype=torch.float32)
   mask=(torch.arange(12)<j+1)[None] if j<11 else None
   SimpleAdapter._run_adapt_steps(a,pred,gt,ctx,3,t+j,'partial' if j<11 else 'full',mask)
   dt.append(time.perf_counter()-st)
  hist.append(float(np.mean(observed)))
 return np.array(out[36:]),sum(dt[36:]),sum(dt[:36])
def robust(x,y,s):
 x=np.asarray(x,dtype=float);y=np.asarray(y,dtype=float);s=np.asarray(s,dtype=float)
 # all arguments contain calibration observations only; X,Y are time x node.
 xpin=np.linalg.pinv(x); ps=s@np.linalg.pinv(s);proj=xpin@x
 beta=xpin@y@ps.T
 res=y-x@beta; norm=lambda z:np.linalg.norm(z)
 coherent=norm(y-y@ps.T)/max(norm(y),1)
 orth=norm(x.T@res)/max(norm(x)*norm(y),1)
 assert coherent<1e-10 and orth<1e-6,(coherent,orth)
 err=x-y; t,n=err.shape; e=err-err.mean(0);q=e[:,:,None]*e[:,None,:]
 cm=q.mean(0)*t/(t-1);vs=((q-q.mean(0))**2).sum(0)*t/(t-1)**3
 off=~np.eye(n,dtype=bool);l=vs[off].sum()/(cm[off]**2).sum()
 ix=np.random.default_rng(0).choice(t,t,replace=True);w=np.cov(err[ix].T);w=l*np.diag(np.diag(w))+(1-l)*w
 precision=np.linalg.pinv(w,hermitian=True); eig=np.linalg.eigvalsh(precision)
 assert eig[0]>=-1e-10*max(1,eig[-1])
 return beta,beta+(np.eye(n)-proj)@ps.T,dict(rank=int(np.linalg.matrix_rank(x)),nodes=n,coherence=coherent,normal_equation=orth,psd_min=float(eig[0]),lmd=float(l))
def run(r):
 root=Path(r.source); dest=H/'runs'/r.dataset/r.backbone/r.window;dest.mkdir(parents=True,exist_ok=True)
 x=rollout.load(root/'endpoints.npz'); y=x['truth']; raw=x['raw']; s=x['S']
 if not (dest/'targets.npz').exists():
  t=time.perf_counter();beta,other,diag=robust(raw[:36],y[:36],s);rob=raw[36:]@beta;alt=raw[36:]@other;rt=time.perf_counter()-t
  target,ct,cc=cosa(raw,y)
  np.savez_compressed(dest/'targets.npz',COSA=target,RobustMN=rob,RobustOrth=alt)
  (dest/'spec.json').write_text(json.dumps(dict(robust=diag,cosa_scored_seconds=ct,cosa_cal_seconds=cc,robust_fit_apply_seconds=rt,input_sha256=sha(root/'endpoints.npz')),indent=2))
 for method,p in np.load(dest/'targets.npz').items():
  f=dest/(method+'.npz')
  if f.exists():continue
  a=rollout.run(x,p,'ML',r.dataset,'nonnegative')
  _,audit=rollout.states_and_audit(x,a['pred'],a['witness'],'nonnegative')
  np.savez_compressed(f,pred=a['pred'],witness=a['witness'])
  (dest/(method+'.json')).write_text(json.dumps(dict(audit=audit,release_seconds=a['elapsed_seconds'],stats=a['stats']),default=str))
 print('OK',r.dataset,r.backbone,r.window,flush=True)
if __name__=='__main__':
 idx=pd.read_csv(rollout.INDEX);rows=list(idx[idx.seed==42].itertuples());assert len(rows)==22
 for r in rows:
  try:run(r)
  except Exception:traceback.print_exc()
