from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib,json,sys
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
H=Path(__file__).resolve().parent
O=H.parent
sys.path.insert(0,str(O/'cpor_duet_stream_20261106'))
import evaluate as duet
c=duet.c
key=['dataset','backbone','window','seed']
methods=['PIR','Candidate','Ray','Full']
def inventory():
    traj=pd.read_csv(c.INDEX)
    inputs=json.loads((c.INDEX.parent/'INPUT_HASHES.json').read_text())
    old=O/'cpor_external_repetitions_20261020'
    dx=O/'dlinear_10000_three_runs_20261021'
    pp={(r['cell'],r['seed']):Path(r['path']) for r in json.loads((old/'RESULT_INDEX.json').read_text()) if r['method']=='PIR'}
    ph=json.loads((old/'INPUT_SHA256.json').read_text())
    dh=pd.read_csv(dx/'ALL_EXTERNAL_RECEIPTS.csv').query("method=='PIR'").set_index(['dataset','window','seed'])
    metrics=pd.read_csv(dx/'ALL_CELL_METRICS.csv').query("method=='PIR'")
    patch=pd.read_csv(dx/'REUSED_PATCHTST_ALL_RUNS.csv').query("method=='PIR'")
    metrics=pd.concat([metrics.query("backbone=='DLinear'"),patch]).set_index(key)
    assert len(metrics)==66 and metrics.index.is_unique
    entries=[]
    for r in traj.to_dict('records'):
        ds,bb,w,seed=(r[k] for k in key)
        ep=Path(r['source'])/'endpoints.npz'
        path=pp[f'{ds}_{bb}_{w}.npz',seed] if bb=='PatchTST' else ep.parent/'PIR.npz'
        pir_hash=ph[str(path)] if bb=='PatchTST' else dh.loc[(ds,w,seed),'sha256']
        assert c.sha(ep)==inputs[str(ep)] and c.sha(path)==pir_hash
        entries.append(dict(**{k:r[k] for k in key},ep=str(ep),pir=str(path),ep_sha=inputs[str(ep)],pir_sha=pir_hash,archived_rmse=metrics.loc[(ds,bb,w,seed),'rmse']))
    assert len(entries)==66
    return entries

def run(r):
    ds,bb,w,seed=(r[k] for k in key)
    out=H/'streams'/ds/bb/w/str(seed)
    out.mkdir(parents=True,exist_ok=True)
    x=c.load(Path(r['ep']))
    data=c.load(Path(r['pir']))
    pir=data['pred'];y=x['truth'][36:];anchor=x['b'][36:]
    assert y.shape==pir.shape and len(y)==72 and np.isfinite(pir).all()
    for field,expected in [('truth',y),('raw',x['raw'][36:])]:
        if field in data:np.testing.assert_allclose(data[field],expected,rtol=1e-12,atol=1e-8)
    rmse=lambda p:np.sqrt(np.mean((p-y)**2,axis=0))
    np.testing.assert_allclose(rmse(pir).mean(),r['archived_rmse'],rtol=1e-11,atol=1e-10)
    with threadpool_limits(1):
        z,u=duet.cpu.old.project(x['S'],pir,x['v'])
        assert np.isfinite(z).all() and u.min()>=0
        np.testing.assert_allclose(z,u@x['S'].T,rtol=1e-8,atol=2e-6)
        z.setflags(write=False)
        ray,ru=duet.shrink(x,z,u)
        full=c.run(x,z,'ML',ds,'nonnegative')
        prof={}; scores=[]; audits=[]
        for method,forecast,witness in [('PIR',pir,None),('Candidate',z,u),('Ray',ray,ru),('Full',full['pred'],full['witness'])]:
            nodes=duet.mapping.query('dataset==@ds').sort_values('node')
            np.testing.assert_array_equal(nodes.node,np.arange(y.shape[1]))
            row={k:r[k] for k in key}
            if method in ('Ray','Full'):
                _,audit=c.states_and_audit(x,forecast,witness,'nonnegative')
                np.testing.assert_array_equal(forecast[0],anchor[0]) if np.array_equal(forecast[0],anchor[0]) else np.testing.assert_allclose(forecast[0],anchor[0],rtol=0,atol=1e-10)
            else:audit={}
            ever,events=duet.risk(forecast,anchor,y)
            audits.append(dict(**row,method=method,nodes=y.shape[1],node_dates=y.size,ever=ever,events=events,**audit))
            if method in ('Ray','Full'):assert ever==events==0
            err=rmse(forecast)
            scopes={s:nodes.scopes.str.split(';').map(lambda v:s in v).to_numpy() for s in sorted(set(';'.join(nodes.scopes).split(';')))}
            if ds in ('Traffic','Wiki2','Labour','M5'):scopes['middle']=~(scopes['bottom']|scopes['system'])
            if ds=='RH':scopes['other_observed']=~scopes['system']
            for scope,mask in scopes.items():scores.append(dict(**row,method=method,scope=scope,rmse=err[mask].mean()))
        np.savez_compressed(out/'releases.npz',target=z,target_u=u,ray=ray,ray_u=ru,full=full['pred'],full_u=full['witness'])
        pd.DataFrame(scores).to_csv(out/'metrics.csv',index=False)
        pd.DataFrame(audits).to_csv(out/'audit.csv',index=False)
        (out/'DONE.json').write_text(json.dumps(dict(**r,release_hash=c.sha(out/'releases.npz')),indent=2))
    return f'{ds}/{bb}/{w}/{seed}'

if __name__=='__main__':
    entries=inventory()
    pd.DataFrame(entries).to_csv(H/'inputs.csv',index=False)
    with ProcessPoolExecutor(max_workers=5) as pool:
        futures=[pool.submit(run,r) for r in entries if not (H/'streams'/r['dataset']/r['backbone']/r['window']/str(r['seed'])/'DONE.json').exists()]
        for n,f in enumerate(as_completed(futures),1):print(n,len(futures),f.result(),flush=True)
