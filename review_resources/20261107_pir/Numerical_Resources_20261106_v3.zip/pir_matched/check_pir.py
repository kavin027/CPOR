"""Recompute the PIR columns of Table 8 and Table S20. Requires only Python 3."""
import csv
from collections import defaultdict
from math import isclose
from pathlib import Path
from statistics import mean

root=Path(__file__).resolve().parent
def read(name):
    with (root/name).open(encoding="utf-8-sig",newline="") as stream:
        return list(csv.DictReader(stream))
windows=read("window_rmse.csv")
key=lambda r:(r["dataset"],r["backbone"],r["window"],r["seed"])
assert len({key(r) for r in windows})==66
assert len(windows)==len({(*key(r),r["scope"]) for r in windows})
groups=defaultdict(list)
for r in windows:
    groups[r["scope"],r["dataset"],r["backbone"],r["seed"]].append(r)
expanded=defaultdict(list)
dataset=defaultdict(list)
byback=defaultdict(list)
byseed=defaultdict(list)
bycost=defaultdict(list)
for (scope,ds,back,seed),rows in groups.items():
    assert len(rows)==(1 if ds=="Labour" else 2)
    candidate,ray,full=[mean(float(r[m]) for r in rows) for m in ("Candidate","Ray","Full")]
    gain=100*(1-full/ray)
    dataset[scope,ds].append((ray,full,gain))
    expanded[scope,ds].append((candidate,ray,full,100*(full/candidate-1),gain))
    if scope=="all":
        byback[ds,back].append(gain)
        byseed[seed].append(gain)
        bycost[ds].append((100*(full/candidate-1),100*(ray/candidate-1)))
def means(rows):
    return tuple(map(mean,zip(*rows)))
records=read("dataset_rmse.csv")
assert len(records)==len(dataset)
for r in records:
    calc=means(dataset[r["scope"],r["dataset"]])
    assert all(isclose(a,float(r[k]),abs_tol=1e-9,rel_tol=1e-12) for a,k in zip(calc,("Ray","Full","full_vs_ray_pct")))
ds_order=["ECommerce","Labour","M5","RH","Traffic","Wiki2"]
reported=[means(dataset["all",ds])[2] for ds in ds_order]
assert [round(x,2) for x in reported]==[.11,3.22,2.46,2.86,1.96,1.93]
assert round(mean(reported),2)==2.09
assert round(mean(means(v)[0] for v in bycost.values()),2)==2.31
assert round(mean(means(v)[1] for v in bycost.values()),2)==4.58
assert round(mean(means(v)[2] for (s,ds),v in dataset.items() if s=="system"),2)==2.34
assert round(means(dataset["state","M5"])[2],2)==2.51 and round(means(dataset["region","Labour"])[2],2)==3.10
allrows=[r for r in windows if r["scope"]=="all"]
losses=[r for r in allrows if float(r["Full"])>float(r["Ray"])]
assert len(losses)==8 and {r["dataset"] for r in losses}=={"ECommerce"}
assert round(max(100*(float(r["Full"])/float(r["Ray"])-1) for r in losses),2)==.42
assert round(mean(byback["ECommerce","PatchTST"]),2)==-.05
assert [round(mean(byseed[s]),2) for s in ("42","1","2")]==[1.73,2.35,2.20]
audit=read("window_audit.csv")
for method,ever in [("Ray",0),("Full",0),("Candidate",4925)]:
    rows=[r for r in audit if r["method"]==method]
    assert len({key(r) for r in rows})==len(rows)==66
    assert sum(int(r["nodes"]) for r in rows)==5994 and sum(int(r["ever"]) for r in rows)==ever
    if method!="Candidate":
        assert sum(int(float(r["exact_node_checks"])) for r in rows)==431568
        assert sum(int(r["events"]) for r in rows)==0
print("PIR: 66 streams, Table 8, layer means, paired costs, ECommerce exceptions and archived audit totals verified.")

for r in records:
    calculated=means(expanded[r['scope'],r['dataset']])
    for value,col in zip(calculated,['Candidate','Ray','Full','full_cost_vs_candidate_pct','full_vs_ray_pct']):
        assert isclose(value,float(r[col]),abs_tol=1e-9,rel_tol=1e-12)
assert sum(float(r["Full"])<float(r["Ray"]) for r in allrows)==58
example=read('labour_release2.csv')
assert len(example)==57 and all(float(r['ray_credit'])==float(r['full_credit']) for r in example)
binding=min(example,key=lambda r:float(r['limit_factor']))
assert binding['node']=='42' and round(100*float(binding['limit_factor']),3)==.295
west=next(r for r in example if r['node']=='8')
assert tuple(round(float(west[m])-float(west['ref']),3) for m in ('target','ray','full'))==(4.552,.013,.073)
print("S20: direct RMSE, both contrast denominators, bottom levels and same-state Labour example verified.")
