from pathlib import Path
from statistics import mean
import json,hashlib
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent
sources=pd.read_csv(H/'inputs.csv')
assert len(sources)==66
rows=[];checks=[]
keys=['dataset','backbone','window','seed']
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for r in sources.to_dict('records'):
    d=H/'streams'/r['dataset']/r['backbone']/r['window']/str(r['seed'])
    receipt=json.loads((d/'DONE.json').read_text())
    assert receipt['release_hash']==sha(d/'releases.npz')
    m=pd.read_csv(d/'metrics.csv')
    a=pd.read_csv(d/'audit.csv')
    with np.load(d/'releases.npz') as p,np.load(r['ep']) as x:
        for name,k in [('Candidate','target'),('Ray','ray'),('Full','full')]:
            expected=m.loc[(m.scope=='all')&(m.method==name),'rmse'].item()
            assert np.isclose(np.sqrt(np.square(p[k]-x['truth'][36:]).mean(0)).mean(),expected,rtol=1e-12,atol=1e-12)
    rows.append(m);checks.append(a)
frame=pd.concat(rows,ignore_index=True);audit=pd.concat(checks,ignore_index=True)
assert not frame.duplicated(keys+['scope','method']).any()
window=frame.pivot(index=keys+['scope'],columns='method',values='rmse').reset_index()
methods=['PIR','Candidate','Ray','Full']
byrun=window.groupby(['scope','dataset','backbone','seed'])[methods].mean()
def contrasts(df):
    result=df.copy()
    result['full_vs_ray_pct']=100*(1-result.Full/result.Ray)
    result['full_cost_vs_candidate_pct']=100*(result.Full/result.Candidate-1)
    result['ray_cost_vs_candidate_pct']=100*(result.Ray/result.Candidate-1)
    return result
window=contrasts(window);byrun=contrasts(byrun).reset_index()
avgcols=methods+['full_vs_ray_pct','full_cost_vs_candidate_pct','ray_cost_vs_candidate_pct']
def average(dim):
    return byrun.groupby(dim,as_index=False)[avgcols].mean()
ds=average(['scope','dataset'])
bb=average(['scope','dataset','backbone'])
seeds=byrun.groupby(['scope','seed'],as_index=False)[avgcols[4:]].mean()
run_ds=average(['scope','dataset','seed'])
disp=run_ds.groupby(['scope','dataset']).full_vs_ray_pct.std().rename('run_sd_pp').reset_index()
ds=ds.merge(disp,on=['scope','dataset'],validate='one_to_one')
auds=audit.groupby(['dataset','method'],as_index=False)[['nodes','node_dates','ever','events']].sum()
for method in ['Ray','Full']:
    guard=audit.query('method==@method')
    assert guard.node_dates.sum()==guard.exact_node_checks.sum()==431568 and guard.nodes.sum()==5994 and not guard.ever.any() and not guard.events.any()
assert len(byrun.query("scope=='all'"))==36 and len(bb.query("scope=='all'"))==12 and len(ds.query("scope=='all'"))==6
for df,name in [(window,'window_rmse'),(byrun,'group_run_rmse'),(bb,'backbone_rmse'),(ds,'dataset_rmse'),(run_ds,'dataset_run_rmse'),(seeds,'run_summary'),(audit,'window_audit'),(auds,'dataset_audit')]:
    df.to_csv(H/(name+'.csv'),index=False)
print(ds[['scope','dataset','Ray','Full','full_vs_ray_pct','full_cost_vs_candidate_pct','run_sd_pp']].round(5).to_string(index=False))
print('RUNS',seeds.query("scope=='all'").to_string(index=False))
print('BACKBONES',bb.query("scope=='all'")[['dataset','backbone','full_vs_ray_pct']].to_string(index=False))
print('AUDIT',auds.pivot(index='dataset',columns='method',values='ever').to_string())
for scope in ['all','system','middle','region','state','bottom']:
    d=ds.query('scope==@scope')
    print('SCOPE',scope,'mean%',d.full_vs_ray_pct.mean(),'wins',sum(d.full_vs_ray_pct>0),'groups',len(d))
v=byrun.query("scope=='all'").full_vs_ray_pct
print('PRIMARY',sum(v>0),len(v),v.mean(),'window wins',sum(window.query("scope=='all'").full_vs_ray_pct>0),'backbone wins',sum(bb.query("scope=='all'").full_vs_ray_pct>0),'cost',byrun.query("scope=='all'").full_cost_vs_candidate_pct.mean(),byrun.query("scope=='all'").ray_cost_vs_candidate_pct.mean())
print(auds.groupby('method')[['nodes','node_dates','ever','events']].sum().to_string())
