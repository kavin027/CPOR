"""Aggregate the locked grid and independently check sampled two-variable QPs."""
from pathlib import Path
import json
from collections import Counter
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from run import HERE, OLD, c, arms, keys, ns
from grouped import optimum

def percent(frame):
    return pd.DataFrame(dict(group_vs_ray=100*(1-frame.Group/frame.Ray),
                             full_vs_group=100*(1-frame.Full/frame.Group),
                             full_vs_ray=100*(1-frame.Full/frame.Ray)))

def verify_gradient(D, lo, hi, v, w):
    # A separate LP checks the first-order condition on the entire polygon.
    grad=D.T@((D@(w-1.))/v)
    norm=max(1.,np.abs(grad).max())
    A=np.vstack((D,-D))
    h=np.r_[hi,-lo]
    scale=np.maximum(1.,np.max(abs(A),axis=1))
    lp=linprog(grad/norm,A_ub=A/scale[:,None],b_ub=h/scale,bounds=(0,1),method='highs')
    assert lp.success
    value=.5*np.sum((D@(w-1.))**2/v)
    gap=max(0.,float(grad@(w-lp.x)))/(1.+value)
    return gap

def report():
    df=pd.read_csv(OLD/'inputs.csv')
    groups=json.loads((HERE/'groups.json').read_text())
    records=[]; timings=[]; guards=Counter(); diagnostic=[]
    for i,r in enumerate(df.itertuples()):
        rel=Path(r.dataset)/r.backbone/r.window/str(r.seed)
        out=HERE/'streams'/rel
        receipt=json.loads((out/'complete.json').read_text())
        assert receipt['release']==c.sha(out/'group.npz') and receipt['ep']==c.sha(r.ep)
        labels=dict(zip(keys,[r.dataset,r.backbone,r.window,r.seed]))
        records.append(pd.read_csv(out/'stats.csv').assign(**labels))
        timings.append(pd.read_csv(out/'time.csv').assign(**labels))
        with np.load(out/'group.npz') as a:
            guards.update(a['repair'].tolist())
            # One pre-specified interior date in each stream, plus boundary tests.
            x=c.load(r.ep); d=c.load(OLD/'streams'/rel/'releases.npz'); j=35
            bal=[c.Fraction(0)]*len(x['v'])
            for t in range(j):
                bal=ns['settle'](ns['exact'](x['b'][36+t]),ns['exact'](a['p'][t]),ns['exact'](x['truth'][36+t]),bal)
            b=x['b'][36+j]; ub=x['ub'][36+j]; m=groups[r.dataset]['first']
            target=d['target'][j]; u=d['target_u'][j]; d0=x['S'][:,m]@(u[m]-ub[m])
            D=np.column_stack((d0,target-b-d0))
            R=float(c.RR); A=np.array(list(map(float,bal))); w0=np.sqrt(A*(R-1)/R)
            lo=np.maximum(-b,-w0); hi=np.where(A<=R*(R-1)*b*b,w0,np.sqrt(A+R*b*b)-b)
            w=optimum(D,lo,hi,1/x['v'])
            gap=verify_gradient(D,lo,hi,x['v'],w)
            assert gap<2e-6,(labels,gap)
            diagnostic.append(dict(**labels,release=j+1,relative_gap=gap))
    stats=pd.concat(records,ignore_index=True); time=pd.concat(timings,ignore_index=True)
    assert len(stats)==66*3 and len(time)==66*72*3 and not time.duplicated(keys+['step','arm']).any()
    stats.to_csv(HERE/'stream_metrics.csv',index=False);time.to_csv(HERE/'release_times.csv',index=False)
    pd.DataFrame(diagnostic).to_csv(HERE/'objective_spot_checks.csv',index=False)
    windows=stats.pivot(index=keys,columns='arm',values='rmse')
    byrun=windows.groupby(['dataset','backbone','seed']).mean()
    paired=percent(byrun)
    combined=byrun.join(paired).groupby('dataset').mean()
    overall=paired.mean()
    wins=percent(windows).gt(0).sum()
    losses=percent(windows).lt(0).sum()
    ties=66-wins-losses
    per_tests=pd.concat({name:op for name,op in [('wins',percent(windows).gt(0)),('losses',percent(windows).lt(0)),('ties',percent(windows).eq(0))]},axis=1).groupby('dataset').sum()
    per_tests.to_csv(HERE/'signs.csv')
    combined.to_csv(HERE/'dataset_rmse.csv')
    grouped=time.groupby(['dataset','arm']).ms
    speeds=grouped.agg(mean='mean',p95=lambda a:a.quantile(.95))
    speeds.to_csv(HERE/'dataset_timing.csv')
    audit=stats.groupby(['dataset','arm'])[['nodes','exact_node_checks','ever','events']].sum()
    audit.to_csv(HERE/'dataset_audit.csv')
    old=pd.read_csv(OLD/'window_rmse.csv').query("scope=='all'").set_index(keys)
    for arm in ['Ray','Full']:
        np.testing.assert_allclose(old.loc[windows.index,arm],windows[arm],rtol=2e-14,atol=1e-10)
    print('Dataset RMSE and paired improvements:\n',combined.round(5).to_string())
    print('Across six datasets:\n',overall.to_string(),'\nstream counts:\n',pd.DataFrame(dict(wins=wins,losses=losses,ties=ties)).to_string())
    print('Timing:\n',speeds.unstack().round(3).to_string())
    print('Pooled times:',time.groupby('arm').ms.agg(['mean',lambda s:s.quantile(.95)]).to_string())
    print('Audit:\n',audit.groupby('arm').sum().to_string(),'\nGrouped numerics:',guards,'\nmax LP check gap:',max(d['relative_gap'] for d in diagnostic))
    print('Signs by dataset:\n',per_tests.to_string())
if __name__=='__main__':
    report()
