from pathlib import Path
import json, sys, time, warnings, platform
from fractions import Fraction
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from grouped import grouped, partition

HERE = Path(__file__).resolve().parent
OLD = HERE.parent/'cpor_pir_matched_20261106'
sys.path.insert(0,str(HERE.parent/'cpor_duet_stream_20261106'))
import evaluate as duet
c = duet.c
ns = duet.ns
keys = ['dataset','backbone','window','seed']
arms = ['Ray','Group','Full']

def locked_inputs(rows):
    groups = {}
    for r in rows.itertuples():
        assert c.sha(r.ep) == r.ep_sha
        with np.load(r.ep) as x:
            S = x['S']
            first = partition(S).tolist()
            dskey = dict(first=first,second=sorted(set(range(S.shape[1]))-set(first)),rows=S.shape[0])
            if r.dataset in groups:
                assert groups[r.dataset] == dskey
            groups[r.dataset] = dskey
    path = HERE/'groups.json'
    if path.exists():
        assert json.loads(path.read_text()) == groups
    else:
        path.write_text(json.dumps(groups,indent=2))
    return groups

def run(cell, num, group):
    rel = Path(cell.dataset)/cell.backbone/cell.window/str(cell.seed)
    path = HERE/'streams'/rel
    path.mkdir(parents=True,exist_ok=True)
    if (path/'complete.json').exists():
        return
    archive = OLD/'streams'/rel/'releases.npz'
    assert c.sha(archive) == json.loads((archive.parent/'DONE.json').read_text())['release_hash']
    x = c.load(Path(cell.ep))
    frozen = c.load(archive)
    S = x['S']
    mask = np.array(group['first'])
    SA = np.ascontiguousarray(S[:,mask])
    inv_var = 1./x['v']
    k = c.kernels('nonnegative')
    qp = k['old'].SafeProjection(S,x['v'])
    balances = {m:[Fraction(0)]*len(inv_var) for m in arms}
    pred = {m:[] for m in arms}
    witnesses = {m:[] for m in arms}
    times, groupweights, repairs = [], [], []
    for j in range(72):
        t=j+36
        b,ub=x['b'][t],x['ub'][t]
        z,u=frozen['target'][j],frozen['target_u'][j]
        start=(num+j)%3
        for arm in arms[start:]+arms[:start]:
            bal=balances[arm]
            tick=time.perf_counter_ns()
            if arm=='Ray':
                p,w=ns['ray'](b,z,ns['exact'](b),bal)
                witness=(1.-w)*ub+w*u
            elif arm=='Group':
                p,witness,weights,repair=grouped(SA,mask,b,ub,z,u,bal,ns['exact'](b),inv_var,ns,float(c.RR))
            else:
                p,witness,_=k['ml'](qp,S,b,ub,z,bal)
            assert k['certified'](b,p,bal,c.RR,c.K) and witness.min()>=0
            assert np.allclose(S@witness,p,rtol=1e-8,atol=2e-6)
            ms=(time.perf_counter_ns()-tick)/1e6
            times.append(dict(step=j+1,arm=arm,ms=ms))
            pred[arm].append(p)
            witnesses[arm].append(witness)
            if arm=='Group':
                groupweights.append(weights)
                repairs.append(repair)
        for arm in arms:
            balances[arm]=ns['settle'](ns['exact'](b),ns['exact'](pred[arm][-1]),ns['exact'](x['truth'][t]),balances[arm])
    np.savez_compressed(path/'group.npz',p=pred['Group'],u=witnesses['Group'],coefficients=groupweights,repair=repairs)
    stats=[]
    for arm in arms:
        a=np.array(pred[arm])
        if arm!='Group':
            assert np.array_equal(a,frozen[arm.lower()]), (arm,rel,np.max(abs(a-frozen[arm.lower()])))
        _,audit=c.states_and_audit(x,a,np.array(witnesses[arm]),'nonnegative')
        nodes=np.sqrt(np.mean((a-x['truth'][36:108])**2,axis=0))
        stats.append(dict(arm=arm,rmse=nodes.mean(),nodes=len(nodes),events=0,ever=0,**audit))
    pd.DataFrame(stats).to_csv(path/'stats.csv',index=False)
    pd.DataFrame(times).to_csv(path/'time.csv',index=False)
    (path/'complete.json').write_text(json.dumps(dict(input=c.sha(archive),ep=cell.ep_sha,release=c.sha(path/'group.npz'))))
    print(num+1,rel,flush=True)

if __name__=='__main__':
    df=pd.read_csv(OLD/'inputs.csv')
    assert len(df)==66 and not df.duplicated(keys).any()
    with threadpool_limits(1):
        groups=locked_inputs(df)
        for n,r in enumerate(df.itertuples()):
            run(r,n,groups[r.dataset])
