"""Rebuild grouped-PIR columns of Table 8 and S21 from the bundled records."""
import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean
from math import isclose, floor

here = Path(__file__).resolve().parent
def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def key(row):
    return tuple(row[k] for k in ('dataset','backbone','seed','window'))

def p95(values):
    values=sorted(values)
    pos=.95*(len(values)-1)
    i=floor(pos)
    return values[i]+(pos-i)*(values[i+1]-values[i])

arms=('Ray','Group','Full')
reference={key(r):r for r in read(here.parent/'pir_matched/window_rmse.csv') if r['scope']=='all'}
cell=defaultdict(dict)
audit=defaultdict(list)
for r in read(here/'stream_metrics.csv'):
    k=key(r)
    assert r['arm'] not in cell[k]
    cell[k][r['arm']]=float(r['rmse'])
    audit[r['arm']].append(r)
assert len(reference)==len(cell)==66
paired=defaultdict(list)
negatives=defaultdict(list)
for k,values in cell.items():
    assert set(values)==set(arms)
    for arm in ('Ray','Full'):
        assert isclose(values[arm],float(reference[k][arm]),rel_tol=1e-12)
    values['Direct']=float(reference[k]['Candidate'])
    paired[k[:3]].append(values)
    for control in ('Ray','Group'):
        if values['Full']>=values[control]:
            assert values['Full']>values[control]
            negatives[control].append(k[0])
assert negatives['Ray']==['ECommerce']*8 and negatives['Group']==['ECommerce']*7
dataset=defaultdict(list)
for (ds,bb,seed),rows in paired.items():
    assert len(rows)==(1 if ds=='Labour' else 2)
    a={arm:mean(r[arm] for r in rows) for arm in (*arms,'Direct')}
    diffs=[100*(1-a['Full']/a[m]) for m in ('Ray','Group')]
    diffs.append(100*(1-a['Group']/a['Ray']))
    costs=[100*(a[m]/a['Direct']-1) for m in arms]
    dataset[ds].append([*diffs,*costs,*[a[m] for m in arms]])
assert len(dataset)==6 and all(len(v)==6 for v in dataset.values())
means={ds:list(map(mean,zip(*v))) for ds,v in dataset.items()}
assert [round(mean(row[i] for row in means.values()),2) for i in range(6)]==[2.09,1.88,.22,4.58,4.33,2.31]
for r in read(here/'dataset_rmse.csv'):
    row=means[r['dataset']]
    for i,col in enumerate(('full_vs_ray','full_vs_group','group_vs_ray')):
        assert isclose(row[i],float(r[col]),abs_tol=1e-10)
    for i,arm in enumerate(arms,6):
        assert isclose(row[i],float(r[arm]),rel_tol=1e-12)
times=defaultdict(list)
steps=set()
for r in read(here/'release_times.csv'):
    k=key(r)
    identifier=(k,r['arm'],int(r['step']))
    assert k in cell and identifier not in steps and 1<=identifier[2]<=72
    steps.add(identifier)
    times[k[0],r['arm']].append(float(r['ms']))
assert len(steps)==66*72*3
for r in read(here/'dataset_timing.csv'):
    series=times[r['dataset'],r['arm']]
    assert isclose(mean(series),float(r['mean'])) and isclose(p95(series),float(r['p95']))
for arm,expected in zip(arms,[(1.86,5.84),(2.52,7.69),(5.74,15.39)]):
    rows=audit[arm]
    assert [sum(int(r[f]) for r in rows) for f in ('nodes','exact_node_checks','ever','events')]==[5994,431568,0,0]
    vals=[v for (ds,m),series in times.items() if m==arm for v in series]
    assert len(vals)==4752 and (round(mean(vals),2),round(p95(vals),2))==expected
print('Tables 8 and S21 verified: full vs grouped 1.88%, grouped vs common 0.22%; timing, coverage and ECommerce losses agree.')
