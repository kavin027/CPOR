# CPOR numerical resources — final-v2, 25 October 2026

Article: CPOR: Cumulative Protection for Online Reconciliation with Nodewise Error Limits
Author: Lei Zhang, Capital Normal University, lei.zhang@cnu.edu.cn
Journal: Knowledge and Information Systems

Start with RESOURCE_INDEX.md. The unchanged base-results ZIP and the three addenda contain numerical evidence for the current Cov/ML manuscript. Figure 1 editable SVG is under artwork/. The separate LaTeX source ZIP contains the submission sources and rendered figure assets.

Internal simulated-review comments and response documents have been excluded. The two addendum checkers omit checks of those editorial records; all scientific calculations and result records are preserved. PACKAGE_MANIFEST_SHA256.json identifies this delivery. No raw-data retraining or new experiments were performed for packaging.
