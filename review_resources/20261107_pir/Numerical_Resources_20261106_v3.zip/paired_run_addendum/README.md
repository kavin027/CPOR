# Paired training-run gains — Supplementary Table S11

Keep this directory beside `CPOR_CovML_Results_Minor_20261024.zip` and run:

```
python paired_run_addendum/check_paired_run_gains.py
```

The checker uses only Python's standard library and verifies the fixed result ZIP hash, the source CSV hash, all six sets of paired run gains and their sample SDs. No cached observations, prediction replay or model retraining are needed.

`PAIRED_RUN_GAINS.csv` uses the original run order recorded in `PROVENANCE.json`. Each run-level value first averages paired percentage reductions over the twelve dataset–backbone groups. Its SD describes initialization sensitivity on the same observations; it is not a confidence interval for unseen datasets. The frozen source ZIP is unchanged.
