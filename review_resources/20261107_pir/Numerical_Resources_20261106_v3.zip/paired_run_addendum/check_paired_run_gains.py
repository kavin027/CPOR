"""Verify Supplementary Table S11 from the unchanged result ZIP (standard library)."""
from pathlib import Path
import csv,io,zipfile,json,math,hashlib
H=Path(__file__).resolve().parent
archive=H.parent/'CPOR_CovML_Results_Minor_20261024.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='a75e6d4ee796925707886e51775275e42a10f5ccdc20ff5c68a754124c03a023'
with zipfile.ZipFile(archive) as z:raw=z.read('GROUP_RUN_RMSE.csv')
meta=json.loads((H/'PROVENANCE.json').read_text());assert hashlib.sha256(raw).hexdigest()==meta['sha256']
data=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
lookup={(r['dataset'],r['backbone'],r['seed'],r['method']):float(r['rmse']) for r in data}
groups=sorted({k[:2] for k in lookup});assert len(groups)==12
with (H/'PAIRED_RUN_GAINS.csv').open(newline='',encoding='utf-8') as f:reported=list(csv.DictReader(f))
assert len(reported)==6
for r in reported:
 method={'Cov':'CovFullFix','ML':'ProtectedMLPol'}[r['implementation']]
 gains=[]
 for run in meta['run_order']:
  v=[100*(1-lookup[(*g,run,method)]/lookup[(*g,run,r['comparator'])]) for g in groups]
  gains.append(sum(v)/12)
 mean=sum(gains)/3;sd=math.sqrt(sum((x-mean)**2 for x in gains)/2)
 for k,x in zip(['run1','run2','run3','mean','sd'],gains+[mean,sd]):assert math.isclose(float(r[k]),x,abs_tol=1e-10),(k,r,x)
report=dict(passed=True,comparisons=6,groups=12,training_runs=3,new_experiments=0,source_zip_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),scope='Paired arithmetic and initialization sensitivity, not population inference.')
(H/'CHECK_RESULT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
