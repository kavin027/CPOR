from pathlib import Path
from types import SimpleNamespace
import json,sys,hashlib,copy,time,os
H=Path(__file__).resolve().parent;O=H.parent
os.environ.update(TORCH_HOME=str(H/'cache'),CUDA_CACHE_PATH=str(H/'cache'),TORCHINDUCTOR_CACHE_DIR=str(H/'cache'))
import torch,numpy as np,pandas as pd
K=O/'cpor_named_venue_screen_20261105/KDDResidual'
sys.path[:0]=[str(K),str(O/'cpor_external_20261105/deps')]
from model.iTransformer import Model
from utils.timefeatures import time_features
index=O/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv'
idx=pd.read_csv(index).query('seed==42')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def get(r):
 src=Path(r.source); ep=src/'endpoints.npz';x=dict(np.load(ep)); d,bb,w=r.dataset,r.backbone,r.window
 if bb=='DLinear' or d=='M5':
  f=src/'full_stream.npz' if bb=='DLinear' else O/f'c0_frozen_m5_20261014/results/PatchTST/{w}/42/raw.npz'
  z=np.load(f); start=int(z['start']);raw=z['raw'][:-72];y=z['truth'][:-72]
  np.testing.assert_array_equal(z['raw'][-108:],x['raw'])
 else:
  f=O/f'rr_recap_trajectory_learning_20261003/inputs/{d}/{bb}/{w}/train.npz';z=np.load(f);raw=z['raw'];y=z['truth']
  meta=json.loads((f.parent/'metadata.json').read_text());assert sha(f)==meta['output_sha256'];start=meta['end']
 np.testing.assert_array_equal(raw[-36:],x['raw'][:36]);np.testing.assert_array_equal(y[-36:],x['truth'][:36])
 df=O/('c0_frozen_m5_20261014/observed.csv' if d=='M5' else 'rr_recap_evidence_extension_20261002/major_revision_20261002/external/data/Labour.csv' if d=='Labour' else f'procast_joint_safe_20261001_v4/data/{d}.csv')
 wide=pd.read_csv(df);n=min(len(y),144);y=y[-n:];raw=raw[-n:];a=start-n
 np.testing.assert_allclose(wide.iloc[a:start,1:],y,rtol=1e-7);np.testing.assert_allclose(wide.iloc[start:start+72,1:],x['truth'][36:],rtol=1e-7)
 dates=pd.DatetimeIndex(pd.to_datetime(wide.iloc[a:start+72,0]));assert dates.is_monotonic_increasing and dates.is_unique
 return x,raw.astype(float)-y,dates,dict(history_hash=sha(f),endpoint_hash=sha(ep),data_sha=sha(df),history_file=str(f),history_start=str(dates[0]),score_start=str(dates[n]))
def fit(r):
 x,history,dates,info=get(r);raw=x['raw'][36:].astype(float);truth=x['truth'][36:];n=len(history);cut=n-(12 if n<60 else 24)
 torch.manual_seed(42);torch.set_num_threads(1);L=24;h=12
 mu=history[:cut].mean(0);sd=history[:cut].std(0);sd[sd==0]=1
 freq='m' if r.dataset=='Labour' else 'd';dt=time_features(dates,freq=freq).T
 t=lambda a:torch.as_tensor(a,dtype=torch.float32,device='cuda')
 cfg=SimpleNamespace(seq_len=L,pred_len=h,output_attention=False,use_norm=True,d_model=256,embed='timeF',freq=freq,dropout=.1,class_strategy='projection',factor=1,n_heads=8,e_layers=2,d_ff=256,activation='gelu')
 # Initialize on CPU, matching the upstream construction, then transfer to GPU.
 st=time.perf_counter();m=Model(cfg).cuda();opt=torch.optim.Adam(m.parameters(),lr=.0001);fn=torch.nn.HuberLoss()
 def batch(ids):
  return [t(np.stack(a)) for a in [[(history[i-L:i]-mu)/sd for i in ids],[dt[i-L:i] for i in ids],[(history[i:i+h]-mu)/sd for i in ids]]]
 best=float('inf')
 for ep in range(10):
  m.train()
  for off in range(L,cut-h+1,32):
   a,b,y=batch(range(off,min(off+32,cut-h+1)));opt.zero_grad();fn(m(a,b,None,None),y).backward();opt.step()
  m.eval()
  with torch.no_grad():
   a,b,y=batch(range(cut,n-h+1));val=float(fn(m(a,b,None,None),y))
  if val<best:best=val;bestep=ep+1;ck=copy.deepcopy(m.state_dict())
 m.load_state_dict(ck);m.eval();torch.cuda.synchronize();ft=time.perf_counter()-st
 pred=[];hs=history.copy();st=time.perf_counter()
 for j in range(0,72,12):
  with torch.no_grad():e=m(t((hs[-L:]-mu)/sd)[None],t(dt[n+j-L:n+j])[None],None,None)[0].cpu().numpy()*sd+mu
  pred.extend(raw[j:j+h]-.05*e);hs=np.concatenate([hs,raw[j:j+h]-truth[j:j+h]])
 pred=np.array(pred);assert np.isfinite(pred).all()
 d=H/'runs'/r.dataset/r.backbone/r.window;d.mkdir(parents=True,exist_ok=True)
 np.savez_compressed(d/'target.npz',pred=pred)
 (d/'fit.json').write_text(json.dumps(dict(**info,training_windows=cut-h-L+1,fit_dates=cut,validation_dates=n-cut,epoch=bestep,validation_loss=best,fit_s=ft,predict_s=time.perf_counter()-st,hash_target=sha(d/'target.npz')),indent=2))
 print('OK',r.dataset,r.backbone,r.window,cut-h-L+1,flush=True)
if __name__=='__main__':
 assert len(idx)==22
 for r in idx.itertuples():get(r)
 for r in idx.itertuples():
  if not (H/'runs'/r.dataset/r.backbone/r.window/'fit.json').exists():fit(r)
