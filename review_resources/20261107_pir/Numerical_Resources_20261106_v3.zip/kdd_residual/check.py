from pathlib import Path
import csv,math,json,collections,statistics
h=Path(__file__).resolve().parent
def read(n):
 with (h/n).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
cells=read('cells.csv');raw=collections.defaultdict(list)
for x in cells:raw[x['dataset'],x['backbone'],x['scope'],x['method']].append(float(x['rmse']))
for x in read('paired.csv'):
 a=x['method'];b=x['baseline'];s=x['scope'];diff=[100*(1-statistics.mean(u)/statistics.mean(raw[ds,bb,sc,b])) for (ds,bb,sc,m),u in raw.items() if sc==s and m==a]
 assert len(diff)==int(x['groups']) and sum(d>0 for d in diff)==int(x['wins'])
 assert abs(statistics.mean(diff)-float(x['mean_pct']))<1e-8 and abs(statistics.median(diff)-float(x['median_pct']))<1e-8
risk=read('risk.csv');assert len(risk)==22 and all(int(r['protected_ever'])==0 for r in risk)
assert tuple(sum(int(r[k]) for r in risk) for k in ('nodes','dates','ever','final','events'))==(1998,143856,1497,415,37059)
print('PASS: 22 configurations; every paired score, win count and reported pooled violation count checked.')
