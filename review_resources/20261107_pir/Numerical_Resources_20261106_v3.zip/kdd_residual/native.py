from pathlib import Path
from types import SimpleNamespace
import sys,os,json,hashlib,copy,time
H=Path(__file__).resolve().parent;O=H.parent
os.environ.update(TORCH_HOME=str(H/'cache'),CUDA_CACHE_PATH=str(H/'cache'),TORCHINDUCTOR_CACHE_DIR=str(H/'cache'))
sys.path[:0]=[str(O/'cpor_named_venue_screen_20261105/KDDResidual'),str(O/'cpor_external_20261105/deps')]
from model.iTransformer import Model
from utils.timefeatures import time_features
import numpy as np,pandas as pd,torch
torch.set_num_threads(1);torch.manual_seed(2024)
f=O/'cpor_external_20261105/native/data/ETTh1/ETTh1.csv'
df=pd.read_csv(f);z=df.iloc[:14400,1:].to_numpy();dates=pd.to_datetime(df.date[:14400])
marks=time_features(pd.DatetimeIndex(dates),freq='h').T
L=h=96;A=8640;B=11520;N=14400
device='cuda'
cfg=SimpleNamespace(seq_len=L,pred_len=h,output_attention=False,use_norm=True,d_model=256,embed='timeF',freq='h',dropout=.1,class_strategy='projection',factor=1,n_heads=8,e_layers=2,d_ff=256,activation='gelu')
def fit(data,start,loss,tag):
 mu=data[start:A].mean(0);sd=data[start:A].std(0);sd[sd==0]=1
 t=lambda a:torch.as_tensor(a,device=device,dtype=torch.float32)
 v=t((data-mu)/sd);dt=t(marks);off=torch.arange(L,device=device)
 m=Model(cfg).to(device);opt=torch.optim.Adam(m.parameters(),lr=.0001);best=1e50;bestep=0
 def batches(lo,hi,bs):
  for i in range(lo,hi-h+1,bs):
   idx=torch.arange(i,min(i+bs,hi-h+1),device=device)[:,None]+off
   yield m(v[idx-L],dt[idx-L],None,None),v[idx]
 for ep in range(10):
  m.train()
  for p,y in batches(start+L,A,32):
   opt.zero_grad();loss(p,y).backward();opt.step()
  m.eval()
  with torch.no_grad():val=np.mean([float(loss(p,y)) for p,y in batches(A,B,32)])
  print(tag,ep+1,val,flush=True)
  if val<best:best=val;ck=copy.deepcopy(m.state_dict());bestep=ep+1
  if ep+1-bestep>=3:break
  for g in opt.param_groups:g['lr']=.0001*.5**(ep+0)
 m.load_state_dict(ck);m.eval();torch.save(ck,H/(tag+'_native.pt'))
 out=[]
 with torch.no_grad():
  for l,r in [(start+L,A),(A,B),(B,N)]:
   out.append(np.concatenate([p.cpu().numpy() for p,_ in batches(l,r,64)])*sd+mu)
 return out,mu,sd
if __name__=='__main__':
 base,mu,sd=fit(z,0,torch.nn.MSELoss(),'base')
 collapse=[]
 for a in base:
  tot=np.zeros((len(a)+h-1,a.shape[-1]));ct=np.zeros(len(tot))
  for j in range(h):tot[j:j+len(a)]+=a[:,j];ct[j:j+len(a)]+=1
  collapse.append(tot/ct[:,None])
 residual=np.zeros_like(z);residual[L:]=np.vstack(collapse)-z[L:]
 resid,_,_=fit(residual,L,torch.nn.HuberLoss(),'corrector')
 p=base[-1];q=p-.05*resid[-1];y=np.stack([z[i:i+h] for i in range(B,N-h+1)])
 def metr(err,scale):return dict(mse=float(np.mean((err/scale)**2)),mae=float(np.mean(abs(err/scale))))
 data=dict(benchmark='ETTh1 iTransformer 96/96',dates=[A,B,N],published={'corrected_MSE':.367,'corrected_MAE':.311,'base_MSE':.386,'base_MAE':.405},feature_standardized={'base':metr(p-y,sd),'corrected':metr(q-y,sd)},upstream_final_flat_target_scaler={'base':metr(p-y,y.std()),'corrected':metr(q-y,y.std())},original_units={'base':metr(p-y,1),'corrected':metr(q-y,1)},n_windows=len(p),source_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),scope='New independent checkpoint fits, documented two-stage protocol; final trained checkpoint used to export chronological predictions; separate scalers; no test labels used in fitting.')
 (H/'native.json').write_text(json.dumps(data,indent=2));print(data)
