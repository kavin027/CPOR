"""Diagnose the public residual CSV's shifted time origin. Same base weights; no model/seed search."""
import native as v
from native import np,torch,json,H
base_model=v.Model(v.cfg).cuda();base_model.load_state_dict(torch.load(H/'base_native.pt',weights_only=True));base_model.eval()
A,B,N,L=v.A,v.B,v.N,v.L
mu=v.z[:A].mean(0);sd=v.z[:A].std(0);a=torch.tensor((v.z-mu)/sd,dtype=torch.float32,device='cuda');mark=torch.tensor(v.marks,dtype=torch.float32,device='cuda')
avg=[];test=None
for l,r in [(L,A),(A,B),(B,N)]:
 lst=[]
 for j in range(l,r-L+1,64):
  ix=torch.arange(j,min(r-L+1,j+64),device='cuda')[:,None]+torch.arange(L,device='cuda')-L
  with torch.no_grad():lst.append(base_model(a[ix],mark[ix],None,None).cpu().numpy()*sd+mu)
 arr=np.concatenate(lst);tt=np.zeros((len(arr)+L-1,7));count=np.zeros(len(tt))
 for j in range(L):tt[j:j+len(arr)]+=arr[:,j];count[j:j+len(arr)]+=1
 avg.append(tt/count[:,None]);test=arr
res=np.zeros_like(v.z);res[L:]=np.vstack(avg)-v.z[L:]
v.A=A+L;v.B=B+L
_,mus,sds=None,None,None
arr,_,_=v.fit(res,L,torch.nn.HuberLoss(),'corrector_shifted')
r=arr[-1];p=test[-len(r):];y=np.stack([v.z[i:i+L] for i in range(v.B,v.N-L+1)])
assert len(p)==len(y)==len(test)-96
q=p-.05*r
def metrics(err,sc):return [float(np.mean((err/sc)**2)),float(np.mean(abs(err/sc)))]
stats={k:{'base':metrics(p-y,sc),'corrected':metrics(q-y,sc)} for k,sc in [('published_script_pooled',y.std()),('train_node_scaler',sd),('raw',1.)]}
stats.update(score_origins=len(y),first_target_index=v.B,interpretation="Use original ETT split offsets on a residual CSV starting 96 rows later. Base checkpoint and alpha unchanged; evaluation on common target dates only.")
(H/'native_clock.json').write_text(json.dumps(stats,indent=2));print(stats)
