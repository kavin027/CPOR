from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib,time
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent;O=H.parent
sys.path.insert(0,str(O/'cpor_envelope_comparison_20261024'))
import run_comparison as c
idx=pd.read_csv(c.INDEX).query('seed==42')
mm=pd.read_csv(O/'kais_review_v2_revision_20261017/Online_Resource_3/review_evidence/node_map.csv')
R=F(40401,40000);rows=[];risks=[];times=[]
for r in idx.itertuples():
 d=Path(r.source);f=H/'runs'/r.dataset/r.backbone/r.window;ft=json.loads((f/'fit.json').read_text()); x=c.load(d/'endpoints.npz')
 assert hashlib.sha256((d/'endpoints.npz').read_bytes()).hexdigest()==ft['endpoint_hash']
 p=np.load(f/'target.npz')['pred'];b=x['b'][36:];y=x['truth'][36:]
 out=c.run(x,p,'ML',r.dataset,'nonnegative');q=out['pred'];u=out['witness'];np.testing.assert_allclose(q,u@x['S'].T,rtol=1e-8,atol=2e-6);assert u.min()>=0
 np.savez_compressed(f/'release.npz',pred=q,witness=u)
 nt=len(b[0]);budget=[F(0)]*nt;a0=[F(0)]*nt;ever=set();last=set();events=0;worst=0
 for t in range(72):
  last=set()
  for i in range(nt):
   ref,obs,target,release=map(lambda a:F.from_float(float(a)),(b[t,i],y[t,i],p[t,i],q[t,i]))
   g=release**2-R*ref**2 if release>R*ref else R*(release-ref)**2/(R-1)
   assert g<=budget[i]
   budget[i]+=R*(ref-obs)**2-(release-obs)**2;assert budget[i]>=0
   a0[i]+=R*(ref-obs)**2-(target-obs)**2
   if a0[i]<0:ever.add(i);last.add(i);events+=1
 key=dict(dataset=r.dataset,backbone=r.backbone,window=r.window)
 risks.append(dict(**key,nodes=nt,dates=q.size,ever=len(ever),final=len(last),events=events,protected_ever=0))
 times.append(dict(**key,**ft,release_s=out['elapsed_seconds']))
 local=mm[mm.dataset==r.dataset]
 for m,arr in dict(raw=x['raw'][36:],anchor=b,kdd=p,protected=q,Cov=np.load(d/'CovFullFix.npz')['pred'],ML=np.load(d/'controls.npz')['ProtectedMLPol']).items():
  v=((arr-y)**2).mean(0)**.5
  for scope in sorted(set(';'.join(local.scopes).split(';'))):
   ii=local.loc[local.scopes.apply(lambda s:scope in s.split(';')),'node'].to_numpy(int)
   rows.append(dict(**key,method=m,scope=scope,rmse=v[ii].mean()))
 print('audited',key,flush=True)
cs=pd.DataFrame(rows);cs.to_csv(H/'cells.csv',index=False)
g=cs.groupby(['dataset','backbone','scope','method']).rmse.mean().unstack();g.to_csv(H/'groups.csv')
risks=pd.DataFrame(risks);risks.to_csv(H/'risk.csv',index=False);pd.DataFrame(times).to_csv(H/'fits.csv',index=False)
paired=[]
for scope in g.index.get_level_values('scope').unique():
 v=g.xs(scope,level='scope')
 for a,b in [('Cov','kdd'),('ML','kdd'),('Cov','protected'),('ML','protected'),('protected','kdd'),('kdd','raw')]:
  d=100*(1-v[a]/v[b]);paired.append(dict(scope=scope,method=a,baseline=b,groups=len(d),wins=int((d>0).sum()),mean_pct=d.mean(),median_pct=d.median()))
pd.DataFrame(paired).to_csv(H/'paired.csv',index=False)
print(pd.DataFrame(paired).query("scope=='all' or (scope=='system' and baseline=='protected')").to_string(index=False));print(risks.sum(numeric_only=True))
