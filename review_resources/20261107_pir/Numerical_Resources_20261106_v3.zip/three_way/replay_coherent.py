from pathlib import Path
from fractions import Fraction as F
import json,numpy as np,pandas as pd
from scipy.optimize import nnls
from threadpoolctl import threadpool_limits
H=Path(__file__).resolve().parent;O=H.parent;K=O/'cpor_kdd_comparison_20261105'
idx=pd.read_csv(O/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv').query('seed==42')
R=F(40401,40000);rows=[]
with threadpool_limits(1):
 for r in idx.itertuples():
  x=np.load(Path(r.source)/'endpoints.npz');loc=K/'runs'/r.dataset/r.backbone/r.window
  target=np.load(loc/'target.npz')['pred'];prot=np.load(loc/'release.npz')['pred']
  S=x['S'];v=x['v'];y=x['truth'][36:];b=x['b'][36:];A=S/np.sqrt(v[:,None]);norm=np.linalg.norm(A,axis=0);valid=norm>0;D=A[:,valid]/norm[valid];proj=[];maxerr=0
  for z in target:
   vec=z/np.sqrt(v);u,_=nnls(D,vec,maxiter=10*len(norm));g=D.T@(D@u-vec);scale=1+abs(D.T@vec).max()
   e=max(0.,-g.min(),np.max(abs(g[u>0])) if np.any(u>0) else 0.)/scale
   maxerr=max(maxerr,e);assert e<1e-7,e
   proj.append(S[:,valid]@(u/norm[valid]))
  p=np.array(proj)
  ever=set();balance=[F(0)]*len(v)
  for a1,b1,y1 in zip(p,b,y):
   for i,(a0,b0,y0) in enumerate(zip(a1,b1,y1)):
    a0,b0,y0=map(lambda z:F.from_float(float(z)),(a0,b0,y0));balance[i]+=R*(b0-y0)**2-(a0-y0)**2
    if balance[i]<0:ever.add(i)
  rm=lambda q:float(np.sqrt(((q-y)**2).mean(0)).mean())
  rows.append(dict(dataset=r.dataset,backbone=r.backbone,window=r.window,nodes=len(v),ever=len(ever),original=rm(target),coherent=rm(p),protected=rm(prot),anchor=rm(b),norm_KKT=maxerr))
d=pd.DataFrame(rows);d.to_csv(H/'coherence_only.csv',index=False);g=d.groupby(['dataset','backbone']).mean(numeric_only=True)
print('Ever:',d.ever.sum(),d.nodes.sum())
for a,b in [('coherent','original'),('protected','coherent'),('protected','original'),('protected','anchor')]:
 dif=100*(1-g[a]/g[b]);print(a,b,dif.mean(),dif.median(),int((dif>0).sum()))
print('max KKT',d.norm_KKT.max())
