"""Check Table 7 and the group RMSEs of Supplementary Table S16 from bundled CSVs."""
from pathlib import Path
import csv
from collections import defaultdict
from math import isclose
from statistics import mean

here = Path(__file__).resolve().parent
def records(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def index(rows):
    keys = {(r["dataset"], r["backbone"], r["window"]): r for r in rows}
    assert len(keys) == len(rows) == 22
    return keys

coherent = index(records(here / "coherence_only.csv"))
residual = here.parent / "kdd_residual"
risk = index(records(residual / "risk.csv"))
assert coherent.keys() == risk.keys()
group_scores = defaultdict(list)
for key, row in coherent.items():
    assert row["nodes"] == risk[key]["nodes"]
    group_scores[key[:2]].append(row)
assert len(group_scores) == 12
totals = tuple(sum(int(r[field]) for r in rows.values()) for rows, field in
               [(risk, "nodes"), (risk, "ever"), (coherent, "ever"), (risk, "protected_ever")])
assert totals == (1998, 1497, 1509, 0)
old = {(r["dataset"],r["backbone"]): r for r in records(residual / "groups.csv") if r["scope"] == "all"}
gains = defaultdict(list)
for key, rows in group_scores.items():
    m = {name: mean(float(r[name]) for r in rows) for name in ("original","coherent","protected","anchor")}
    for name, other in [("original","kdd"),("protected","protected"),("anchor","anchor")]:
        assert isclose(m[name], float(old[key][other]), rel_tol=1e-12)
    for name, baseline in [("coherent","original"),("protected","coherent"),("protected","anchor")]:
        gains[name,baseline].append(100*(1-m[name]/m[baseline]))
    for name in ("Cov","ML"):
        gains[name,"protected"].append(100*(1-float(old[key][name])/m["protected"]))
assert [round(mean(gains[pair]),2) for pair in gains] == [-0.10,0.23,0.29,6.40,6.42]
assert sum(v>0 for v in gains["protected","coherent"]) == 7
assert all(v>0 for v in gains["Cov","protected"] + gains["ML","protected"])
print("Node sequences, direct/coherent/protected ever over limit:", totals)
for pair, values in gains.items():
    print(*pair, f"{mean(values):+.6f}%", f"{sum(v>0 for v in values)}/12")

