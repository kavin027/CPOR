from protocol_engine import *

EXTERNAL=['PIR','PIRCoherent','PIRFull','PIRCommon','PIRTwoGroup','ProCAST','Ada-Y','ProtectedProCAST','ProtectedAda-Y']

def targets(ds,bb,s,part):
    if part=='continuous':
        a=targets(ds,bb,s,'early');b=targets(ds,bb,s,'late')
        return {k:np.concatenate([a[k],b[k]]) for k in a if k in b}
    d=folder(ds,bb,s)/part/'external'
    out={}
    for name in ['PIR','ProCAST','Ada-Y']:
        p=d/(name+'.npz')
        if not p.with_suffix('.json').exists():continue
        assert sha(p)==json.loads(p.with_suffix('.json').read_text(encoding='utf8'))['sha256'];out[name]=load(p)['pred']
    return out

def score_external(ds,bb,s,part,mode='single'):
    base=folder(ds,bb,s)/part;d=base/mode
    if not (d/'CORE_DONE.json').exists():return
    if (d/'ALL_DONE.json').exists():return
    x=load(base/'context.npz');zz=targets(ds,bb,s,part);reset=72 if mode=='reset' else None
    coherent={}
    for name in ['PIR','ProCAST','Ada-Y']:
        if name not in zz:continue
        if not saved(d,name):put(d,x,name,zz[name],reset=reset)
        shared=base/(name+'_SHARED_EXTERNAL_TARGET.npz')
        if shared.exists():
            z=load(shared);coherent[name]=(z['target'],z['witness'])
        else:
            coherent[name]=old.project(x['S'],zz[name],x['v']);np.savez_compressed(shared,target=coherent[name][0],witness=coherent[name][1])
    if 'PIR' in coherent and not saved(d,'PIRCoherent'):put(d,x,'PIRCoherent',*coherent['PIR'],reset=reset)
    for name,source,rule in [('PIRFull','PIR','Full'),('PIRCommon','PIR','Common'),('PIRTwoGroup','PIR','TwoGroup'),('ProtectedProCAST','ProCAST','Full'),('ProtectedAda-Y','Ada-Y','Full')]:
        if saved(d,name):continue
        if source not in coherent:continue
        target,u=coherent[source];p,u,logs,secs=publish(x,target,rule,ds,reset,u);put(d,x,name,p,u,True,reset,logs,secs)
    if not all(saved(d,name) for name in CORE+EXTERNAL):return
    js(d/'ALL_DONE.json',dict(dataset=ds,backbone=bb,seed=s,part=part,mode=mode,methods=CORE+EXTERNAL));print('ALL_DONE',ds,bb,s,part,mode,flush=True)

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--shard',type=int,default=0);ap.add_argument('--shards',type=int,default=1);args=ap.parse_args();verify()
    with threadpool_limits(1):
        stages=[(ds,bb,s,part,mode) for ds,bb,s in jobs()[args.shard::args.shards] for part,mode in ([('early','single'),('late','single'),('continuous','reset'),('continuous','carry')]+([('month','carry')] if ds=='AEMO' and bb=='DUET' else []))]
        while stages:
            for ds,bb,s,part,mode in stages:score_external(ds,bb,s,part,mode)
            stages=[q for q in stages if not (folder(*q[:3])/q[3]/q[4]/'ALL_DONE.json').exists()]
            if stages:time.sleep(5)
