from pathlib import Path
import json,hashlib,sys,datetime,os
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent;O=H.parent;ROOT=O.parent;DUET=O/'cpor_duet_stream_20261106'
DS=['RH','ECommerce','Traffic','Wiki2','Labour','M5','AEMO'];DUET_SEEDS=[2021,2022,2023]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,default=str,ensure_ascii=False),encoding='utf8')
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def datafile(ds):
    if ds=='AEMO':return O/'cpor_aemo_underlying_october_20261107/observed.csv'
    if ds=='M5':return O/'c0_frozen_m5_20261014/observed.csv'
    if ds=='Labour':return O/'rr_recap_evidence_extension_20261002/major_revision_20261002/external/data/Labour.csv'
    return O/f'procast_joint_safe_20261001_v4/data/{ds}.csv'
def starts(ds):
    w=pd.read_csv(datafile(ds),parse_dates=['ds']).set_index('ds')
    if ds=='AEMO':return w,len(w)-144,len(w)-72
    first={'RH':'2023-08-10','ECommerce':'2011-05-24','Traffic':'2008-08-10','Wiki2':'2016-08-10','Labour':'2008-12-01','M5':'2015-12-31'}[ds]
    i=w.index.get_loc(first);return w,i,i+72
def folder(ds,bb,seed):return H/'streams'/ds/bb/str(seed)
def oldsource(ds,bb,win,seed):
    if ds=='Labour' and win=='early':return O/'cpor_labour_early_three_runs_20261107/runs'/bb/str(seed)/'context.npz'
    idx=pd.read_csv(O/'cpor_minor_v8_20261022/fresh_evidence/CURRENT_RESULTS_20261022/derived/TRAJECTORY_INDEX.csv')
    r=idx[(idx.dataset==ds)&(idx.backbone==bb)&(idx.window==win)&(idx.seed==seed)].iloc[0]
    return Path(r.source)/'endpoints.npz'
def stream(ds,bb,seed,win):
    d=folder(ds,bb,seed)
    if bb=='DUET':
        a=load(d/(win+'.npz'));a.setdefault('cal_start',np.array(int(a['start'])-36));return a
    if ds=='AEMO':
        p=O/'cpor_aemo_full_three_runs_20261107/runs'/bb/str(seed)/'models'/bb/'raw.npz';x=load(p);w,early,late=starts(ds);start=early if win=='early' else late;beg=int(x['begin']);cal=start-36
        raw=x['raw'][cal-beg:start+72-beg];assert raw.shape==(108,6)
        return dict(raw=raw,truth=w.iloc[cal:start+72].to_numpy(),S=x['S'],start=np.array(start),cal_start=np.array(cal))
    x=load(oldsource(ds,bb,win,seed));w,early,late=starts(ds);start=early if win=='early' else late
    return dict(raw=x['raw'],truth=x['truth'],S=x['S'],start=np.array(start),cal_start=np.array(start-36))
def jobs():return [(ds,bb,s) for ds in DS for bb in ['PatchTST','DLinear','DUET'] for s in (DUET_SEEDS if bb=='DUET' else [42,1,2])]
def register():
    p=H/'REGISTRATION.json'
    if p.exists():verify();return
    inputs={};windows=[]
    for ds in DS:
        wide,a,b=starts(ds);inputs[str(datafile(ds))]=sha(datafile(ds));windows.append(dict(dataset=ds,early_start=str(wide.index[a]),early_end=str(wide.index[b-1]),late_start=str(wide.index[b]),late_end=str(wide.index[b+71]),n=wide.shape[1]))
        if ds!='AEMO':
            for bb in ['PatchTST','DLinear']:
              for seed in [42,1,2]:
               for win in ['early','late']:
                q=oldsource(ds,bb,win,seed);inputs[str(q)]=sha(q)
        else:
            for bb in ['PatchTST','DLinear']:
             for seed in [42,1,2]:
              q=O/'cpor_aemo_full_three_runs_20261107/runs'/bb/str(seed)/'models'/bb/'raw.npz';inputs[str(q)]=sha(q)
    for ds in DS[:-1]:
        for q in (DUET/'streams'/ds).glob('*'):
            if q.suffix in ['.npz','.json','.pt']:inputs[str(q)]=sha(q)
    for q in [DUET/'train.py',DUET/'replay_streams.py',DUET/'DUET/ts_benchmark/baselines/deep_forecasting_model_base.py',DUET/'DUET/ts_benchmark/baselines/duet/duet.py',O/'cpor_kais_labour_early_20261107/KAIS_CPOR_Labour_Early_Clean_20261108.zip']:
        inputs[str(q)]=sha(q)
    rec=dict(registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='Seven datasets under independent72/72 windows and matched reset/carry144 protocols; DUET third backbone; report before editing any frozen paper.',retrospective=True,windows=windows,backbone_runs={'PatchTST':[42,1,2],'DLinear':[42,1,2],'DUET':DUET_SEEDS},duet='User explicitly requested three runs. Retain author implementation/settings,seed2021 fits and11streams;newLabourearly fit excludesfuturelabels;lateusesoriginalscheduledfit. Other runs use identicalperdatasetfittingboundaries. AEMO DUETfit beforeSeptember28support;frozenforecaststhroughOctober. This is CPOR-protocoltransfer,notpaper-reproductionagreement.',independent='Each72-window:36calibrationrecords;zeroinitialallowance;fixedprecalvariance;causalselectors;allmethodscommonbase,dates,reference,feedback. AEMO windows are the final144 storedhalf-hours;monthstudyretained.',continuous='36earlycalrecords+144consecutivescoreforecasts;no duplicated late-calibration observations. Keepvarianceatpreearlycal,continuousCov/MLstatesandfixedCalBestidentity. Resetarmonlyclearsprotectionbalancesat72;carryarmdoesnot. Both useidenticalcandidates/reference/variance/feedback. Latebackbonerefreshesarecausal,sharedbyarms.',protection='NNLSreference;epsilon=.005;exactR40401/40000;rawnonnegativeobservationsunchanged;allregionsretained;ownactualbalancesperrule.',methods=['Raw','NNLS','CovTarget','MLTarget','CalBest','CPOR-Cov','CPOR-ML','ProtectedCalBest','CovCommon','CovTwoGroup','MLCommon','MLTwoGroup','ProtectedWLSvar','ProtectedMinTshrink','ProtectedMinT_Cov','ProtectedRollingMinT','PIR','PIRCoherent','PIRFull','PIRCommon','PIRTwoGroup','ProCAST','Ada-Y','ProtectedProCAST','ProtectedAda-Y'],external='Reuse valid savedsame-streamtargets whereavailable. MissingDUETadapters usefixedinitialization42;needcausalhistoricalDUETsupportbeforecalibration. When past data constrain support, use the largest multiple12 up to216 leaving at least64 observations before support;M5/AEMO original support108. No scoring-based hyperparameter tuning. Missing history is declared,notfilledusingfuture-fittedmodels.',summary='All-node,region,system,bottomRMSE,three-runmean/sampleSD;pairedreset/carrydifferencesincludinglate-halferrors,unprotectedtargetcost,exactenvelope/prefixaudits,activeconstraints,runtime.Nevercount63streamsasindependentdatasets.',inputs=inputs,no_manuscript_edits=True)
    js(p,rec);js(H/'INITIAL_SOURCE_HASHES.json',{str(q):sha(q) for q in H.glob('*.py')});print('REGISTERED',len(inputs),len(jobs()),'streams')
def verify():
    rec=json.loads((H/'REGISTRATION.json').read_text(encoding='utf8'))
    for p,h in rec['inputs'].items():assert sha(p)==h,p
    return rec
if __name__=='__main__':register()
