from unified_common import *
from unified_analysis import METHODS,stages
import argparse,time

def binary_parts(a):
    q=[float(v).as_integer_ratio() for v in np.asarray(a).ravel()]
    return q,max(d.bit_length()-1 for _,d in q)

def exact_check(x,p,reset=None):
    # Every stored IEEE754 value is a dyadic rational. Use one shared power-of-2
    # denominator and integer cross-products; no floating-point certificate.
    b=x['b'][36:];y=x['truth'][36:];parts=[binary_parts(a) for a in (b,y,p)];ex=max(k for _,k in parts);D=1<<ex;n=b.shape[1]
    B,Y,P=[np.array([a*(D//d) for a,d in q],dtype=object).reshape(b.shape) for q,_ in parts]
    A=[0]*n;G=[0]*n;ever=set();events=env=0
    for t in range(len(p)):
        if reset is not None and t==reset:A=[0]*n
        for i in range(n):
            bb,yy,pp=B[t,i],Y[t,i],P[t,i]
            bad=(40000*pp*pp-40401*bb*bb>A[i]) if 40000*pp>40401*bb else (40401*40000*(pp-bb)**2>401*A[i])
            env+=int(bad);inc=40401*(bb-yy)**2-40000*(pp-yy)**2;A[i]+=inc;G[i]+=inc
            if A[i]<0:events+=1;ever.add(i)
    return dict(ever=len(ever),events=events,envelope_failures=env,global_final_negative=sum(v<0 for v in G))

def run(partial=False,core_only=False):
    reg=verify();checks=[];prefix_differences=[];done=0;tick=time.perf_counter()
    methods=METHODS[:16] if core_only else METHODS;marker='CORE_DONE.json' if core_only else 'ALL_DONE.json'
    for ds,bb,s in jobs():
        f=folder(ds,bb,s);wide,a,b=starts(ds)
        for win,start in [('early',a),('late',b)]:
            z=stream(ds,bb,s,win);assert int(z['start'])==start;assert z['raw'].shape==(108,len(wide.columns));np.testing.assert_array_equal(z['truth'],wide.iloc[start-36:start+72]);assert (z['S']>=0).all() and (z['S'].sum(1)>0).all()
            if bb=='DUET' and (f/(win+'_REUSE.json')).exists():
                q=json.loads((f/(win+'_REUSE.json')).read_text(encoding='utf8'));np.testing.assert_array_equal(z['raw'],load(q['source'])['raw']);assert sha(q['source'])==q['sha256']
        for part,mode in stages(ds,bb,s):
            d=f/part/mode
            if not (d/marker).exists():
                if partial:continue
                raise AssertionError(f'Incomplete: {d}')
            x=load(f/part/'context.npz');done+=1
            for name in methods:
                p=d/(name+'.npz');r=json.loads(p.with_suffix('.json').read_text(encoding='utf8'));assert sha(p)==r['sha256'];z=load(p);got=exact_check(x,z['pred'],r['reset_at']);want=r['audit']
                for k in ['ever','events','envelope_failures']:assert got[k]==want[k],(p,k,got[k],want[k])
                if r['protected']:assert all(v==0 for v in got.values()) and z['pred'].min()>=0
                if 'witness' in z:assert z['witness'].min()>=0 and np.allclose(z['pred'],z['witness']@x['S'].T,rtol=1e-8,atol=2e-6)
                checks.append(dict(path=str(p.relative_to(H)),sha256=r['sha256'],protected=r['protected'],**got))
            if part=='continuous' and mode=='carry' and (f/part/'reset'/marker).exists():
                early=load(f/'early/context.npz')
                for key in ['raw','truth','b','ub','CovTarget','MLTarget','CalBest']:
                    np.testing.assert_allclose(x[key][:108],early[key],rtol=1e-12,atol=2e-8,err_msg=f'{ds}/{bb}/{s}/{key}')
                for name in methods:
                    zr=load(f/part/'reset'/(name+'.npz'))['pred'];zc=load(d/(name+'.npz'))['pred'];diff=float(abs(zr[:72]-zc[:72]).max());np.testing.assert_allclose(zr[:72],zc[:72],rtol=1e-11,atol=1e-7,err_msg=f'{ds}/{bb}/{s}/{name}: pre-reset difference')
                    prefix_differences.append(dict(dataset=ds,backbone=bb,seed=s,method=name,max_abs=diff,bitwise_equal=bool(np.array_equal(zr[:72],zc[:72]))))
            print('CHECKED',ds,bb,s,part,mode,flush=True)
    js(H/('CORE_INDEPENDENT_CHECKS.json' if core_only else 'PARTIAL_INDEPENDENT_CHECKS.json' if partial else 'INDEPENDENT_CHECKS.json'),dict(stages=done,expected_stages=255,arrays=len(checks),seconds=time.perf_counter()-tick,arithmetic='Exact integer cross-products of stored binary rationals. Prefix update in common denominator40000; envelope comparison cross-multiplied by401 where required. Independent of Fraction-based producer audit.',checks=checks,pre_reset_differences=prefix_differences,registered_inputs_verified=len(reg['inputs'])))
    print('CHECKS_DONE',done,len(checks),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');ap.add_argument('--core-only',action='store_true');args=ap.parse_args();run(args.partial,args.core_only)
