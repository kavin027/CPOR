from unified_common import *
import time,random,importlib.util,logging
import duet_train as dt
import torch
def module(name,path):
    sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
ext=module('unified_external_author',O/'cpor_external_repetitions_20261020/run.py')
pro=module('unified_procast_author',O/'rr_recap_strong_baseline_20261006/run.py')
def reset():random.seed(42);np.random.seed(42);torch.manual_seed(42);torch.cuda.manual_seed_all(42);torch.set_num_threads(1)
def support_duet(ds,s):
    d=folder(ds,'DUET',s);p=d/'historical_support.npz'
    if p.exists():return load(p)
    wide,early,late=starts(ds);wide.index.name='date';cal=early-36
    if ds=='AEMO':return load(d/'month.npz')
    count=108 if ds=='M5' else min(216,12*((cal-64)//12));begin=cal-count;assert count>=12 and begin>=64
    m=dt.fitted(wide,ds,s,begin,'historical_support');raw=dt.forecast(m,wide,s,begin,cal);np.savez_compressed(p,raw=raw,begin=begin,end=cal)
    js(p.with_suffix('.json'),dict(sha256=sha(p),begin=begin,end=cal,count=count,causal=True));del m;torch.cuda.empty_cache();return load(p)
def data(ds,s,part,bb='DUET'):
    wide,early,late=starts(ds);values=wide.to_numpy();d=folder(ds,bb,s)
    if part=='month':
        base=load(d/'month.npz');raw=base['raw'];begin=int(base['begin']);start=int(base['start']);cal=start-36;S=base['S']
    else:
        start=early if part=='early' else late;cal=start-36;a=stream(ds,bb,s,part);S=a['S']
        if ds=='AEMO':
            base=load(d/'month.npz') if bb=='DUET' else load(O/'cpor_aemo_full_three_runs_20261107/runs'/bb/str(s)/'models'/bb/'raw.npz');begin=cal-216;raw=base['raw'][begin-int(base['begin']):start+72-int(base['begin'])]
        else:
            support=support_duet(ds,s);firstcal=early-36;count=108 if ds=='M5' else min(216,12*((cal-64)//12));begin=cal-count
            past=np.concatenate([support['raw'],stream(ds,'DUET',s,'early')['raw'][:72]])
            offset=begin-int(support['begin']);hist=past[offset:offset+count];assert len(hist)==count;raw=np.concatenate([hist,a['raw']])
    end=start+(len(raw)-(start-begin));positions=np.arange(begin,end);library=np.arange(24,cal);mu=values[:cal].mean(0);sd=values[:cal].std(0);sd=np.where(sd>0,sd,1.)
    dd=dict(x=((np.stack([values[i-24:i] for i in positions])-mu)/sd).astype('float32'),raw=((raw-mu)/sd)[:,None,:].astype('float32'),y=((values[positions]-mu)/sd)[:,None,:].astype('float32'),encmark=np.stack([ext.pir.calendar(wide.index[i-24:i]) for i in positions]),mark=ext.pir.calendar(wide.index[positions])[:,None,:],lib_x=((np.stack([values[i-24:i] for i in library])-mu)/sd).astype('float32'),lib_y=((values[library]-mu)/sd)[:,None,:].astype('float32'),library_index=positions-24,mu=mu,sd=sd,train_count=cal-begin,score_start=start-begin)
    assert len(dd['raw'])-dd['score_start']==(1488 if part=='month' else 72)
    return dd,raw,values[positions],S
def old_external(ds,bb,s,part,name):
    if bb=='DUET':return None
    if ds=='AEMO':return None
    if ds=='Labour' and part=='early':
        p=O/'cpor_labour_early_three_runs_20261107/runs'/bb/str(s)/'results'/(name+'.npz');return load(p)['pred'],str(p)
    src=oldsource(ds,bb,part,s).parent
    if bb=='DLinear' and (src/(name+'.npz')).exists():p=src/(name+'.npz')
    elif name=='ProCAST':p=src/'ProCAST72Warm.npz'
    else:
        rows=json.loads((O/'cpor_external_repetitions_20261020/RESULT_INDEX.json').read_text(encoding='utf8'));match=next(r for r in rows if r['cell']==f'{ds}_{bb}_{part}.npz' and r['seed']==s and r['method']==name);p=Path(match['path'])
    z=load(p);return z['pred'],str(p)
def run(ds,bb,s,part,methods=None,procast_device='cuda'):
    d=folder(ds,bb,s)/part/'external';d.mkdir(parents=True,exist_ok=True)
    for name in ['PIR','Ada-Y','ProCAST']:
        if methods is not None and name not in methods:continue
        p=d/(name+'.npz')
        if p.with_suffix('.json').exists():assert sha(p)==json.loads(p.with_suffix('.json').read_text(encoding='utf8'))['sha256'];continue
        reused=old_external(ds,bb,s,part,name)
        if reused is not None:
            pred,src=reused;np.savez_compressed(p,pred=pred);js(p.with_suffix('.json'),dict(sha256=sha(p),reused=src));continue
        reset();dd,raw,y,S=data(ds,s,part,bb);tick=time.perf_counter()
        if name=='PIR':
            m=ext.pir.CachedPIR(ext.pir.config(S.shape[0])).float().cuda();tt=ext.pir.tensors(dd,'cuda');logs,state=ext.pir.fit(m,tt,dd['train_count'],dd['score_start']);pred=[]
            with torch.no_grad():
                for i in range(dd['score_start'],len(raw)):
                    out,_=ext.pir.forward(m,tt,torch.tensor([i],device='cuda'));pred.append(out.cpu().numpy()[0,0]*dd['sd']+dd['mu'])
            pred=np.array(pred);torch.save(state,d/'PIR_checkpoint.pt');del m,tt
        elif name=='Ada-Y':pred,state,logs=ext.fit_aday(dd,'cuda');torch.save(state,d/'Ada-Y_checkpoint.pt')
        else:
            yh=torch.tensor(raw,device=procast_device,dtype=torch.float64);yt=torch.tensor(y,device=procast_device,dtype=torch.float64);counts=[];m=pro._TorchPinv(torch.tensor(S,dtype=torch.float32),masked=False,max_iter=100000,callback=lambda a:counts.append(int(a[1])) if a[0]=='count' else None).to(device=procast_device,dtype=torch.float64);out=[]
            for i in range(dd['train_count'],len(raw)):
                n=min(72,i);weights=torch.tensor([.5/n]*n+[.5],device=procast_device,dtype=torch.float64);m.fit(yh[i-n:i+1],torch.cat([yt[i-n:i],yh[i:i+1]]),weights=weights)
                with torch.no_grad():u=(yh[i:i+1]@m.pinv).clamp(min=0);out.append((u@m.mat).cpu().numpy()[0])
                if len(out)%36==0:print('PROCAST_PROGRESS',ds,bb,s,part,len(out),'of',len(raw)-dd['train_count'],procast_device,flush=True)
            pred=np.array(out)[36:];logs=dict(iteration_limit_hits=sum(i>=100000 for i in counts),max_iterations=max(counts),calls=len(counts),device=procast_device);del yh,yt,m
        assert pred.shape==(len(raw)-dd['score_start'],S.shape[0]) and np.isfinite(pred).all();np.savez_compressed(p,pred=pred);js(p.with_suffix('.json'),dict(sha256=sha(p),adapter_initialization=42,train_count=dd['train_count'],calibration_count=36,seconds=time.perf_counter()-tick,logs=logs));torch.cuda.empty_cache();print('EXTERNAL_DONE',ds,bb,s,part,name,flush=True)
    if all((d/(n+'.json')).exists() for n in ['PIR','Ada-Y','ProCAST']):js(d/'DONE.json',dict(complete=True))
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--shard',type=int,default=0);ap.add_argument('--shards',type=int,default=1);ap.add_argument('--methods',default='PIR,Ada-Y,ProCAST');ap.add_argument('--datasets',default=','.join(DS));ap.add_argument('--procast-device',choices=['cpu','cuda'],default='cuda');args=ap.parse_args()
    logging.getLogger().setLevel(logging.ERROR);verify()
    for ds,bb,s in jobs()[args.shard::args.shards]:
        if ds not in args.datasets.split(','):continue
        if bb=='DUET':
            while not (folder(ds,bb,s)/'BASE_DONE.json').exists():time.sleep(5)
        for part in ['early','late']:run(ds,bb,s,part,args.methods.split(','),args.procast_device)
        if ds=='AEMO' and bb=='DUET':run(ds,bb,s,'month',args.methods.split(','),args.procast_device)
