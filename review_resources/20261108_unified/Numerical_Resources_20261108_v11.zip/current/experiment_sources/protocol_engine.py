from unified_common import *
import ast,inspect,time,copy
from fractions import Fraction as F
from threadpoolctl import threadpool_limits
sys.path.insert(0,str(DUET));import evaluate as legacy
sys.path.insert(0,str(O/'pir_grouped_release_20261106'));from grouped import grouped,partition
c=legacy.c;old=legacy.cpu.old;fresh=legacy.cpu.fresh;ns=legacy.ns;RR=F(40401,40000);K=RR-1
CORE=['Raw','NNLS','CovTarget','MLTarget','CalBest','CPOR-Cov','CPOR-ML','ProtectedCalBest','CovCommon','CovTwoGroup','MLCommon','MLTwoGroup','ProtectedWLSvar','ProtectedMinTshrink','ProtectedMinT_Cov','ProtectedRollingMinT']
def numeric(z):
    if isinstance(z,dict):return {str(k):numeric(v) for k,v in z.items()}
    if isinstance(z,(list,tuple)):return [numeric(v) for v in z]
    if isinstance(z,np.ndarray):return z.tolist()
    if isinstance(z,np.generic):return z.item()
    if isinstance(z,F):return str(z)
    return z
def rawdata(ds,bb,s,part):
    if part in ['early','late']:return stream(ds,bb,s,part)
    if part=='month':
        if bb=='DUET':a=load(folder(ds,bb,s)/'month.npz')
        else:a=load(O/'cpor_aemo_full_three_runs_20261107/runs'/bb/str(s)/'models'/bb/'raw.npz')
        w,*_=starts(ds);st=int(a['start']);return dict(raw=a['raw'][108:],truth=w.iloc[st-36:].to_numpy(),S=a['S'],start=np.array(st),cal_start=np.array(st-36))
    a=stream(ds,bb,s,'early');b=stream(ds,bb,s,'late');np.testing.assert_array_equal(a['S'],b['S']);w,st,_=starts(ds)
    raw=np.concatenate([a['raw'],b['raw'][36:]]);y=w.iloc[st-36:st+144].to_numpy();np.testing.assert_array_equal(np.concatenate([a['truth'],b['truth'][36:]]),y)
    return dict(raw=raw,truth=y,S=a['S'],start=np.array(st),cal_start=np.array(st-36))
def context(ds,bb,s,part):
    d=folder(ds,bb,s)/part;d.mkdir(parents=True,exist_ok=True);p=d/'context.npz'
    if p.exists():return load(p)
    a=rawdata(ds,bb,s,part);raw,y,S=a['raw'],a['truth'],a['S'];wide,_,_=starts(ds);cal=int(a['cal_start']);v=wide.iloc[:cal].var(ddof=0).to_numpy();positive=v[v>1e-12];v=np.maximum(v,max(1e-12,1e-6*np.median(positive)) if len(positive) else 1e-12);b,ub=old.project(S,raw)
    tick=time.perf_counter();bank=None;reuse=None
    if part in ['early','late'] and ds!='AEMO' and bb!='DUET':
        src=oldsource(ds,bb,part,s)
        if ds=='Labour' and part=='early':reuse=load(src);bank=reuse['bank']
        elif (src.parent/'contexts.npz').exists():
            z=load(src.parent/'contexts.npz')
            if 'bank' in z:bank=z['bank']
    if bank is None:bank=fresh.expert_bank(wide,raw,v,cal)
    n,J=bank.shape[1:];co=[];mo=[];w=np.full((n,J),1/J);regrets=np.zeros_like(w);sq=np.zeros_like(w);scaled=bank/np.sqrt(v)[None,:,None];labels=y/np.sqrt(v)[None,:]
    for t in range(len(y)):
        wc=np.full_like(bank[t],1/J) if not t else fresh.weights(old.cov.moment(bank[:t],y[:t],v,t),old.cov);co.append((bank[t]*wc).sum(1));pm=(scaled[t]*w).sum(1);mo.append(pm*np.sqrt(v));r=2*(pm-labels[t])[:,None]*(pm[:,None]-scaled[t]);regrets+=r;sq+=r*r;q=np.maximum(regrets,0)/(1+sq);den=q.sum(1,keepdims=True);w=np.divide(q,den,out=np.full_like(q,1/J),where=den>0)
    co=np.array(co);mo=np.array(mo);ct,cu=old.project(S,co,v);mt,mu=old.project(S,mo,v);experts=np.stack([old.project(S,bank[:36,:,j],v)[0] for j in range(J)],2);chosen=int(np.argmin(np.sqrt(((experts-y[:36,:,None])**2).mean(0)).mean(0)));cb,cbu=old.project(S,bank[:,:,chosen],v)
    x=dict(raw=raw,truth=y,S=S,v=v,b=b,ub=ub,CovRaw=co,CovTarget=ct,CovU=cu,MLTarget=mt,MLU=mu,CalBest=cb,CalBestU=cbu,chosen=np.array(chosen),start=a['start'],cal_start=a['cal_start'])
    if part in ['early','late'] and ds!='AEMO' and bb!='DUET':
        src=oldsource(ds,bb,part,s)
        if reuse is not None:
            for key in ['v','b','ub','CovTarget','MLTarget']:np.testing.assert_allclose(x[key],reuse[key],rtol=1e-12,atol=2e-8)
        else:
            original=load(src);ctx=load(src.parent/'contexts.npz');ctl=load(src.parent/'controls.npz');np.testing.assert_array_equal(original['raw'],raw);np.testing.assert_array_equal(original['v'],v);np.testing.assert_allclose(ct,ctx['D'],rtol=1e-12,atol=2e-8);np.testing.assert_allclose(mt[36:],ctl['MLPol'],rtol=1e-12,atol=2e-8)
    np.savez_compressed(p,**x);js(d/'CONTEXT_READY.json',dict(sha256=sha(p),calibration_start=str(wide.index[cal]),score_start=str(wide.index[int(a['start'])]),observations=len(y)-36,chosen_expert=chosen,seconds=time.perf_counter()-tick,registration_sha256=sha(H/'REGISTRATION.json')));print('CONTEXT',ds,bb,s,part,flush=True);return x
def audit(x,p,u,reset=None,protected=False):
    n=len(x['v']);A=[F(0)]*n;globalA=[F(0)]*n;ever=set();events=env=active=outside=0;mid=None
    for j in range(len(p)):
        if reset is not None and j==reset:mid=[float(a) for a in A];A=[F(0)]*n
        for i,(b,z,y) in enumerate(zip(ns['exact'](x['b'][j+36]),ns['exact'](p[j]),ns['exact'](x['truth'][j+36]))):
            bound=z*z-RR*b*b if z>RR*b else RR*(z-b)**2/K;env+=int(bound>A[i]);active+=int(A[i]>RR*K*b*b);outside+=int(RR*(z-b)**2/K>A[i]);inc=RR*(b-y)**2-(z-y)**2;A[i]+=inc;globalA[i]+=inc
            if A[i]<0:ever.add(i);events+=1
            if protected:assert A[i]>=0 and globalA[i]>=0
    if u is not None:assert u.min()>=0 and np.allclose(p,u@x['S'].T,rtol=1e-8,atol=2e-6)
    if protected:assert p.min()>=0 and env==events==0
    return dict(node_dates=p.size,ever=len(ever),events=events,envelope_failures=env,active_node_dates=active,outside_real_node_dates=outside,mid_allowance=mid,final_allowance=[float(a) for a in A],max_coherence=float(abs(p-u@x['S'].T).max()) if u is not None else None)
def publish(x,target,rule,ds,reset=None,u=None):
    k=c.kernels('nonnegative');T=len(target);tick=time.perf_counter()
    if rule=='Cov':
        f=k['m5'] if ds=='M5' else k['cov'];tree=ast.parse(inspect.getsource(f));fn=tree.body[0];loop=next(z for z in fn.body if isinstance(z,ast.For));loop.body.insert(1,ast.parse('if __reset_at is not None and i==__reset_at: accounts=[Fraction(0) for _ in accounts]').body[0]);ast.fix_missing_locations(tree);g=dict(f.__globals__,__reset_at=reset);exec(compile(tree,'canonical_cov_reset_injection','exec'),g);out=g[fn.name](x,target,'CovFull' if ds=='M5' else 'Full');return out['pred'],out['witness'],out['stats'],time.perf_counter()-tick
    S=x['S'];qp=k['old'].SafeProjection(S,x['v']);A=[F(0)]*len(x['v']);ps=[];us=[];logs=[];mask=partition(S)
    if u is None:u=old.project(S,target,x['v'])[1]
    for j in range(T):
        if reset is not None and j==reset:A=[F(0)]*len(A)
        t=j+36;b=x['b'][t];bq=ns['exact'](b)
        if rule=='Common':p,w=ns['ray'](b,target[j],bq,A);rep=(1-w)*x['ub'][t]+w*u[j];info=dict(contraction=w)
        elif rule=='TwoGroup':p,rep,w,repair=grouped(S[:,mask],mask,b,x['ub'][t],target[j],u[j],A,bq,1/x['v'],ns,float(RR));info=dict(weights=w,repair=repair)
        else:p,rep,info=k['ml'](qp,S,b,x['ub'][t],target[j],A)
        assert k['certified'](b,p,A,RR,K);ps.append(p);us.append(rep);logs.append(info);A=ns['settle'](bq,ns['exact'](p),ns['exact'](x['truth'][t]),A)
    return np.array(ps),np.array(us),logs,time.perf_counter()-tick
def saved(d,name):
    p=d/(name+'.json')
    if not p.exists():return False
    assert sha(d/(name+'.npz'))==json.loads(p.read_text(encoding='utf8'))['sha256'];return True
def put(d,x,name,p,u=None,protected=False,reset=None,logs=None,seconds=None,reused=None):
    assert p.shape==x['truth'][36:].shape and np.isfinite(p).all();r=audit(x,p,u,reset,protected);a=dict(pred=p)
    if u is not None:a['witness']=u
    np.savez_compressed(d/(name+'.npz'),**a);js(d/(name+'.json'),dict(sha256=sha(d/(name+'.npz')),protected=protected,reset_at=reset,audit=r,seconds=seconds,reused=reused,logs=numeric(logs)))
def reuse_primary(ds,bb,s,part,name,x):
    if part not in ['early','late'] or ds=='AEMO' or bb=='DUET':return None
    src=oldsource(ds,bb,part,s)
    if ds=='Labour' and part=='early':
        p=src.parent/'results'/(name+'.npz')
        if p.exists():z=load(p);return z['pred'],z.get('witness'),str(p)
    if name=='CPOR-Cov':
        z=load(src.parent/'CovFullFix.npz');return z['pred'],z['witness'],str(src.parent/'CovFullFix.npz')
    if name in ['CPOR-ML','ProtectedCalBest']:
        z=load(src.parent/'controls.npz');field='ProtectedMLPol' if name=='CPOR-ML' else name;p=z[field];u=z.get('MLPolWitness' if name=='CPOR-ML' else 'CalBestWitness')
        if u is None:u=old.project(x['S'],p,x['v'])[1]
        return p,u,str(src.parent/'controls.npz')
    return None
def score(ds,bb,s,part,mode='single'):
    x=context(ds,bb,s,part);d=folder(ds,bb,s)/part/mode;d.mkdir(parents=True,exist_ok=True);reset=72 if mode=='reset' else None
    if (d/'CORE_DONE.json').exists():return
    for name,key,uk in [('Raw','raw',None),('NNLS','b','ub'),('CovTarget','CovTarget','CovU'),('MLTarget','MLTarget','MLU'),('CalBest','CalBest','CalBestU')]:
        if not saved(d,name):put(d,x,name,x[key][36:],x[uk][36:] if uk else None,name=='NNLS',reset)
    arms=[('CPOR-Cov','CovTarget','Cov'),('CPOR-ML','MLTarget','Full'),('ProtectedCalBest','CalBest','Full'),('CovCommon','CovTarget','Common'),('CovTwoGroup','CovTarget','TwoGroup'),('MLCommon','MLTarget','Common'),('MLTwoGroup','MLTarget','TwoGroup')]
    for name,key,rule in arms:
        if saved(d,name):continue
        reused=reuse_primary(ds,bb,s,part,name,x)
        if reused is not None:p,u,source=reused;put(d,x,name,p,u,True,reset,reused=source)
        else:p,u,logs,secs=publish(x,x[key][36:],rule,ds,reset);put(d,x,name,p,u,True,reset,logs,secs)
    W,C,lam,floor=legacy.cpu.classic.covariance(x['raw'][:36]-x['truth'][:36])
    for name in ['ProtectedWLSvar','ProtectedMinTshrink','ProtectedMinT_Cov','ProtectedRollingMinT']:
        if saved(d,name):continue
        shared=folder(ds,bb,s)/part/(name+'_SHARED_TARGET.npz')
        if shared.exists():
            zz=load(shared);z,u=zz['target'],zz['witness']
        elif name=='ProtectedRollingMinT':
            zz=[];uu=[]
            for t in range(36,len(x['truth'])):
                WW,*_=legacy.cpu.classic.covariance(x['raw'][t-36:t]-x['truth'][t-36:t]);p,u,_=legacy.cpu.classic.target(x['S'],x['raw'][t:t+1],WW);zz.append(p[0]);uu.append(u[0])
            z,u=np.array(zz),np.array(uu)
        else:
            target=x['CovRaw'] if name=='ProtectedMinT_Cov' else x['raw'];WW=legacy.cpu.classic.covariance(target[:36]-x['truth'][:36])[0] if name=='ProtectedMinT_Cov' else np.diag(np.maximum(np.diag(C),floor)) if name=='ProtectedWLSvar' else W;z,u,_=legacy.cpu.classic.target(x['S'],target[36:],WW)
        if not shared.exists():np.savez_compressed(shared,target=z,witness=u)
        p,u,logs,secs=publish(x,z,'Full',ds,reset,u);put(d,x,name,p,u,True,reset,logs,secs)
    js(d/'CORE_DONE.json',dict(dataset=ds,backbone=bb,seed=s,part=part,mode=mode));print('CORE_DONE',ds,bb,s,part,mode,flush=True)
def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--shard',type=int,default=0);ap.add_argument('--shards',type=int,default=1);a=ap.parse_args();verify()
    for ds,bb,s in jobs()[a.shard::a.shards]:
        if bb=='DUET':
            while not (folder(ds,bb,s)/'BASE_DONE.json').exists():time.sleep(5)
        for part in ['early','late']:score(ds,bb,s,part)
        for mode in ['reset','carry']:score(ds,bb,s,'continuous',mode)
        if ds=='AEMO' and bb=='DUET':score(ds,bb,s,'month','carry')
if __name__=='__main__':
    with threadpool_limits(1):main()
