from pathlib import Path
import json,hashlib,itertools
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent;E=H.parent/'cpor_unified_protocol_duet_20261108';D=H/'derived'
DS=['RH','ECommerce','Traffic','Wiki2','Labour','M5','AEMO'];BB=['PatchTST','DLinear','DUET']
def main():
    run=pd.read_csv(E/'summary/run_group_rmse.csv');run=run[run.protocol.isin(['window','continuous_carry','continuous_reset'])]
    assert (pd.read_csv(E/'summary/three_run_rmse.csv')['count']==3).all()
    keys=['dataset','backbone','seed','protocol','level'];wide=run.pivot(index=keys,columns='method',values='rmse').reset_index()
    comps=['Raw','NNLS','ProCAST','Ada-Y','PIR','ProtectedWLSvar','ProtectedMinTshrink','ProtectedRollingMinT','ProtectedMinT_Cov','ProtectedCalBest','ProtectedProCAST','ProtectedAda-Y','PIRFull']
    pairs=[]
    for r in wide.to_dict('records'):
        for m in ['CPOR-Cov','CPOR-ML']:
            for c in comps:
                pairs.append({**{k:r[k] for k in keys},'method':m,'comparator':c,'gain':100*(1-r[m]/r[c])})
    p=pd.DataFrame(pairs);p.to_csv(D/'PROCEDURE_PAIRS.csv',index=False)
    p.groupby(['dataset','backbone','protocol','level','method','comparator']).gain.agg(['mean','std','count']).reset_index().to_csv(D/'PROCEDURE_GROUPS.csv',index=False)
    p[p.level=='all'].groupby(['protocol','backbone','method','comparator']).gain.agg(['mean','min','max',lambda x:int(x.gt(0).groupby([p.loc[x.index,'dataset']]).mean().gt(.5).sum())]).reset_index().to_csv(D/'PROCEDURE_BACKBONES.csv',index=False)
    p[p.level=='all'].groupby(['protocol','method','comparator']).gain.agg(['mean','median','min','max']).reset_index().to_csv(D/'PROCEDURE_GLOBAL.csv',index=False)
    aud=pd.read_csv(E/'summary/protection_and_cost.csv');aud=aud[aud.protocol.isin(['window','continuous_carry'])].copy();length=aud.protocol.map({'window':72,'continuous_carry':144});aud['node_sequences']=aud.node_dates/length
    a=aud.groupby(['protocol','method'])[['node_sequences','node_dates','ever','events','envelope_failures']].sum().reset_index();a['ever_pct']=100*a.ever/a.node_sequences;a['event_pct']=100*a.events/a.node_dates;a.to_csv(D/'COMPLIANCE.csv',index=False)
    # Figure and cost comparisons use the same candidate and independent accounts.
    gains=pd.read_csv(E/'summary/paired_gains.csv');sel=gains[(gains.level=='all')&gains.protocol.isin(['window','continuous_carry'])&gains.comparator.isin(['CovTarget','MLTarget','PIRCoherent'])].copy();sel['cost']=-sel.gain_pct;sel.to_csv(D/'COST_PAIRS.csv',index=False)
    sel.groupby(['protocol','dataset','method']).cost.agg(['mean','median','min','max']).reset_index().to_csv(D/'COST_DATASETS.csv',index=False)
    sel.groupby(['protocol','method']).cost.agg(['mean','median','min','max']).reset_index().to_csv(D/'COST_GLOBAL.csv',index=False)
    figure=[]
    for proto in ['window','continuous_carry']:
      for ds in DS:
        for m,c in [('CPOR-Cov','CovTarget'),('CPOR-ML','MLTarget')]:
            x=aud[(aud.protocol==proto)&(aud.dataset==ds)&(aud.method==c)];y=aud[(aud.protocol==proto)&(aud.dataset==ds)&(aud.method==m)];v=sel[(sel.protocol==proto)&(sel.dataset==ds)&(sel.method==m)].cost.mean()
            figure.append(dict(protocol=proto,dataset=ds,method=m,before_pct=100*x.ever.sum()/x.node_sequences.sum(),after_pct=100*y.ever.sum()/y.node_sequences.sum(),cost_pct=v))
    pd.DataFrame(figure).to_csv(D/'FIGURE2_DATA.csv',index=False)
    # Retrospective uncertainty analysis, preserving the earlier dataset-cluster rule.
    matched=gains[gains.level=='all'].rename(columns={'gain_pct':'gain'})
    boot=np.array(list(itertools.product(range(7),repeat=7)),dtype=np.uint8);sign=np.array(list(itertools.product([-1,1],repeat=7)),dtype=np.int8);stats=[];effects=[]
    for proto in ['window','continuous_carry']:
      families=[('complete',[(m,c) for m in ['CPOR-Cov','CPOR-ML'] for c in ['NNLS','ProCAST','PIR']]),('matched_PIR',[('PIRFull','PIRCommon'),('PIRFull','PIRTwoGroup')])]
      for fam,tests in families:
        current=[]
        for m,c in tests:
            df=(p if fam=='complete' else matched);df=df[(df.protocol==proto)&(df.level=='all')&(df.method==m)&(df.comparator==c)];eff=df.groupby('dataset').gain.mean().reindex(DS).to_numpy();assert np.isfinite(eff).all();b=eff[boot].mean(1);ci=np.quantile(b,[.025,.975],method='linear');obs=float(eff.mean());pv=float(np.mean(abs((sign*eff).mean(1))>=abs(obs)-1e-12));loo=np.array([np.delete(eff,i).mean() for i in range(7)])
            row=dict(protocol=proto,family=fam,method=m,comparator=c,mean=obs,lower=ci[0],upper=ci[1],p=pv,loo_min=loo.min(),loo_max=loo.max());current.append(row)
            effects.extend(dict(protocol=proto,family=fam,method=m,comparator=c,dataset=ds,gain=float(v)) for ds,v in zip(DS,eff))
        order=np.argsort([r['p'] for r in current]);mx=0.
        for k,i in enumerate(order):mx=max(mx,(len(order)-k)*current[i]['p']);current[i]['holm']=min(1.,mx)
        stats.extend(current)
    pd.DataFrame(stats).to_csv(D/'CURRENT_UNCERTAINTY.csv',index=False);pd.DataFrame(effects).to_csv(D/'DATASET_EFFECTS.csv',index=False)
    (D/'STATISTICAL_SCOPE.json').write_text(json.dumps(dict(retrospective=True,datasets=7,bootstrap='All7^7=823543 dataset resamples; linear-interpolated empirical percentiles.',sign_flip='All2^7=128 signs; independent symmetric dataset effects under null.',families='Six complete-procedure contrasts per protocol; two matched-PIR contrasts per protocol. Families are adjusted separately.',new_forecasting_experiments=0),indent=2),encoding='utf8')
    idx={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in D.glob('*') if p.is_file() and p.name!='DERIVED_HASHES.json'};(D/'DERIVED_HASHES.json').write_text(json.dumps(idx,indent=2),encoding='utf8');print('AGGREGATED',len(pairs),len(stats),flush=True)
if __name__=='__main__':main()
