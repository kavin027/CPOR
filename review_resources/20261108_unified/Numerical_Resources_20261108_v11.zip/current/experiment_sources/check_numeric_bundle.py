from pathlib import Path
import json,hashlib,argparse
import numpy as np,pandas as pd
from unified_checks import exact_check
from unified_analysis import masks

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--audit',action='store_true');args=ap.parse_args();root=Path(__file__).resolve().parent;idx=json.loads((root/'summary/RESULT_INDEX.json').read_text(encoding='utf8'));expected=pd.read_csv(root/'summary/run_window_rmse.csv');want=expected.set_index(['dataset','backbone','seed','protocol','window','method','level']).rmse;count=0;contexts={}
    manifest=root/'BUNDLE_MANIFEST.json'
    if manifest.exists():
        for p,digest in json.loads(manifest.read_text(encoding='utf8')).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest,p
    for r in idx:
        p=root/r['path'].replace('\\','/');assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];ds,bb,s,part,mode=p.relative_to(root).parts[1:6];protocol='window' if part in ['early','late'] else f'{part}_{mode}';cp=p.parent.parent/'context.npz'
        if cp not in contexts:
            with np.load(cp,allow_pickle=False) as z:contexts[cp]={k:z[k] for k in ['truth','b','S','v']}
        x=contexts[cp]
        with np.load(p,allow_pickle=False) as z:pred=z['pred'];u=z['witness'] if 'witness' in z.files else None
        rmse=np.sqrt(((pred-x['truth'][36:])**2).mean(0))
        for level,mask in masks(ds,len(rmse)).items():np.testing.assert_allclose(float(rmse[mask].mean()),want.loc[(ds,bb,int(s),protocol,part,p.stem,level)],rtol=1e-12,atol=1e-10)
        if args.audit:
            rec=json.loads(p.with_suffix('.json').read_text(encoding='utf8'));got=exact_check(x,pred,rec['reset_at'])
            for k in ['ever','events','envelope_failures']:assert got[k]==rec['audit'][k],(p,k)
            if rec['protected']:assert all(v==0 for v in got.values()) and pred.min()>=0
            if u is not None:assert u.min()>=0 and np.allclose(pred,u@x['S'].T,rtol=1e-8,atol=2e-6)
        count+=1
    assert count==6375
    month=pd.read_csv(root/'summary/aemo_month_run_rmse.csv').set_index(['backbone','seed','method','level']).rmse
    old_count=0
    for r in json.loads((root/'RETAINED_MONTH_INDEX.json').read_text(encoding='utf8')):
        p=root/r['bundle_path'];cp=root/r['context_bundle_path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
        with np.load(cp,allow_pickle=False) as a:x={k:a[k] for k in ['truth','b','S','v']}
        with np.load(p,allow_pickle=False) as a:pred=a['pred']
        rmse=np.sqrt(((pred-x['truth'][36:])**2).mean(0))
        for level,mask in masks('AEMO',6).items():np.testing.assert_allclose(float(rmse[mask].mean()),month.loc[(r['backbone'],r['seed'],r['method'],level)],rtol=1e-12,atol=1e-10)
        if args.audit:
            got=exact_check(x,pred)
            for k in ['ever','events','envelope_failures']:assert got[k]==r['exact_audit'][k]
            if r['protected']:assert all(v==0 for v in got.values())
        old_count+=r['backbone']!='DUET'
    assert old_count==138
    print('NUMERIC_BUNDLE_PASS',count,'new arrays plus',old_count,'retained month arrays; exact protection replay='+str(args.audit),flush=True)

if __name__=='__main__':main()
