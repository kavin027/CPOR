from unified_common import *
import random,time,logging
os.environ['CUDA_CACHE_PATH']=str(H/'cuda_cache');os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
sys.path[:0]=[str(DUET/'DUET'),str(O/'cpor_external_20261105/deps')]
import torch
from ts_benchmark.baselines.duet.duet import DUET as Model
SETTINGS=dict(seq_len=24,horizon=12,norm=True,d_model=64,d_ff=128,hidden_size=64,e_layers=1,n_heads=1,num_experts=2,k=1,lr=.0005,lradj='type1',loss='MAE',batch_size=16,num_epochs=100,patience=5)
def seed(v):random.seed(v);np.random.seed(v);torch.manual_seed(v);torch.cuda.manual_seed_all(v)
class Logged(Model):
    def validate(self,*a):
        x=super().validate(*a);self.validation.append(float(x));return x
def fitted(wide,ds,s,cut,name,reuse=None):
    d=folder(ds,'DUET',s)/'fits'/name;d.mkdir(parents=True,exist_ok=True);p=d/'model.pt'
    if reuse is not None:
        receipt=json.loads((reuse/'complete.json').read_text(encoding='utf8'));assert receipt['fit_end_exclusive']==cut and receipt['seed']==s and sha(reuse/'model.pt')==receipt['model_sha256'];saved=torch.load(reuse/'model.pt',map_location='cpu',weights_only=False);m=Model(**SETTINGS);m.multi_forecasting_hyper_param_tune(wide.iloc[:cut]);m.model=m._init_model();m.check_point=saved['state_dict'];m.scaler.fit(wide.iloc[:receipt['train_rows']].values);np.testing.assert_array_equal(m.scaler.mean_,saved['mean']);np.testing.assert_array_equal(m.scaler.scale_,saved['scale_'] if 'scale_' in saved else saved['scale']);js(d/'REUSED.json',dict(source=str(reuse),model_sha256=receipt['model_sha256'],fit_end_exclusive=cut));return m
    if (d/'fit.json').exists():
        rec=json.loads((d/'fit.json').read_text(encoding='utf8'));assert sha(p)==rec['model_sha256'];saved=torch.load(p,map_location='cpu',weights_only=False);m=Model(**SETTINGS);m.multi_forecasting_hyper_param_tune(wide.iloc[:cut]);m.model=m._init_model();m.check_point=saved['state_dict'];m.scaler.fit(wide.iloc[:rec['train_rows']].values);return m
    seed(s);m=Logged(**SETTINGS);m.validation=[];tick=time.perf_counter();print('FIT_START',ds,s,name,cut,flush=True);m.forecast_fit(wide.iloc[:cut],train_ratio_in_tv=.8)
    assert m.check_point is not None and np.isfinite(m.validation).all();torch.save(dict(state_dict=m.check_point,mean=m.scaler.mean_,scale=m.scaler.scale_),p)
    js(d/'fit.json',dict(seed=s,settings=SETTINGS,fit_end_exclusive=cut,train_rows=int(.8*cut),last_fit_label=str(wide.index[cut-1]),validation=m.validation,best_epoch=int(np.argmin(m.validation))+1,stopping_epochs=len(m.validation),seconds=time.perf_counter()-tick,model_sha256=sha(p),data_sha256=sha(datafile(ds))))
    print('FIT_DONE',ds,s,name,len(m.validation),flush=True);return m
def forecast(m,wide,s,begin,end):
    assert (end-begin)%12==0;out=[]
    for i in range(begin,end,12):
        seed(s+i);p=m.forecast(12,wide.iloc[i-24:i]);assert p.shape==(12,wide.shape[1]) and np.isfinite(p).all();out.append(p.astype('float64'))
    return np.concatenate(out)
def run(ds,s):
    verify();torch.set_num_threads(1);wide,early,late=starts(ds);wide.index.name='date';d=folder(ds,'DUET',s);d.mkdir(parents=True,exist_ok=True)
    if (d/'BASE_DONE.json').exists():return
    if ds=='AEMO':
        old=load(O/'cpor_aemo_full_three_runs_20261107/runs/PatchTST/42/models/PatchTST/raw.npz');begin=int(old['begin']);S=old['S'];m=fitted(wide,ds,s,begin,'month');raw=forecast(m,wide,s,begin,len(wide));np.savez_compressed(d/'month.npz',raw=raw,truth=wide.iloc[begin:].to_numpy(),S=S,begin=begin,start=int(old['start']),dates=wide.index[begin:].astype(str).to_numpy(dtype='U'))
        for name,start in [('early',early),('late',late)]:np.savez_compressed(d/(name+'.npz'),raw=raw[start-36-begin:start+72-begin],truth=wide.iloc[start-36:start+72].to_numpy(),S=S,start=start,cal_start=start-36)
        del m
    else:
        S=load(DUET/'streams'/ds/('late.npz' if ds=='Labour' else 'early.npz'))['S']
        for name,start in [('early',early),('late',late)]:
            path=d/(name+'.npz');src=DUET/'streams'/ds/(name+'.npz')
            if path.exists():continue
            if s==2021 and src.exists():
                x=load(src);assert int(x['start'])==start;np.savez_compressed(path,**x,truth=wide.iloc[start-36:start+72].to_numpy());js(d/(name+'_REUSE.json'),dict(source=str(src),sha256=sha(src)));print('STREAM_REUSE',ds,s,name,flush=True);continue
            cut=(start-36 if ds=='Labour' else early-36);reuse=(DUET/'streams'/ds if s==2021 and (ds!='Labour' or name=='late') else None)
            m=fitted(wide,ds,s,cut,'late' if ds=='Labour' and name=='late' else 'main',reuse)
            raw=forecast(m,wide,s,start-36,start+72);np.savez_compressed(path,raw=raw,truth=wide.iloc[start-36:start+72].to_numpy(),S=S,start=start,cal_start=start-36);del m;torch.cuda.empty_cache()
    js(d/'BASE_DONE.json',dict(dataset=ds,seed=s,streams={w:sha(d/(w+'.npz')) for w in ['early','late']},registration_sha256=sha(H/'REGISTRATION.json')));print('BASE_DONE',ds,s,flush=True)
if __name__=='__main__':
    logging.getLogger().setLevel(logging.ERROR)
    for ds in DS:
      for s in DUET_SEEDS:run(ds,s)
