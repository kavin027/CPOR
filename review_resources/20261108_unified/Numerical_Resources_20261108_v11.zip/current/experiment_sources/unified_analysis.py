from unified_common import *
import argparse

METHODS=json.loads((H/'REGISTRATION.json').read_text(encoding='utf8'))['methods']

def masks(ds,n):
    local=H/'node_map.csv';z=pd.read_csv(local if local.exists() else O/'kais_review_v2_revision_20261017/Online_Resource_3/review_evidence/node_map.csv')
    out={'all':np.ones(n,dtype=bool)}
    if ds=='AEMO':return dict(all=out['all'],system=np.arange(n)==0,region=np.arange(n)>0)
    sub=z[z.dataset==ds]
    for level in ['system','region','bottom','middle','state','store']:
        ix=[int(r.node) for r in sub.itertuples() if level in str(r.scopes).split(';')]
        if ix:
            out[level]=np.isin(np.arange(n),ix)
    if 'system' in out:out['non_system_observed']=~out['system']
    # ECommerce has overlapping observed aggregates, with no separately observed
    # system total or bottom series. Never fabricate a system-level metric.
    if 'bottom' in out and 'system' in out:
        mid=~(out['bottom']|out['system'])
        if mid.any():out['intermediate_observed']=mid
    return out

def stages(ds,bb,s):
    return [('early','single'),('late','single'),('continuous','reset'),('continuous','carry')]+([('month','carry')] if ds=='AEMO' and bb=='DUET' else [])

def build(partial=False,core_only=False):
    verify();rows=[];node_rows=[];audits=[];receipts=[];comparisons=[];complete=0
    methods=METHODS[:16] if core_only else METHODS
    for ds,bb,s in jobs():
        f=folder(ds,bb,s)
        for part,mode in stages(ds,bb,s):
            d=f/part/mode
            if not (d/('CORE_DONE.json' if core_only else 'ALL_DONE.json')).exists():
                if partial:continue
                raise AssertionError(f'Incomplete stage: {d}')
            complete+=1;x=load(f/part/'context.npz');y=x['truth'][36:];b=x['b'][36:];base=(b-y)**2;levels=masks(ds,y.shape[1]);protocol='window' if part in ['early','late'] else f'{part}_{mode}'
            for name in methods:
                p=d/(name+'.npz');rec=json.loads(p.with_suffix('.json').read_text(encoding='utf8'));assert sha(p)==rec['sha256'];z=load(p)['pred'];assert z.shape==y.shape;err=(z-y)**2;rmse=np.sqrt(err.mean(0))
                for level,mask in levels.items():
                    rows.append(dict(dataset=ds,backbone=bb,seed=s,protocol=protocol,window=part,method=name,level=level,rmse=float(rmse[mask].mean())))
                for i,r in enumerate(rmse):node_rows.append(dict(dataset=ds,backbone=bb,seed=s,protocol=protocol,window=part,method=name,node=i,rmse=r))
                a=rec['audit'];audits.append(dict(dataset=ds,backbone=bb,seed=s,protocol=protocol,window=part,method=name,protected=rec['protected'],node_dates=a['node_dates'],ever=a['ever'],events=a['events'],envelope_failures=a['envelope_failures'],large_credit_branch_fraction=a['active_node_dates']/a['node_dates'],outside_allreal_fraction=a['outside_real_node_dates']/a['node_dates'],coherence_max=a['max_coherence'],seconds=rec['seconds'],reused=rec['reused']))
                if rec['protected']:assert a['ever']==a['events']==a['envelope_failures']==0
                receipts.append(dict(path=p.relative_to(H).as_posix(),sha256=rec['sha256']))
                if part=='continuous':
                    for half,sl in [('early',slice(0,72)),('late',slice(72,144))]:
                        rr=np.sqrt(err[sl].mean(0));br=np.sqrt(base[sl].mean(0));cum=np.cumsum(err[sl],0);cb=np.cumsum(base[sl],0);viol=cum>float(40401/40000)*cb+1e-10*np.maximum(1,cb)
                        for level,mask in levels.items():
                            comparisons.append(dict(dataset=ds,backbone=bb,seed=s,mode=mode,method=name,half=half,level=level,rmse=float(rr[mask].mean()),nnls_rmse=float(br[mask].mean()),standalone_half_ever=int(viol[:,mask].any(0).sum()),nodes=int(mask.sum()),boundary_credit_sum=float((40401/40000*base[:72].sum(0)-err[:72].sum(0))[mask].sum())))
    out=H/('core_summary' if core_only else 'partial' if partial else 'summary');out.mkdir(exist_ok=True)
    df=pd.DataFrame(rows);df.to_csv(out/'run_window_rmse.csv',index=False)
    pd.DataFrame(node_rows).to_csv(out/'node_rmse.csv',index=False)
    pd.DataFrame(audits).to_csv(out/'protection_and_cost.csv',index=False)
    pd.DataFrame(comparisons).to_csv(out/'continuous_halves.csv',index=False)
    js(out/'RESULT_INDEX.json',receipts)
    # For independent windows first average their two RMSEs, then aggregate runs.
    run=df.groupby(['dataset','backbone','seed','protocol','method','level'],as_index=False).rmse.mean()
    run.to_csv(out/'run_group_rmse.csv',index=False)
    group=run.groupby(['dataset','backbone','protocol','method','level']).rmse.agg(['mean','std','count']).reset_index();group.to_csv(out/'three_run_rmse.csv',index=False)
    pairs=[]
    for (ds,bb,s,protocol,level),g in run.groupby(['dataset','backbone','seed','protocol','level']):
        q=g.set_index('method').rmse.to_dict()
        for method,comp in [('CPOR-Cov','ProCAST'),('CPOR-ML','ProCAST'),('CPOR-Cov','PIR'),('CPOR-ML','PIR'),('CPOR-Cov','CovTarget'),('CPOR-ML','MLTarget'),('CPOR-Cov','CovCommon'),('CPOR-ML','MLCommon'),('CPOR-Cov','CovTwoGroup'),('CPOR-ML','MLTwoGroup'),('PIRFull','PIRCommon'),('PIRFull','PIRTwoGroup'),('PIRFull','PIRCoherent')]:
            if method in q and comp in q and q[comp]>0:pairs.append(dict(dataset=ds,backbone=bb,seed=s,protocol=protocol,level=level,method=method,comparator=comp,gain_pct=100*(1-q[method]/q[comp])))
    pair=pd.DataFrame(pairs);pair.to_csv(out/'paired_gains.csv',index=False)
    if len(pair):pair.groupby(['dataset','backbone','protocol','level','method','comparator']).gain_pct.agg(['mean','std','count']).reset_index().to_csv(out/'three_run_gains.csv',index=False)
    cont=run[run.protocol.isin(['continuous_carry','continuous_reset'])].pivot(index=['dataset','backbone','seed','method','level'],columns='protocol',values='rmse').dropna().reset_index()
    if len(cont):
        cont['carry_gain_pct']=100*(1-cont.continuous_carry/cont.continuous_reset);cont.to_csv(out/'carry_vs_reset.csv',index=False);cont.groupby(['dataset','backbone','method','level']).carry_gain_pct.agg(['mean','std','count']).reset_index().to_csv(out/'three_run_carry_gain.csv',index=False)
    js(out/'COMPLETENESS.json',dict(completed=complete,expected=255,methods=len(methods),result_arrays=len(receipts),partial=partial,core_only=core_only,aggregation='Independent: arithmetic mean of two window RMSEs within run. Continuous: RMSE computed directly from all144 observations. Then mean/sampleSD over3 runs. Paired percentages are computed before averaging runs. Seven datasets and three backbones receive equal weight in grand summaries. Half-window ratio diagnostics use floating-point thresholds and do not replace exact whole-prefix certificates.',training_runs_are_not_independent_datasets=True))
    print('SUMMARY',complete,len(receipts),out,flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');ap.add_argument('--core-only',action='store_true');args=ap.parse_args();build(args.partial,args.core_only)
