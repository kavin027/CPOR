"""Rebuild current aggregate arithmetic; optional stored-array replay only."""
from pathlib import Path
import argparse,json,hashlib,itertools,subprocess,sys,zipfile
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent
def same(a,b):np.testing.assert_allclose(a,b,rtol=1e-11,atol=1e-10,equal_nan=True)
def main():
    ap=argparse.ArgumentParser();args=ap.parse_args();data=H/'data';derived=H/'derived'
    manifest=H.parent/'CURRENT_FILE_HASHES.json'
    if manifest.exists():
        for rel,digest in json.loads(manifest.read_text(encoding='utf8')).items():assert hashlib.sha256((H.parent/rel).read_bytes()).hexdigest()==digest,rel
    rw=pd.read_csv(data/'run_window_rmse.csv');rg=pd.read_csv(data/'run_group_rmse.csv');g=pd.read_csv(data/'three_run_rmse.csv');keys=['dataset','backbone','seed','protocol','method','level'];r=rw.groupby(keys).rmse.mean().sort_index();same(r.to_numpy(),rg.set_index(keys).rmse.sort_index().to_numpy())
    keys3=['dataset','backbone','protocol','method','level'];z=rg.groupby(keys3).rmse.agg(['mean','std','count']).sort_index();g=g.set_index(keys3).sort_index();same(z[['mean','std','count']],g[['mean','std','count']]);assert (g['count']==3).all()
    base=rg[rg.level=='all'].pivot(index=['dataset','backbone','seed','protocol'],columns='method',values='rmse').reset_index();actual=[];effects=[]
    for proto in ['window','continuous_carry']:
        b=base[base.protocol==proto];assert len(b)==63
        for target,m,c,t,d in [('Cov','CPOR-Cov','CovCommon','CovTwoGroup','CovTarget'),('ML','CPOR-ML','MLCommon','MLTwoGroup','MLTarget'),('PIR','PIRFull','PIRCommon','PIRTwoGroup','PIRCoherent')]:
            actual.append(dict(protocol=proto,candidate=target,common_gain=float((100*(1-b[m]/b[c])).mean()),two_group_gain=float((100*(1-b[m]/b[t])).mean()),protection_cost=float((100*(b[m]/b[d]-1)).mean())))
        for m in ['CPOR-Cov','CPOR-ML']:
          for c in ['NNLS','ProCAST','PIR']:
            q=b.assign(gain=100*(1-b[m]/b[c])).groupby('dataset').gain.mean()
            effects.extend(dict(protocol=proto,family='complete',method=m,comparator=c,dataset=ds,gain=v) for ds,v in q.items())
        for c in ['PIRCommon','PIRTwoGroup']:
            q=b.assign(gain=100*(1-b.PIRFull/b[c])).groupby('dataset').gain.mean();effects.extend(dict(protocol=proto,family='matched_PIR',method='PIRFull',comparator=c,dataset=ds,gain=v) for ds,v in q.items())
    a=pd.DataFrame(actual).set_index(['protocol','candidate']).sort_index();want=pd.read_csv(derived/'TABLE8_SUMMARY.csv').set_index(['protocol','candidate']).sort_index();same(a,want)
    eff=pd.DataFrame(effects).set_index(['protocol','family','method','comparator','dataset']).sort_index();want=pd.read_csv(derived/'DATASET_EFFECTS.csv').set_index(['protocol','family','method','comparator','dataset']).sort_index();same(eff.gain,want.gain)
    signs=np.array(list(itertools.product([-1,1],repeat=7)));boot=np.array(list(itertools.product(range(7),repeat=7)),dtype=np.uint8);stats=pd.read_csv(derived/'CURRENT_UNCERTAINTY.csv');out=[]
    for row in stats.to_dict('records'):
        v=eff.loc[(row['protocol'],row['family'],row['method'],row['comparator'])].gain.to_numpy();assert len(v)==7;ci=np.quantile(v[boot].mean(1),[.025,.975],method='linear');p=float(np.mean(abs((signs*v).mean(1))>=abs(v.mean())-1e-12));same([v.mean(),*ci,p],[row['mean'],row['lower'],row['upper'],row['p']]);out.append({**row,'recomputed_p':p})
    for (proto,fam),df in pd.DataFrame(out).groupby(['protocol','family']):
        so=df.sort_values('recomputed_p');adj=np.maximum.accumulate(so.recomputed_p.to_numpy()*np.arange(len(so),0,-1));same(np.minimum(1,adj),so.holm)
    pa=pd.read_csv(data/'protection_and_cost.csv');p=pa[pa.protected];assert p['ever'].sum()==p.events.sum()==p.envelope_failures.sum()==0;assert len(p)==4335 and p.node_dates.sum()==35750592
    # Verify costs in their stated run-level unit, not medians of grouped means.
    costs=pd.read_csv(derived/'COST_GLOBAL.csv')
    for rr in costs.to_dict('records'):
        b=base[base.protocol==rr['protocol']];co={'CPOR-Cov':'CovTarget','CPOR-ML':'MLTarget','PIRFull':'PIRCoherent'}[rr['method']];v=100*(b[rr['method']]/b[co]-1);same([v.mean(),v.median(),v.min(),v.max()],[rr['mean'],rr['median'],rr['min'],rr['max']])
    print('CURRENT_TABLES_PASS: seven datasets;three backbones;three runs; window/continuous arithmetic,Table8,costs,dataset-cluster statistics and reported compliance counts. No optimizer/model execution.',flush=True)
if __name__=='__main__':main()
