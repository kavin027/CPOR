"""Self-contained checks for compact OR2; no training or optimizer execution."""
from pathlib import Path
import hashlib,json,subprocess,sys
import pandas as pd
import numpy as np
H=Path(__file__).resolve().parent

def main():
    for rel,r in json.loads((H/'MANIFEST.json').read_text(encoding='utf8'))['files'].items():
        assert hashlib.sha256((H/rel).read_bytes()).hexdigest()==r['sha256'],rel
    for cmd in [[sys.executable,str(H/'current/check_tables.py')],[sys.executable,str(H/'supplement/check_supplement_results.py')],[sys.executable,str(H/'supplement/check_li_levels.py')]]:
        subprocess.run(cmd,check=True,cwd=H)
    node=pd.read_csv(H/'process/NODE_RMSE.csv');mapping=pd.read_csv(H/'process/NODE_MAP.csv');assign=[]
    for ds,g in mapping.groupby('dataset'):
        ids=set(g.node.astype(int));scopes={'all':ids}
        if ds=='AEMO':scopes.update(system={0},region=ids-{0})
        else:
            for lev in ['system','region','bottom','middle','state','store']:
                q={int(r.node) for r in g.itertuples() if lev in str(r.scopes).split(';')}
                if q:scopes[lev]=q
            if 'system' in scopes:scopes['non_system_observed']=ids-scopes['system']
            if 'system' in scopes and 'bottom' in scopes:
                q=ids-scopes['system']-scopes['bottom']
                if q:scopes['intermediate_observed']=q
        for lev,ix in scopes.items():assign.extend((ds,i,lev) for i in ix)
    expanded=node.merge(pd.DataFrame(assign,columns=['dataset','node','level']),on=['dataset','node'],validate='many_to_many')
    keys=['dataset','backbone','seed','protocol','window','method','level']
    vals=expanded.groupby(keys).rmse.mean().sort_index()
    stored=pd.read_csv(H/'current/data/run_window_rmse.csv').set_index(keys).rmse.sort_index()
    assert vals.index.equals(stored.index)
    np.testing.assert_allclose(vals,stored,rtol=1e-12,atol=1e-9)
    audit=pd.read_csv(H/'process/RELEASE_CHECKS.csv').set_index(keys[:-1]).sort_index()
    cost=pd.read_csv(H/'current/data/protection_and_cost.csv').set_index(keys[:-1]).sort_index()
    assert audit.index.equals(cost.index)
    for col in ['node_dates','ever','events','envelope_failures']:
        np.testing.assert_array_equal(audit[col].to_numpy(),cost[col].to_numpy())
    assert (audit['protected'].to_numpy()==cost['protected'].to_numpy()).all()
    month=pd.read_csv(H/'current/data/aemo_month_run_rmse.csv')
    mk=['backbone','method','level']
    ms=month.groupby(mk).rmse.agg(['mean','std','count']).sort_index()
    mw=pd.read_csv(H/'current/data/aemo_month_three_run_rmse.csv').set_index(mk).sort_index()
    assert ms.index.equals(mw.index)
    np.testing.assert_allclose(ms,mw[['mean','std','count']],rtol=1e-12,atol=1e-9)
    mn=pd.read_csv(H/'process/MONTH_NODE_RMSE_WITH_PIR.csv');wanted=month.set_index(['backbone','seed','method','level']).rmse
    mc=0
    for key,g in mn.groupby(['backbone','seed','method']):
        for lev,q in [('all',g),('system',g[g.node==0]),('region',g[g.node>0])]:
            np.testing.assert_allclose(q.rmse.mean(),wanted.loc[key+(lev,)],rtol=1e-12,atol=1e-9);mc+=1
    result={'passed':True,'node_error_records':len(node),'recomputed_level_records':len(vals),'stored_release_checks':len(audit),'aemo_month_group_statistics':len(ms),'aemo_month_node_to_level_checks':mc,'aggregation_statistics_and_Li_checks':True,'scope':'Stored result arithmetic, node-to-level aggregation and recorded release-check summaries. No raw-prediction exact replay, training or release-policy execution.'}
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
